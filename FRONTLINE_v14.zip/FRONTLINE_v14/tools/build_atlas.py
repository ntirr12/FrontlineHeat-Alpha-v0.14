#!/usr/bin/env python3
"""
PEMBANGUN ATLAS FRONTLINE
=========================
Menggabungkan ratusan PNG kecil menjadi 2-3 gambar besar (atlas) supaya Godot bisa menggambar
semuanya dengan hanya beberapa draw-call. Ini optimasi terpenting untuk HP lowend.

Pemakaian (dari folder proyek):
    python tools/build_atlas.py                       # pakai sumber di art_src/
    python tools/build_atlas.py --assets ../frontline_assets      # pakai paket aset asli
    python tools/build_atlas.py --assets ../frontline_assets --collect   # + salin sumber ke art_src/
Butuh:  pip install pillow numpy
Setelah selesai, buka proyek di Godot sekali (impor otomatis) lalu jalankan game.
"""
import argparse, json, shutil, sys
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))
from atlas_spec import SPRITES  # noqa: E402

PAD = 2                                  # jarak aman antar sprite (cegah "bocor" saat filter linear)
TEAM_RGB = {1: (64, 140, 255), 2: (255, 77, 77)}          # biru (pemain) dan merah (musuh)
SIZES = [256, 512, 1024, 1536, 2048]      # v14: 1536 ditambah agar atlas tidak melompat 1024 -> 2048 (hemat 2 MB VRAM)
DEFAULT_UP = {"units": 2, "fx": 1, "ui": 1}


# ------------------------------------------------------------------ gambar
def bake_team(im: Image.Image, team: int) -> tuple[Image.Image, int]:
    """Ganti piksel hijau-murni (0,~168,0) menjadi warna tim. Mengembalikan (gambar, jumlah piksel)."""
    a = np.array(im.convert("RGBA"))
    r, g, b, al = a[..., 0].astype(int), a[..., 1].astype(int), a[..., 2].astype(int), a[..., 3]
    m = (al > 0) & (r <= 40) & (b <= 40) & (g >= 80)
    n = int(m.sum())
    if n:
        lum = np.clip(g[m] / 168.0, 0.35, 1.25)
        for i, ch in enumerate(TEAM_RGB[team]):
            a[..., i][m] = np.clip(ch * lum, 0, 255).astype(np.uint8)
    return Image.fromarray(a, "RGBA"), n


def erase_marks(im: Image.Image, rects: list) -> Image.Image:
    """Hapus tulisan/tanda tangan kecil: piksel gelap di dalam kotak diganti warna rata-rata sekitarnya."""
    a = np.array(im.convert("RGBA"))
    for x, y, w, h in rects:
        reg = a[y:y + h, x:x + w]
        lum = reg[..., :3].mean(-1)
        dark = lum < np.median(lum) * 0.55          # teks jauh lebih gelap dari lambung (median)
        if dark.any() and (~dark).any():
            reg[dark, :3] = np.median(reg[~dark][:, :3], axis=0).astype(np.uint8)
    return Image.fromarray(a, "RGBA")


def tint_image(im: Image.Image, rgb: tuple, amount: float) -> Image.Image:
    """Campur warna piksel (yang tidak transparan) dengan `rgb` sebesar `amount` (0..1). Untuk varian salju."""
    a = np.array(im.convert("RGBA")).astype(float)
    m = a[..., 3] > 0
    for i, ch in enumerate(rgb):
        a[..., i][m] = a[..., i][m] * (1 - amount) + ch * amount
    return Image.fromarray(a.astype(np.uint8), "RGBA")


def extrude(im: Image.Image, pad: int) -> Image.Image:
    a = np.array(im)
    a = np.pad(a, ((pad, pad), (pad, pad), (0, 0)), mode="edge")
    return Image.fromarray(a, "RGBA")


def centroid(im: Image.Image) -> tuple[float, float]:
    a = np.array(im)[..., 3].astype(float)
    tot = a.sum()
    if tot <= 0:
        return im.width / 2.0, im.height / 2.0
    ys, xs = np.mgrid[0:a.shape[0], 0:a.shape[1]]
    return float((xs * a).sum() / tot) + 0.5, float((ys * a).sum() / tot) + 0.5


# ------------------------------------------------------------------ pengepak MaxRects
class MaxRects:
    def __init__(self, w: int, h: int):
        self.free = [(0, 0, w, h)]

    def insert(self, w: int, h: int):
        best, best_s = None, (10**9, 10**9)
        for fx, fy, fw, fh in self.free:
            if w <= fw and h <= fh:
                s = (min(fw - w, fh - h), max(fw - w, fh - h))
                if s < best_s:
                    best_s, best = s, (fx, fy)
        if best is None:
            return None
        x, y = best
        new = []
        for fx, fy, fw, fh in self.free:
            if x >= fx + fw or x + w <= fx or y >= fy + fh or y + h <= fy:
                new.append((fx, fy, fw, fh))
                continue
            if x > fx: new.append((fx, fy, x - fx, fh))
            if x + w < fx + fw: new.append((x + w, fy, fx + fw - (x + w), fh))
            if y > fy: new.append((fx, fy, fw, y - fy))
            if y + h < fy + fh: new.append((fx, y + h, fw, fy + fh - (y + h)))
        self.free = [r for i, r in enumerate(new)
                     if not any(j != i and _inside(r, o) for j, o in enumerate(new))]
        return x, y


def _inside(a, b) -> bool:
    return a[0] >= b[0] and a[1] >= b[1] and a[0] + a[2] <= b[0] + b[2] and a[1] + a[3] <= b[1] + b[3]


def pack(items: list[dict]):
    """items: [{key, img(+pad)}]. Mencari atlas terkecil yang muat. Return (W, H, {key: (x, y)})."""
    order = sorted(items, key=lambda it: -max(it["img"].size))
    cands = sorted(((w, h) for w in SIZES for h in SIZES), key=lambda s: (s[0] * s[1], max(s)))
    area = sum(it["img"].width * it["img"].height for it in items)
    for W, H in cands:
        if W * H < area:
            continue
        mr, pos, ok = MaxRects(W, H), {}, True
        for it in order:
            p = mr.insert(*it["img"].size)
            if p is None:
                ok = False
                break
            pos[it["key"]] = p
        if ok:
            return W, H, pos
    raise SystemExit("Atlas terlalu besar (>2048x2048). Kurangi sprite atau perkecil dengan fit=.")


# ------------------------------------------------------------------ utama
def main() -> None:
    root = Path(__file__).resolve().parent.parent
    ap = argparse.ArgumentParser()
    ap.add_argument("--assets", default=str(root / "art_src"), help="folder sumber PNG")
    ap.add_argument("--out", default=str(root / "assets" / "atlas"))
    ap.add_argument("--collect", action="store_true", help="salin sumber yang dipakai ke art_src/")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args()
    src_root, out = Path(args.assets), Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    groups: dict[str, list[dict]] = {}
    meta: dict[str, dict] = {}
    missing, used = [], set()

    for sp in SPRITES:
        path = src_root / sp["path"]
        if not path.exists():
            missing.append(sp["path"])
            continue
        used.add(sp["path"])
        grp = sp["group"]
        up = sp.get("up", DEFAULT_UP[grp])
        base = Image.open(path).convert("RGBA")
        if sp.get("crop"):
            x, y, w, h = sp["crop"]
            base = base.crop((x, y, x + w, y + h))
        if sp.get("erase"):
            base = erase_marks(base, sp["erase"])
        if sp.get("tint"):
            base = tint_image(base, *sp["tint"])
        n = sp.get("frames", 1)
        if base.width % n:
            raise SystemExit(f"{sp['name']}: lebar {base.width} tidak habis dibagi {n} frame")
        fw = base.width // n
        teams = [0] if not sp.get("team") else [1, 2]
        for f in range(n):
            frame = base.crop((f * fw, 0, (f + 1) * fw, base.height))
            if sp.get("fit") and (frame.width > sp["fit"][0] or frame.height > sp["fit"][1]):
                frame.thumbnail(sp["fit"], Image.LANCZOS)
            for tm in teams:
                im, cnt = bake_team(frame, tm) if tm else (frame, 0)
                if tm == 1 and cnt == 0:
                    tm = 0          # tanpa piksel tim -> cukup SATU salinan polos
                big = im.resize((im.width * up, im.height * up), Image.NEAREST) if up > 1 else im
                key = sp["name"] + (f"@{tm}" if tm else "") + (f"#{f}" if n > 1 else "")
                groups.setdefault(grp, []).append({"key": key, "img": extrude(big, PAD), "raw": big})
                cx, cy = centroid(frame)
                meta[key] = {"g": grp, "s": [frame.width, frame.height], "c": [round(cx, 2), round(cy, 2)], "u": up}
                if tm == 0:
                    break

    if missing:
        print("PERINGATAN - file sumber tidak ditemukan:")
        for m in missing:
            print("   ", m)
        if len(missing) > 3:
            raise SystemExit("Terlalu banyak file hilang, hentikan.")

    names, files, ups = [], [], []
    for grp, items in groups.items():
        W, H, pos = pack(items)
        sheet = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        for it in items:
            x, y = pos[it["key"]]
            sheet.paste(it["img"], (x, y))
            meta[it["key"]]["r"] = [x + PAD, y + PAD, it["raw"].width, it["raw"].height]
            meta[it["key"]]["gi"] = len(names)
        fn = f"{grp}.png"
        sheet.save(out / fn, optimize=True)
        names.append(grp)
        files.append(f"res://assets/atlas/{fn}")
        ups.append(DEFAULT_UP[grp])
        used_px = sum(it["img"].width * it["img"].height for it in items)
        print(f"{fn:10s} {W}x{H}  {len(items):4d} gambar  terpakai {used_px / (W * H) * 100:4.1f}%  "
              f"VRAM ~{W * H * 4 / 1048576:.1f} MB  ({(out / fn).stat().st_size // 1024} KB file)")

    # data atlas ditulis sebagai GDScript (bukan JSON): pasti ikut ter-export & tanpa biaya parse saat start
    lines = ["## DIHASILKAN OTOMATIS oleh tools/build_atlas.py - JANGAN diedit manual.",
             "## Daftar sprite & posisinya di dalam atlas. Dibaca oleh SpriteLib.",
             "class_name AtlasData", "extends RefCounted", "",
             "const FILES := [" + ", ".join(f'"{f}"' for f in files) + "]",
             "const UP := [" + ", ".join(str(u) for u in ups) + "]    # faktor pembesaran gambar di atlas",
             "## kunci: [atlas, x, y, w, h, sumber_w, sumber_h, pusat_x, pusat_y]",
             "const SPRITES := {"]
    for k in sorted(meta):
        m = meta[k]
        r = m["r"]
        lines.append(f'\t"{k}": [{m["gi"]}, {r[0]}, {r[1]}, {r[2]}, {r[3]}, {m["s"][0]}, {m["s"][1]}, {m["c"][0]}, {m["c"][1]}],')
    lines.append("}")
    gd = root / "scripts" / "data" / "atlas_data.gd"
    gd.parent.mkdir(parents=True, exist_ok=True)
    gd.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"{gd.relative_to(root)}: {len(meta)} entri")

    if args.collect:
        dst = root / "art_src"
        for rel in sorted(used):
            (dst / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_root / rel, dst / rel)
        print(f"art_src/: {len(used)} file sumber disalin ({sum(p.stat().st_size for p in dst.rglob('*.png')) // 1024} KB)")


if __name__ == "__main__":
    main()
