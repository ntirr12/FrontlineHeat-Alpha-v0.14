#!/usr/bin/env python3
"""
PEMBANGUN AUDIO FRONTLINE
=========================
Mengubah suara sumber (OGG/WAV dari paket aset) menjadi file ringan untuk HP lowend:
  * Efek suara pendek -> WAV mono 22.05 kHz 16-bit (TANPA dekoding saat dimainkan = hemat CPU,
    penting karena tembakan bisa belasan kali per detik)
  * Musik -> disalin apa adanya (OGG, di-stream Godot)
  * Suara mesin kendaraan sengaja TIDAK diganti: klip mesin di paket aset adalah klip sekali-putar yang
    meluruh (bila di-loop berdenyut), jadi game tetap memakai loop mesin sintesis yang mulus.

Pemakaian (dari folder proyek):
    python tools/build_audio.py --assets ../frontline_assets
Butuh:  pip install soundfile soxr numpy

Daftar suara ada di tabel SFX di bawah. Tiap baris: nama_file_keluaran: (sumber, detik_maks, gain_dB).
Nama keluaran dipakai di scripts/data/audio_defs.gd.
"""
import argparse, shutil
from pathlib import Path

import numpy as np
import soundfile as sf
import soxr

RATE = 22050
PEAK_DB = -1.5                       # semua suara dinormalkan ke puncak ini lalu digeser gain_dB

A = "audio/sfx/"
# nama_keluaran: (sumber, detik_maks, gain_dB)
SFX = {
    # --- senapan (indeks sfx 0) ---
    "rifle_1": (A + "small_arms/assaultshot2.ogg", 0.40, 0),
    "rifle_2": (A + "small_arms/gun.ogg", 0.40, 0),
    "rifle_3": (A + "small_arms/gun2.ogg", 0.40, 0),
    "rifle_4": (A + "small_arms/gun1.ogg", 0.40, -1),
    # --- ledakan (1) ---
    "explosion_1": (A + "explosion/bomb.ogg", 2.2, 0),
    "explosion_2": (A + "explosion/explode.ogg", 2.4, 0),
    "explosion_3": (A + "explosion/explode2.wav", 2.2, 0),
    # --- roket / rudal (2) ---
    "rocket_1": (A + "missile_rocket/commonmissile.ogg", 1.3, 0),
    "rocket_2": (A + "missile_rocket/firer1.ogg", 1.8, -2),
    # --- tembakan jauh (13) & dentum artileri jauh (14) ---
    "far_gun_1": (A + "small_arms/gun0.ogg", 1.0, -3),
    "far_gun_2": (A + "small_arms/gun5.ogg", 0.9, -3),
    "far_gun_3": (A + "small_arms/shoot1.ogg", 1.2, -4),
    "far_artillery_1": (A + "explosion/explosion0.ogg", 2.6, -2),
    # --- meriam tank (15) ---
    "cannon_1": (A + "tank_cannon/125mm.ogg", 1.7, 0),
    "cannon_2": (A + "tank_cannon/115mm.ogg", 1.3, 0),
    "cannon_3": (A + "tank_cannon/medium_tank.ogg", 1.6, 0),
    "cannon_4": (A + "tank_cannon/152mm.ogg", 1.3, 0),
    # --- prajurit gugur (16) ---
    "death_1": (A + "infantry/death.ogg", 1.2, -4),
    "death_2": (A + "infantry/death2.ogg", 1.0, -4),
    "death_3": (A + "infantry/death4.ogg", 1.1, -4),
    # --- teriakan perang saat bendera direbut (17 = pihak AS, 18 = pihak Rusia) ---
    "warcry_us": ("audio/voice/intro/logintro_usmc_oorah.ogg", 1.8, -3),
    "warcry_ru": ("audio/voice/intro/logintro_rus_ura.ogg", 2.6, -3),
}
MUSIC = {"menu": "audio/music/tactical_invasion_by_averyalexander.ogg",
         "battle": "audio/music/action_a10_by_averyalexander.ogg"}


def load_mono(path: Path) -> tuple[np.ndarray, int]:
    x, sr = sf.read(str(path), dtype="float32", always_2d=True)
    return x.mean(axis=1), sr


def process(x: np.ndarray, sr: int, max_s: float, gain_db: float, fade_ms: float = 120.0) -> np.ndarray:
    x = x[: int(max_s * sr)]
    if sr != RATE:
        x = soxr.resample(x, sr, RATE)
    n = min(len(x), int(fade_ms / 1000 * RATE))
    if n > 0 and len(x) >= int(max_s * RATE) - 2:          # potong paksa -> fade-out halus (tanpa klik)
        x[-n:] *= np.linspace(1.0, 0.0, n) ** 1.5
    peak = float(np.max(np.abs(x))) or 1.0
    x = x / peak * 10 ** ((PEAK_DB + gain_db) / 20)
    return np.clip(x, -1.0, 1.0)


def main() -> None:
    root = Path(__file__).resolve().parent.parent
    ap = argparse.ArgumentParser()
    ap.add_argument("--assets", required=True, help="folder paket aset asli (berisi audio/)")
    args = ap.parse_args()
    src = Path(args.assets)
    out = root / "assets" / "audio"
    (out / "sfx").mkdir(parents=True, exist_ok=True)
    (out / "music").mkdir(parents=True, exist_ok=True)

    total = 0
    for name, (rel, max_s, gain) in SFX.items():
        x, sr = load_mono(src / rel)
        y = process(x, sr, max_s, gain)
        sf.write(out / "sfx" / f"{name}.wav", y, RATE, subtype="PCM_16")
        total += (out / "sfx" / f"{name}.wav").stat().st_size
        print(f"  {name:18s} {len(y) / RATE:4.2f}s")

    for name, rel in MUSIC.items():
        shutil.copy2(src / rel, out / "music" / f"{name}.ogg")
        print(f"  musik {name}.ogg  {(out / 'music' / f'{name}.ogg').stat().st_size // 1024} KB")
    print(f"SFX WAV total: {total // 1024} KB")


if __name__ == "__main__":
    main()
