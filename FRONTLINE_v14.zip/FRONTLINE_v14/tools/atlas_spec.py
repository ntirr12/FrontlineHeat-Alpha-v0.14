"""
DAFTAR SPRITE YANG MASUK ATLAS  (file ini yang diedit untuk menambah / mengganti gambar)
=======================================================================================
Cara kerja singkat:
  1. Setiap baris `add(...)` = satu sprite. `name` adalah nama yang dipakai di game
     (lihat scripts/data/sprite_defs.gd), `path` adalah lokasi file PNG relatif terhadap folder
     art_src/ (atau paket aset asli bila memakai --assets).
  2. Jalankan:   python tools/build_atlas.py
  3. Hasilnya: assets/atlas/units.png, fx.png, ui.png + atlas.json  (JANGAN diedit manual).

Opsi `add`:
  group  : "units" (pixel-art, di-upscale 2x nearest agar tajam saat diputar)  /  "fx" (efek, ukuran asli)
  frames : jumlah frame bila gambarnya strip horizontal. Hasilnya: nama#0, nama#1, ...
  team   : True = piksel hijau-murni (penanda warna tim) diganti BIRU dan MERAH -> nama@1 dan nama@2
  crop   : (x, y, w, h) potong sebagian gambar (untuk spritesheet)
  fit    : (w, h) perkecil agar muat (efek besar -> hemat memori)
  up     : paksa faktor upscale (default: 2 untuk units, 1 untuk fx)
  erase  : [(x, y, w, h), ...] hapus tulisan/tanda tangan kecil di area itu
  tint   : ((r, g, b), jumlah) campur warna sprite dengan warna lain (varian salju)
"""

SPRITES: list[dict] = []


def add(name: str, path: str, group: str = "units", **kw) -> None:
    SPRITES.append(dict(name=name, path=path, group=group, **kw))


def skin_pair(name: str, tan: str | None, grn: str | None, **kw) -> None:
    """Satu sprite dengan dua skin: gurun (tan) dan hutan (grn). Game memilih sesuai biome."""
    if tan:
        add(name + "_tan", tan, **kw)
    if grn:
        add(name + "_grn", grn, **kw)


S = "sprites/"

# ============================================================ INFANTERI
# strip 2 frame: #0 diam, #1 menembak. (sniper = 3 frame, worker = 1 frame)
for role, us_file, frames in [
    ("assault", "assault_%s", 2), ("at", "at_%s", 2), ("worker", "worker_%s", 1),
    ("mg", "machinegun_%s", 2), ("sniper", "ussniper0", 3),
]:
    nm = us_file % "us" if "%s" in us_file else us_file
    add(f"inf/us_army_{role}", f"{S}us/infantry/us_army/{nm}.png", frames=frames, team=True)
    nm = us_file % "usmc" if "%s" in us_file else us_file
    add(f"inf/usmc_{role}", f"{S}us/infantry/usmc/{nm}.png", frames=frames, team=True)
    nm = us_file % "ru" if "%s" in us_file else "sniper_ru"
    add(f"inf/ru_{role}", f"{S}ru/infantry/ru_army/{nm}.png", frames=frames, team=True)

# ============================================================ KENDARAAN
# Nama: veh/<id>/<bagian>_<skin>.   Bagian: body, turret, barrel, wreck.
HM = S + "us/light_vehicle/hmmwv/"
add("veh/us_humvee/body_tan", HM + "hmmwv_m1025_a.png", team=True)
add("veh/us_humvee/body_grn", HM + "hmmwv_m1025_a_g.png", team=True)
add("veh/us_humvee/mg_tan", HM + "mounted_mg_usmc.png", team=True)
add("veh/us_humvee/mg_grn", HM + "mounted_mg_usa.png", team=True)
add("veh/us_humvee/at_tan", HM + "mounted_at_usmc.png", team=True)
add("veh/us_humvee/at_grn", HM + "mounted_at_usa.png", team=True)
add("veh/us_humvee/wreck", HM + "hmmwv_d.png")

AB = S + "us/tank/m1a2abrams/"
skin_pair("veh/us_abrams/body", AB + "m1a2.png", AB + "m1a2_g.png", team=True)
skin_pair("veh/us_abrams/turret", AB + "m1a2_turret.png", AB + "m1a2_turret_g.png", team=True)
skin_pair("veh/us_abrams/barrel", AB + "abrams_120m_barrel.png", AB + "abrams_120m_barrel_g.png")
add("veh/us_abrams/wreck", AB + "d.png")

BR = S + "us/ifv_apc/bradley/m2a3_bradley/"
skin_pair("veh/us_bradley/body", BR + "m2a3.png", BR + "m2a3_g.png", team=True)
skin_pair("veh/us_bradley/turret", BR + "m2a3_turret.png", BR + "m2a3_turret_g.png", team=True)
add("veh/us_bradley/barrel_tan", BR + "bradley_barrel.png")
add("veh/us_bradley/wreck", BR + "d.png")

MX = S + "us/tank/m1a3/"        # tank masa depan -> RAILGUN TANK
# erase = hapus tulisan "snob" (tanda tangan pembuat sprite) di lambung
skin_pair("veh/us_m1x/body", MX + "m1ax.png", MX + "m1ax_g.png", team=True, erase=[(5, 23, 20, 9)])
skin_pair("veh/us_m1x/turret", MX + "m1ax_turret.png", MX + "m1ax_g_turret.png", team=True)
skin_pair("veh/us_m1x/barrel", MX + "m1ax_barrel.png", MX + "m1ax_g_barrel.png")
add("veh/us_m1x/wreck", MX + "m1ax_dead.png")

TG = S + "ru/light_vehicle/gaz/gaz2330_tigr/"
add("veh/ru_tigr/body_grn", TG + "tigr.png", team=True)
add("veh/ru_tigr/at_body_grn", TG + "tigr_at.png", team=True)
add("veh/ru_tigr/mg_grn", TG + "mounted_mg_rus.png", team=True)
add("veh/ru_tigr/at_grn", S + "ru/buildings/ru-turret/konkurs/konkurs_t2.png", team=True)
add("veh/ru_tigr/wreck", TG + "d.png")

T9 = S + "ru/tank/t90/"
skin_pair("veh/ru_t90/body", T9 + "t90a_desert.png", T9 + "t90a.png", team=True)
skin_pair("veh/ru_t90/turret", T9 + "t90a_desert_turret.png", T9 + "t90a_turret.png", team=True)
skin_pair("veh/ru_t90/barrel", T9 + "t90a_desert_barrel.png", T9 + "t90a_barrel.png")
add("veh/ru_t90/wreck", T9 + "t90a_d.png")

BM = S + "ru/ifv_apc/bmp/bmp3/"
add("veh/ru_bmp3/body_grn", BM + "bmp3.png", team=True)
add("veh/ru_bmp3/turret_grn", BM + "bmp3_turret.png", team=True)
add("veh/ru_bmp3/wreck", BM + "bmp3_d.png")

# ---- v14: KENDARAAN BARU -------------------------------------------------------------------------
# APC: LAV-25 (AS) vs BTR-82A (Rusia). SPG: M109A6 Paladin vs 2S3 Akatsiya. MEDEVAC: Stryker M1133 vs Ural-4320 (truk medis).
LV = S + "us/ifv_apc/lav/lav25/"
skin_pair("veh/us_lav/body", LV + "lav25.png", LV + "lav25_g.png", team=True)
skin_pair("veh/us_lav/turret", LV + "lav25_turret.png", LV + "lav25_turret_g.png", team=True)
add("veh/us_lav/barrel_tan", LV + "barrel.png")
add("veh/us_lav/wreck", LV + "d.png", up=1)

BT = S + "ru/ifv_apc/btr/btr80-82/"
add("veh/ru_btr/body_grn", BT + "btr80.png", team=True)
add("veh/ru_btr/turret_grn", BT + "btr82a_turret.png", team=True)
add("veh/ru_btr/barrel_grn", BT + "btr82a_barrel.png")
add("veh/ru_btr/wreck", BT + "btr82a_d.png", up=1)

M9 = S + "us/artillery/m109/m109a6/"
skin_pair("veh/us_m109/body", M9 + "m109a6.png", M9 + "m109a6_g.png", team=True)
skin_pair("veh/us_m109/turret", M9 + "m109a6_turret.png", M9 + "m109a6_turret_g.png", team=True)
skin_pair("veh/us_m109/barrel", M9 + "m109a6_barrel.png", M9 + "m109a6_barrel_g.png")
add("veh/us_m109/wreck", M9 + "m109a6_d.png", up=1)

S3 = S + "ru/artillery/2s3_akatsiya/"
add("veh/ru_2s3/body_grn", S3 + "2s3.png", team=True)
add("veh/ru_2s3/turret_grn", S3 + "2s3_turret.png", team=True)
add("veh/ru_2s3/barrel_grn", S3 + "2s3_barrel.png")
add("veh/ru_2s3/wreck", S3 + "2s3_d.png", up=1)

MD = S + "us/ifv_apc/stryker/m1133_medevac_stryker/"
skin_pair("veh/us_medevac/body", MD + "m1133.png", MD + "m1133_g.png", team=True)
add("veh/us_medevac/wreck", MD + "d.png", up=1)
UR = S + "ru/light_vehicle/ural/"
add("veh/ru_ural/body_grn", UR + "ural4320_roof.png", team=True)
add("veh/ru_ural/wreck", UR + "ural4320_d.png", up=1)

# ---- v14: peluncur MLRS panggilan radio (HIMARS AS, Uragan Rusia): badan + palang roket (turret)
HM2 = S + "us/artillery/m142himars/"
skin_pair("veh/us_himars/body", HM2 + "m142.png", HM2 + "m142_g.png", team=True)
skin_pair("veh/us_himars/turret", HM2 + "m142_turret.png", HM2 + "m142_turret_g.png", team=True)
UG = S + "ru/artillery/9a53_uragan-1m/"
add("veh/ru_uragan/body_grn", UG + "body.png", team=True)
add("veh/ru_uragan/turret_grn", UG + "turret.png", team=True)

# ============================================================ TURRET TETAP
add("tur/us_mg", S + "us/buildings/us-turret/m2hb/mounted_m2hb_usa.png", team=True)
add("tur/us_tow", S + "us/buildings/us-turret/tow/mounted_tow_usa.png", team=True)
add("tur/ru_mg", S + "ru/buildings/ru-turret/pkm/mounted_pkm_rus.png", team=True)
add("tur/ru_at", S + "ru/buildings/ru-turret/konkurs/konkurs_t2.png", team=True)
add("tur/ring", "props/misc/infantry_turret_sandback.png")

# ============================================================ BANGUNAN BUATAN
D = S + "defenses/"
add("bld/tower", D + "watchtower/watchtower.png", team=True)
add("bld/trap", D + "tank_traps/tanktrap.png")
add("bld/wire", D + "barb_wire/barbwire_vert.png")
add("bld/wire_d", D + "barb_wire/barbwire_vert_d.png")
add("bld/bunker", D + "machine_gun_nest/sdbgs_1.png")
add("bld/bunker_cover", D + "machine_gun_nest/sdbgs_1_cover.png")
add("bld/bunker_d", D + "machine_gun_nest/sdbgs_1_d.png")
add("bld/depot", "props/supplies/supplies3.png")
add("bld/stash", "props/supplies/supply_stash.png")
for i in range(1, 7):
    add(f"wall/hesco{i}", D + f"hesco_barrier_blocks/hesco_block{i}.png")

# ============================================================ DEKOR PETA
add("prop/tree1", "props/trees/acacia_tree1.png")
add("prop/tree2", "props/trees/acacia_tree2.png")
add("prop/tree3", "props/trees/acacia_tree2_2.png")
for i, nm in enumerate(["acacia_tree1", "acacia_tree2", "acacia_tree2_2"], 1):   # varian bersalju (tertutup putih)
    add(f"prop/tree{i}_snow", f"props/trees/{nm}.png", tint=((236, 244, 255), 0.62))
M0 = "props/misc/misc0.png"
add("prop/rock_l", M0, crop=(3, 62, 38, 36))
add("prop/rock_m", M0, crop=(41, 22, 20, 19))
add("prop/rock_s", M0, crop=(3, 24, 11, 10))
add("prop/bush", M0, crop=(121, 42, 20, 18))
add("prop/cactus1", M0, crop=(121, 20, 16, 24))
add("prop/cactus2", M0, crop=(103, 71, 17, 29))
add("prop/cactus3", M0, crop=(60, 76, 17, 24))
add("prop/crater1", M0, crop=(60, 20, 20, 20))
add("prop/crater2", M0, crop=(80, 20, 20, 20))
add("prop/crater3", M0, crop=(100, 20, 20, 20))

# ============================================================ DETAIL ATAP GEDUNG
# Atap peta berukuran beragam -> sprite tidak diregangkan; hanya potongan detail (kipas, kisi, panel)
# yang ditempel dengan skala seragam di atas warna atap. Skin tan = bangunan AS, grn = bangunan Rusia.
for sk, fac in [("tan", "us"), ("grn", "ru")]:
    tf = f"{S}{fac}/buildings/{fac}-tank_factory/{fac}tankfactory.png"
    sc = f"{S}{fac}/buildings/{fac}-strategy_center/{fac}_sc.png"
    add(f"roof/fans_{sk}", tf, crop=(17, 4, 36, 28))
    add(f"roof/grill_{sk}", tf, crop=(20, 72, 31, 40))
    add(f"roof/tech_{sk}", sc, crop=(48, 4, 43, 40) if fac == "us" else (44, 4, 45, 34))

# ============================================================ PESAWAT (skala asli, tanpa upscale)
for nm, p in [("a10", "us/aircraft/a10/a10.png"), ("f15", "us/aircraft/f15/f15.png"),
              ("su25", "ru/aircraft/su25/su25.png"), ("su27", "ru/aircraft/su27/su27.png")]:
    add(f"air/{nm}", S + p, up=1)

# ---- v14: pesawat angkut C-17 (bantuan terjun payung). team=True mewarnai lampu navigasi hijau-murni di sprite.
add("air/c17", S + "us/aircraft/c17/c17.png", up=1, team=True, fit=(180, 180))   # fit: pesawat tidak perlu 257 px (hemat memori)

# ============================================================ EFEK (group fx, skala asli)
E = "effects/"
add("fx/expl_s", E + "explosion/exp5.png", group="fx", frames=14)            # ledakan kecil/granat
add("fx/expl_m", E + "explosion/explosion1.png", group="fx", frames=10)      # ledakan besar berdebu
add("fx/fire", E + "fire_flame/fire1.png", group="fx", frames=8)             # api bangkai
add("fx/smoke", E + "smoke_dust/smoke5.png", group="fx", fit=(112, 112))
add("fx/smoke_b", E + "smoke_dust/smoke4.png", group="fx", fit=(80, 80))
add("fx/dirt", E + "impact_debris/dirtbig.png", group="fx", fit=(72, 72))
add("fx/muzzle_r", E + "muzzle_flash/shoot3.png", group="fx", up=2)
add("fx/muzzle_t", E + "muzzle_flash/tankmuzzleflash.png", group="fx", frames=9)
add("fx/crater_l", E + "explosion/crater_l.png", group="fx")
add("fx/crater_m", E + "explosion/crater_m.png", group="fx", up=2)
add("fx/crater_x", E + "impact_debris/crater.png", group="fx", fit=(96, 96))
add("fx/parachute", E + "air_para/parachute.png", group="fx", up=2)
# ---- v14: kanopi penerjun, peti suplai (salib hijau = medis), roket MLRS
add("fx/canopy", E + "air_para/paradrop/newpara.png", group="fx", up=2)
add("fx/crate_med", E + "air_para/para1.png", group="fx", up=2)
add("fx/crate", E + "air_para/para2.png", group="fx", up=2)
add("fx/rocket", E + "projectile_ammo/projectile.png", group="fx", up=1)
for i in range(1, 5):
    add(f"fx/blood{i}", E + f"impact_debris/blood{i}.png", group="fx", up=2)
for nm in ["corpse1", "infantryd", "infantryd2", "infd", "infd2"]:
    add(f"fx/{nm}", E + f"corpse_body/{nm}.png", group="fx", up=2)
