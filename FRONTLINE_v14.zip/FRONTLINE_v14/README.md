# FRONTLINE v14.0 (Godot 4.7)

Game perang top-down ala Battlefield untuk HP. v13 memperbaiki **sistem tembak & kerusakan**, membuat **AI lebih natural**,
memperkuat **kendaraan**, menambah **efek pertempuran**, dan memangkas **draw call ~65%** tanpa menghapus satu fitur pun
(daftar lengkap & angka ukur: `docs/CHANGELOG.md`). Seluruh gambar vektor lama tetap ada sebagai cadangan otomatis.

## Baru di v14 (lihat docs/CHANGELOG.md)
- **Kendaraan lebih besar** (jelas > prajurit) dan **3 kendaraan baru**: APC (LAV-25 / BTR-82A), SPG howitzer (M109 / 2S3), MEDEVAC (penyembuh sekutu).
- **Skill kendaraan** (BOOST / TIRAI ASAP lewat tombol SKILL), mesin pincang saat rusak parah, peluru asap, peluru artileri lengkung.
- **RADIO: TERJUN C-17**: pesawat C-17 menerjunkan satu regu + peti medis. **RADIO: MLRS**: salvo 18 roket, dibidik seperti airstrike.
  **DROP: SUPLAI** & peti medis/amunisi. Hadiah **kill streak**. Musuh dan Director juga memakai C-17 & MLRS.
- **Efek baru**: debu roda/rantai, api boost, asap artileri, jejak roket, peluncuran, penerjun mendarat; **percikan ledakan kini benar-benar tampil** (bug lama diperbaiki).
- Optimasi: lapisan udara digambar per tekstur, draw-call pertempuran biasa 107 -> 115 (dengan 7 kendaraan/markas + sprite lebih besar), simulasi tetap ~1,8 ms/frame.

## Baru di v13
- **Peluru tidak lagi menembus**: tabrakan dites sepanjang jalur peluru (bukan titik), jadi tidak ada peluru yang melompati
  sasaran antar-frame, bahkan di 20 FPS. Peluru yang meleset **jatuh ke tanah di sekitar sasaran** (debu, bekas hantaman),
  baik ditembak AI, pemain berjalan, maupun dari kendaraan. Peluru meriam/granat yang meleset tetap meledak dan memberi **damage splash**.
- **Kena langsung vs splash**: peluru ledak yang menabrak sasaran memberi damage langsung (`Cfg.DIRECT_DMG`) + ledakan area.
- **AI tidak menghindar dari strike**: AI tidak "tahu" artileri/airstrike/granat akan jatuh (`Cfg.AI_DODGE_DANGER = false`).
  Yang ada reaksi *setelah* tertekan: **merunduk/cari cover** saat peluru nyaris kena atau ledakan dekat (suppression).
- **Taktik AI lebih natural**: tembak sambil berdiri & bergerak di jeda rentetan, regu **melompat bergantian** (separuh menahan,
  separuh maju), satu anggota **mengitari musuh dari samping**, **tembakan penekan** ke posisi terakhir musuh, berhenti waspada,
  kecepatan jalan berbeda per prajurit, formasi baji. Tank menjaga jarak & **mundur** bila terlalu dekat.
- **Kendaraan di-buff**: HP +50%, lebih kebal peluru senapan & ledakan kecil, senapan mesin lebih kuat, tembak lebih cepat,
  **melindas** infantri musuh. Kendaraan rusak parah berasap lalu menyala.
- **Efek**: tank hancur = bola api + kilatan + **semburan api dari panel/palka** + **turret terlempar** (berputar, jatuh, bikin kawah) +
  ledakan susulan + bangkai berasap hitam; ledakan berlapis (kilatan, semburan tanah, serpihan); prajurit **terlempar** ledakan;
  debu di tanah saat meriam menembak; percikan di baja/gedung.
- **Jauh lebih ringan**: draw call 297 -> 107 (30 AI/tim) dan 474 -> 147 di tengah baku tembak; CPU simulasi -18..22%, skrip gambar -29..38%.

## Cara membuka
1. Pasang **Godot 4.7** (versi standar, bukan .NET).
2. `Import` > pilih `project.godot` > `Run` (F5). Pertama kali Godot akan memindai skrip (beberapa detik).
3. Export Android: lihat `export_presets.cfg` (isi keystore dan nama paket sendiri).

## v12: aset (lihat docs/ASET.md)
- **Sprite pixel-art**: prajurit 8 divisi, 5 kendaraan (badan + turret + laras terpisah, laras menyentak saat menembak),
  turret, bunker, menara, kawat berduri, tank trap, atap gedung, pohon/semak/kaktus/batu, jet, parasut.
- **Dua faksi**: tim biru = pasukan AS, tim merah = Rusia. Skin kendaraan mengikuti biome (GURUN tan, HUTAN/SALJU hijau).
  Spy yang menyamar tampil dengan sprite musuh.
- **Efek sprite**: ledakan beranimasi, muzzle flash searah tembakan, asap, api bangkai, darah, kawah, mayat.
- **Suara nyata**: tembakan, meriam tank, ledakan, roket, prajurit gugur, teriakan perang saat bendera direbut, dua lagu OGG.
- **Ringan**: 2 atlas (~6 MB VRAM), 21 SFX WAV mono, musik 8 kHz. Musik tidak lagi dibangkitkan sintesis saat start.
- **Aman**: `Cfg.USE_SPRITES = false` mengembalikan tampilan vektor v11 sepenuhnya.

## Fitur v11
- **AI jauh lebih pintar**: bergerak dalam *regu 4 orang*, berlindung dan mengintip, menyerbu, menjaga bendera,
  mundur saat HP kritis (pakai asap), menghindari tank bila tak punya senjata anti-tank (v13: tidak lagi lari dari strike),
  punya waktu reaksi dan menembak per-rentetan (bukan laser), mengejar posisi *terakhir* musuh terlihat (tidak "tahu" posisi asli).
- **Medan perang lebih kacau & epik**: jumlah AI sampai **44 per tim**, *Director* menjaga aksi tetap dekat pemain
  (menarik regu, hujan artileri, jet pembom, pasukan bantuan terjun), tracer berwarna per tim, ambien tembakan jauh.
- **Persiapan Misi baru**: Jumlah AI, Panjang Misi, Tingkat Kekacauan, Kesulitan, Medan.
- **Kontrol diperbaiki**: analog **MELAYANG / TETAP**, zona mati, kecepatan bidik, tombol **TEMBAK** yang bisa diseret untuk
  membidik, tembak otomatis, transparansi kontrol. Kendaraan tidak lagi macet di tembok (meluncur menyamping).
- **Optimasi HP lawas**: peta statis digambar sekali (potongan 1024px), peluru/efek di-pool, grid spasial, A* dibagi per regu,
  LOD AI untuk prajurit jauh, minimap hanya ~7x/detik, mode render **HEMAT** (720p), governor kualitas otomatis.

## Struktur folder (mulai baca dari sini)
```
project.godot, main.tscn
assets/                atlas (assets/atlas) dan suara (assets/audio) -- DIBUAT OTOMATIS oleh tools/
art_src/               PNG sumber terpilih (tidak diimpor Godot, tidak ikut APK)
tools/                 build_atlas.py, build_audio.py, atlas_spec.py (daftar sprite)
scripts/
  main.gd              Game: data pertandingan + loop simulasi sim(dt)   <- titik masuk
  data/cfg.gd          SEMUA ANGKA TUNING (ubah keseimbangan di sini)
  data/sprite_defs.gd  benda game -> nama sprite, skala, posisi turret      (v12)
  data/audio_defs.gd   nomor suara -> file sampel                            (v12)
  data/atlas_data.gd   posisi sprite di atlas, DIBUAT OTOMATIS, jangan diedit (v12)
  entities/            Unit, Vehicle, Turret, Structure, Bullet, Fx, ... (data saja)
  systems/             aturan permainan: world, map_generator, combat, infantry, vehicle_sys, support, air_support (C-17/MLRS/peti, v14),
                       objectives, director, player_ctl, spatial_grid, fx_pool,
                       vfx (efek pertempuran: ledakan, kendaraan hancur, hantaman)               (v13)
  ai/                  ai_planner (regu & tujuan), ai_brain (state machine), ai_nav, ai_vehicle, squad
  input/touch_input.gd analog, tombol, keyboard
  render/              terrain_view (peta statis), battle_view (dinamis), air_view (C-17/roket/penerjun, v14), hud, decal_view, ui_kit, gfx,
                       sprite_lib (pemuat atlas), sprite_bank (sprite siap gambar),
                       icon_atlas (ikon tombol dibake sekali)                                    (v13)
  ui/menus.gd          semua layar menu
  audio/               synth (suara sintesis: UI & cadangan), audio_mgr (sampel + ambien perang)
  save/prefs.gd        pengaturan + statistik (user://f.cfg)
docs/                  ARSITEKTUR.md, ASET.md, TUNING.md, CHANGELOG.md, CREDITS.md
tests/                 tes otomatis (lihat bawah)
```
Satu file = satu tanggung jawab. Aturan praktis: **angka** ke `cfg.gd`, **perilaku AI** ke `scripts/ai/`,
**tampilan** ke `scripts/render/`, **menu** ke `scripts/ui/menus.gd`.

## Menjalankan tes (butuh Godot di PATH, atau set `GODOT=/jalur/godot`)
```
bash tests/check.sh                                                  # cek skrip error/warning
godot --headless --path . --script tests/player_test.gd              # fitur pemain, item, kendaraan, drone, analog
godot --headless --path . --script tests/sim_test.gd -- 2 240 1      # simulasi AI (preset 0..3, detik, kualitas 1..3)
godot --headless --path . --script tests/ai_scenarios.gd             # metrik perilaku AI
xvfb-run -a godot --rendering-driver opengl3 --path . --script tests/ui_flow.gd   # alur menu & sentuhan nyata
godot --headless --path . --script tests/audio_test.gd               # bank suara, musik, fallback sintesis (v12)
godot --headless --path . --script tests/sprite_test.gd              # atlas, kamus sprite, fallback vektor (v12)
godot --headless --path . --script tests/combat_test.gd              # peluru tidak menembus, jatuh ke tanah, splash, kendaraan, cook-off (v13)
godot --headless --path . --script tests/air_test.gd                 # kendaraan baru, C-17, MLRS, peti, skill, kill streak (v14)
xvfb-run -a godot --rendering-driver opengl3 --path . --script tests/shots_air.gd -- 1   # foto kendaraan/C-17/MLRS (biome 0/1/2) (v14)
godot --headless --path . --script tests/pace_test.gd -- 120 8       # tempo gugur/menit + sumber kematian (detik per seed, jumlah seed) (v13)
xvfb-run -a godot --rendering-driver opengl3 --path . --script tests/shots_vfx.gd -- 0   # foto efek tank hancur/peluru/meriam (kualitas efek 0..2) (v13)
xvfb-run -a godot --rendering-driver opengl3 --path . --script tests/render_bench.gd -- 1 8 0 2   # draw-call/primitif (kualitas, detik, biome, AI)
xvfb-run -a godot --rendering-driver opengl3 --path . --script tests/shots_sprites.gd -- 0   # foto adegan sprite (biome 0/1/2)
```
> Catatan jujur: tes dijalankan di Godot 4.7.2 Linux (headless + tampilan virtual). **Belum diuji di HP fisik** -
> setelan Android/GLES bisa berbeda. Kalau ada yang janggal di perangkat, mulai dari Pengaturan > Kualitas / Resolusi.
