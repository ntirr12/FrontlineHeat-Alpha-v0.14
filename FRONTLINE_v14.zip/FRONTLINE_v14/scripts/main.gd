class_name Game
extends Node2D
## FRONTLINE - TITIK MASUK GAME.
## Game memegang semua DATA pertandingan (daftar prajurit, kendaraan, dst.) dan menjalankan
## loop simulasi `sim(dt)`. Setiap aturan permainan ada di "sistem" terpisah (folder scripts/systems, scripts/ai):
##
##   World      peta, tabrakan, LOS, navigasi        Objectives bendera, tiket, spawn
##   Combat     peluru, ledakan, kerusakan           Support    granat, airstrike, bangunan, drone
##   Infantry   senjata prajurit                     VehicleSys kendaraan & turret
##   AiPlanner  regu & tujuan AI                     AiBrain    otak prajurit AI (state machine)
##   Director   kejadian acak ala Battlefield        PlayerCtl  kontrol pemain
## Tampilan ada di scripts/render, menu di scripts/ui, input sentuh di scripts/input.
## Baca docs/ARSITEKTUR.md untuk peta lengkapnya.

enum Mode { MENU, PLAY, OVER }

const CHEAT_KEYS := ["god", "unl", "amo", "ohk", "frz", "spd"]

# ------------------------------------------------------------------ sistem
var prefs := Prefs.new()
var world := World.new()
var grid := SpatialGrid.new()
var fx := FxPool.new()
var combat: Combat
var radio_next := [0.0, 0.0, 0.0]  # waktu paling cepat barrage radio AI berikutnya per tim (dukungan artileri itu langka)
var vfx: Vfx                      # efek pertempuran (hantaman, ledakan berlapis, kendaraan hancur) - lihat systems/vfx.gd
var infantry: Infantry
var vehicle_sys: VehicleSys
var support: Support
var air: AirSupport                # v14: C-17 terjun payung, MLRS, peti suplai (systems/air_support.gd)
var objectives: Objectives
var planner: AiPlanner
var brain: AiBrain
var ai_nav: AiNav
var director: Director
var player_ctl: PlayerCtl
var input: TouchInput
var audio: Node = null                 # AudioMgr (null saat tes headless)

# ------------------------------------------------------------------ tampilan (null saat tes headless)
var view_root: Node2D
var terrain_view: Node2D
var decal_view: Node2D
var battle_view: Node2D
var air_view: Node2D                   # v14: lapisan udara (C-17, penerjun, roket MLRS, peti) - render/air_view.gd
var hud: Node2D
var menus: Node2D

# ------------------------------------------------------------------ data pertandingan
var units: Array[Unit] = []
var vehicles: Array[Vehicle] = []
var turrets: Array[Turret] = []
var structs: Array[Structure] = []
var grenades: Array[BO.Grenade] = []
var smokes: Array[BO.Smoke] = []
var barrages: Array[BO.Barrage] = []
var jets: Array[BO.Jet] = []
var mines: Array[BO.Mine] = []
var charges: Array[BO.Charge] = []
var nukes: Array[BO.Nuke] = []
var drops: Array[BO.Drop] = []
var ai_drones: Array[BO.Drone] = []
var airlifts: Array[BO.Airlift] = []   # v14: C-17 yang sedang melintas
var chutes: Array[BO.Chute] = []       # v14: penerjun/peti yang melayang turun
var crates: Array[BO.Crate] = []       # v14: peti suplai di tanah
var salvos: Array[BO.Salvo] = []       # v14: panggilan MLRS aktif
var rockets: Array[BO.Rocket] = []     # v14: roket MLRS di udara
var beams: Array[BO.Beam] = []
var decals: Array[BO.Mark] = []
var alerts: Array[BO.Alert] = []
var player_drone: BO.Drone = null
var player: Unit = null
var scratch: Array = []                # buffer kueri bersama (jangan simpan hasilnya antar-panggilan!)

var tickets := [0, 80, 80]
var tickets_max := [0, 80, 80]
var time := 0.0                        # waktu berjalan (detik)
var frame := 0
var match_start := 0.0
var match_duration := 0.0
var win := false
var over_time := 0.0
var units_dirty := true
var decals_dirty := false
var ai_alive := [0, 0, 0]
var _spawn_t := [0.0, 0.0, 0.0]
var respawn_t := 0.0

# ------------------------------------------------------------------ statistik misi
var kills := 0
var deaths := 0
var streak := 0
var best_streak := 0
var flags_captured := 0

# ------------------------------------------------------------------ status tampilan
var mode := Mode.MENU
var paused := false
var selecting := false
var screen := "main"
var prev_screen := "main"
var settings_tab := 0
var help_page := 0
var confirm_t := 0.0
var loading_frames := 0
var last_class := -1
var spawn_choice := -1
var msg := ""
var msg_t := 0.0
var kill_feed: Array = []              # [{text, color, t}]
var tip := ""
var tutorial_t := 0.0
var vehicle_prompt := ""
var _prompt_t := 0.0
var _heartbeat_t := 0.0
var vs := Vector2(1280, 720)
var margin_l := 20.0
var margin_r := 20.0
var _pvs := Vector2.ZERO

# ------------------------------------------------------------------ kamera & umpan balik
var cam := Vector2(300, 1000)
var zoom := 1.0
var shake := 0.0
var hit_marker_t := 0.0
var kill_marker_t := 0.0
var hurt_flash := 0.0
var damage_dir := 0.0
var damage_dir_t := 0.0
var gunfire_t := 0.0                   # >0 = ada tembakan dekat pemain (untuk Director)
var gunfire_events := 0                # jumlah tembakan sejak frame lalu (untuk audio ambien)

# ------------------------------------------------------------------ kualitas adaptif
var sprites := SpriteBank.new()        # sprite siap gambar (diatur ulang tiap pertandingan, lihat render/sprite_bank.gd)
var quality_level := 0                 # 0 tinggi, 1 sedang, 2 rendah
var ai_scale := 1.0                    # pengali jumlah AI (turun hanya sebagai pilihan terakhir)
var fps_avg := 60.0
var _gov_down := 0.0
var _gov_up := 0.0
var _gov_block := 0.0
var _gov_wait := 60.0
var _gov_pressure := 0.0

# ------------------------------------------------------------------ dev
var dev := false
var profile_on := false                # aktifkan hanya saat tes performa
var prof: Dictionary = {}             # nama bagian -> [total_us, maks_us]
var draw_us := 0                      # total mikrodetik skrip gambar (hanya saat profile_on)
var cheats := {"god": false, "unl": false, "amo": false, "ohk": false, "frz": false, "spd": false}


func _ready() -> void:
	prefs.load_all()
	combat = Combat.new(self)
	vfx = Vfx.new(self)
	infantry = Infantry.new(self)
	vehicle_sys = VehicleSys.new(self)
	support = Support.new(self)
	air = AirSupport.new(self)
	objectives = Objectives.new(self)
	planner = AiPlanner.new(self)
	brain = AiBrain.new(self)
	ai_nav = AiNav.new(self)
	director = Director.new(self)
	player_ctl = PlayerCtl.new(self)
	input = TouchInput.new(self)
	world.smokes = smokes
	world.region_changed.connect(_on_region_changed)
	quality_level = 1 if OS.has_feature("mobile") else 0
	var headless := DisplayServer.get_name() == "headless"
	if not headless:
		_build_views()
	apply_settings()
	world.generate(7, 0)
	objectives.setup(world.flag_positions)
	if terrain_view != null:
		sprites.resolve(world.biome)
		terrain_view.call("rebuild")


func _build_views() -> void:
	view_root = Node2D.new()
	add_child(view_root)
	terrain_view = TerrainView.new()
	view_root.add_child(terrain_view)
	decal_view = DecalView.new()
	view_root.add_child(decal_view)
	battle_view = BattleView.new()
	view_root.add_child(battle_view)
	air_view = AirView.new()
	view_root.add_child(air_view)
	var layer := CanvasLayer.new()
	layer.layer = 5
	add_child(layer)
	hud = Hud.new()
	layer.add_child(hud)
	menus = Menus.new()
	layer.add_child(menus)
	for v in [terrain_view, decal_view, battle_view, air_view, hud, menus]:
		v.call("setup", self)
	audio = AudioMgr.new()
	add_child(audio)
	audio.call("setup", self)


func _exit_tree() -> void:
	if audio != null:
		audio.call("shutdown")


# ================================================================ pengaturan
func apply_settings() -> void:
	prefs.clamp_all()
	Engine.max_fps = prefs.fps_cap
	if prefs.quality > 0:
		quality_level = prefs.quality - 1
	fx.quality = quality_level
	if DisplayServer.get_name() != "headless":
		var win_node := get_window()
		var sharp := prefs.resolution == 1 or (prefs.resolution == 0 and not OS.has_feature("mobile"))
		win_node.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS if sharp else Window.CONTENT_SCALE_MODE_VIEWPORT


func cheat(key: String) -> bool:
	return dev and cheats.get(key, false)


func ai_cap() -> int:
	return maxi(4, int(round(float(Cfg.AI_COUNT[prefs.ai_count]) * ai_scale)))


# ================================================================ siklus pertandingan
func begin_start() -> void:
	loading_frames = 3


func start_match() -> void:
	var biome := (prefs.biome - 1) if prefs.biome > 0 else randi() % 3
	world.generate(randi(), biome)
	objectives.setup(world.flag_positions)
	if terrain_view != null:
		sprites.resolve(world.biome)
		terrain_view.call("rebuild")
	units.clear()
	vehicles.clear()
	turrets.clear()
	structs.clear()
	for arr in [grenades, smokes, barrages, jets, mines, charges, nukes, drops, ai_drones, beams, decals, alerts, airlifts, chutes, crates, salvos, rockets]:
		arr.clear()
	player_drone = null
	fx.clear()
	vfx.reset()
	radio_next = [0.0, 0.0, 0.0]
	combat.bullets.clear()
	kill_feed.clear()
	planner.reset()
	director.reset()
	air.reset()
	input.reset()
	screen = ""
	paused = false
	msg = ""
	msg_t = 0.0
	kills = 0
	deaths = 0
	streak = 0
	best_streak = 0
	flags_captured = 0
	tip = ""
	tutorial_t = 0.0
	vehicle_prompt = ""
	match_start = time
	var ticket_base: float = Cfg.TICKET_BASE + Cfg.TICKET_PER_AI * Cfg.AI_COUNT[prefs.ai_count]
	var mult: float = Cfg.LENGTH_MULT[prefs.match_length]
	tickets_max = [0, int(ticket_base * mult * Cfg.DIFF_TICKET_BLUE[prefs.difficulty]), int(ticket_base * mult * Cfg.DIFF_TICKET_RED[prefs.difficulty])]
	tickets = tickets_max.duplicate()
	for m in [1, 2]:
		var sgn := 1 if m == 1 else -1
		var base := Objectives.base_pos(m)
		var tower := Structure.create(Cfg.Item.TOWER, base + Vector2(0, -190), m)
		tower.hp = 300.0
		tower.max_hp = 300.0
		structs.append(tower)
		var station := Structure.create(Cfg.Item.DRONE_ST, base + Vector2(0, 190), m)
		station.hp = 150.0
		station.max_hp = 150.0
		structs.append(station)
		# v14: 7 kendaraan per markas dalam dua kolom (kolom dalam: HUMVEE, TANK, HUMVEE TOW, BRADLEY; kolom luar: APC, SPG, MEDEVAC)
		for k in 4:
			vehicles.append(Vehicle.create(k, _base_vehicle_pos(base, sgn, 150.0, (k - 1.5) * 230.0, k), m, 0.0 if m == 1 else PI))
		for j in 3:
			var kind: int = [Cfg.Veh.APC, Cfg.Veh.SPG, Cfg.Veh.MEDEVAC][j]
			vehicles.append(Vehicle.create(kind, _base_vehicle_pos(base, sgn, 330.0, (j - 1) * 260.0, kind), m, 0.0 if m == 1 else PI))
		for sy in [-1, 1]:
			turrets.append(Turret.create(0, base + Vector2(70 * sgn, sy * 100), m, 0.0 if m == 1 else PI))
	for m in [1, 2]:
		for i in mini(12, ai_cap()):
			spawn_ai(m)
	player = null
	respawn_t = 0.0
	selecting = true
	cam = Objectives.base_pos(1)
	zoom = 1.0
	mode = Mode.PLAY
	units_dirty = true
	_spawn_t = [0.0, 0.0, 0.0]
	_gov_down = 0.0
	_gov_up = 0.0
	_gov_wait = 60.0
	ai_scale = 1.0
	if prefs.quality == 0 and not OS.has_feature("mobile"):
		quality_level = 0
	fx.quality = quality_level
	prefs.matches += 1
	if decal_view != null:
		decal_view.call("clear")


## Posisi parkir kendaraan di markas. Bila tertutup bangunan, digeser menjauhi markas sampai bebas.
func _base_vehicle_pos(base: Vector2, sgn: int, dx: float, dy: float, kind: int) -> Vector2:
	var p := base + Vector2(dx * sgn, dy)
	var r := float(Cfg.VEH_RADIUS[kind]) + 6.0
	for k in 10:
		if not world.blocked(p, r):
			break
		p += Vector2(40.0 * sgn, 0.0)
	return p


func end_match() -> void:
	mode = Mode.OVER
	win = tickets[2] <= 0
	over_time = time
	match_duration = time - match_start
	prefs.play_seconds += match_duration
	if win:
		prefs.wins += 1
	prefs.best_kills = maxi(prefs.best_kills, kills)
	prefs.best_streak = maxi(prefs.best_streak, best_streak)
	prefs.deaths += deaths
	prefs.flags_taken += flags_captured
	prefs.save_all()
	input.reset()
	ui_sfx(5 if win else 9)


func go_menu() -> void:
	if mode == Mode.PLAY:
		prefs.play_seconds += time - match_start
	mode = Mode.MENU
	screen = "main"
	paused = false
	selecting = false
	player = null
	player_drone = null
	confirm_t = 0.0
	input.reset()
	# bersihkan sisa pertandingan supaya latar menu berupa peta kosong
	units.clear()
	vehicles.clear()
	turrets.clear()
	structs.clear()
	for arr in [grenades, smokes, barrages, jets, mines, charges, nukes, drops, ai_drones, beams, decals, alerts, airlifts, chutes, crates, salvos, rockets]:
		arr.clear()
	combat.bullets.clear()
	fx.clear()
	vfx.reset()
	for f in objectives.flags:
		f.capture = 0.0
		f.owner_team = 0
	prefs.save_all()


func set_pause(v: bool) -> void:
	paused = v
	input.reset()
	if v:
		screen = "pause"
		confirm_t = 0.0
		prefs.save_all()


func go_back() -> void:
	if screen == "set":
		screen = prev_screen
		prefs.save_all()
	elif screen == "pause":
		set_pause(false)
	else:
		screen = "main"


var _last_back := 0.0

func back_key() -> void:
	if time - _last_back < .25:
		return
	_last_back = time
	if menus != null and menus.call("close_overlay"):
		return
	if mode == Mode.PLAY:
		if selecting:
			return
		if paused:
			go_back()
		else:
			set_pause(true)
	elif mode == Mode.OVER:
		go_menu()
	else:
		if screen == "main":
			if menus != null and menus.get("info_open"):
				menus.set("info_open", false)
			else:
				get_tree().quit()
		else:
			go_back()


func _notification(what: int) -> void:
	match what:
		NOTIFICATION_WM_GO_BACK_REQUEST:
			back_key()
		NOTIFICATION_APPLICATION_PAUSED, NOTIFICATION_APPLICATION_FOCUS_OUT, NOTIFICATION_WM_WINDOW_FOCUS_OUT:
			if mode == Mode.PLAY and not selecting and not paused:
				set_pause(true)
			else:
				prefs.save_all()
		NOTIFICATION_WM_CLOSE_REQUEST:
			prefs.save_all()


# ================================================================ pemain
func pick_class(c: int) -> void:
	if Cfg.CLASS_NEED[c] > prefs.total_kills and not cheat("unl"):
		return
	last_class = c
	var pos: Vector2
	if spawn_choice >= 0 and spawn_choice < objectives.flags.size() and objectives.flags[spawn_choice].owner_team == 1:
		pos = objectives.flags[spawn_choice].pos + Vector2(randf_range(-70, 70), randf_range(-70, 70))
	else:
		spawn_choice = -1
		pos = Objectives.base_pos(1) + Vector2(randf_range(-90, 90), randf_range(-300, 300))
	var u := Unit.create(c, 1, false, pos)
	u.spawn_protect = 2.5
	units.append(u)
	player = u
	player_ctl.reset_for_class(c)
	selecting = false
	cam = pos
	input.reset()


func on_player_died() -> void:
	player = null
	respawn_t = 3.0
	streak = 0
	deaths += 1
	input.reset()


func register_kill(victim: Unit) -> void:
	kills += 1
	prefs.total_kills += 1
	streak += 1
	best_streak = maxi(best_streak, streak)
	kill_marker_t = .35
	ui_sfx(4)
	feed("ELIMINASI  " + Cfg.CLASS_NAMES[victim.cls], Color(1, .85, .3))
	if streak % Cfg.STREAK_REWARD_EVERY == 0:
		_streak_reward()


## v14: hadiah kill streak - bantuan radio langsung siap + poin bangun (tidak berlaku untuk AI).
func _streak_reward() -> void:
	var txt := "KILL STREAK x" + str(streak)
	if player != null:
		var had_cd := player.radio_cd > 0.0
		player.radio_cd = 0.0
		player.build_points += Cfg.STREAK_BUILD_POINTS
		if had_cd or Cfg.CLASS_ITEMS[player.cls].has(Cfg.Item.MLRS):
			txt += " - RADIO SIAP!"
		ui_sfx(5)
	say(txt, 2.5)


func on_flag_captured(f: Flag) -> void:
	var letter: String = "ABCDE"[f.index]
	if f.owner_team == 1:
		flags_captured += 1
		say("FLAG " + letter + " DIREBUT - TIM BIRU", 3.0)
		ui_sfx(5)
		ui_sfx(17)                                       # teriakan perang pasukan AS
	else:
		say("FLAG " + letter + " DIREBUT - MUSUH", 3.0)
		feed("FLAG " + letter + " DIREBUT MUSUH", Color(1, .4, .4))
		ui_sfx(18)                                       # teriakan perang pasukan Rusia


# ================================================================ spawn AI
func ai_class(team: int) -> int:
	var rr := randf()
	var c := 0 if rr < .62 else (1 if rr < .76 else (2 if rr < .88 else 3))
	var elapsed := time - match_start
	if elapsed < Cfg.AI_SPY_AFTER:
		return c
	var specials := 0
	for u in units:
		if u.is_ai and u.team == team and u.hp > 0.0 and (u.cls == Cfg.Cls.SPY or u.cls == Cfg.Cls.ELITE):
			specials += 1
	if specials >= Cfg.AI_MAX_SPECIAL:
		return c
	var f: float = [.6, 1.0, 1.5][prefs.difficulty]
	if randf() < .04 * f:
		return Cfg.Cls.SPY
	if elapsed >= Cfg.AI_ELITE_AFTER and randf() < .025 * f:
		return Cfg.Cls.ELITE
	return c


func spawn_ai(team: int, at: Vector2 = Vector2.INF) -> Unit:
	var cls := ai_class(team)
	var pos := at if at != Vector2.INF else planner.spawn_position(team)
	var u := Unit.create(cls, team, true, pos)
	u.stubborn = randf() < .3
	u.pace = randf_range(Cfg.AI_PACE.x, Cfg.AI_PACE.y)
	u.post = Objectives.base_pos(team).lerp(Objectives.base_pos(3 - team), randf_range(.12, .45)) + Vector2(0, randf_range(-500, 500))
	if cls == Cfg.Cls.ELITE:
		u.jammer_on = true
	units.append(u)
	planner.assign_new(u)
	units_dirty = true
	return u


## Muncul satu regu penuh di titik tertentu (dipakai Director: pasukan bantuan).
func spawn_squad_at(team: int, pos: Vector2, count: int) -> int:
	planner.close_open(team)
	var n := 0
	for i in count:
		var p := pos + Vector2(randf_range(-50, 50), randf_range(-50, 50))
		if world.blocked(p, 12.0):
			p = pos
		spawn_ai(team, p)
		tickets[team] -= 0           # bantuan gratis (tidak mengurangi tiket)
		n += 1
	planner.close_open(team)
	return n


func _update_spawns(dt: float) -> void:
	var cap := ai_cap()
	for m in [1, 2]:
		_spawn_t[m] -= dt
		if _spawn_t[m] <= 0.0 and tickets[m] > 0 and ai_alive[m] < cap:
			var deficit: int = cap - ai_alive[m]
			_spawn_t[m] = Cfg.AI_SPAWN_GAP * (.45 if deficit >= Cfg.SQUAD_SIZE * 2 else 1.0)
			spawn_ai(m)


# ================================================================ util dipakai banyak sistem
## Tabrakan lengkap: dunia + (untuk benda besar) tank trap & bunker.
func blocked(p: Vector2, r: float) -> bool:
	if world.blocked(p, r):
		return true
	if r > 20.0:
		for s in structs:
			if (s.kind == Cfg.Item.TRAP or s.kind == Cfg.Item.BUNKER) and s.pos.distance_squared_to(p) < (s.radius + r) * (s.radius + r):
				return true
	return false


func move_unit(u: Unit, d: Vector2) -> void:
	if d.length_squared() > .01:
		u.move_anim_t = .2
	if not world.blocked(Vector2(u.pos.x + d.x, u.pos.y), 11.0):
		u.pos.x += d.x
	if not world.blocked(Vector2(u.pos.x, u.pos.y + d.y), 11.0):
		u.pos.y += d.y


func threat_near(p: Vector2, team: int) -> bool:
	for o in units:
		if o.team != team and o.hp > 0.0 and o.pos.distance_squared_to(p) < 1210000.0:
			return true
	for v in vehicles:
		if v.team != team and not v.dead and v.pos.distance_squared_to(p) < 1210000.0:
			return true
	return false


func note_gunfire(p: Vector2) -> void:
	gunfire_events += 1
	if player != null and p.distance_squared_to(player.pos) < 810000.0:
		gunfire_t = 3.0


## dirty = false untuk bekas kecil yang sering muncul (hantaman peluru): tidak memicu gambar ulang langsung.
func add_decal(p: Vector2, radius: float, life: float, kind: int, color: Color, dirty := true) -> void:
	if world.bullet_hits_building(p):
		return                                   # tidak menggambar bekas di atas atap
	var d := BO.Mark.new()
	d.pos = p
	d.radius = radius
	d.life = life
	d.kind = kind
	d.color = color
	decals.append(d)
	if decals.size() > Cfg.MAX_DECALS:
		decals.pop_front()
	if dirty:
		decals_dirty = true


## src/blast: tewas karena ledakan -> tubuh terlempar menjauhi pusat ledakan dan mayatnya jatuh di sana.
func death_effects(u: Unit, src := Vector2.INF, blast := false) -> void:
	var at := vfx.body_launch(u, src) if (blast and src != Vector2.INF) else u.pos
	add_decal(at, 9.0, 22.0, 1, Cfg.TEAM_COLORS[u.team].darkened(.5))
	if quality_level < 2:
		add_decal(at + Vector2(randf_range(-6, 6), randf_range(-6, 6)), randf_range(7, 12), 26.0, 2, Color(.5, .05, .05))
	fx.spawn(u.pos, .5, 26, Color(1, .9, .9, .5), Fx.Type.RING)
	sfx(16, u.pos)


func say(text: String, seconds: float) -> void:
	msg = text
	msg_t = seconds


func feed(text: String, color: Color) -> void:
	kill_feed.append({"text": text, "color": color, "t": 3.5})
	if kill_feed.size() > 4:
		kill_feed.pop_front()


func sfx(n: int, p: Vector2) -> void:
	if audio != null:
		audio.call("sfx_at", n, p)


func ui_sfx(n: int) -> void:
	if audio != null:
		audio.call("sfx_ui", n)


func haptic(ms: int) -> void:
	if prefs.vibrate:
		Input.vibrate_handheld(ms)


# ================================================================ loop
func _process(delta: float) -> void:
	var dt := minf(delta, .05)
	time += dt
	frame += 1
	vs = get_viewport_rect().size
	if vs != _pvs:
		_pvs = vs
		_calc_margins()
	if loading_frames > 0:
		loading_frames -= 1
		if loading_frames == 0:
			start_match()
	if mode == Mode.PLAY and not paused:
		sim(dt)
	elif mode == Mode.MENU:
		cam = Vector2(Cfg.MAP_W * .5 + sin(time * .05) * 1400.0, Cfg.MAP_H * .5 + cos(time * .07) * 600.0)
		zoom = .8
	if audio != null:
		audio.call("tick", dt)
	_update_views()


func _update_views() -> void:
	if view_root == null:
		return
	var shake_off := Vector2.from_angle(randf() * TAU) * shake
	view_root.position = vs / 2.0 - cam * zoom + shake_off
	view_root.scale = Vector2(zoom, zoom)
	for v in [battle_view, air_view, decal_view, hud, menus]:
		v.call("refresh")


func _calc_margins() -> void:
	margin_l = 20.0
	margin_r = 20.0
	if not OS.has_feature("mobile"):
		return
	var ws := DisplayServer.window_get_size()
	if ws.x <= 0:
		return
	var sa := DisplayServer.get_display_safe_area()
	var kx := vs.x / float(ws.x)
	margin_l = maxf(20.0, sa.position.x * kx + 8.0)
	margin_r = maxf(20.0, (ws.x - sa.end.x) * kx + 8.0)


func _on_region_changed(r: Rect2) -> void:
	if terrain_view != null:
		terrain_view.call("invalidate", r)


# ================================================================ SIMULASI
func _p(name: String, t0: int) -> int:
	var now := Time.get_ticks_usec()
	var e: Array = prof.get(name, [0, 0])
	e[0] += now - t0
	e[1] = maxi(e[1], now - t0)
	prof[name] = e
	return now


func sim(dt: float) -> void:
	var tp := Time.get_ticks_usec() if profile_on else 0
	input.update()
	_governor(dt)
	ai_nav.budget = [3, 2, 1][quality_level]     # batas permintaan A* per frame (hindari lonjakan)
	fx.cam_pos = cam
	fx.zoom = zoom
	fx.quality = quality_level
	planner.update(dt)
	if profile_on: tp = _p("planner", tp)
	_update_spawns(dt)
	if player == null and not selecting:
		respawn_t -= dt
		if respawn_t <= 0.0:
			selecting = true
	director.update(dt)
	if profile_on: tp = _p("director+spawn", tp)
	# ---- prajurit
	var idx := 0
	var alive_ai := [0, 0, 0]
	var near_sq := 810000.0 if quality_level == 2 else 0.0
	for u in units:
		idx += 1
		if u.hp <= 0.0:
			continue
		infantry.tick(u, dt)
		if u.is_ai:
			alive_ai[u.team] += 1
			if cheat("frz"):
				continue
			var far := player != null and u.mount == null and u.pos.distance_squared_to(player.pos) > 3240000.0
			if quality_level > 0 and far:
				if (frame + idx) % 3 == 0:
					brain.update(u, dt * 3.0)
			elif quality_level == 2 and u.mount == null and (player == null or u.pos.distance_squared_to(player.pos) > near_sq):
				if (frame + idx) % 2 == 0:
					brain.update(u, dt * 2.0)
			else:
				brain.update(u, dt)
		else:
			player_ctl.update(u, dt)
	ai_alive = alive_ai
	if profile_on: tp = _p("units+ai", tp)
	for v in vehicles:
		vehicle_sys.update_vehicle(v, dt)
	for q in turrets:
		vehicle_sys.update_turret(q, dt)
	if profile_on: tp = _p("vehicles", tp)
	objectives.update(dt)
	if profile_on: tp = _p("objectives", tp)
	support.update_objects(dt)
	support.update_grenades(dt)
	support.update_barrages(dt)
	support.update_jets(dt)
	air.update(dt)
	if player_drone != null:
		if player == null or support.update_drone(player_drone, dt, input.move, input.aim.y):
			player_drone = null
	support.update_ai_drones(dt)
	if profile_on: tp = _p("support", tp)
	grid.rebuild(units)
	combat.update_bullets(dt)
	if profile_on: tp = _p("grid+bullets", tp)
	vfx.update(dt)
	fx.update(dt)
	_update_timers(dt)
	if units_dirty or frame % 45 == 0:
		var alive: Array[Unit] = []
		for u in units:
			if u.hp > 0.0:
				alive.append(u)
		units = alive
		units_dirty = false
	_update_camera(dt)
	_tutorial(dt)
	_prompt_t -= dt
	if _prompt_t <= 0.0:
		_prompt_t = .25
		vehicle_prompt = player_ctl.vehicle_prompt()
	if player != null and player.hp < player.max_hp * .3:
		_heartbeat_t -= dt
		if _heartbeat_t <= 0.0:
			_heartbeat_t = .9
			ui_sfx(8)
	if tickets[1] <= 0 or tickets[2] <= 0:
		end_match()


func _update_timers(dt: float) -> void:
	shake = maxf(0.0, shake - 25.0 * dt)
	hurt_flash = maxf(0.0, hurt_flash - 1.5 * dt)
	hit_marker_t = maxf(0.0, hit_marker_t - dt)
	kill_marker_t = maxf(0.0, kill_marker_t - dt)
	damage_dir_t = maxf(0.0, damage_dir_t - dt)
	gunfire_t = maxf(0.0, gunfire_t - dt)
	msg_t = maxf(0.0, msg_t - dt)
	var i := 0
	while i < alerts.size():
		alerts[i].t -= dt
		if alerts[i].t <= 0.0:
			alerts.remove_at(i)
		else:
			i += 1
	i = 0
	while i < kill_feed.size():
		kill_feed[i].t -= dt
		if kill_feed[i].t <= 0.0:
			kill_feed.remove_at(i)
		else:
			i += 1
	for d in decals:
		d.t += dt
	if decals_dirty or frame % 120 == 0:
		var keep: Array[BO.Mark] = []
		for d in decals:
			if d.t < d.life:
				keep.append(d)
		if keep.size() != decals.size():
			decals_dirty = true
		decals = keep


func _update_camera(dt: float) -> void:
	if player_drone != null:
		cam = cam.lerp(player_drone.pos, 8.0 * dt)
	elif player != null:
		var look := input.aim * 70.0
		if input.throwing and Cfg.ITEM_RANGE[player_ctl.item] >= 500:
			look = input.throw_vec * float(Cfg.ITEM_RANGE[player_ctl.item]) * .55
		cam = cam.lerp(player.pos + look, 6.0 * dt)
	zoom = lerpf(zoom, _zoom_target(), minf(1.0, 2.5 * dt))
	var vh := vs / (2.0 * zoom)
	if Cfg.MAP_W > vh.x * 2.0:
		cam.x = clampf(cam.x, vh.x, Cfg.MAP_W - vh.x)
	if Cfg.MAP_H > vh.y * 2.0:
		cam.y = clampf(cam.y, vh.y, Cfg.MAP_H - vh.y)


func _zoom_target() -> float:
	if input.throwing and player != null and player.mount == null and Cfg.ITEM_RANGE[player_ctl.item] >= 500:
		return .6
	if player_drone != null:
		return .9
	if prefs.zoom > 0:
		return Cfg.ZOOM_LEVELS[prefs.zoom]
	if player != null and player.mount is Vehicle:
		return Cfg.VEH_ZOOM[(player.mount as Vehicle).kind]
	return 1.0


func _tutorial(dt: float) -> void:
	if not prefs.tutorial or player == null or selecting:
		return
	tutorial_t += dt
	tip = ""
	for i in Cfg.TIPS.size():
		var tp: Array = Cfg.TIPS[i]
		if tutorial_t >= tp[0] and tutorial_t < tp[0] + 6.0:
			tip = tp[1]
			if i == 1 and prefs.fire_mode == 1:
				tip = "JEMPOL KANAN: bidik. Geser sedikit saja = menembak"
			elif i == 1 and prefs.fire_mode == 2:
				tip = "Sentuh tombol TEMBAK lalu geser untuk membidik"
	if tutorial_t > 40.0:
		prefs.tutorial = false
		prefs.save_all()


## Governor kualitas: bila FPS rendah 4 detik berturut-turut turunkan DETAIL (efek, frekuensi AI jauh).
## Hanya bila detail sudah terendah dan FPS tetap buruk, jumlah AI dikurangi sedikit (pilihan terakhir).
func _governor(dt: float) -> void:
	fps_avg = lerpf(fps_avg, 1.0 / maxf(dt, .0001), .04)
	if prefs.quality != 0 or time - match_start < 10.0:
		return
	var lo := 40.0 if prefs.fps_cap >= 60 else 24.0
	var hi := 56.0 if prefs.fps_cap >= 60 else 28.5
	if fps_avg < lo:
		_gov_up = 0.0
		_gov_down += dt
		if _gov_down > 4.0:
			_gov_down = 0.0
			if quality_level < 2:
				quality_level += 1
				_gov_block = time + _gov_wait
				_gov_wait = minf(_gov_wait * 2.0, 480.0)
			elif ai_scale > .65:
				ai_scale = maxf(.65, ai_scale - .1)
	else:
		_gov_down = 0.0
		if fps_avg > hi and time > _gov_block:
			_gov_up += dt
			if _gov_up > 20.0:
				_gov_up = 0.0
				if ai_scale < 1.0:
					ai_scale = minf(1.0, ai_scale + .1)
				elif quality_level > 0:
					quality_level -= 1
		else:
			_gov_up = 0.0


# ================================================================ input
func _input(e: InputEvent) -> void:
	if e is InputEventKey and e.pressed and not e.echo:
		if e.keycode == KEY_P or (e.keycode == KEY_ESCAPE and not OS.has_feature("mobile")):
			back_key()
		else:
			input.key_pressed(e)
	elif e is InputEventScreenTouch:
		if e.pressed:
			_touch_down(e.index, e.position)
		else:
			_touch_up(e.index)
	elif e is InputEventScreenDrag:
		_touch_drag(e.index, e.position)


func _touch_down(index: int, p: Vector2) -> void:
	if menus != null and menus.call("overlay_touch", p):
		return
	if mode != Mode.PLAY or paused or selecting:
		if menus != null:
			menus.call("tap", p, index)
		return
	input.touch_down(index, p)


func _touch_up(index: int) -> void:
	if menus != null:
		menus.call("release", index)
	input.touch_up(index)


func _touch_drag(index: int, p: Vector2) -> void:
	if menus != null:
		menus.call("drag", p, index)
	input.touch_drag(index, p)
