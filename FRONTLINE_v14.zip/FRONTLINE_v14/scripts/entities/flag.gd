class_name Flag
extends RefCounted
## Bendera rebutan. capture: -1 (milik merah penuh) .. +1 (milik biru penuh).

var pos := Vector2.ZERO
var capture := 0.0
var owner_team := 0            # 0 netral, 1 biru, 2 merah
var index := 0                 # 0..4 = huruf A..E
