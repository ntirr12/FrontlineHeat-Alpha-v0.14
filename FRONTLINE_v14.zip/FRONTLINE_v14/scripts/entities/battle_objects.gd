class_name BO
extends RefCounted
## Benda-benda kecil di medan perang. Dikumpulkan di satu file supaya mudah dicari.

class Grenade:
	var pos := Vector2.ZERO
	var from := Vector2.ZERO
	var dest := Vector2.ZERO
	var t := 0.0
	var kind := 0              # 0 granat, 1 flashbang, 2 smoke (memanggil airstrike)
	var team := 0
	var by_player := false

class Smoke:
	var pos := Vector2.ZERO
	var radius := 110.0
	var t := 14.0              # sisa umur (detik)

class Barrage:                 # serangan udara/artileri: serangkaian ledakan
	var pos := Vector2.ZERO
	var t := 0.0
	var fired := 0
	var count := 26
	var radius := 260.0
	var team := 0
	var by_player := false
	var carpet := false        # false = acak di area, true = garis karpet
	var dir := Vector2.RIGHT
	var jet_played := false
	var ambient := false       # true = kejadian acak director (tanpa jet suara berulang)
	var damage := 170.0        # kerusakan per ledakan (pusat)

class Mine:
	var pos := Vector2.ZERO
	var team := 0
	var by_player := false

class Charge:                  # C4
	var pos := Vector2.ZERO
	var t := 6.0
	var team := 0
	var by_player := false

class Nuke:
	var pos := Vector2.ZERO
	var t := 0.0
	var by_player := false

class Drop:                    # paket udara yang turun dengan parasut
	var pos := Vector2.ZERO
	var t := 0.0
	var kind := 0              # nilai Cfg.Item: DROP_MG, DROP_TOW, DROP_VEH
	var team := 0

class Drone:                   # drone FPV (milik pemain atau AI)
	var pos := Vector2.ZERO
	var home := Vector2.ZERO
	var alt := 40.0
	var team := 0
	var crash := false
	var signal_q := 1.0        # kualitas sinyal 0..1
	var target: Unit = null
	var done := false
	var player_owned := false  # true = dikendalikan pemain (FPV)

class Beam:                    # sinar railgun
	var a := Vector2.ZERO
	var b := Vector2.ZERO
	var t := 0.35

class Mark:                   # bekas ledakan / mayat di tanah
	var pos := Vector2.ZERO
	var radius := 10.0
	var t := 0.0
	var life := 30.0
	var kind := 0              # 0 kawah, 1 mayat, 2 darah
	var color := Color.BLACK

class Jet:                     # jet lewat (visual + bom). Hanya hiasan bila bombs == 0
	var pos := Vector2.ZERO
	var dir := Vector2.RIGHT
	var speed := 900.0
	var life := 5.0
	var bombs := 0
	var team := 0
	var bomb_t := 0.0

# ---------------------------------------------------------------- v14: bantuan udara & artileri
class Airlift:                 # C-17 yang melintas lalu menerjunkan regu (dan peti suplai)
	var pos := Vector2.ZERO    # posisi pesawat
	var dir := Vector2.RIGHT
	var dz := Vector2.ZERO     # titik terjun (pusat sasaran)
	var team := 0
	var by_player := false
	var troops := 6            # sisa penerjun yang belum keluar
	var total := 6             # jumlah penerjun awal
	var batch := 0             # id rombongan (untuk membentuk regu setelah mendarat)
	var crates := 1            # sisa peti suplai yang belum dijatuhkan
	var jump_t := 0.0          # hitung mundur sampai penerjun berikutnya keluar
	var passed := false        # sudah melewati titik terjun?
	var life := 9.0

class Chute:                   # satu penerjun yang melayang turun (jadi prajurit AI saat mendarat)
	var pos := Vector2.ZERO    # titik mendarat di tanah
	var start := Vector2.ZERO  # posisi saat keluar dari pesawat (tanah di bawahnya)
	var t := 0.0
	var fall := 3.4            # lama melayang (detik)
	var team := 0
	var phase := 0.0           # fase ayunan kanopi
	var crate := false         # true = membawa peti suplai (bukan prajurit)
	var batch := 0             # id rombongan pesawat asal

class Crate:                   # peti suplai di tanah: sembuhkan + isi ulang prajurit sekutu yang menyentuhnya
	var pos := Vector2.ZERO
	var team := 0
	var kind := 0              # 0 medis, 1 amunisi
	var t := 0.0               # umur
	var drop_t := 0.0          # >0 = masih jatuh dari udara (belum bisa diambil)

class Salvo:                   # satu panggilan MLRS: peluncur bersiap, lalu menembakkan roket satu per satu
	var pos := Vector2.ZERO    # pusat sasaran
	var origin := Vector2.ZERO # posisi peluncur
	var dir := Vector2.RIGHT   # arah dari peluncur ke sasaran
	var team := 0
	var by_player := false
	var t := 0.0
	var fired := 0
	var count := 18
	var radius := 250.0
	var ambient := false       # true = kejadian acak director

class Rocket:                  # satu roket yang sedang terbang menuju titik hantam
	var from := Vector2.ZERO
	var to := Vector2.ZERO
	var t := 0.0
	var flight := 2.0          # lama terbang (detik)
	var arc := 120.0           # tinggi lengkung (px)
	var team := 0
	var by_player := false
	var trail_t := 0.0
	var whistled := false      # desing sebelum jatuh sudah dimainkan?

class Alert:                   # zona bahaya yang harus dihindari AI (granat, airstrike, nuke, C4)
	var pos := Vector2.ZERO
	var radius := 100.0
	var t := 3.0
	var team := 0              # tim pembuat bahaya (AI sekutu tidak lari dari bahaya sendiri)
