class_name Entity
extends RefCounted
## Induk semua benda yang punya posisi, tim, dan nyawa:
## prajurit (Unit), kendaraan (Vehicle), turret (Turret), bangunan (Structure).
## Karena semuanya punya `pos`, `team`, `hp`, AI bisa menjadikan apa pun sebagai target.

var pos := Vector2.ZERO
var team := 0            # 0 = netral, 1 = BIRU (pemain), 2 = MERAH (musuh)
var hp := 100.0
var max_hp := 100.0


func is_alive() -> bool:
	return hp > 0.0
