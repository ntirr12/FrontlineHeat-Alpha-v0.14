class_name Unit
extends Entity
## Satu prajurit (pemain ATAU AI). Bidang dikelompokkan per topik agar mudah dicari.

# ---- identitas
var cls := 0                   # divisi, enum Cfg.Cls
var is_ai := true
var angle := 0.0               # arah hadap (radian)

# ---- senjata & amunisi
var weapon := 0                # 0 senjata utama, 1 senjata kedua (M203 / pistol / Javelin / pisau)
var ammo := 30
var reload_t := 0.0            # >0 = sedang reload
var fire_cd := 0.0             # jeda tembak
var javelin := 0               # sisa Javelin
var javelin_max := 0
var javelin_regen := 0.0
var lock_t := 0.0              # progres lock Javelin (detik)
var lock_target: Entity = null
var m203 := 4                  # sisa peluru M203 (Assault)
var m203_regen := 0.0
var grenades: Array[int] = [3, 0, 0, 0]   # [granat, flashbang, smoke, ranjau]
var grenade_regen := 0.0
var c4 := 0
var heat := 0.0                # Juggernaut: panas minigun
var overheated := false

# ---- status tempur
var in_cover := false          # sedang berlindung di balik tembok
var in_bunker := false
var exposed_t := 0.0           # >0 = baru menembak (peluru tak bisa diblokir cover)
var shot_t := 0.0              # >0 = baru menembak (terlihat dari jauh)
var alert_t := 0.0             # >0 = baru kena tembak (terlihat musuh)
var flash_t := 0.0             # >0 = terkena flashbang
var spawn_protect := 0.0       # kebal sementara setelah respawn (pemain)
var regen_t := 0.0             # detik sejak terakhir terluka
var move_anim_t := 0.0         # >0 = sedang berjalan (animasi kaki)
var radio_cd := 0.0            # cooldown radio airstrike
var build_points := 60.0       # poin bangun (Engineer/Elite)
var seat := 0                  # 0 pengemudi, 1 penembak (di kendaraan)

# ---- skill khusus
var disguise_t := 0.0          # Spy: sisa waktu samaran
var skill_cd := 0.0
var suspicion := 0.0
var sabotage_target: Entity = null
var sabotage_t := 0.0
var jammer_on := false         # Elite

# ---- kendaraan yang dinaiki
var mount: Platform = null

# ---- otak AI (hanya dipakai bila is_ai)
var state := 0                 # enum AiBrain.State
var role := 0                  # 0 penyerbu, 1 pejuang berlindung, 2 penjaga
var squad: Squad = null
var target: Entity = null      # musuh yang sedang dibidik
var last_known := Vector2.ZERO # posisi terakhir musuh terlihat
var has_last_known := false
var scan_t := 0.0              # hitung mundur sebelum berpikir lagi
var memory_t := 0.0            # berapa lama masih ingat target
var can_see := false           # target sedang terlihat jelas?
var react_t := 0.0             # waktu reaksi sebelum mulai menembak target baru
var burst_left := 0            # sisa peluru dalam rentetan
var burst_pause := 0.0
var strafe_dir := 1.0
var strafe_t := 0.0
var cover_pos := Vector2.ZERO
var has_cover := false
var peek_t := 0.0
var peeking := true
var goal := Vector2.ZERO       # tujuan dari perencana / regu
var flag_goal := -1            # indeks bendera tujuan (-1 = markas musuh/tidak ada)
var post := Vector2.ZERO       # titik jaga (role penjaga)
var board_target: Platform = null
var board_cd := 0.0
var turret_idle_t := 0.0
var repair_t := 0.0
var repair_target: Entity = null
var danger_flee := Vector2.ZERO
var danger_t := 0.0
var think_acc := 0.0           # akumulasi dt untuk berpikir berkala
var hurt_from := Vector2.ZERO  # arah penembak terakhir
var hurt_t := 0.0
var retreating := false
var retreat_t := 0.0           # sisa waktu maksimum mundur
var retreat_pos := Vector2.ZERO
var stubborn := false          # keras kepala: tidak pernah mundur
var sep := Vector2.ZERO        # dorongan menjauh dari teman yang terlalu dekat
var wander_t := 0.0
var wander_pos := Vector2.ZERO
var grenade_cd := 0.0
var scan_phase := 0.0          # sudut sapuan saat berjaga

# ---- taktik v13
var suppress := 0.0            # tekanan tembakan 0..1.5 (peluru nyaris kena / ledakan dekat). Tinggi = merunduk & kurang akurat
var pace := 1.0                # variasi kecepatan jalan pribadi (agar regu tidak berbaris seragam)
var pause_t := 0.0             # >0 = berhenti sejenak, waspada menyapu pandangan
var flank_pos := Vector2.ZERO  # titik tujuan manuver mengitari musuh
var flank_t := 0.0             # >0 = sedang mengitari
var aim_point := Vector2.INF   # titik yang sedang dibidik AI (dipakai agar peluru yang meleset jatuh di sekitarnya)

# ---- navigasi
var path := PackedVector2Array()
var path_i := 0
var path_goal := Vector2.ZERO
var path_refresh := 0.0
var direct_t := 0.0            # timer cek garis lurus
var direct_ok := false
var stuck_count := 0
var stuck_timer := 0.0
var last_pos := Vector2.ZERO
var side_t := 0.0              # menyamping saat macet
var side_sign := 1.0
var slot_id := 0               # nomor unik (untuk stagger & formasi)


static var _next_id := 1

static func create(c: int, tm: int, ai: bool, p: Vector2) -> Unit:
	var u := Unit.new()
	u.cls = c
	u.team = tm
	u.is_ai = ai
	u.pos = p
	u.last_pos = p
	u.angle = 0.0 if tm == 1 else PI
	u.max_hp = Cfg.CLASS_HP[c]
	u.hp = u.max_hp
	u.slot_id = _next_id
	_next_id += 1
	var is_destroyer := c == Cfg.Cls.DESTROYER
	u.javelin_max = 5 if is_destroyer else (4 if c == Cfg.Cls.ELITE else 0)
	u.javelin = u.javelin_max
	u.grenades = [
		2 if is_destroyer else 3,
		2 if (c == Cfg.Cls.ASSAULT or c == Cfg.Cls.SUPPORT or c == Cfg.Cls.ELITE or c == Cfg.Cls.SECRET) else 0,
		1 if (c == Cfg.Cls.ASSAULT or c == Cfg.Cls.ENGINEER or c == Cfg.Cls.SPY or c == Cfg.Cls.ELITE or c == Cfg.Cls.SECRET) else 0,
		5 if is_destroyer else (3 if (c == Cfg.Cls.SPY or c == Cfg.Cls.ELITE) else 0)]
	u.c4 = 3 if c == Cfg.Cls.SPY else (2 if c == Cfg.Cls.ELITE else 0)
	u.role = randi() % 3
	return u


func has_javelin_class() -> bool:
	return javelin_max > 0
