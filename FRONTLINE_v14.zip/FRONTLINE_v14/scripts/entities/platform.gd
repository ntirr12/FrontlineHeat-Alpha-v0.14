class_name Platform
extends Entity
## Induk Vehicle & Turret: sesuatu yang bisa ditumpangi prajurit, punya senjata
## berputar, dan bisa hancur lalu hidup lagi (respawn).

var dead := false
var respawn_t := 0.0
var driver: Unit = null        # prajurit yang mengendalikan (boleh pemain atau AI)
var aim := 0.0                 # arah laras (radian)
var cooldown := 0.0            # jeda tembak
var shot_t := 0.0              # >0 = baru menembak (kelihatan dari jauh)


func is_alive() -> bool:
	return not dead
