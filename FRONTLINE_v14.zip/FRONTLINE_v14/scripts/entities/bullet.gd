class_name Bullet
extends RefCounted
## Satu peluru/rudal. Objek ini didaur ulang (pool) agar tidak membebani memori.
## v13: peluru bergerak lewat SEGMEN (prev -> pos) sehingga tidak bisa "menembus" sasaran antar-frame.

var pos := Vector2.ZERO
var prev := Vector2.ZERO       # posisi frame lalu (awal segmen tabrakan)
var vel := Vector2.ZERO
var team := 0
var kind := 0                  # enum Cfg.Bul
var life0 := 1.0               # v14: umur awal (untuk menghitung tinggi lengkung peluru artileri)
var life := 1.0                # sisa umur. Peluru yang membidik sasaran diberi umur pas sampai "tanah" di sekitar sasaran
var target: Entity = null      # Javelin: musuh yang dikejar. TOW: kendaraan penembak (dituntun arah larasnya)
var by_player := false
var cover_roll := -1           # -1 belum dilempar dadu; 0 = meleset dari yang berlindung; 1 = kena
var dmg_mult := 1.0            # pengali kerusakan (senapan mesin kendaraan lebih kuat dari senapan prajurit)
var supp_last: Unit = null     # prajurit terakhir yang sudah ditekan peluru ini (agar tidak dihitung dua kali)
