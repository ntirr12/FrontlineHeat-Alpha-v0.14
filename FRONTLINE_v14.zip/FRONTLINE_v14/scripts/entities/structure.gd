class_name Structure
extends Entity
## Bangunan statis yang bisa dihancurkan.
## `kind` memakai nilai Cfg.Item: WIRE, TRAP, TOWER, DRONE_ST, JAMMER, BUNKER.

var kind := 0
var radius := 20.0
var timer := 0.0               # serbaguna: cooldown stasiun drone / jeda kawat

static func create(k: int, p: Vector2, tm: int) -> Structure:
	var s := Structure.new()
	s.kind = k
	s.pos = p
	s.team = tm
	match k:
		Cfg.Item.WIRE: s.max_hp = 80.0; s.radius = 34.0
		Cfg.Item.TRAP: s.max_hp = 150.0; s.radius = 34.0
		Cfg.Item.TOWER: s.max_hp = 220.0; s.radius = 16.0
		Cfg.Item.DRONE_ST: s.max_hp = 120.0; s.radius = 18.0
		Cfg.Item.JAMMER: s.max_hp = 120.0; s.radius = 9.0
		_: s.max_hp = 420.0; s.radius = 55.0   # bunker
	s.hp = s.max_hp
	return s
