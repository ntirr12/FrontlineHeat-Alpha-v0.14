class_name Fx
extends RefCounted
## Satu partikel efek visual (letupan, asap, percikan). Didaur ulang lewat pool.
## PUFF..SPARK = efek vektor lama. EXPLOSION, MUZZLE, BLOOD = efek bersprite (bila atlas tidak ada,
## otomatis digambar sebagai PUFF). MUZZLE memakai `vel` sebagai ARAH tembakan.
## v13 menambah: DUST (debu hantaman), FLAME (semburan api), DEBRIS (serpihan), TURRET (turret terlempar),
## BODY (prajurit terlempar ledakan), FLASH (kilatan terang, digambar aditif), EMBER (bara).
## Untuk SPARK/FLAME/DEBRIS/TURRET/BODY/DUST: `vel` = TOTAL perpindahan selama umur efek (bukan kecepatan per detik),
## jadi pool tidak perlu mengintegrasikan posisi tiap frame (hemat CPU).
enum Type { PUFF, RING, SMOKE, SPARK, EXPLOSION, MUZZLE, BLOOD, DUST, FLAME, DEBRIS, TURRET, BODY, FLASH, EMBER }
const TYPE_COUNT := 14
## Efek kecil yang boleh dibuang lebih dulu saat pool hampir penuh (urutan = enum Type).
const LOW_PRIORITY := [true, false, false, true, false, false, true, true, false, true, false, false, false, true]

var pos := Vector2.ZERO
var t := 0.0                   # umur sekarang
var life := 1.0
var radius := 10.0
var color := Color.WHITE
var type := 0
var vel := Vector2.ZERO
var rot := 0.0                 # sudut awal (TURRET/BODY/DEBRIS)
var spin := 0.0                # putaran total selama umur efek (rad)
var aux := 0                   # TURRET: jenis kendaraan (Cfg.Veh)
var aux2 := 0                  # TURRET: tim
