class_name Turret
extends Platform
## Turret tetap (MG kembar atau TOW). Dibangun engineer / diturunkan lewat drop.

var type := 0                  # 0 = MG kembar, 1 = TOW
var alt := false               # bergantian laras kiri/kanan


static func create(ty: int, p: Vector2, tm: int, angle: float) -> Turret:
	var q := Turret.new()
	q.type = ty
	q.pos = p
	q.team = tm
	q.aim = angle
	q.max_hp = 250.0
	q.hp = 250.0
	return q
