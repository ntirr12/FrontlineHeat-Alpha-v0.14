class_name Vehicle
extends Platform
## Kendaraan beroda/rantai. `kind` memakai enum Cfg.Veh.

var kind := 0
var heading := 0.0             # arah badan
var speed := 0.0               # kecepatan maju (px/detik)
var home := Vector2.ZERO       # titik markas untuk respawn / dikembalikan saat macet
var weapon := 0                # senjata aktif (0 atau 1)
var gunner: Unit = null        # penembak kursi ke-2 (tank/bradley)
var gunner_aim := 0.0          # arah senapan mesin penembak
var gunner_cd := 0.0           # jeda tembak penembak
var burn_t := 0.0              # detik sejak hancur (mengatur semburan api & asap bangkai)
var crush_cd := 0.0            # jeda antar lindasan
var fx_t := 0.0                # penghitung waktu asap/api saat rusak
var skill_cd := 0.0            # v14: jeda skill kendaraan (BOOST atau TIRAI ASAP, tombol SKILL)
var boost_t := 0.0             # v14: sisa detik boost kecepatan
var heal_t := 0.0              # v14: MEDEVAC - penghitung denyut penyembuhan
var dust_t := 0.0              # v14: penghitung debu roda/rantai
var pulse := 0.0               # v14: kilau cincin penyembuhan MEDEVAC (0..1, hanya tampilan)


static func create(k: int, p: Vector2, tm: int, angle: float) -> Vehicle:
	var v := Vehicle.new()
	v.kind = k
	v.pos = p
	v.home = p
	v.team = tm
	v.heading = angle
	v.aim = angle
	v.max_hp = Cfg.VEH_HP[k]
	v.hp = v.max_hp
	return v


func radius() -> float:
	return float(Cfg.VEH_RADIUS[kind])


## Kendaraan ini punya senjata? (MEDEVAC tidak bersenjata.)
func armed() -> bool:
	return kind != Cfg.Veh.MEDEVAC


## Masih ada kursi kosong untuk penembak (kursi ke-2)?
func has_free_gunner_seat() -> bool:
	return Cfg.VEH_SEATS[kind] > 1 and gunner == null
