class_name TouchInput
extends RefCounted
## INPUT SENTUH & KEYBOARD. Hasil akhirnya hanya 5 nilai yang dibaca PlayerCtl:
##   move   : arah jalan (-1..1)
##   aim    : arah bidik (panjang > 0.2 = sedang membidik)
##   fire   : sedang menembak?
##   throwing / throw_vec : tombol LEMPAR sedang ditahan & arah geserannya
##   fire_hold_no_aim : tombol TEMBAK ditekan tanpa digeser (tembak ke arah hadap)
##
## GAYA ANALOG (Pengaturan > Kontrol):
##   MELAYANG : pusat analog muncul di tempat jempol menyentuh (analog gerak ikut jempol).
##   TETAP    : analog berada di posisi tetap di layar; sentuh di dekatnya untuk memakainya.
## MODE TEMBAK:
##   MENTOK : dorong analog bidik sampai tepi = menembak.
##   SENTUH : geser sedikit saja = menembak.
##   TOMBOL : tombol TEMBAK terpisah; sentuh lalu geser untuk membidik sambil menembak (satu jempol).

enum Role { MOVE, AIM, FIRE }

class Touch:
	var role := 0
	var base := Vector2.ZERO       # pusat analog
	var pos := Vector2.ZERO        # posisi jempol sekarang

var g: Game
var move := Vector2.ZERO
var aim := Vector2.ZERO
var fire := false
var fire_hold_no_aim := false
var throwing := false
var throw_vec := Vector2.ZERO
var touches: Dictionary = {}       # index sentuhan -> Touch
var _throw_index := -1
var _throw_pos := Vector2.ZERO


func _init(game: Game) -> void:
	g = game


func reset() -> void:
	touches.clear()
	throwing = false
	_throw_index = -1
	move = Vector2.ZERO
	aim = Vector2.ZERO
	fire = false
	fire_hold_no_aim = false
	throw_vec = Vector2.ZERO


# ================================================================ tata letak (dipakai juga oleh HUD)
func scale_factor() -> float:
	return Cfg.CTL_SCALE[g.prefs.control_size]


func button_radius() -> float:
	return Cfg.BASE_BUTTON_R * scale_factor()


func stick_radius() -> float:
	return Cfg.STICK_RADIUS * scale_factor()


func pause_pos() -> Vector2:
	return Vector2(g.vs.x - g.margin_r - 40.0, 44.0)


func button_pos(i: int) -> Vector2:
	var br := button_radius()
	var gap := br * 2.4
	return Vector2(g.vs.x - g.margin_r - br - 12.0 - (0.0 if i < 3 else (gap if i < 6 else gap * 2.0)), 150.0 + (i % 3) * gap)


func fire_radius() -> float:
	return button_radius() * 1.6


func fire_pos() -> Vector2:
	var fr := fire_radius()
	return Vector2(g.vs.x - g.margin_r - fr - 14.0, g.vs.y - fr - 24.0)


func move_base() -> Vector2:
	var r := stick_radius()
	return Vector2(maxf(g.margin_l, 20.0) + r * 1.5 + 24.0, g.vs.y - r * 1.5 - 36.0)


func aim_base() -> Vector2:
	var r := stick_radius()
	return Vector2(g.vs.x * .62, g.vs.y - r * 1.5 - 36.0)


func fire_button_visible() -> bool:
	return g.prefs.fire_mode == 2


# ================================================================ peristiwa sentuh
## Mengembalikan true bila sentuhan dipakai oleh kontrol permainan.
func touch_down(index: int, p: Vector2) -> bool:
	if p.distance_to(pause_pos()) < 48.0:
		g.set_pause(true)
		g.ui_sfx(6)
		return true
	var br := button_radius()
	for i in 7:
		if p.distance_to(button_pos(i)) < br + 8.0:
			g.haptic(12)
			if i == 4:
				throwing = true
				_throw_index = index
				_throw_pos = p
			else:
				g.player_ctl.action(i)
			return true
	if fire_button_visible() and p.distance_to(fire_pos()) < fire_radius() + 10.0:
		var t := Touch.new()
		t.role = Role.FIRE
		t.base = fire_pos()
		t.pos = p
		touches[index] = t
		g.haptic(8)
		return true
	var left := p.x < g.vs.x * .5
	var t2 := Touch.new()
	t2.role = Role.MOVE if left else Role.AIM
	t2.pos = p
	if g.prefs.stick_style == 1:                     # TETAP: harus menyentuh di dekat analog
		t2.base = move_base() if left else aim_base()
		if p.distance_to(t2.base) > stick_radius() * 2.2:
			return false
	else:
		t2.base = p
	touches[index] = t2
	return true


func touch_up(index: int) -> void:
	touches.erase(index)
	if index == _throw_index:
		throwing = false
		_throw_index = -1
		if g.mode == Game.Mode.PLAY and not g.paused:
			g.player_ctl.release_throw(throw_vec)
		throw_vec = Vector2.ZERO


func touch_drag(index: int, p: Vector2) -> void:
	if index == _throw_index:
		_throw_pos = p
	if touches.has(index):
		(touches[index] as Touch).pos = p


## Dipanggil sekali per frame sebelum pemain diproses.
func update() -> void:
	move = Vector2.ZERO
	aim = Vector2.ZERO
	fire = false
	fire_hold_no_aim = false
	var r := stick_radius()
	var mode := g.prefs.fire_mode
	for t: Touch in touches.values():
		var dv := t.pos - t.base
		match t.role:
			Role.MOVE:
				if g.prefs.stick_style == 0 and dv.length() > r:    # melayang: pusat mengikuti jempol
					t.base = t.pos - dv.limit_length(r)
					dv = t.pos - t.base
				move = _stick(dv, r)
			Role.AIM:
				aim = _stick(dv, r)
				if mode == 0 and aim.length() > .96:
					fire = true
				elif mode == 1 and aim.length() > .4:
					aim = aim.normalized()
					fire = true
			Role.FIRE:
				fire = true
				if dv.length() > 14.0:
					aim = dv.normalized()
				else:
					fire_hold_no_aim = true
	if move == Vector2.ZERO:                                          # keyboard (desktop)
		var kv := Vector2(int(Input.is_key_pressed(KEY_D)) - int(Input.is_key_pressed(KEY_A)),
			int(Input.is_key_pressed(KEY_S)) - int(Input.is_key_pressed(KEY_W)))
		if kv != Vector2.ZERO:
			move = kv.normalized()
	if throwing:
		throw_vec = ((_throw_pos - button_pos(4)) / 90.0).limit_length(1.0)
		aim = Vector2.ZERO
		fire = false


func _stick(dv: Vector2, r: float) -> Vector2:
	var dz: float = Cfg.DEADZONE[g.prefs.deadzone]
	var l := dv.length() / r
	if l < dz:
		return Vector2.ZERO
	return dv.normalized() * minf(1.0, (l - dz) / (1.0 - dz))


# ================================================================ keyboard
func key_pressed(e: InputEventKey) -> void:
	if g.mode != Game.Mode.PLAY or g.paused:
		return
	if g.selecting:
		if e.keycode >= KEY_1 and e.keycode <= KEY_8:
			g.pick_class(e.keycode - KEY_1)
		return
	var map := {KEY_Q: 0, KEY_E: 1, KEY_C: 2, KEY_G: 3, KEY_R: 5, KEY_SPACE: 6}
	if map.has(e.keycode):
		g.player_ctl.action(map[e.keycode])
	if e.keycode == KEY_F and g.player != null:
		var mouse_dir := ((g.get_viewport().get_mouse_position() - g.vs / 2.0) / 420.0).limit_length(1.0)
		g.player_ctl.release_throw(mouse_dir)
