class_name Prefs
extends RefCounted
## PENGATURAN PEMAIN + PROFIL (statistik/total kill). Disimpan di user://f.cfg.
## Nama bagian/kunci lama dipertahankan agar save dari versi sebelumnya tetap terbaca.

# ---- suara & grafik
var sfx_vol := .8
var music_vol := .5
var vibrate := true
var show_fps := false
var fps_cap := 60
var quality := 0               # 0 AUTO, 1 TINGGI, 2 SEDANG, 3 RENDAH
var resolution := 0            # 0 AUTO, 1 TAJAM, 2 HEMAT (render 720p lalu diperbesar)
# ---- kontrol
var fire_mode := 0             # 0 MENTOK, 1 SENTUH, 2 TOMBOL (tombol tembak yang bisa diseret untuk membidik)
var aim_assist := 1
var zoom := 0
var control_size := 1
var stick_style := 0           # 0 MELAYANG, 1 TETAP
var deadzone := 1
var aim_speed := 0             # 0 CEPAT, 1 SEDANG, 2 LAMBAT (kecepatan putar bidik)
var control_alpha := 1.0       # transparansi kontrol 0.3..1
var auto_fire := false         # menembak otomatis bila musuh tepat di garis bidik
var tutorial := true
# ---- misi
var difficulty := 1
var biome := 0
var ai_count := 2              # indeks Cfg.AI_COUNT
var match_length := 1
var chaos := 1

# ---- profil
var total_kills := 0
var deaths := 0
var matches := 0
var wins := 0
var flags_taken := 0
var play_seconds := 0.0
var best_streak := 0
var best_kills := 0


func clamp_all() -> void:
	difficulty = clampi(difficulty, 0, 2)
	biome = clampi(biome, 0, 3)
	fire_mode = clampi(fire_mode, 0, 2)
	aim_assist = clampi(aim_assist, 0, 2)
	zoom = clampi(zoom, 0, 3)
	control_size = clampi(control_size, 0, 2)
	stick_style = clampi(stick_style, 0, 1)
	deadzone = clampi(deadzone, 0, 2)
	aim_speed = clampi(aim_speed, 0, 2)
	quality = clampi(quality, 0, 3)
	resolution = clampi(resolution, 0, 2)
	ai_count = clampi(ai_count, 0, 3)
	match_length = clampi(match_length, 0, 2)
	chaos = clampi(chaos, 0, 2)
	fps_cap = 30 if fps_cap < 45 else 60
	sfx_vol = clampf(sfx_vol, 0.0, 1.0)
	music_vol = clampf(music_vol, 0.0, 1.0)
	control_alpha = clampf(control_alpha, 0.3, 1.0)


func load_all() -> void:
	var cf := ConfigFile.new()
	if cf.load(Cfg.SAVE_PATH) != OK:
		return
	total_kills = cf.get_value("a", "k", 0)
	sfx_vol = cf.get_value("s", "sv", sfx_vol)
	music_vol = cf.get_value("s", "mv", music_vol)
	vibrate = cf.get_value("s", "vib", vibrate)
	fire_mode = cf.get_value("s", "fm", fire_mode)
	aim_assist = cf.get_value("s", "aa", aim_assist)
	zoom = cf.get_value("s", "zm", zoom)
	control_size = cf.get_value("s", "hs", control_size)
	fps_cap = cf.get_value("s", "fps", fps_cap)
	quality = cf.get_value("s", "q", quality)
	show_fps = cf.get_value("s", "sf", show_fps)
	tutorial = cf.get_value("s", "tut", tutorial)
	difficulty = cf.get_value("s", "df", difficulty)
	biome = cf.get_value("s", "bm", biome)
	# kunci baru v11
	stick_style = cf.get_value("s", "stick_style", stick_style)
	deadzone = cf.get_value("s", "deadzone", deadzone)
	aim_speed = cf.get_value("s", "aim_speed", aim_speed)
	control_alpha = cf.get_value("s", "control_alpha", control_alpha)
	auto_fire = cf.get_value("s", "auto_fire", auto_fire)
	resolution = cf.get_value("s", "resolution", resolution)
	ai_count = cf.get_value("s", "ai_count", ai_count)
	match_length = cf.get_value("s", "match_length", match_length)
	chaos = cf.get_value("s", "chaos", chaos)
	deaths = cf.get_value("p", "d", 0)
	matches = cf.get_value("p", "m", 0)
	wins = cf.get_value("p", "w", 0)
	flags_taken = cf.get_value("p", "f", 0)
	play_seconds = cf.get_value("p", "s", 0.0)
	best_streak = cf.get_value("p", "bs", 0)
	best_kills = cf.get_value("p", "bk", 0)
	clamp_all()


func save_all() -> void:
	var cf := ConfigFile.new()
	cf.set_value("a", "k", total_kills)
	cf.set_value("s", "sv", sfx_vol)
	cf.set_value("s", "mv", music_vol)
	cf.set_value("s", "vib", vibrate)
	cf.set_value("s", "fm", fire_mode)
	cf.set_value("s", "aa", aim_assist)
	cf.set_value("s", "zm", zoom)
	cf.set_value("s", "hs", control_size)
	cf.set_value("s", "fps", fps_cap)
	cf.set_value("s", "q", quality)
	cf.set_value("s", "sf", show_fps)
	cf.set_value("s", "tut", tutorial)
	cf.set_value("s", "df", difficulty)
	cf.set_value("s", "bm", biome)
	cf.set_value("s", "stick_style", stick_style)
	cf.set_value("s", "deadzone", deadzone)
	cf.set_value("s", "aim_speed", aim_speed)
	cf.set_value("s", "control_alpha", control_alpha)
	cf.set_value("s", "auto_fire", auto_fire)
	cf.set_value("s", "resolution", resolution)
	cf.set_value("s", "ai_count", ai_count)
	cf.set_value("s", "match_length", match_length)
	cf.set_value("s", "chaos", chaos)
	cf.set_value("p", "d", deaths)
	cf.set_value("p", "m", matches)
	cf.set_value("p", "w", wins)
	cf.set_value("p", "f", flags_taken)
	cf.set_value("p", "s", play_seconds)
	cf.set_value("p", "bs", best_streak)
	cf.set_value("p", "bk", best_kills)
	cf.save(Cfg.SAVE_PATH)
