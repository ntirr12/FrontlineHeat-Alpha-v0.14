class_name SpriteDefs
extends RefCounted
## KAMUS TAMPILAN: benda di game -> nama sprite di atlas.
## Nama sprite didaftarkan di tools/atlas_spec.py. MAU GANTI TAMPILAN? Ubah nama/angka di sini,
## (kalau sprite baru: tambahkan dulu di atlas_spec.py & jalankan tools/build_atlas.py), lalu jalankan game.
##
## Istilah:
##   skin   = "tan" (gurun, dipakai biome GURUN) atau "grn" (hijau, biome HUTAN & SALJU)
##   scale  = berapa piksel DUNIA untuk 1 piksel sprite (makin besar = makin besar di layar)
##   tpos   = posisi turret terhadap pusat badan, dalam piksel sprite: (kanan, MAJU). Negatif = mundur.
##   bpos   = posisi laras terhadap pusat turret (sama: kanan, maju)

# ============================================================ INFANTERI
## Peran sprite tiap divisi (urutan = Cfg.Cls: ASSAULT, DESTROYER, ENGINEER, SUPPORT, JUGGERNAUT, SPY, ELITE, SECRET)
const CLASS_ROLE := ["assault", "at", "worker", "mg", "mg", "assault", "assault", "sniper"]
## Pembesaran relatif tiap divisi (Juggernaut = lapis baja tebal -> lebih besar)
const CLASS_SCALE := [1.0, 1.0, 0.95, 1.0, 1.4, 1.0, 1.1, 1.1]
## Pasukan tiap tim. [skin gurun, skin hijau]. Tim 1 = AS (biru), tim 2 = Rusia (merah)
const INF_SET := {1: ["usmc", "us_army"], 2: ["ru", "ru"]}
const INF_SCALE := 2.6
## Seberapa kuat badan kendaraan diberi semburat warna tim (0 = murni sprite, 1 = warna tim penuh).
## Membantu membedakan kawan/lawan saat kedua faksi sama-sama hijau. Naikkan bila masih sulit dibedakan.
const TEAM_TINT := 0.26

# ============================================================ KENDARAAN
## Cfg.Veh -> tim -> bagian. Kunci yang dipakai:
##   id       awalan nama sprite (veh/<id>/...)
##   body     nama bagian badan          turret  turret senjata utama      turret2  turret senjata ke-2 (weapon == 1)
##   barrel   laras terpisah ("" = tidak ada)
##   scale    skala badan                tscale  pengali skala turret/laras   bstretch  pengali panjang laras
##   tpos/bpos posisi turret & laras
const VEHICLES := {
	Cfg.Veh.HUMVEE_MG: {
		1: {id = "us_humvee", body = "body", turret = "mg", scale = 1.4, tscale = 1.25, tpos = Vector2(0, -1)},
		2: {id = "ru_tigr", body = "body", turret = "mg", scale = 1.3, tscale = 1.35, tpos = Vector2(0, 0)},
	},
	Cfg.Veh.TANK: {
		1: {id = "us_abrams", body = "body", turret = "turret", barrel = "barrel", scale = 1.5, tpos = Vector2(0, 1), bpos = Vector2(0, 12)},
		2: {id = "ru_t90", body = "body", turret = "turret", barrel = "barrel", scale = 1.5, tpos = Vector2(0, 0), bpos = Vector2(0, 3)},
	},
	Cfg.Veh.HUMVEE_AT: {
		1: {id = "us_humvee", body = "body", turret = "at", turret2 = "mg", scale = 1.4, tscale = 1.25, tpos = Vector2(0, -1)},
		2: {id = "ru_tigr", body = "at_body", turret = "at", turret2 = "mg", scale = 1.3, tscale = 1.2, tpos = Vector2(0, -2)},
	},
	Cfg.Veh.BRADLEY: {
		1: {id = "us_bradley", body = "body", turret = "turret", barrel = "barrel", scale = 1.5, tscale = 1.15, bstretch = 1.6, tpos = Vector2(1.3, -3), bpos = Vector2(0, 1)},
		2: {id = "ru_bmp3", body = "body", turret = "turret", scale = 1.45, tpos = Vector2(0, 2.5)},
	},
	Cfg.Veh.RAILGUN: {
		1: {id = "us_m1x", body = "body", turret = "turret", barrel = "barrel", scale = 1.55, tpos = Vector2(0, 2), bpos = Vector2(0, 12)},
		2: {id = "us_m1x", body = "body", turret = "turret", barrel = "barrel", scale = 1.55, tpos = Vector2(0, 2), bpos = Vector2(0, 12)},
	},
	# ---- v14: kendaraan baru
	Cfg.Veh.APC: {                      # LAV-25 (AS) / BTR-82A (Rusia): panser roda cepat bersenjata kanon 25mm
		1: {id = "us_lav", body = "body", turret = "turret", barrel = "barrel", scale = 1.5, tpos = Vector2(0, 4), bpos = Vector2(0, 4)},
		2: {id = "ru_btr", body = "body", turret = "turret", barrel = "barrel", scale = 1.45, tpos = Vector2(0, 11), bpos = Vector2(0, 2)},
	},
	Cfg.Veh.SPG: {                      # M109A6 Paladin (AS) / 2S3 Akatsiya (Rusia): howitzer swa-gerak
		1: {id = "us_m109", body = "body", turret = "turret", barrel = "barrel", scale = 1.55, tpos = Vector2(0, -2), bpos = Vector2(0, 8)},
		2: {id = "ru_2s3", body = "body", turret = "turret", barrel = "barrel", scale = 1.5, tpos = Vector2(0, -2), bpos = Vector2(0, 8)},
	},
	Cfg.Veh.MEDEVAC: {                  # Stryker M1133 (AS) / Ural-4320 (Rusia): kendaraan medis, tanpa senjata
		1: {id = "us_medevac", body = "body", scale = 1.45},
		2: {id = "ru_ural", body = "body", scale = 1.4},
	},
}

## Peluncur MLRS panggilan radio (tampil di dekat titik peluncuran): badan + palang roket.
const MLRS := {
	1: {id = "us_himars", body = "body", turret = "turret", scale = 1.5, tpos = Vector2(0, -6)},
	2: {id = "ru_uragan", body = "body", turret = "turret", scale = 1.4, tpos = Vector2(0, -8)},
}

## C-17 (bantuan terjun payung): sprite atlas diperkecil (fit 180 px) dari 257 px, jadi 1.58 = 257/180 x 1.1 ~ bentang sayap 280 px dunia.
const C17_SCALE := 1.58
const C17_TINT := {1: Color(1, 1, 1), 2: Color(.82, .86, .78)}     # pesawat tim merah sedikit kehijauan/gelap

# ============================================================ TURRET TETAP
## tipe (0 = MG kembar, 1 = TOW) -> tim -> nama sprite
const TURRETS := {
	0: {1: "tur/us_mg", 2: "tur/ru_mg"},
	1: {1: "tur/us_tow", 2: "tur/ru_at"},
}
const TURRET_SCALE := 2.0

# ============================================================ PESAWAT
## tim -> [jet pembom (bombs > 0), jet hiasan]
const JETS := {0: ["air/f15", "air/f15"], 1: ["air/a10", "air/f15"], 2: ["air/su25", "air/su27"]}
const JET_SCALE := 0.75

# ============================================================ DEKOR PETA (Cfg.BIOMES: 0 HUTAN, 1 GURUN, 2 SALJU)
const TREES := ["prop/tree1", "prop/tree2", "prop/tree3"]
const TREES_SNOW := ["prop/tree1_snow", "prop/tree2_snow", "prop/tree3_snow"]
const ROCKS := ["prop/rock_s", "prop/rock_m", "prop/rock_l"]
const BUSHES := ["prop/bush"]
const CACTI := ["prop/cactus1", "prop/cactus2", "prop/cactus3"]
const CRATERS := ["prop/crater1", "prop/crater2", "prop/crater3"]
const WALL_BLOCKS := ["wall/hesco1", "wall/hesco2", "wall/hesco3", "wall/hesco4", "wall/hesco5", "wall/hesco6"]
## Pewarnaan sprite pohon per biome (modulate): HUTAN apa adanya, GURUN kekuningan, SALJU kebiruan
## Warna dasar atap gedung per skin (diambil dari sprite agar potongan detail menyatu)
const ROOF_BASE := {"tan": Color(0.65, 0.61, 0.51), "grn": Color(0.37, 0.42, 0.33)}
## Kawah dekor di peta: digelapkan agar menyatu dengan tanah
const CRATER_TINT := Color(0.5, 0.45, 0.4, 0.85)
const TREE_TINT := [Color(0.9, 1.0, 0.85), Color(1.0, 0.95, 0.7), Color(1.0, 1.0, 1.0)]
