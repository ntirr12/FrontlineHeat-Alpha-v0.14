class_name AudioDefs
extends RefCounted
## KAMUS SUARA: nomor efek suara game -> file sampel di assets/audio/sfx/.
## Nomor yang TIDAK ada di daftar ini memakai suara sintesis (scripts/audio/synth.gd), misalnya suara UI.
## Satu nomor boleh punya banyak varian; game memilih acak supaya tembakan beruntun tidak terdengar monoton.
## Mau ganti suara? Taruh file .wav baru di assets/audio/sfx/ (atau ubah tools/build_audio.py) lalu ubah nama di sini.
##
## Nomor 0..14 sudah ada sejak v11 (lihat Synth.make). Nomor baru di v12:
##   15 = meriam tank   16 = prajurit gugur   17/18 = teriakan perang saat bendera direbut (AS / Rusia)

const SFX_DIR := "res://assets/audio/sfx/"
const COUNT := 19

const SAMPLES := {
	0: ["rifle_1", "rifle_2", "rifle_3", "rifle_4"],
	1: ["explosion_1", "explosion_2", "explosion_3"],
	2: ["rocket_1", "rocket_2"],
	13: ["far_gun_1", "far_gun_2", "far_gun_3"],
	14: ["far_artillery_1"],
	15: ["cannon_1", "cannon_2", "cannon_3", "cannon_4"],
	16: ["death_1", "death_2", "death_3"],
	17: ["warcry_us"],
	18: ["warcry_ru"],
}

## Bila sampel sebuah nomor tidak ada, pakai suara nomor lain sebagai cadangan.
const FALLBACK := {15: 1, 17: 5, 18: 5}

## Musik (OGG, di-stream). menu = menu & jeda, battle = saat bertempur.
const MUSIC_MENU := "res://assets/audio/music/menu.ogg"
const MUSIC_BATTLE := "res://assets/audio/music/battle.ogg"
