class_name Cfg
extends RefCounted
## =====================================================================
##  CFG - SEMUA ANGKA TUNING GAME ADA DI SINI.
##  Mau gim lebih mudah/sulit/ramai? Ubah angka di file ini saja,
##  tidak perlu membuka file lain. Setiap baris diberi penjelasan.
## =====================================================================

const VERSION := "v14.0"
const USE_SPRITES := true            # false = paksa gambar vektor lama (uji / HP sangat lemah)

# ---------------------------------------------------------------- PETA
const MAP_W := 5200.0          # lebar dunia (px)
const MAP_H := 3000.0          # tinggi dunia (px)
const NAV_CELL := 32.0         # ukuran sel peta navigasi AI (px)
const NAV_W := 163             # jumlah sel navigasi horizontal (MAP_W / NAV_CELL, dibulatkan ke atas)
const NAV_H := 94              # jumlah sel navigasi vertikal
const COARSE_CELL := 256.0     # ukuran sel grid tabrakan statis (gedung/tembok)
const CHUNK := 1024.0          # ukuran potongan peta statis yang digambar sekali (optimasi)
const HQ_OFFSET := 300.0       # jarak markas dari tepi peta

# ------------------------------------------------------- PRESET MISI (menu "Persiapan Misi")
const AI_COUNT_NAMES := ["SEDIKIT", "SEDANG", "BANYAK", "EPIK"]
const AI_COUNT := [14, 22, 30, 44]                 # jumlah AI maksimum PER TIM
const AI_COUNT_DESC := ["Ringan untuk HP lawas.", "Seimbang.", "Medan ramai.", "Perang total! Butuh HP kuat."]
const LENGTH_NAMES := ["PENDEK", "NORMAL", "PANJANG"]
const LENGTH_MULT := [0.6, 1.0, 1.7]               # pengali tiket (lama pertempuran)
const CHAOS_NAMES := ["TENANG", "NORMAL", "BRUTAL"]
const CHAOS_DESC := ["Sedikit kejadian acak.", "Artileri & jet sesekali.", "Hujan artileri, jet, pasukan terjun!"]
const CHAOS_MULT := [0.45, 1.0, 1.9]               # frekuensi kejadian acak (director)
const DIFF_NAMES := ["MUDAH", "NORMAL", "SULIT"]
const DIFF_DESC := [
	"Musuh lambat bereaksi & kurang akurat. Tiketmu lebih banyak.",
	"Pertarungan seimbang.",
	"Musuh cepat & akurat. Tiketmu lebih sedikit.",
]
const TICKET_BASE := 70.0                          # tiket dasar
const TICKET_PER_AI := 11.0                        # tambahan tiket per slot AI (makin ramai makin panjang). v13: dulu 7; peluru kini benar-benar mengenai, tempo gugur ~1,6x, jadi tiket dinaikkan agar durasi pertandingan tetap
const DIFF_TICKET_BLUE := [1.25, 1.0, 0.85]        # pengali tiket tim pemain per kesulitan
const DIFF_TICKET_RED := [0.75, 1.0, 1.25]         # pengali tiket tim musuh per kesulitan
const DIFF_AIM := [1.5, 1.0, 0.7]                  # pengali sebaran tembakan musuh (besar = ngawur)
const DIFF_REACT := [1.5, 1.0, 0.75]               # pengali waktu reaksi musuh (besar = lambat)
const DIFF_DMG := [0.65, 1.0, 1.3]                 # pengali kerusakan yang kamu terima
const BIOME_NAMES := ["ACAK", "HUTAN", "GURUN", "SALJU"]

# ------------------------------------------------------------ KONTROL & TAMPILAN
const CTL_SCALE := [0.85, 1.0, 1.2]                # skala tombol/analog (KECIL/SEDANG/BESAR)
const CTL_SCALE_NAMES := ["KECIL", "SEDANG", "BESAR"]
const DEADZONE := [0.08, 0.14, 0.22]               # zona mati analog
const DEADZONE_NAMES := ["KECIL", "SEDANG", "BESAR"]
const ZOOM_LEVELS := [1.0, 1.12, 1.0, 0.8]         # AUTO, DEKAT, NORMAL, JAUH
const ZOOM_NAMES := ["AUTO", "DEKAT", "NORMAL", "JAUH"]
const AIM_ASSIST_NAMES := ["MATI", "RINGAN", "KUAT"]
const FIRE_MODE_NAMES := ["MENTOK", "SENTUH", "TOMBOL"]
const STICK_STYLE_NAMES := ["MELAYANG", "TETAP"]
const QUALITY_NAMES := ["AUTO", "TINGGI", "SEDANG", "RENDAH"]
const RES_NAMES := ["AUTO", "TAJAM", "HEMAT"]
const STICK_RADIUS := 90.0                         # radius analog (px layar logis)
const BASE_BUTTON_R := 44.0                        # radius tombol aksi

# ---------------------------------------------------------- KUALITAS (indeks 0=TINGGI,1=SEDANG,2=RENDAH)
const MAX_FX := [300, 150, 56]                     # batas partikel efek aktif (efek kecil dibuang lebih dulu saat 75% penuh)
const FX_DIST := [1100.0, 800.0, 600.0]            # jarak efek digambar dari kamera
const MAX_BULLETS := 420                           # batas peluru aktif (pool)
const MAX_DECALS := 90                             # batas bekas ledakan/mayat
const AI_FAR_THINK := [0.25, 0.5, 0.9]             # selang berpikir AI jauh dari pemain (detik)
const AI_NEAR_THINK := [0.12, 0.18, 0.28]          # selang berpikir AI dekat pemain (detik)

# ------------------------------------------------------------------- AI
const AI_NEAR_DIST := 1300.0                       # di bawah ini = "dekat pemain" (berpikir cepat, LOS penuh)
const AI_SIGHT := 560.0                            # jarak pandang infanteri
const AI_SIGHT_VEH := 760.0                        # jarak pandang kendaraan
const AI_PLAN_INTERVAL := 2.5                      # selang perencana tim (detik)
const SQUAD_SIZE := 4                              # anggota per regu
const SQUAD_SPREAD := 70.0                         # jarak formasi anggota dari pemimpin
const AI_RETREAT_HP := 0.42                        # AI mundur bila HP di bawah ini
const AI_RECOVER_HP := 0.75                        # AI kembali bertempur bila HP sudah segini
const AI_REACT_MIN := 0.22                         # waktu reaksi awal terhadap musuh baru (detik)
const AI_REACT_MAX := 0.60
const AI_BURST_MIN := 3                            # panjang rentetan tembakan AI
const AI_BURST_MAX := 7
const AI_BURST_PAUSE := Vector2(0.25, 0.7)         # jeda antar rentetan (detik)
const AI_BASE_SPREAD := 0.07                      # sebaran tembakan dasar (radian)
const AI_SPREAD_PER_PX := 0.00018                  # tambahan sebaran per px jarak
const AI_SPAWN_GAP := 0.6                          # jeda spawn antar AI (detik)
const AI_VEHICLE_BOARD_CHANCE := 0.35              # peluang AI naik kendaraan kosong
const DANGER_FLEE_PAD := 60.0                      # (dipakai hanya bila AI_DODGE_DANGER = true) jarak tambahan zona bahaya
const AI_DODGE_DANGER := false                     # false = AI TIDAK lari dari strike/artileri/granat (tidak "tahu" bom akan jatuh)

# ---- AI v13: taktik yang lebih natural (semua bisa dimatikan dengan mengubah angkanya)
const AI_BOUND_PERIOD := Vector2(2.0, 3.4)         # lama satu "lompatan" regu: separuh regu maju, separuh menahan & menembak (detik)
const AI_FLANK_COOLDOWN := 14.0                    # jeda minimal antar manuver mengitari musuh per regu (detik)
const AI_FLANK_TIME := Vector2(4.5, 7.0)           # lama maksimal satu manuver mengitari
const AI_FLANK_DIST := Vector2(150.0, 230.0)       # seberapa jauh ke samping musuh titik tujuan pengitaran
const AI_PACE := Vector2(0.93, 1.04)               # variasi kecepatan jalan antar-prajurit (supaya tidak berbaris seragam)
const AI_PAUSE_CHANCE := 0.035                     # peluang tiap "berpikir" prajurit berhenti sejenak waspada saat maju
const AI_GRENADE_CD := Vector2(11.0, 20.0)          # jeda lempar granat per prajurit AI (dulu 6 dtk; AI musuh tak lagi lari dari granat)
const AI_GRENADE_OPEN_CHANCE := 0.3                # peluang granat dilempar ke musuh di tempat terbuka (musuh berlindung: selalu dipertimbangkan)
const AI_RADIO_CD := 90.0                          # jeda tiap prajurit Support memanggil barrage via radio (dulu 45)
const AI_RADIO_TEAM_GAP := Vector2(40.0, 75.0)     # jeda satu TIM antar barrage radio AI: dukungan artileri itu aset langka
const AI_VEH_FIRE_GAP := Vector2(1.0, 3.0)         # jeda tambahan acak setelah kendaraan AI menembak meriam/rudal (mengincar ulang sasaran)
const AI_BLIND_FIRE_TIME := 1.5                    # detik setelah kehilangan musuh: tembak penekan ke posisi terakhirnya
const SUPPRESS_PIN := 0.7                          # tingkat tekanan tembakan yang membuat AI merunduk / cari cover
const SUPPRESS_NEAR := 30.0                        # peluru lewat sedekat ini dari badan = "nyaris kena" (px)
const SUPPRESS_ADD := 0.3                          # tekanan per peluru yang nyaris kena
const SUPPRESS_DECAY := 0.55                       # pemulihan tekanan per detik

# ---------------------------------------------------------- DIRECTOR (kejadian acak "Battlefield")
const DIR_CALM_TIME := 7.0                         # detik tenang sebelum director memanaskan suasana
const DIR_EVENT_GAP := [26.0, 38.0]                # jeda antar kejadian acak (detik) min/max (dibagi CHAOS_MULT)
const DIR_AMBIENT_SHELL_GAP := [8.0, 16.0]         # jeda hujan artileri di bendera yang diperebutkan (v13: dulu 4-9; AI tak lagi menghindar, jadi lebih jarang)
const DIR_AMBIENT_DMG := 90.0                      # kerusakan per peluru artileri ambient (dulu 150)
const DIR_FLYOVER_GAP := [22.0, 45.0]              # jeda jet lewat (visual + sedikit bom)

# ------------------------------------------------- v14: BANTUAN UDARA, MLRS, SUPLAI, HADIAH BERUNTUN
# --- Bantuan terjun payung: pesawat C-17 melintas lalu menerjunkan satu regu (dipakai pemain via RADIO: TERJUN C-17 & Director)
const PARADROP_COUNT := 6                          # jumlah prajurit yang diterjunkan
const PARADROP_CD := 75.0                          # jeda panggilan pemain (detik; Elite x0,6)
const PARADROP_PLANE_SPEED := 560.0                # kecepatan C-17 (px/dtk)
const PARADROP_LEAD := 1500.0                      # C-17 muncul sejauh ini sebelum titik terjun (px) = tiba dalam ~2,7 dtk
const PARADROP_JUMP_GAP := 0.2                     # jeda antar-penerjun keluar dari pesawat (detik)
const PARADROP_FALL := Vector2(3.0, 3.8)           # lama melayang di udara (detik, acak)
const PARADROP_SPREAD := 140.0                     # sebaran titik mendarat di sekitar titik terjun (px)
const PARADROP_CRATES := 1                         # jumlah peti suplai medis yang ikut dijatuhkan
# --- MLRS: salvo roket dari kendaraan peluncur di luar layar (dibidik seperti airstrike)
const MLRS_ROCKETS := 18                           # jumlah roket per salvo
const MLRS_CD := 38.0                              # jeda panggilan pemain (detik; Elite x0,6)
const MLRS_WARMUP := 2.4                           # detik dari panggilan sampai roket pertama meluncur (peluncur bersiap)
const MLRS_FIRE_GAP := 0.16                        # jeda antar-roket (detik)
const MLRS_RADIUS := 250.0                         # sebaran area hantaman (px)
const MLRS_ROCKET_RADIUS := 78.0                   # radius ledakan satu roket
const MLRS_ROCKET_DMG := 135.0                     # kerusakan ledakan satu roket (pusat)
const MLRS_SPEED := 820.0                          # kecepatan roket (px/dtk) -> waktu terbang
const MLRS_STANDOFF := 1250.0                      # jarak peluncur dari target, ke arah markas sendiri (px)
const AI_MLRS_CHANCE := 0.3                        # peluang radio AI Support memilih MLRS (bukan airstrike biasa)
# --- Peti suplai (dari DROP: SUPLAI, C-17, atau kendaraan MEDEVAC hancur): sembuhkan + isi ulang
const SUPPLY_CD := 45.0                            # jeda DROP: SUPLAI (detik)
const CRATE_LIFE := 80.0                           # umur peti di tanah (detik)
const CRATE_PICKUP_R := 40.0                       # jarak ambil (px)
const CRATE_HEAL := 0.6                            # pulihkan HP sebesar ini (pecahan HP maks)
const CRATE_GRENADES := 2                          # tambahan granat tiap jenis
const CRATE_BUILD_POINTS := 30.0                   # tambahan poin bangun (Engineer/Elite)
# --- Hadiah beruntun (kill streak): tiap kelipatan ini pemain mendapat bantuan radio siap pakai + poin bangun
const STREAK_REWARD_EVERY := 5
const STREAK_BUILD_POINTS := 25.0

# ------------------------------------------------------------------- DIVISI (indeks sama dengan Cls)
enum Cls { ASSAULT, DESTROYER, ENGINEER, SUPPORT, JUGGERNAUT, SPY, ELITE, SECRET }
const CLASS_NAMES := ["ASSAULT", "DESTROYER", "ENGINEER", "SUPPORT", "JUGGERNAUT", "SPY", "ELITE", "SECRET"]
const CLASS_HP := [100.0, 140.0, 70.0, 90.0, 420.0, 80.0, 150.0, 130.0]
const CLASS_SPEED := [210.0, 165.0, 210.0, 215.0, 105.0, 225.0, 200.0, 205.0]
const CLASS_NEED := [0, 0, 0, 0, 350, 80, 200, 600]       # total kill untuk membuka divisi
const CLASS_RADIUS := [11, 12, 10, 10, 16, 10, 11, 11]
const CLASS_COLOR := [
	Color.WHITE, Color(1, .8, .2), Color(.3, 1, .5), Color(.4, .8, 1),
	Color(1, .3, .9), Color(.7, .4, 1), Color(1, .9, .5), Color(.3, 1, 1)]
const LOCK_TIME := [1.4, .7, 1.4, 1.4, 1.4, 1.4, .9, 1.4]  # waktu lock Javelin
const CLASS_DESC := [
	["M4A1 + granat", "flash + smoke", "serbaguna"],
	["Javelin lock cepat", "ranjau, tahan rudal", "jalan lambat"],
	["Perbaiki kendaraan", "& turret (otomatis)", "HP kecil"],
	["SMG jarak dekat", "radio: AIRSTRIKE, MLRS", "terjun C-17, suplai"],
	["Armor tebal, minigun", "overheat 10 dtk", "lambat, no kendaraan"],
	["Samaran 20 dtk", "C4, sabotase, pisau", "HP kecil"],
	["Semua skill digabung", "radio tanpa menara", "jammer backpack"],
	["AR peluru explosif", "summon tank RAILGUN", "NUKE taktis"],
]
const RANK_NAMES := ["REKRUT", "PRAJURIT", "KOPRAL", "SERSAN", "LETNAN", "KAPTEN", "MAYOR", "KOLONEL", "JENDERAL"]
const RANK_KILLS := [0, 10, 30, 60, 100, 160, 250, 400, 650]

# Divisi yang boleh dipakai AI: hanya 4 dasar. Spy/Elite muncul belakangan (detik), maks 2 per tim.
const AI_SPY_AFTER := 240.0
const AI_ELITE_AFTER := 420.0
const AI_MAX_SPECIAL := 2

# ----------------------------------------------------------------- KENDARAAN (indeks sama dengan Veh)
enum Veh { HUMVEE_MG, TANK, HUMVEE_AT, BRADLEY, RAILGUN, APC, SPG, MEDEVAC }     # v14: APC, SPG, MEDEVAC baru (tambah di AKHIR agar nilai lama tidak bergeser)
const VEH_COUNT := 8
const VEH_NAMES := [["HUMVEE .50CAL", "HUMVEE .50CAL"], ["TANK 120mm", "TANK 120mm"],
	["HUMVEE TOW", "HUMVEE M240"], ["BRADLEY 25mm", "BRADLEY TOW"], ["RAILGUN TANK", "RAILGUN TANK"],
	["APC 25mm", "APC ASAP"], ["HOWITZER 155mm", "PELURU ASAP"], ["MEDEVAC", "MEDEVAC"]]
const VEH_COOLDOWN := [[.07, .07], [1.9, 1.9], [3.6, .08], [.12, 4.2], [3.0, 3.0], [.09, 5.0], [4.6, 6.0], [9.0, 9.0]]  # jeda tembak per senjata
const SHOT_RAIL := 99                                            # penanda khusus di VEH_SHOT: tembakan railgun (bukan peluru biasa)
const VEH_SHOT := [[0, 0], [1, 1], [3, 0], [0, 3], [SHOT_RAIL, SHOT_RAIL], [0, 7], [6, 7], [0, 0]]   # jenis peluru (Bul)
## v14: SEMUA kendaraan diperbesar (VEH_SCALE) supaya jelas lebih besar dari prajurit (sprite prajurit ~34x62 px, tank ~64x130 px).
## VEH_SCALE dipakai SpriteBank (ukuran gambar) dan fallback vektor; VEH_RADIUS & VEH_MUZZLE sudah memuat pembesaran itu.
const VEH_SCALE := 1.45
const VEH_MUZZLE := [44, 72, 44, 66, 76, 62, 92, 40]
const VEH_RADIUS := [33, 45, 33, 42, 45, 40, 48, 40]
const VEH_SPEED := [345.0, 185.0, 335.0, 245.0, 200.0, 310.0, 150.0, 285.0]
const VEH_TURN := [2.7, 1.6, 2.7, 2.0, 1.6, 2.3, 1.1, 2.4]
const VEH_HP := [240.0, 820.0, 250.0, 560.0, 1000.0, 540.0, 650.0, 430.0]
const VEH_ZOOM := [.78, .6, .78, .66, .62, .7, .56, .72]                        # zoom kamera saat menyetir (lebih kecil = lebih jauh)
const VEH_SEATS := [1, 2, 1, 1, 1, 2, 1, 2]                      # jumlah kursi (kursi ke-2 = penembak senapan mesin otomatis)
# ---- v13: BUFF KENDARAAN (indeks sama dengan Veh)
const VEH_GUN_DMG := [1.9, 1.0, 1.4, 1.7, 1.0, 2.1, 1.0, 1.0]    # pengali kerusakan senapan mesin kendaraan ke PRAJURIT
const GUNNER_DMG := 1.3                                          # pengali senapan mesin penembak tank
const VEH_SPLASH_RESIST := [0.9, 0.55, 0.9, 0.7, 0.5, 0.72, 0.62, 0.85]   # pengali ledakan area (granat, bom, ranjau, C4) yang diterima tiap kendaraan
const VEH_CRUSH_DMG := 140.0                                     # kendaraan melindas prajurit musuh (kerusakan per sentuhan)
const VEH_CRUSH_SPEED := 70.0                                    # kecepatan minimal untuk melindas (px/dtk)
# ---- v14: MEKANIKA KENDARAAN BARU
const NAV_VEH_CLEAR := 40.0                                      # v14: jarak aman navigasi kendaraan dari dinding (px); harus mendekati radius kendaraan terbesar (45-48) agar tidak tersangkut di celah sempit
const VEH_SKILL_CD := [12.0, 16.0, 12.0, 16.0, 18.0, 12.0, 18.0, 12.0]     # jeda skill kendaraan (tombol SKILL saat menyetir)
const VEH_SKILL_BOOST := [true, false, true, false, false, true, false, true]   # true = BOOST kecepatan, false = TIRAI ASAP
const VEH_BOOST_TIME := 2.4                                      # lama boost (detik)
const VEH_BOOST_MULT := 1.65                                     # pengali kecepatan saat boost
const VEH_SMOKE_RADIUS := 125.0                                  # tirai asap yang dilepas kendaraan lapis baja
const VEH_SMOKE_TIME := 9.0
const VEH_LIMP_HP := 0.3                                         # di bawah ini mesin rusak: kendaraan melambat
const VEH_LIMP_MULT := 0.74
const MEDEVAC_RADIUS := 190.0                                    # jangkauan penyembuhan MEDEVAC (px)
const MEDEVAC_HEAL := 13.0                                       # HP/detik untuk prajurit sekutu di jangkauan (x2 saat berhenti)
const MEDEVAC_IDLE_SPEED := 40.0                                 # di bawah kecepatan ini MEDEVAC dianggap berhenti (menyembuhkan 2x)
const VEH_RESPAWN := 28.0
const TURRET_RESPAWN := 40.0

# ---------------------------------------------------------------- PELURU / SENJATA
enum Bul { RIFLE, SHELL, JAVELIN, TOW, M203, EXPLO, HOWITZER, SMOKESHELL }    # v14: HOWITZER (peluru lengkung artileri), SMOKESHELL (peluru asap)
const BUL_SPEED := [1100.0, 820.0, 480.0, 430.0, 650.0, 1000.0, 760.0, 700.0]
const BUL_LIFE := [.7, 1.6, 3.0, 4.0, .9, .7, 2.9, 2.4]
const BUL_SOUND := [0, 15, 2, 2, 2, 0, 15, 15]    # 15 = meriam tank (v12); M203 memakai desis roket
const BUL_ARC := [false, false, false, false, false, false, true, true]   # v14: peluru lengkung melintas di atas rintangan, hanya meledak saat mendarat
const RIFLE_DMG := 16.0
const RIFLE_DMG_VEH := [3.0, 0.6, 2.5, 0.8, 0.5, 0.8, 0.7, 1.6]                 # kerusakan peluru senapan ke tiap jenis kendaraan (v13: lebih kebal)
const RIFLE_DMG_TURRET := 5.0
const COVER_PASS_CHANCE := 0.1                                   # peluang peluru tetap kena target yang sedang berlindung

# ---- v13: MODEL KENA TEMBAK (indeks sama dengan Bul: RIFLE, SHELL, JAVELIN, TOW, M203, EXPLO)
# Peluru ledak yang menabrak sesuatu = KENA LANGSUNG (DIRECT_DMG ke sasaran itu) + LEDAKAN AREA (BLAST_* ke sekitarnya).
# Peluru ledak yang tidak menabrak apa pun jatuh ke TANAH dan tetap meledak: sasaran di dekatnya kena ledakan area.
const DIRECT_DMG := [0.0, 230.0, 420.0, 360.0, 130.0, 40.0, 0.0, 0.0]
const BLAST_RADIUS := [0.0, 100.0, 100.0, 100.0, 75.0, 48.0, 128.0, 0.0]
const BLAST_DMG := [0.0, 110.0, 220.0, 220.0, 95.0, 32.0, 235.0, 0.0]
const GROUND_OVERSHOOT := Vector2(-20.0, 75.0)                   # peluru yang membidik sasaran mendarat segini dari sasaran (px, min/maks)
const ARTY_DEFAULT_RANGE := 1050.0                               # v14: jarak jatuh peluru howitzer/asap bila tidak ada sasaran di garis bidik
const ARTY_AIM_RANGE := 1250.0                                   # v14: howitzer mencari sasaran sejauh ini di garis bidik (bantuan jarak untuk pemain)
const SHELL_DEFAULT_RANGE := 700.0                               # jarak jatuh peluru meriam bila tidak ada sasaran di garis bidik
const AIM_LATERAL := 60.0                                        # musuh sejauh ini (px) di samping garis bidik dianggap sedang dibidik PEMAIN (menentukan titik jatuh peluru yang meleset)

# --------------------------------------------------------------- ITEM (indeks sama dengan Item)
enum Item { GRENADE, FLASH, SMOKE, MINE, BARRAGE, CARPET, SANDBAG, WIRE, TRAP, TURRET_MG, TURRET_TOW,
	TOWER, DRONE_ST, JAMMER, DROP_MG, DROP_TOW, DROP_VEH, BUNKER, C4, NUKE,
	MLRS, PARADROP, DROP_SUPPLY }                    # v14: RADIO MLRS (salvo roket), BANTUAN TERJUN (C-17), PAKET SUPLAI (medis + amunisi)
const ITEM_NAMES := ["GRANAT", "FLASHBANG", "SMOKE>AIRSTRIKE", "RANJAU", "RADIO: BARAGE", "RADIO: KARPET", "SANDBAG",
	"KAWAT BERDURI", "TANK TRAP", "TURRET MG", "TURRET TOW", "MENARA RADIO", "STASIUN DRONE FPV", "JAMMER DRONE",
	"DROP: TURRET MG", "DROP: TURRET TOW", "DROP: HUMVEE", "BUNKER HQ", "C4", "NUKE TAKTIS",
	"RADIO: MLRS", "RADIO: TERJUN C-17", "DROP: SUPLAI"]
const ITEM_BUILD_COST := [0, 0, 0, 0, 0, 0, 10, 15, 20, 40, 60, 70, 30, 50, 0, 0, 0, 90, 0, 0, 0, 0, 0]
const ITEM_RANGE := [380, 380, 520, 60, 1600, 1600, 170, 170, 170, 170, 170, 170, 170, 170, 1600, 1600, 1600, 170, 60, 1600, 1600, 1600, 1600]
const ITEM_RADIUS := [120, 380, 110, 28, 260, 260, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 60, 30, 150, 250, 170, 60]
# Item yang bisa dipilih tiap divisi (urutan tombol ITEM)
const CLASS_ITEMS := [
	[0, 1, 2], [0, 3], [0, 2, 6, 7, 8, 9, 10, 11, 12, 13, 17], [0, 1, 2, 4, 5, 20, 21, 22, 14, 15, 16],
	[0], [2, 3, 18], [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22], [0, 1, 2, 19]]

# ---------------------------------------------------------------- BIOME
const BIOMES := [
	{name = "HUTAN", g1 = Color(.15, .22, .12), g2 = Color(.25, .35, .19), tree = Color(.10, .30, .14),
		road = Color(.40, .34, .26), road_edge = Color(.29, .24, .18), roof = Color(.33, .33, .36),
		roof2 = Color(.42, .42, .46), clear = Color(.09, .14, .08), snow = false},
	{name = "GURUN", g1 = Color(.60, .50, .32), g2 = Color(.75, .64, .42), tree = Color(.42, .48, .22),
		road = Color(.48, .38, .26), road_edge = Color(.38, .30, .20), roof = Color(.56, .46, .36),
		roof2 = Color(.67, .57, .45), clear = Color(.34, .27, .17), snow = false},
	{name = "SALJU", g1 = Color(.66, .72, .78), g2 = Color(.88, .92, .96), tree = Color(.12, .30, .30),
		road = Color(.50, .54, .60), road_edge = Color(.40, .44, .50), roof = Color(.36, .40, .48),
		roof2 = Color(.50, .55, .64), clear = Color(.42, .47, .53), snow = true},
]
const TEAM_COLORS := [Color.WHITE, Color(.25, .55, 1), Color(1, .3, .3)]   # indeks 0 netral, 1 biru (pemain), 2 merah

# ---------------------------------------------------------------- DEV / SAVE
const DEV_PASSWORD_SHA256 := "caa8893e00937dc50d6d59b49167ba0bcc6a514ae9a90988afe0191a76d90d8f"
const SAVE_PATH := "user://f.cfg"      # nama file dipertahankan agar progres lama tetap terbaca

# ---------------------------------------------------------------- TUTORIAL
const TIPS := [
	[1.0, "Geser JEMPOL KIRI untuk berjalan"],
	[7.0, "JEMPOL KANAN: bidik. Dorong sampai MENTOK untuk menembak"],
	[15.0, "Berdiri di dekat BENDERA untuk merebutnya (ikuti panah kuning)"],
	[24.0, "Tombol NAIK: masuk kendaraan atau turret terdekat"],
	[32.0, "COVER di dekat tembok = lebih aman. Selamat bertempur!"],
]
