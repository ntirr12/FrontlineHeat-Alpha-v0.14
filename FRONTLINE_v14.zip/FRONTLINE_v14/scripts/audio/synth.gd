class_name Synth
extends RefCounted
# Sintesis audio prosedural: tanpa file audio eksternal.
# sfx()        -> daftar efek suara (indeks dipakai oleh game.gd)
# engine()     -> loop mesin kendaraan (digeser pitch-nya sesuai kecepatan)
# music_pair() -> [musik menu, musik tempur] (berat, jalankan di Thread)

const SR := 22050


func _wav(d: PackedByteArray, rate: int, looped := false) -> AudioStreamWAV:
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = d
	if looped:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = d.size() >> 1
	return w


# Suara serbaguna: derau terfilter (low-pass 1 kutub) + nada sapuan.
# a0/a1 = koefisien filter awal/akhir (kecil = gelap/bass), f0/f1 = frekuensi nada awal/akhir,
# tv = volume nada, pw = kecuraman peluruhan, hump = envelope naik-turun (untuk jet lewat).
func _voice(ln: float, nz: float, a0: float, a1: float, f0: float, f1: float, tv: float, vol: float, pw: float, hump := false) -> AudioStreamWAV:
	var n := int(SR * ln)
	var d := PackedByteArray()
	d.resize(n * 2)
	var rng := RandomNumberGenerator.new()
	rng.seed = 12345 + n
	var lp := 0.0
	var ph := 0.0
	for i in n:
		var k := float(i) / n
		var a := lerpf(a0, a1, k)
		lp += ((rng.randf() * 2.0 - 1.0) - lp) * a
		var norm := sqrt((2.0 - a) / a)
		ph += TAU * lerpf(f0, f1, k) / SR
		var env := 0.0
		if hump:
			env = pow(sin(k * PI), pw)
		else:
			env = pow(1.0 - k, pw) * minf(1.0, i / 24.0)
		var s := (lp * norm * 0.5 * nz + sin(ph) * tv) * env
		d.encode_s16(i * 2, int(clampf(s * vol, -1.0, 1.0) * 32000.0))
	return _wav(d, SR)


# Urutan nada [[frekuensi, durasi], ...]; frekuensi 0 = hening.
func _notes(notes: Array, vol: float) -> AudioStreamWAV:
	var total := 0.0
	for nt in notes:
		total += float(nt[1])
	var n := int(SR * total)
	var d := PackedByteArray()
	d.resize(n * 2)
	var idx := 0
	var start := 0.0
	for i in n:
		var t := float(i) / SR
		while idx < notes.size() - 1 and t >= start + float(notes[idx][1]):
			start += float(notes[idx][1])
			idx += 1
		var lt := t - start
		var ln: float = notes[idx][1]
		var f: float = notes[idx][0]
		var s := 0.0
		if f > 0.0:
			var env := exp(-4.0 * lt / ln) * minf(1.0, lt * 400.0) * minf(1.0, (ln - lt) * 200.0)
			s = (sin(TAU * f * t) + 0.3 * sin(TAU * f * 2.0 * t)) * env
		d.encode_s16(i * 2, int(clampf(s * vol, -1.0, 1.0) * 30000.0))
	return _wav(d, SR)


## Jumlah suara sintesis. Indeks sama dengan indeks sfx() di Game.
const SFX_COUNT := 15


## Membangkitkan SATU suara sintesis (dipakai AudioMgr hanya untuk suara yang tidak punya sampel nyata).
func make(i: int) -> AudioStreamWAV:
	match i:
		0:
			return _voice(0.11, 0.9, 0.9, 0.5, 700.0, 180.0, 0.35, 0.9, 3.0)     # tembakan
		1:
			return _voice(0.9, 1.0, 0.25, 0.04, 80.0, 30.0, 0.6, 1.1, 2.0)     # ledakan
		2:
			return _voice(0.55, 0.9, 0.5, 0.15, 300.0, 90.0, 0.3, 0.9, 1.2)     # roket
		3:
			return _voice(0.05, 0.0, 1.0, 1.0, 1800.0, 1400.0, 1.0, 0.5, 2.0)     # hit marker
		4:
			return _notes([[880.0, 0.06], [1320.0, 0.13]], 0.5)     # kill
		5:
			return _notes([[523.0, 0.1], [659.0, 0.1], [784.0, 0.1], [1047.0, 0.28]], 0.5)     # flag / menang
		6:
			return _voice(0.04, 0.0, 1.0, 1.0, 700.0, 500.0, 1.0, 0.45, 2.0)     # klik UI
		7:
			return _voice(0.07, 0.7, 0.5, 0.3, 400.0, 200.0, 0.5, 0.7, 4.0)     # reload
		8:
			return _notes([[62.0, 0.1], [0.0, 0.1], [55.0, 0.14]], 0.9)     # detak jantung (HP rendah)
		9:
			return _voice(0.15, 0.6, 0.3, 0.15, 180.0, 90.0, 0.7, 0.9, 2.0)     # kena tembak / kalah
		10:
			return _voice(0.25, 1.0, 0.08, 0.4, 0.0, 0.0, 0.0, 0.5, 1.5)     # lempar granat
		11:
			return _voice(1.9, 1.0, 0.04, 0.3, 0.0, 0.0, 0.0, 0.7, 1.0, true)     # jet airstrike lewat
		12:
			return _voice(1.7, 0.15, 0.5, 0.5, 2600.0, 500.0, 0.55, 0.55, 0.7)     # desing peluru artileri jatuh
		13:
			return _voice(0.22, 0.9, 0.6, 0.2, 500.0, 120.0, 0.25, 0.7, 4.0)     # tembakan jauh (pecah tumpul)
		14:
			return _voice(0.5, 1.0, 0.1, 0.03, 70.0, 28.0, 0.5, 0.9, 2.5)     # dentum artileri jauh
	return null


## Semua suara sintesis sekaligus (cadangan bila sampel tidak ada).
func sfx() -> Array:
	var out: Array = []
	for i in SFX_COUNT:
		out.append(make(i))
	return out


# Loop mesin: harmonik kelipatan 28 Hz (siklus bulat per detik => loop mulus).
func engine() -> AudioStreamWAV:
	var rate := 11025
	var d := PackedByteArray()
	d.resize(rate * 2)
	for i in rate:
		var t := float(i) / rate
		var s := 0.0
		for h in range(1, 11):
			s += sin(TAU * 28.0 * h * t) / pow(float(h), 1.15)
		s *= 0.78 + 0.22 * sin(TAU * 7.0 * t)
		d.encode_s16(i * 2, int(clampf(s * 0.33, -1.0, 1.0) * 30000.0))
	return _wav(d, rate, true)


func music_pair() -> Array:
	return [_music(false), _music(true)]


# Loop 8 detik, 120 BPM, 4 bar (Am - Am - C - G). drums=false untuk versi menu.
func _music(drums: bool) -> AudioStreamWAV:
	var rate := 11025
	var n := rate * 8
	var d := PackedByteArray()
	d.resize(n * 2)
	var rng := RandomNumberGenerator.new()
	rng.seed = 777
	var roots := [55.0, 55.0, 65.41, 49.0]
	var chords := [[110.0, 130.81, 164.81], [110.0, 130.81, 164.81], [130.81, 164.81, 196.0], [98.0, 123.47, 146.83]]
	for c in chords:
		for j in c.size():
			c[j] = snappedf(c[j], 0.125)
	var bar := 2.0
	var hp := 0.0
	var bass_gain := 1.0 if drums else 0.6
	for i in n:
		var t := float(i) / rate
		var bi := int(t / bar) % 4
		var bt := fmod(t, bar)
		var s := 0.0
		# pad
		var pe := pow(sin(PI * bt / bar), 0.6)
		for f in chords[bi]:
			s += sin(TAU * f * t) * 0.07 * pe
		# bass: denyut not-8
		var lt := fmod(bt, 0.25)
		var fb: float = roots[bi]
		var be := exp(-9.0 * lt) * minf(1.0, (0.25 - lt) * 60.0) * minf(1.0, lt * 200.0)
		s += (sin(TAU * fb * t) + 0.4 * sin(TAU * fb * 2.0 * t)) * 0.28 * be * bass_gain
		if drums:
			var kt := fmod(t, 1.0)
			var kph := TAU * (45.0 * kt + 85.0 * (1.0 - exp(-18.0 * kt)) / 18.0)
			s += sin(kph) * 0.55 * exp(-9.0 * kt) * minf(1.0, kt * 400.0)
			var st2 := fmod(t + 0.5, 1.0)
			s += (rng.randf() * 2.0 - 1.0) * 0.2 * exp(-22.0 * st2) * minf(1.0, st2 * 300.0)
			var ht := fmod(t, 0.25)
			var nz := rng.randf() * 2.0 - 1.0
			s += (nz - hp) * 0.05 * exp(-70.0 * ht)
			hp = nz
		d.encode_s16(i * 2, int(clampf(s * 0.9, -1.0, 1.0) * 30000.0))
	return _wav(d, rate, true)
