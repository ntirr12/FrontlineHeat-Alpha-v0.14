class_name AudioMgr
extends Node
## AUDIO: efek suara (pool 12 pemutar), mesin kendaraan, musik, dan AMBIEN PERTEMPURAN.
## v12: efek suara & musik memakai SAMPEL NYATA (lihat data/audio_defs.gd). Suara yang tidak punya sampel
## (UI, mesin) tetap sintesis. Bila file sampel hilang, otomatis kembali ke sintesis penuh seperti v11.
## Ambien: bunyi tembakan jauh/dentum artileri yang frekuensinya mengikuti intensitas perang di peta,
## sehingga medan terasa hidup walau musuh belum terlihat.

var g: Game
var _synth := Synth.new()
var _players: Array[AudioStreamPlayer] = []
var _engine: AudioStreamPlayer
var _music: AudioStreamPlayer
var _sounds: Array = []            # per nomor suara: Array[AudioStream] (varian; dipilih acak)
var _music_streams: Array = []
var _thread: Thread
var _music_want := -1
var _ambient_t := 0.0
var _intensity := 0.0              # tembakan per detik (dihaluskan)


func setup(game: Game) -> void:
	g = game
	for i in 12:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_players.append(p)
	_engine = AudioStreamPlayer.new()
	add_child(_engine)
	_music = AudioStreamPlayer.new()
	add_child(_music)
	_load_sounds()
	_engine.stream = _synth.engine()
	if not _load_music():
		_thread = Thread.new()                   # tanpa file musik: dibuat sintesis di thread terpisah agar tidak patah-patah
		_thread.start(_synth.music_pair)


## Memuat sampel tiap nomor suara; nomor tanpa sampel dibangkitkan sintesis (hanya yang dibutuhkan).
func _load_sounds() -> void:
	_sounds.clear()
	for i in AudioDefs.COUNT:
		var bank: Array = []
		for nm: String in AudioDefs.SAMPLES.get(i, []):
			var st := load(AudioDefs.SFX_DIR + nm + ".wav") as AudioStream
			if st != null:
				bank.append(st)
		_sounds.append(bank)
	for i in AudioDefs.COUNT:
		if (_sounds[i] as Array).is_empty():
			if AudioDefs.FALLBACK.has(i) and not (_sounds[AudioDefs.FALLBACK[i]] as Array).is_empty():
				_sounds[i] = _sounds[AudioDefs.FALLBACK[i]]
			elif i < Synth.SFX_COUNT:
				_sounds[i] = [_synth.make(i)]


## Musik dari file OGG (di-loop). true bila kedua lagu berhasil dimuat.
func _load_music() -> bool:
	var menu := load(AudioDefs.MUSIC_MENU) as AudioStream
	var battle := load(AudioDefs.MUSIC_BATTLE) as AudioStream
	if menu == null or battle == null:
		return false
	for m in [menu, battle]:
		if m is AudioStreamOggVorbis:
			(m as AudioStreamOggVorbis).loop = true
	_music_streams = [menu, battle]
	return true


func shutdown() -> void:
	if _thread != null and _thread.is_started():
		_thread.wait_to_finish()


func _play(n: int, db: float, pitch := 1.0) -> void:
	if g.prefs.sfx_vol <= .01 or n >= _sounds.size():
		return
	var bank: Array = _sounds[n]
	if bank.is_empty():
		return
	for q in _players:
		if not q.playing:
			q.stream = bank[randi() % bank.size()]
			q.volume_db = db + linear_to_db(g.prefs.sfx_vol)
			q.pitch_scale = pitch
			q.play()
			return


## Suara 3D sederhana: makin jauh dari kamera makin pelan; terlalu jauh = dibuang.
func sfx_at(n: int, p: Vector2) -> void:
	var d := p.distance_to(g.cam)
	if d > 1000.0 or (n == 0 and (randf() < .4 or g.quality_level == 2)):
		return
	if n == 16 and (randf() < .5 or g.quality_level == 2):      # suara gugur: jangan menumpuk saat banyak yang tewas
		return
	_play(n, -4.0 - d / 55.0, randf_range(.85, 1.15))


func sfx_ui(n: int) -> void:
	_play(n, -6.0)


func tick(dt: float) -> void:
	if _thread != null and not _thread.is_alive():
		_music_streams = _thread.wait_to_finish()
		_thread = null
	var playing := g.mode == Game.Mode.PLAY and not g.paused and not g.selecting
	if _music_streams.size() == 2 and g.prefs.music_vol > .01:
		var w := 1 if playing else 0
		if _music_want != w or not _music.playing:
			_music_want = w
			_music.stream = _music_streams[w]
			_music.play()
		_music.volume_db = linear_to_db(g.prefs.music_vol) - 12.0 - (6.0 if w == 1 else 0.0)
	elif _music != null and _music.playing:
		_music.stop()
		_music_want = -1
	var driving := playing and g.player != null and g.player.mount is Vehicle and g.prefs.sfx_vol > .01
	if driving:
		var v := g.player.mount as Vehicle
		if not _engine.playing:
			_engine.play()
		_engine.pitch_scale = .65 + absf(v.speed) / float(Cfg.VEH_SPEED[v.kind])
		_engine.volume_db = -14.0 + linear_to_db(g.prefs.sfx_vol)
	elif _engine.playing:
		_engine.stop()
	if playing:
		_ambient(dt)
	else:
		g.gunfire_events = 0


## Ambien perang jauh: kerapatan bunyi ~ jumlah tembakan di peta.
func _ambient(dt: float) -> void:
	_intensity = lerpf(_intensity, float(g.gunfire_events) / maxf(dt, .001), minf(1.0, dt * 1.5))
	g.gunfire_events = 0
	_ambient_t -= dt
	if _ambient_t > 0.0 or g.prefs.sfx_vol <= .01 or g.quality_level == 2:
		return
	var level := clampf(_intensity / 60.0, 0.0, 1.0)
	_ambient_t = lerpf(1.4, .22, level) * randf_range(.6, 1.4)
	var kind := 13 if randf() < .78 else 14
	_play(kind, -17.0 - randf() * 6.0 - (1.0 - level) * 5.0, randf_range(.7, 1.1))
