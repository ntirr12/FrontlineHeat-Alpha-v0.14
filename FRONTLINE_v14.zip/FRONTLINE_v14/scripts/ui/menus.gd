class_name Menus
extends Node2D
## SEMUA LAYAR MENU: utama, persiapan misi, pengaturan (bertab), bantuan, statistik, jeda,
## pilih divisi, hasil misi, layar loading, dan panel developer.
## Gaya "immediate mode": tombol didaftarkan ke daftar _buttons saat digambar, lalu tap() mencari tombol
## yang kena sentuh. Menambah tombol baru = tambahkan satu baris di fungsi _draw_xxx + satu case di _do().

const HELP_PAGES := [
	["KONTROL", [
		"JEMPOL KIRI: gerak (analog melayang atau tetap, atur di Pengaturan)",
		"JEMPOL KANAN: bidik. MENTOK/SENTUH = menembak, atau pakai tombol TEMBAK",
		"LEMPAR: tahan lalu geser untuk membidik item, lepas untuk melempar",
		"ITEM ganti item  |  GANTI senjata  |  COVER berlindung di dekat tembok",
		"NAIK/TURUN kendaraan & turret (dekati dulu)  |  SKILL divisi (di kendaraan: BOOST / ASAP)",
	]],
	["TUJUAN", [
		"Rebut 5 bendera (A-E) dengan berdiri di dalam lingkarannya.",
		"Tim dengan bendera lebih banyak menguras tiket lawan.",
		"Tiap prajurit gugur = -1 tiket. Tiket habis = kalah.",
		"Berlindung dekat HQ / bunker untuk memulihkan HP.",
		"Total kill membuka divisi baru dan menaikkan pangkat.",
	]],
	["PERTEMPURAN", [
		"AI bergerak dalam REGU 4 orang: menyerbu, menjaga, atau membantu bendera.",
		"AI berlindung & merunduk saat ditembak, mundur saat HP kritis (tapi tidak \"tahu\" bom akan jatuh).",
		"Artileri & jet lewat acak: waspada lingkaran jingga/merah di tanah!",
		"Tank/Humvee musuh berbahaya: bawa Javelin (Destroyer) atau granat.",
		"Atur jumlah AI, panjang misi & tingkat kekacauan di Persiapan Misi.",
	]],
	["KENDARAAN", [
		"8 kendaraan per tim: Humvee .50cal & TOW, TANK, BRADLEY, APC (LAV-25 / BTR-82A),",
		"SPG howitzer (M109 / 2S3: jangkauan jauh, peluru lengkung, ganti senjata = peluru asap), MEDEVAC.",
		"MEDEVAC berawak menyembuhkan prajurit sekutu di sekitarnya (2x saat berhenti).",
		"Tombol SKILL di kendaraan: BOOST (ringan) atau TIRAI ASAP (lapis baja). HP < 30% = mesin pincang.",
		"Kendaraan melindas infanteri musuh. Peti medis jatuh saat MEDEVAC hancur.",
	]],
	["BANTUAN RADIO", [
		"Support & Elite (butuh menara radio, Elite tidak): bidik seperti airstrike, lalu lepas.",
		"RADIO: MLRS - peluncur di belakang garis menembakkan 18 roket ke area oval yang dibidik.",
		"RADIO: TERJUN C-17 - pesawat melintas dan menerjunkan 1 regu (gratis) + peti medis.",
		"DROP: SUPLAI - dua peti: sentuh untuk memulihkan HP & mengisi granat/rudal.",
		"Kill streak tiap 5: radio langsung siap + poin bangun. Musuh juga bisa memanggil C-17 & MLRS!",
	]],
]
const DEV_LABELS := ["GOD MODE", "UNLOCK SEMUA", "AMMO & ITEM INF", "ONE HIT KILL", "AI DIAM (PASIF)", "KECEPATAN x1.8", "+100 TOTAL KILL"]

var g: Game
var ui := UiKit.new()
var info_open := false

var _buttons: Array[Dictionary] = []
var _slider_id := ""
var _slider_touch := -1
var _info_taps := 0
var _info_tap_t := 0.0
var _password_box: LineEdit = null
var _over_start := 0.0


func setup(game: Game) -> void:
	g = game


func rebuild() -> void:
	pass


func invalidate(_r: Rect2) -> void:
	pass


func clear() -> void:
	pass


func _needs_draw() -> bool:
	return g.mode != Game.Mode.PLAY or g.paused or g.selecting or g.loading_frames > 0


func refresh() -> void:
	var show := _needs_draw()
	visible = show
	_info_tap_t -= get_process_delta_time()
	if _info_tap_t <= 0.0:
		_info_taps = 0
	if g.confirm_t > 0.0:
		g.confirm_t -= get_process_delta_time()
	if show:
		queue_redraw()
	else:
		_buttons.clear()


# ============================================================ gambar
func _draw() -> void:
	_buttons.clear()
	if g.mode == Game.Mode.OVER and _over_start == 0.0:
		_over_start = g.time
	if g.mode != Game.Mode.OVER:
		_over_start = 0.0
	if g.mode == Game.Mode.MENU:
		match g.screen:
			"setup": _draw_setup()
			"set": _draw_settings()
			"help": _draw_help()
			"stats": _draw_stats()
			_: _draw_main()
	else:
		if g.selecting and g.mode == Game.Mode.PLAY and not g.paused:
			_draw_class_select()
		if g.paused:
			if g.screen == "set":
				_draw_settings()
			else:
				_draw_pause()
		if g.mode == Game.Mode.OVER:
			_draw_over()
	if g.loading_frames > 0:
		_dim(.85)
		ui.center(self, "MEMBUAT PETA...", g.vs.y * .5, 52, Color(1, .85, .3))
		ui.center(self, "peta acak sedang disiapkan", g.vs.y * .5 + 40, 22, Color(.8, .85, .95))


func _dim(a: float) -> void:
	draw_rect(Rect2(Vector2.ZERO, g.vs), Color(0, 0, 0, a))


func _btn(r: Rect2, label: String, id: String, col := Color(.16, .36, .62), size := 26, enabled := true, highlight := false) -> void:
	_buttons.append(ui.button(self, r, label, id, col, size, enabled, highlight))


func _opt(r: Rect2, label: String, id: String, selected: bool, size := 24) -> void:
	_btn(r, label, id, Color(.2, .5, .9) if selected else Color(.15, .18, .24), size)


func _rank_index() -> int:
	var r := 0
	for i in Cfg.RANK_KILLS.size():
		if g.prefs.total_kills >= Cfg.RANK_KILLS[i]:
			r = i
	return r


func _rank_bar(cxm: float, y: float, w: float) -> void:
	var r := _rank_index()
	var tot := g.prefs.total_kills
	var cur: int = Cfg.RANK_KILLS[r]
	var nxt: int = Cfg.RANK_KILLS[r + 1] if r + 1 < Cfg.RANK_KILLS.size() else cur
	var frac := 1.0 if nxt == cur else clampf(float(tot - cur) / float(nxt - cur), 0.0, 1.0)
	ui.center(self, Cfg.RANK_NAMES[r] + "   (" + str(tot) + " kill)", y, 26, Color(1, .85, .3))
	ui.rbox(self, Rect2(cxm - w / 2.0, y + 12, w, 12), Color(0, 0, 0, .5), Color(1, 1, 1, .2), 1, 6)
	if frac > .03:
		ui.rbox(self, Rect2(cxm - w / 2.0, y + 12, w * frac, 12), Color(1, .85, .3), Color(0, 0, 0, 0), 0, 6)
	if nxt != cur:
		ui.center(self, "menuju " + Cfg.RANK_NAMES[r + 1] + ": " + str(nxt - tot) + " kill lagi", y + 46, 18, Color(.8, .85, .95))


# ---------------------------------------------------------------- menu utama
func _draw_main() -> void:
	var vs := g.vs
	_dim(.45)
	var cxm := vs.x / 2.0
	ui.center(self, "FRONTLINE", vs.y * .2, 96, Color(1, .85, .3))
	ui.center(self, "PERANG TOP-DOWN  |  " + Cfg.VERSION, vs.y * .2 + 44, 24, Color(.85, .9, 1))
	_rank_bar(cxm, vs.y * .2 + 100, 320.0)
	var bw := 440.0
	var y := vs.y * .55
	_btn(Rect2(cxm - bw / 2.0, y, bw, 86), "MAIN", "play", Color(.15, .55, .25), 44)
	_btn(Rect2(cxm - 330, y + 106, 200, 60), "CARA MAIN", "help", Color(.2, .35, .6), 24)
	_btn(Rect2(cxm - 100, y + 106, 200, 60), "STATISTIK", "stats", Color(.2, .35, .6), 24)
	_btn(Rect2(cxm + 130, y + 106, 200, 60), "PENGATURAN", "set", Color(.2, .35, .6), 24)
	if g.dev:
		ui.left(self, "DEV MODE", Vector2(g.margin_l, 110), 22, Color(1, .4, .3))
		for i in 7:
			var on: bool = i < 6 and g.cheats[Game.CHEAT_KEYS[i]]
			_btn(Rect2(g.margin_l, 120 + i * 50, 270, 42), DEV_LABELS[i], "dv%d" % i, Color(.15, .5, .2) if on else Color(.1, .1, .12), 19)
	if info_open:
		_buttons.append({"r": Rect2(Vector2.ZERO, vs), "id": "infoc", "en": true})
		ui.panel(self, Rect2(cxm - 330, vs.y * .2, 660, vs.y * .5))
		var lines := ["FRONTLINE " + Cfg.VERSION, "Analog kiri: gerak  |  kanan: bidik",
			"Rebut 5 bendera, kuras tiket musuh", "8 divisi - total kill membuka divisi elite", "Sentuh di mana saja untuk menutup"]
		for i in lines.size():
			ui.center(self, lines[i], vs.y * .2 + 70 + i * 44, 24)
	var ip := Vector2(g.margin_l + 26, 40)
	_buttons.append({"r": Rect2(ip - Vector2(30, 30), Vector2(60, 60)), "id": "info", "en": true})
	draw_circle(ip, 26, Color(0, 0, 0, .5))
	draw_arc(ip, 26, 0, TAU, 20, Color(1, 1, 1, .7), 3)
	draw_string(ui.font, ip + Vector2(-12, 9), "i", HORIZONTAL_ALIGNMENT_CENTER, 24, 26)


# ---------------------------------------------------------------- persiapan misi
func _draw_setup() -> void:
	var vs := g.vs
	var p := g.prefs
	_dim(.62)
	var pnl := Rect2(vs.x / 2 - 440, 12, 880, vs.y - 24)
	ui.panel(self, pnl)
	ui.center(self, "PERSIAPAN MISI", pnl.position.y + 50, 44, Color(1, .85, .3), pnl.position.x, pnl.size.x)
	var x0 := pnl.position.x + 40
	var y := pnl.position.y + 76
	var rows := [
		["KESULITAN", "df", Cfg.DIFF_NAMES, p.difficulty, 3],
		["MEDAN", "bm", Cfg.BIOME_NAMES, p.biome, 4],
		["JUMLAH AI / TIM", "ai", Cfg.AI_COUNT_NAMES, p.ai_count, 4],
		["PANJANG MISI", "ln", Cfg.LENGTH_NAMES, p.match_length, 3],
		["KEKACAUAN", "ch", Cfg.CHAOS_NAMES, p.chaos, 3],
	]
	for row in rows:
		ui.left(self, row[0], Vector2(x0, y + 22), 22, Color(.9, .92, 1))
		var n: int = row[4]
		var bw := (pnl.size.x - 80 - (n - 1) * 10.0) / n
		for i in n:
			_opt(Rect2(x0 + i * (bw + 10), y + 32, bw, 46), row[2][i], "%s%d" % [row[1], i], row[3] == i, 22)
		y += 90.0
	var desc: String = Cfg.DIFF_DESC[p.difficulty] + "  |  " + str(Cfg.AI_COUNT[p.ai_count]) + " AI/tim: " + Cfg.AI_COUNT_DESC[p.ai_count] + "  |  " + Cfg.CHAOS_DESC[p.chaos]
	ui.center(self, desc, pnl.end.y - 108, 16, Color(.8, .85, .95), pnl.position.x, pnl.size.x)
	_btn(Rect2(pnl.position.x + 40, pnl.end.y - 84, 520, 66), "MULAI MISI", "go", Color(.15, .55, .25), 36)
	_btn(Rect2(pnl.end.x - 40 - 260, pnl.end.y - 84, 260, 66), "KEMBALI", "back", Color(.2, .3, .45), 26)


# ---------------------------------------------------------------- pengaturan
func _setting_rows() -> Array:
	if g.settings_tab == 0:
		return [["EFEK SUARA", "sl_sv"], ["MUSIK", "sl_mv"], ["GETAR", "t_vib"], ["TAMPILKAN FPS", "t_sf"], ["BATAS FPS", "c_fps"],
			["KUALITAS GRAFIK", "c_q"], ["RESOLUSI RENDER", "c_res"], ["BANTUAN AWAL", "t_tut"]]
	return [["GAYA ANALOG", "c_ss"], ["MODE TEMBAK", "c_fm"], ["TEMBAK OTOMATIS", "t_af"], ["BANTUAN BIDIK", "c_aa"], ["ZONA MATI ANALOG", "c_dz"],
		["KECEPATAN BIDIK", "c_as"], ["UKURAN KONTROL", "c_hs"], ["TRANSPARANSI", "sl_ca"], ["ZOOM KAMERA", "c_zm"]]


func _setting_value(id: String) -> String:
	var p := g.prefs
	match id:
		"t_vib": return "AKTIF" if p.vibrate else "MATI"
		"t_sf": return "AKTIF" if p.show_fps else "MATI"
		"t_tut": return "AKTIF" if p.tutorial else "MATI"
		"t_af": return "AKTIF" if p.auto_fire else "MATI"
		"c_fps": return "%d FPS" % p.fps_cap
		"c_fm": return Cfg.FIRE_MODE_NAMES[p.fire_mode]
		"c_aa": return Cfg.AIM_ASSIST_NAMES[p.aim_assist]
		"c_zm": return Cfg.ZOOM_NAMES[p.zoom]
		"c_hs": return Cfg.CTL_SCALE_NAMES[p.control_size]
		"c_q": return Cfg.QUALITY_NAMES[p.quality]
		"c_res": return Cfg.RES_NAMES[p.resolution]
		"c_ss": return Cfg.STICK_STYLE_NAMES[p.stick_style]
		"c_dz": return Cfg.DEADZONE_NAMES[p.deadzone]
		"c_as": return ["CEPAT", "SEDANG", "LAMBAT"][p.aim_speed]
	return ""


func _draw_settings() -> void:
	var vs := g.vs
	_dim(.66)
	var pnl := Rect2(vs.x / 2 - 540, 12, 1080, vs.y - 24)
	ui.panel(self, pnl)
	ui.center(self, "PENGATURAN", pnl.position.y + 48, 42, Color(1, .85, .3), pnl.position.x, pnl.size.x)
	_btn(Rect2(pnl.position.x + 40, pnl.position.y + 64, 250, 44), "SUARA & GRAFIK", "tab0", Color(.2, .5, .9) if g.settings_tab == 0 else Color(.15, .18, .24), 20)
	_btn(Rect2(pnl.position.x + 300, pnl.position.y + 64, 250, 44), "KONTROL", "tab1", Color(.2, .5, .9) if g.settings_tab == 1 else Color(.15, .18, .24), 20)
	var rows := _setting_rows()
	var per_col := 5
	var rh := (pnl.size.y - 230.0) / per_col
	for i in rows.size():
		var cl := i / per_col
		var rw := i % per_col
		var x0 := pnl.position.x + 40 + cl * 520.0
		var y0 := pnl.position.y + 124 + rw * rh
		ui.left(self, rows[i][0], Vector2(x0, y0 + rh * .5 + 8), 22, Color(.9, .92, 1))
		var id: String = rows[i][1]
		var cr := Rect2(x0 + 270, y0 + rh * .5 - 24, 220, 48)
		if id.begins_with("sl_"):
			var v := g.prefs.sfx_vol if id == "sl_sv" else (g.prefs.music_vol if id == "sl_mv" else (g.prefs.control_alpha - .3) / .7)
			var lbl := "%d%%" % int(g.prefs.control_alpha * 100.0) if id == "sl_ca" else ""
			_buttons.append(ui.slider(self, cr, id, v, lbl))
		else:
			_btn(cr, _setting_value(id), id, Color(.18, .3, .5), 22)
	if g.settings_tab == 1:
		var hint := ""
		match g.prefs.fire_mode:
			0: hint = "MENTOK: dorong analog bidik sampai tepi untuk menembak."
			1: hint = "SENTUH: geser analog bidik sedikit saja = menembak."
			_: hint = "TOMBOL: sentuh tombol TEMBAK (bisa digeser untuk membidik sambil menembak)."
		if g.prefs.stick_style == 1:
			hint += "  Analog TETAP: sentuh di dekat lingkaran analog."
		ui.center(self, hint, pnl.end.y - 96, 16, Color(.8, .85, .95), pnl.position.x, pnl.size.x)
	_btn(Rect2(vs.x / 2 - 120, pnl.end.y - 76, 240, 56), "KEMBALI", "back", Color(.15, .55, .25), 28)


# ---------------------------------------------------------------- statistik & bantuan
func _draw_stats() -> void:
	var vs := g.vs
	var p := g.prefs
	_dim(.7)
	var pnl := Rect2(vs.x / 2 - 400, vs.y * .06, 800, vs.y * .88)
	ui.panel(self, pnl)
	ui.center(self, "STATISTIK", pnl.position.y + 58, 48, Color(1, .85, .3))
	_rank_bar(vs.x / 2, pnl.position.y + 104, 360.0)
	var rows := [["Total kill", str(p.total_kills)], ["Kill terbaik (1 misi)", str(p.best_kills)], ["Streak terbaik", str(p.best_streak)],
		["Gugur", str(p.deaths)], ["Bendera direbut", str(p.flags_taken)], ["Misi dimainkan", str(p.matches)],
		["Misi dimenangkan", str(p.wins)], ["Waktu bermain", "%d menit" % int(p.play_seconds / 60.0)]]
	var y := pnl.position.y + 190
	for i in rows.size():
		ui.left(self, rows[i][0], Vector2(pnl.position.x + 70, y + i * 38), 24, Color(.8, .85, .95))
		ui.right(self, rows[i][1], Vector2(pnl.end.x - 70 - 220, y + i * 38), 220, 24)
	_btn(Rect2(vs.x / 2 - 120, pnl.end.y - 76, 240, 56), "KEMBALI", "back", Color(.15, .55, .25), 28)


func _available_classes() -> Array[int]:
	var av: Array[int] = []
	for i in 8:
		if Cfg.CLASS_NEED[i] <= g.prefs.total_kills or g.cheat("unl"):
			av.append(i)
	return av


func _draw_help() -> void:
	var vs := g.vs
	_dim(.7)
	var pnl := Rect2(vs.x / 2 - 540, vs.y * .06, 1080, vs.y * .88)
	ui.panel(self, pnl)
	var last := HELP_PAGES.size()
	var title: String = HELP_PAGES[g.help_page][0] if g.help_page < last else "DIVISI"
	ui.center(self, "CARA MAIN - " + title + "  (" + str(g.help_page + 1) + "/" + str(last + 1) + ")", pnl.position.y + 58, 38, Color(1, .85, .3))
	var y := pnl.position.y + 120
	if g.help_page < last:
		for ln: String in HELP_PAGES[g.help_page][1]:
			ui.left(self, ln, Vector2(pnl.position.x + 50, y), 22)
			y += 56.0
	else:
		var av := _available_classes()
		for k in av.size():
			var i := av[k]
			ui.left(self, Cfg.CLASS_NAMES[i], Vector2(pnl.position.x + 50, y + k * 46), 22, Cfg.CLASS_COLOR[i])
			ui.left(self, ", ".join(Cfg.CLASS_DESC[i]), Vector2(pnl.position.x + 250, y + k * 46), 20)
		ui.left(self, "Divisi lain terbuka seiring total kill-mu bertambah.", Vector2(pnl.position.x + 50, pnl.end.y - 110), 20, Color(.8, .85, .95))
	_btn(Rect2(pnl.position.x + 50, pnl.end.y - 76, 200, 56), "SEBELUMNYA", "hp_prev", Color(.2, .3, .45), 22, g.help_page > 0)
	_btn(Rect2(pnl.end.x - 250, pnl.end.y - 76, 200, 56), "BERIKUTNYA", "hp_next", Color(.2, .3, .45), 22, g.help_page < last)
	_btn(Rect2(vs.x / 2 - 100, pnl.end.y - 76, 200, 56), "KEMBALI", "back", Color(.15, .55, .25), 24)


# ---------------------------------------------------------------- jeda, hasil, pilih divisi
func _draw_pause() -> void:
	var vs := g.vs
	_dim(.62)
	var pnl := Rect2(vs.x / 2 - 250, vs.y * .12, 500, vs.y * .76)
	ui.panel(self, pnl)
	ui.center(self, "JEDA", pnl.position.y + 76, 64)
	var bx := vs.x / 2 - 160
	var y := pnl.position.y + 110
	_btn(Rect2(bx, y, 320, 64), "LANJUT", "resume", Color(.15, .55, .25), 32)
	_btn(Rect2(bx, y + 82, 320, 56), "PENGATURAN", "set", Color(.2, .35, .6), 28)
	_btn(Rect2(bx, y + 154, 320, 56), "MENU UTAMA" if g.confirm_t <= 0.0 else "TAP LAGI: KELUAR", "tomenu", Color(.6, .18, .14), 26)
	ui.center(self, "Tiket  BIRU %d  |  MERAH %d" % [maxi(g.tickets[1], 0), maxi(g.tickets[2], 0)], y + 246, 22, Color(.8, .85, .95))
	ui.center(self, "AI hidup  BIRU %d  |  MERAH %d" % [g.ai_alive[1], g.ai_alive[2]], y + 276, 18, Color(.7, .75, .85))


func _draw_over() -> void:
	var vs := g.vs
	_dim(.7)
	var pr := Rect2(vs.x / 2 - 300, vs.y * .05, 600, vs.y * .9)
	ui.panel(self, pr)
	ui.center(self, "MENANG!" if g.win else "KALAH", pr.position.y + 90, 80, Color(.4, 1, .4) if g.win else Color(1, .4, .4))
	var rows := [["KILL", str(g.kills)], ["GUGUR", str(g.deaths)], ["K/D", "%.1f" % (float(g.kills) / maxf(1.0, float(g.deaths)))],
		["BENDERA DIREBUT", str(g.flags_captured)], ["STREAK TERBAIK", str(g.best_streak)],
		["DURASI", "%d:%02d" % [int(g.match_duration / 60.0), int(g.match_duration) % 60]]]
	var y0 := pr.position.y + 140
	for i in rows.size():
		ui.left(self, rows[i][0], Vector2(pr.position.x + 60, y0 + i * 40), 24, Color(.8, .85, .95))
		ui.right(self, rows[i][1], Vector2(pr.end.x - 260, y0 + i * 40), 200, 26)
	_rank_bar(vs.x / 2, y0 + 6 * 40 + 26, 360.0)
	var by := pr.end.y - 150
	_btn(Rect2(vs.x / 2 - 170, by, 340, 64), "MAIN LAGI", "again", Color(.15, .55, .25), 30)
	_btn(Rect2(vs.x / 2 - 170, by + 78, 340, 56), "MENU UTAMA", "menu", Color(.2, .35, .6), 26)


## Potret prajurit divisi `cls` (sprite tim biru) di sudut kartu. Tanpa sprite -> tidak menggambar apa-apa.
func _draw_class_portrait(cls: int, center: Vector2) -> void:
	if not g.sprites.ok:
		return
	var frames: Array = (g.sprites.inf[1] as Array)[cls]
	if frames.is_empty():
		return
	var s: SpriteLib.Spr = frames[0]
	draw_set_transform(center, .35, Vector2.ONE)                       # sedikit miring: lebih hidup
	s.blit(self, 2.6 * float(SpriteDefs.CLASS_SCALE[cls]))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _draw_class_select() -> void:
	var vs := g.vs
	_dim(.78)
	ui.center(self, "PILIH DIVISI", vs.y * .1, 48, Color(1, .85, .3))
	var av := _available_classes()
	var n := av.size()
	var gw := vs.x - g.margin_l - g.margin_r - 80.0
	var cw := gw / 4.0 - 12.0
	var chh := vs.y * .29
	var y0 := vs.y * .17
	var nrows := 1 if n <= 4 else 2
	for k in n:
		var i := av[k]
		var rr := k / 4
		var cc := k % 4
		var inrow := mini(4, n - rr * 4)
		var rx := (vs.x - (inrow * (cw + 12.0) - 12.0)) / 2.0
		var cx0 := rx + cc * (cw + 12.0)
		var cy0 := y0 + rr * (chh + 12.0)
		var r := Rect2(cx0, cy0, cw, chh)
		_buttons.append({"r": r, "id": "cl%d" % i, "en": true})
		ui.rbox(self, r, Color(.09, .11, .15, .96), Cfg.CLASS_COLOR[i], 4 if i == g.last_class else 2, 14)
		draw_string(ui.font, Vector2(cx0, cy0 + 40), Cfg.CLASS_NAMES[i], HORIZONTAL_ALIGNMENT_CENTER, cw, 28, Cfg.CLASS_COLOR[i])
		_draw_class_portrait(i, Vector2(cx0 + 38.0, cy0 + 44.0))
		for j in 3:
			draw_string(ui.font, Vector2(cx0, cy0 + 78 + j * 28), Cfg.CLASS_DESC[i][j], HORIZONTAL_ALIGNMENT_CENTER, cw, 18, Color(.85, .88, .95))
		draw_string(ui.font, Vector2(cx0, cy0 + chh - 18), "[" + str(i + 1) + "] PILIH", HORIZONTAL_ALIGNMENT_CENTER, cw, 18, Color(.5, 1, .5))
	var sy0 := y0 + nrows * (chh + 12.0) + 14.0
	ui.left(self, "TITIK SPAWN", Vector2(g.margin_l + 40.0, sy0 + 32), 22)
	var bx := g.margin_l + 40.0 + 190.0
	var flags := g.objectives.flags
	var sel := g.spawn_choice if (g.spawn_choice < 0 or (g.spawn_choice < flags.size() and flags[g.spawn_choice].owner_team == 1)) else -1
	_btn(Rect2(bx, sy0, 86, 46), "HQ", "sp-1", Color(.2, .45, .8) if sel == -1 else Color(.15, .18, .24), 22)
	for i in flags.size():
		_btn(Rect2(bx + (i + 1) * 96.0, sy0, 86, 46), "ABCDE"[i], "sp%d" % i, Color(.2, .45, .8) if sel == i else Color(.15, .18, .24), 22, flags[i].owner_team == 1)
	if g.last_class >= 0 and (Cfg.CLASS_NEED[g.last_class] <= g.prefs.total_kills or g.cheat("unl")):
		_btn(Rect2(vs.x - g.margin_r - 40 - 320, sy0, 320, 46), "ULANG: " + Cfg.CLASS_NAMES[g.last_class], "last", Color(.15, .55, .25), 22)
	var nxt := 999999
	for i in 8:
		if Cfg.CLASS_NEED[i] > g.prefs.total_kills and Cfg.CLASS_NEED[i] < nxt:
			nxt = Cfg.CLASS_NEED[i]
	var line: String = "Total kill: " + str(g.prefs.total_kills) + "   Pangkat: " + Cfg.RANK_NAMES[_rank_index()]
	if nxt < 999999 and not g.cheat("unl"):
		line += "   |   Divisi baru terbuka di " + str(nxt) + " kill"
	ui.center(self, line, vs.y - 22, 20, Color(.8, .85, .95))


# ============================================================ sentuhan
## Panel password dev: sentuhan di luar kotak menutupnya.
func overlay_touch(p: Vector2) -> bool:
	if _password_box == null:
		return false
	if not Rect2(_password_box.position, _password_box.size).has_point(p):
		_password_box.queue_free()
		_password_box = null
	return true


func close_overlay() -> bool:
	if _password_box != null:
		_password_box.queue_free()
		_password_box = null
		return true
	return false


func tap(p: Vector2, index: int) -> void:
	if g.loading_frames > 0:
		return
	if g.mode == Game.Mode.OVER and _over_start > 0.0 and g.time - _over_start < 1.0:
		return
	for i in range(_buttons.size() - 1, -1, -1):
		var b := _buttons[i]
		if (b.r as Rect2).has_point(p):
			if not b.en:
				return
			g.ui_sfx(6)
			var id: String = b.id
			if id.begins_with("sl_"):
				_slider_id = id
				_slider_touch = index
				_apply_slider(p)
			else:
				_do(id)
			return


func release(index: int) -> void:
	if _slider_id != "" and index == _slider_touch:
		if _slider_id == "sl_sv":
			g.ui_sfx(6)
		_slider_id = ""
		g.prefs.save_all()


func drag(p: Vector2, index: int) -> void:
	if _slider_id != "" and index == _slider_touch:
		_apply_slider(p)


func _apply_slider(p: Vector2) -> void:
	for b in _buttons:
		if b.id == _slider_id:
			var v := clampf((p.x - (b.tr as Rect2).position.x) / (b.tr as Rect2).size.x, 0.0, 1.0)
			match _slider_id:
				"sl_sv": g.prefs.sfx_vol = v
				"sl_mv": g.prefs.music_vol = v
				"sl_ca": g.prefs.control_alpha = .3 + .7 * v
			return


func _do(id: String) -> void:
	var p := g.prefs
	g.haptic(10)
	match id:
		"play": g.screen = "setup"
		"help":
			g.screen = "help"
			g.help_page = 0
		"stats": g.screen = "stats"
		"set":
			g.prev_screen = g.screen
			g.screen = "set"
		"back": g.go_back()
		"go":
			p.save_all()
			g.begin_start()
		"tab0": g.settings_tab = 0
		"tab1": g.settings_tab = 1
		"t_vib": p.vibrate = not p.vibrate
		"t_sf": p.show_fps = not p.show_fps
		"t_tut": p.tutorial = not p.tutorial
		"t_af": p.auto_fire = not p.auto_fire
		"c_fps": p.fps_cap = 30 if p.fps_cap >= 60 else 60
		"c_fm": p.fire_mode = (p.fire_mode + 1) % 3
		"c_aa": p.aim_assist = (p.aim_assist + 1) % 3
		"c_zm": p.zoom = (p.zoom + 1) % 4
		"c_hs": p.control_size = (p.control_size + 1) % 3
		"c_q": p.quality = (p.quality + 1) % 4
		"c_res": p.resolution = (p.resolution + 1) % 3
		"c_ss": p.stick_style = (p.stick_style + 1) % 2
		"c_dz": p.deadzone = (p.deadzone + 1) % 3
		"c_as": p.aim_speed = (p.aim_speed + 1) % 3
		"hp_prev": g.help_page = maxi(0, g.help_page - 1)
		"hp_next": g.help_page = mini(HELP_PAGES.size(), g.help_page + 1)
		"resume": g.set_pause(false)
		"tomenu":
			if g.confirm_t > 0.0:
				g.go_menu()
			else:
				g.confirm_t = 2.5
		"again": g.begin_start()
		"menu": g.go_menu()
		"last": g.pick_class(g.last_class)
		"info":
			_info_tap_t = 2.0
			_info_taps += 1
			if _info_taps >= 3:
				_info_taps = 0
				info_open = false
				_ask_password()
			else:
				info_open = not info_open
		"infoc": info_open = false
		_:
			if id.begins_with("df"): p.difficulty = int(id.substr(2))
			elif id.begins_with("bm"): p.biome = int(id.substr(2))
			elif id.begins_with("ai"): p.ai_count = int(id.substr(2))
			elif id.begins_with("ln"): p.match_length = int(id.substr(2))
			elif id.begins_with("ch"): p.chaos = int(id.substr(2))
			elif id.begins_with("cl"): g.pick_class(int(id.substr(2)))
			elif id.begins_with("sp"): g.spawn_choice = int(id.substr(2))
			elif id.begins_with("dv"):
				var k := int(id.substr(2))
				if k < 6:
					var key: String = Game.CHEAT_KEYS[k]
					g.cheats[key] = not g.cheats[key]
				else:
					p.total_kills += 100
					p.save_all()
	if id.begins_with("c_") or id.begins_with("t_"):
		g.apply_settings()


# ============================================================ developer
func _ask_password() -> void:
	if _password_box != null:
		return
	_password_box = LineEdit.new()
	_password_box.secret = true
	_password_box.placeholder_text = "password"
	_password_box.size = Vector2(320, 48)
	_password_box.position = Vector2(g.vs.x / 2 - 160, g.vs.y * .35)
	add_child(_password_box)
	_password_box.text_submitted.connect(_check_password)
	_password_box.grab_focus()


func _check_password(txt: String) -> void:
	if txt.sha256_text() == Cfg.DEV_PASSWORD_SHA256:
		g.dev = true
	_password_box.queue_free()
	_password_box = null
