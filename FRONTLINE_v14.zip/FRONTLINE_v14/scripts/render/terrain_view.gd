class_name TerrainView
extends Node2D
## PETA STATIS (tanah, jalan, dekor, markas, gedung, tembok).
## OPTIMASI UTAMA: peta dibagi jadi potongan 1024px. Tiap potongan menggambar SEKALI (perintah gambar
## disimpan oleh Godot), lalu hanya digeser oleh kamera tanpa menjalankan GDScript lagi. Potongan di luar
## layar dibuang otomatis. Potongan hanya digambar ulang bila tembok hancur/bertambah (invalidate()).

class Chunk extends Node2D:
	var view: TerrainView
	var area := Rect2()

	func _ready() -> void:
		var ci := get_canvas_item()
		RenderingServer.canvas_item_set_custom_rect(ci, true, area)   # culling pakai kotak potongan
		RenderingServer.canvas_item_set_clip(ci, true)                # gambar tidak bocor ke potongan lain

	func _draw() -> void:
		var t0 := Time.get_ticks_usec() if view.g.profile_on else 0
		view.paint(self, area)
		if view.g.profile_on:
			view.g.draw_us += Time.get_ticks_usec() - t0

var g: Game
var _chunks: Array[Chunk] = []
var _ground: ImageTexture
var _font: Font = ThemeDB.fallback_font


func setup(game: Game) -> void:
	g = game


func refresh() -> void:
	pass


func rebuild() -> void:
	for c in _chunks:
		c.queue_free()
	_chunks.clear()
	var bio: Dictionary = Cfg.BIOMES[g.world.biome]
	_ground = Gfx.ground(bio.g1, bio.g2, 4242 + g.world.biome)
	RenderingServer.set_default_clear_color(bio.clear)
	var cs := Cfg.CHUNK
	for cx in int(ceil(Cfg.MAP_W / cs)):
		for cy in int(ceil(Cfg.MAP_H / cs)):
			var ch := Chunk.new()
			ch.view = self
			ch.area = Rect2(cx * cs, cy * cs, cs, cs).intersection(Rect2(0, 0, Cfg.MAP_W, Cfg.MAP_H))
			add_child(ch)
			_chunks.append(ch)


## Gambar ulang hanya potongan yang bersinggungan dengan r (dipanggil saat tembok berubah).
func invalidate(r: Rect2) -> void:
	for c in _chunks:
		if c.area.intersects(r):
			c.queue_redraw()


func _hits(area: Rect2, p: Vector2, radius: float) -> bool:
	return area.intersects(Rect2(p - Vector2(radius, radius), Vector2(radius, radius) * 2.0))


## Menggambar isi satu potongan. Semua koordinat adalah koordinat DUNIA.
##
## URUTAN GAMBAR DIKELOMPOKKAN PER JENIS (bukan per benda) - ini penghemat draw call terbesar di game ini.
## Aturan Godot yang sudah diukur: draw_circle SELALU 1 draw call sendiri; kotak/garis/sprite bertekstur sama yang
## berurutan digabung jadi 1 draw call; selang-seling jenis memutus gabungan. Jadi:
##   tanah -> garis tepi jalan -> cakram sambungan jalan -> garis jalan -> ... -> bayangan dekor (cakram) ->
##   sprite dekor per jenis -> kotak bangunan & bayangan tembok -> sprite atap & ubin tembok -> garis & kerangka.
## Tampilan hampir sama, draw call per potongan turun dari ~60 menjadi ~15.
func paint(c: CanvasItem, area: Rect2) -> void:
	var sp: SpriteBank = g.sprites if g.sprites.ok else null       # null = gambar vektor lama
	if sp == null or sp.roof_fans == null:
		_paint_vec(c, area)
		return
	var w := g.world
	var bo: Dictionary = Cfg.BIOMES[w.biome]
	var snow: bool = bo.snow
	var hard := Gfx.disc_hard()
	c.draw_rect(area, bo.g1)
	# ---- tanah bertekstur: ubin 256px dunia = tekstur 128px
	for gx in range(int(floor(area.position.x / 256.0)), int(floor(area.end.x / 256.0)) + 1):
		for gy in range(int(floor(area.position.y / 256.0)), int(floor(area.end.y / 256.0)) + 1):
			var org := Vector2(gx * 256.0, gy * 256.0)
			var tq := Rect2(org, Vector2(256, 256)).intersection(area)
			if tq.size.x <= 0.0 or tq.size.y <= 0.0:
				continue
			c.draw_texture_rect_region(_ground, tq, Rect2((tq.position - org) / 2.0, tq.size / 2.0))
	# ---- jalan: (garis tepi) -> (sambungan tepi) -> (garis aspal) -> (sambungan aspal); tiap kelompok = 1 draw call
	var ra := area.grow(60.0)
	for pass_i in 2:
		var col: Color = bo.road_edge if pass_i == 0 else bo.road
		var lw := 56.0 if pass_i == 0 else 44.0
		var jr := lw * .5
		for rd: PackedVector2Array in w.roads:
			for i in rd.size() - 1:
				var a := rd[i]
				var b := rd[i + 1]
				if ra.intersects(Rect2(a, Vector2.ZERO).expand(b)):
					c.draw_line(a, b, col, lw)
		for rd: PackedVector2Array in w.roads:
			for i in rd.size() - 1:
				var a := rd[i]
				var b := rd[i + 1]
				if ra.intersects(Rect2(a, Vector2.ZERO).expand(b)):
					c.draw_texture_rect(hard, Rect2(b.x - jr, b.y - jr, lw, lw), false, col)
	# ---- dekor: dikumpulkan per jenis dulu, lalu digambar per lapis
	var by_kind: Array = [[], [], [], []]                    # 0 pohon, 1 semak/kaktus, 2 batu, 3 kawah
	for d: Dictionary in w.decor:
		if _hits(area, d.p, d.r + 16.0):
			(by_kind[mini(int(d.k), 3)] as Array).append(d)
	var sh: Array = []                                      # bayangan: [pusat, radius, alpha]
	var draws: Array = []                                   # sprite: [Spr, pos, sudut, skala, warna]
	for kk in [3, 2, 1, 0]:                                  # urutan lapis: kawah di bawah, pohon paling atas
		for d: Dictionary in by_kind[kk]:
			var p: Vector2 = d.p
			var h := int(absf(p.x) * 7.0 + absf(p.y) * 13.0)   # variasi deterministik per benda (peta statis)
			var ang := float(h % 628) * .01
			var r: float = d.r
			match kk:
				0:
					if not sp.trees.is_empty():
						var ts: SpriteLib.Spr = sp.trees[h % sp.trees.size()]
						sh.append([p + Vector2(7, 9), r * .8, .22])
						draws.append([ts, p, ang, r * 2.3 / ts.size.x, SpriteDefs.TREE_TINT[w.biome]])
					else:
						_vec_tree(c, d, bo, snow)
				1:
					var bs: SpriteLib.Spr = null
					if w.biome == 1 and not sp.cacti.is_empty() and h % 3 != 0:
						bs = sp.cacti[h % sp.cacti.size()]                # GURUN: kaktus
					elif not sp.bushes.is_empty():
						bs = sp.bushes[0]
					if bs != null:
						var cactus := w.biome == 1 and sp.cacti.has(bs)
						sh.append([p + Vector2(4, 5), r * .8, .18])
						draws.append([bs, p, 0.0 if cactus else ang, r * (2.6 if cactus else 2.4) / (bs.size.y if cactus else bs.size.x),
								Color(1, 1, 1) if not snow else Color(.85, .95, 1)])
					else:
						c.draw_circle(p, r, bo.tree.lightened(.1))
						c.draw_circle(p + Vector2(-3, -3), r * .6, bo.tree.lightened(.28))
				2:
					if not sp.rocks.is_empty():
						var rs: SpriteLib.Spr = sp.rocks[0] if r < 14.0 else (sp.rocks[1] if r < 24.0 or sp.rocks.size() < 3 else sp.rocks[2])
						sh.append([p + Vector2(4, 5), r * .85, .2])
						draws.append([rs, p, ang, r * 2.2 / maxf(rs.size.x, rs.size.y), Color.WHITE])
					else:
						c.draw_circle(p + Vector2(4, 5), r, Color(0, 0, 0, .2))
						c.draw_circle(p, r, Color(.45, .45, .47))
				_:
					if not sp.craters.is_empty():
						var cs: SpriteLib.Spr = sp.craters[h % sp.craters.size()]
						sh.append([p, r * .95, .16])                     # kawah besar: lingkaran gelap lembut + sprite berskala dibatasi
						draws.append([cs, p, ang, minf(r * 2.3 / cs.size.x, 2.8), SpriteDefs.CRATER_TINT if not snow else Color(.45, .5, .58, .85)])
					else:
						c.draw_circle(p, r, Color(0, 0, 0, .16))
						c.draw_arc(p, r, 0, TAU, 20, Color(0, 0, 0, .25), 3.0)
	for e: Array in sh:                                     # semua bayangan dekor = 1 draw call
		var sc: Vector2 = e[0]
		var sr: float = e[1]
		c.draw_texture_rect(hard, Rect2(sc.x - sr, sc.y - sr, sr * 2.0, sr * 2.0), false, Color(0, 0, 0, e[2]))
	for e: Array in draws:                                  # semua sprite dekor sejenis tekstur = 1 draw call
		_blit_at(c, e[0], e[1], e[2], e[3], e[4])
	# ---- markas (hanya 2 di seluruh peta)
	for m in [1, 2]:
		var bp := Objectives.base_pos(m)
		if _hits(area, bp, 175.0):
			var tc: Color = Cfg.TEAM_COLORS[m]
			c.draw_circle(bp, 170, Color(tc, .18))
			c.draw_arc(bp, 170, 0, TAU, 40, Color(tc, .5), 3)
			c.draw_arc(bp, 120, 0, TAU, 32, Color(tc, .25), 2)
			c.draw_string(_font, bp + Vector2(-60, 14), "HQ", HORIZONTAL_ALIGNMENT_CENTER, 120, 44, Color(tc, .55))
	c.draw_rect(Rect2(0, 0, Cfg.MAP_W, Cfg.MAP_H), Color(0, 0, 0, .5), false, 8)
	# ---- gedung & tembok. Lapis 1: semua KOTAK (bayangan, dasar atap, bayangan tembok) = 1 draw call
	var base: Color = SpriteDefs.ROOF_BASE[sp.skin]
	var blds: Array[Rect2] = []
	for b in w.buildings:
		if area.intersects(b.grow(12.0)):
			blds.append(b)
	var wls: Array[Rect2] = []
	for wl in w.walls:
		if area.intersects(wl.grow(8.0)):
			wls.append(wl)
	for b in blds:
		c.draw_rect(Rect2(b.position + Vector2(9, 11), b.size), Color(0, 0, 0, .26))
	for b in blds:
		c.draw_rect(b, base.darkened(.4))
		c.draw_rect(b.grow(-6), base.darkened(.15))
		c.draw_rect(b.grow(-12), base)
	for wl in wls:
		c.draw_rect(Rect2(wl.position + Vector2(4, 5), wl.size), Color(0, 0, 0, .22))
	# Lapis 2: semua SPRITE (detail atap, ubin tembok) = 1-2 draw call
	for b in blds:
		_paint_roof_details(c, b, sp)
	if not sp.walls.is_empty():
		for wl in wls:
			_paint_wall_spr(c, wl, sp)
	else:
		for wl in wls:
			c.draw_rect(wl, Color(.56, .5, .38))
			c.draw_rect(wl.grow(-4), Color(.66, .6, .46))
	# Lapis 3: garis (alur atap, kerangka) lalu kotak salju
	for b in blds:
		var cc := b.get_center()
		if b.size.x >= b.size.y:
			c.draw_line(Vector2(b.position.x + 14, cc.y), Vector2(b.end.x - 14, cc.y), Color(0, 0, 0, .18), 3)
		else:
			c.draw_line(Vector2(cc.x, b.position.y + 14), Vector2(cc.x, b.end.y - 14), Color(0, 0, 0, .18), 3)
		c.draw_rect(b, Color(.1, .1, .13), false, 4)
	if snow:
		for b in blds:
			c.draw_rect(b.grow(-26), Color(1, 1, 1, .35))


## Pohon gambar vektor (hanya dipakai bila daftar sprite pohon kosong).
func _vec_tree(c: CanvasItem, d: Dictionary, bo: Dictionary, snow: bool) -> void:
	var p: Vector2 = d.p
	var r: float = d.r
	c.draw_circle(p + Vector2(7, 9), r, Color(0, 0, 0, .22))
	c.draw_circle(p, r, bo.tree.darkened(.18))
	c.draw_circle(p + Vector2(-r * .15, -r * .18), r * .72, bo.tree.lerp(Color.WHITE, .04 + d.v * .08))
	c.draw_circle(p + Vector2(-r * .3, -r * .3), r * .32, bo.tree.lightened(.22))
	if snow:
		c.draw_circle(p + Vector2(-r * .1, -r * .1), r * .45, Color(.95, .97, 1, .85))


## Jalur GAMBAR VEKTOR (cadangan bila atlas sprite tidak ada). Tidak dioptimalkan, tapi tidak pernah dipakai bila sprite ada.
func _paint_vec(c: CanvasItem, area: Rect2) -> void:
	var w := g.world
	var bo: Dictionary = Cfg.BIOMES[w.biome]
	var snow: bool = bo.snow
	var sp: SpriteBank = g.sprites if g.sprites.ok else null       # null = gambar vektor lama
	c.draw_rect(area, bo.g1)
	# ---- tanah bertekstur: ubin 256px dunia = tekstur 128px
	for gx in range(int(floor(area.position.x / 256.0)), int(floor(area.end.x / 256.0)) + 1):
		for gy in range(int(floor(area.position.y / 256.0)), int(floor(area.end.y / 256.0)) + 1):
			var org := Vector2(gx * 256.0, gy * 256.0)
			var tq := Rect2(org, Vector2(256, 256)).intersection(area)
			if tq.size.x <= 0.0 or tq.size.y <= 0.0:
				continue
			c.draw_texture_rect_region(_ground, tq, Rect2((tq.position - org) / 2.0, tq.size / 2.0))
	# ---- jalan (dipotong per ruas supaya kotak gambar potongan tidak membengkak)
	var ra := area.grow(60.0)
	for rd: PackedVector2Array in w.roads:
		for i in rd.size() - 1:
			var a := rd[i]
			var b := rd[i + 1]
			if not ra.intersects(Rect2(a, Vector2.ZERO).expand(b)):
				continue
			c.draw_line(a, b, bo.road_edge, 56.0)
			c.draw_circle(b, 28.0, bo.road_edge)
	for rd: PackedVector2Array in w.roads:
		for i in rd.size() - 1:
			var a := rd[i]
			var b := rd[i + 1]
			if not ra.intersects(Rect2(a, Vector2.ZERO).expand(b)):
				continue
			c.draw_line(a, b, bo.road, 44.0)
			c.draw_circle(b, 22.0, bo.road)
	# ---- dekor
	for d: Dictionary in w.decor:
		var p: Vector2 = d.p
		if not _hits(area, p, d.r + 16.0):
			continue
		# variasi deterministik per benda (peta statis: hasilnya selalu sama tiap digambar ulang)
		var h := int(absf(p.x) * 7.0 + absf(p.y) * 13.0)
		var ang := float(h % 628) * .01
		match d.k:
			0:
				var ts: SpriteLib.Spr = sp.trees[h % sp.trees.size()] if (sp != null and not sp.trees.is_empty()) else null
				if ts != null:
					c.draw_circle(p + Vector2(7, 9), d.r * .8, Color(0, 0, 0, .22))
					_blit_at(c, ts, p, ang, d.r * 2.3 / ts.size.x, SpriteDefs.TREE_TINT[w.biome])
				else:
					c.draw_circle(p + Vector2(7, 9), d.r, Color(0, 0, 0, .22))
					c.draw_circle(p, d.r, bo.tree.darkened(.18))
					c.draw_circle(p + Vector2(-d.r * .15, -d.r * .18), d.r * .72, bo.tree.lerp(Color.WHITE, .04 + d.v * .08))
					c.draw_circle(p + Vector2(-d.r * .3, -d.r * .3), d.r * .32, bo.tree.lightened(.22))
					if snow:
						c.draw_circle(p + Vector2(-d.r * .1, -d.r * .1), d.r * .45, Color(.95, .97, 1, .85))
			1:
				var bs: SpriteLib.Spr = null
				if sp != null:
					if w.biome == 1 and not sp.cacti.is_empty() and h % 3 != 0:
						bs = sp.cacti[h % sp.cacti.size()]                # GURUN: kaktus
					elif not sp.bushes.is_empty():
						bs = sp.bushes[0]
				if bs != null:
					var cactus := w.biome == 1 and sp.cacti.has(bs)
					c.draw_circle(p + Vector2(4, 5), d.r * .8, Color(0, 0, 0, .18))
					_blit_at(c, bs, p, 0.0 if cactus else ang, d.r * (2.6 if cactus else 2.4) / (bs.size.y if cactus else bs.size.x), Color(1, 1, 1) if not snow else Color(.85, .95, 1))
				else:
					c.draw_circle(p, d.r, bo.tree.lightened(.1))
					c.draw_circle(p + Vector2(-3, -3), d.r * .6, bo.tree.lightened(.28))
			2:
				var rs: SpriteLib.Spr = null
				if sp != null and not sp.rocks.is_empty():
					rs = sp.rocks[0] if d.r < 14.0 else (sp.rocks[1] if d.r < 24.0 or sp.rocks.size() < 3 else sp.rocks[2])
				if rs != null:
					c.draw_circle(p + Vector2(4, 5), d.r * .85, Color(0, 0, 0, .2))
					_blit_at(c, rs, p, ang, d.r * 2.2 / maxf(rs.size.x, rs.size.y), Color.WHITE)
				else:
					c.draw_circle(p + Vector2(4, 5), d.r, Color(0, 0, 0, .2))
					c.draw_circle(p, d.r, Color(.45, .45, .47))
					c.draw_circle(p + Vector2(-d.r * .25, -d.r * .25), d.r * .55, Color(.6, .6, .62))
			_:
				var cs: SpriteLib.Spr = sp.craters[h % sp.craters.size()] if (sp != null and not sp.craters.is_empty()) else null
				if cs != null:
					# kawah besar: lingkaran gelap lembut + sprite berskala dibatasi (menghindari piksel kasar)
					c.draw_circle(p, d.r * .95, Color(0, 0, 0, .16))
					_blit_at(c, cs, p, ang, minf(d.r * 2.3 / cs.size.x, 2.8), SpriteDefs.CRATER_TINT if not snow else Color(.45, .5, .58, .85))
				else:
					c.draw_circle(p, d.r, Color(0, 0, 0, .16))
					c.draw_arc(p, d.r, 0, TAU, 20, Color(0, 0, 0, .25), 3.0)
	# ---- markas
	for m in [1, 2]:
		var bp := Objectives.base_pos(m)
		if _hits(area, bp, 175.0):
			var tc: Color = Cfg.TEAM_COLORS[m]
			c.draw_circle(bp, 170, Color(tc, .18))
			c.draw_arc(bp, 170, 0, TAU, 40, Color(tc, .5), 3)
			c.draw_arc(bp, 120, 0, TAU, 32, Color(tc, .25), 2)
			c.draw_string(_font, bp + Vector2(-60, 14), "HQ", HORIZONTAL_ALIGNMENT_CENTER, 120, 44, Color(tc, .55))
	c.draw_rect(Rect2(0, 0, Cfg.MAP_W, Cfg.MAP_H), Color(0, 0, 0, .5), false, 8)
	# ---- gedung
	for b in w.buildings:
		if not area.intersects(b.grow(12.0)):
			continue
		c.draw_rect(Rect2(b.position + Vector2(9, 11), b.size), Color(0, 0, 0, .26))
		if sp != null and sp.roof_fans != null:
			_paint_roof_spr(c, b, sp)
			if snow:
				c.draw_rect(b.grow(-26), Color(1, 1, 1, .35))
			continue
		c.draw_rect(b, bo.roof.darkened(.15))
		c.draw_rect(b.grow(-10), bo.roof)
		c.draw_rect(b.grow(-22), bo.roof2)
		c.draw_rect(b, Color(.1, .1, .13), false, 4)
		var cc := b.get_center()
		if b.size.x >= b.size.y:
			c.draw_line(Vector2(b.position.x + 12, cc.y), Vector2(b.end.x - 12, cc.y), Color(0, 0, 0, .25), 3)
		else:
			c.draw_line(Vector2(cc.x, b.position.y + 12), Vector2(cc.x, b.end.y - 12), Color(0, 0, 0, .25), 3)
		c.draw_rect(Rect2(b.position + Vector2(16, 16), Vector2(18, 14)), bo.roof.darkened(.3))
		if snow:
			c.draw_rect(b.grow(-26), Color(1, 1, 1, .35))
	# ---- tembok / blok pelindung (ubin sprite disusun sepanjang sisi panjang)
	for wl in w.walls:
		if not area.intersects(wl.grow(8.0)):
			continue
		c.draw_rect(Rect2(wl.position + Vector2(4, 5), wl.size), Color(0, 0, 0, .22))
		if sp != null and not sp.walls.is_empty():
			_paint_wall_spr(c, wl, sp)
		else:
			c.draw_rect(wl, Color(.56, .5, .38))
			c.draw_rect(wl.grow(-4), Color(.66, .6, .46))
			c.draw_rect(wl, Color(.25, .21, .14), false, 3)


## Satu sprite di titik p, diputar `ang`, dengan skala k (piksel dunia per piksel sprite).
func _blit_at(c: CanvasItem, s: SpriteLib.Spr, p: Vector2, ang: float, k: float, mod: Color) -> void:
	c.draw_set_transform(p, ang, Vector2.ONE)
	s.blit(c, k, mod)
	c.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


## Atap gedung bersprite (jalur vektor/cadangan): warna dasar + potongan detail (kipas, kisi, panel) berskala seragam.
## Detail hanya ditaruh bila muat di atap, posisinya deterministik dari posisi gedung.
func _paint_roof_spr(c: CanvasItem, b: Rect2, sp: SpriteBank) -> void:
	var base: Color = SpriteDefs.ROOF_BASE[sp.skin]
	c.draw_rect(b, base.darkened(.4))
	c.draw_rect(b.grow(-6), base.darkened(.15))
	c.draw_rect(b.grow(-12), base)
	var cc := b.get_center()
	if b.size.x >= b.size.y:
		c.draw_line(Vector2(b.position.x + 14, cc.y), Vector2(b.end.x - 14, cc.y), Color(0, 0, 0, .18), 3)
	else:
		c.draw_line(Vector2(cc.x, b.position.y + 14), Vector2(cc.x, b.end.y - 14), Color(0, 0, 0, .18), 3)
	_paint_roof_details(c, b, sp)
	c.draw_rect(b, Color(.1, .1, .13), false, 4)


## Hanya potongan detail atap (kipas, kisi, panel): sprite bertekstur sama, digambar berurutan antar-gedung.
func _paint_roof_details(c: CanvasItem, b: Rect2, sp: SpriteBank) -> void:
	var cc := b.get_center()
	var k := 1.4
	var h := int(absf(b.position.x) * 3.0 + absf(b.position.y) * 5.0)
	var inner := b.grow(-18)
	var fan_sz := sp.roof_fans.size * k
	var grill_sz := sp.roof_grill.size * k
	var tech_sz := sp.roof_tech.size * k
	if inner.size.x >= fan_sz.x and inner.size.y >= fan_sz.y:
		var fp := inner.position if h % 2 == 0 else Vector2(inner.end.x - fan_sz.x, inner.position.y)
		c.draw_texture_rect_region(sp.roof_fans.tex, Rect2(fp, fan_sz), sp.roof_fans.r)
	if inner.size.x >= grill_sz.x + fan_sz.x + 20.0 and inner.size.y >= grill_sz.y + fan_sz.y + 16.0:
		var gp := Vector2(cc.x - grill_sz.x * .5, inner.end.y - grill_sz.y)
		c.draw_texture_rect_region(sp.roof_grill.tex, Rect2(gp, grill_sz), sp.roof_grill.r)
	if inner.size.x >= tech_sz.x + fan_sz.x + 24.0 and inner.size.y >= tech_sz.y + 20.0:
		var tp := Vector2(inner.end.x - tech_sz.x, inner.end.y - tech_sz.y) if h % 2 == 0 else Vector2(inner.position.x, inner.end.y - tech_sz.y)
		c.draw_texture_rect_region(sp.roof_tech.tex, Rect2(tp, tech_sz), sp.roof_tech.r)


## Menyusun blok-blok sprite sepanjang tembok `wl` (sisi panjang dibagi rata, tiap blok bentuk persegi).
func _paint_wall_spr(c: CanvasItem, wl: Rect2, sp: SpriteBank) -> void:
	var horizontal := wl.size.x >= wl.size.y
	var long_side := wl.size.x if horizontal else wl.size.y
	var short_side := wl.size.y if horizontal else wl.size.x
	var n := maxi(1, int(round(long_side / maxf(short_side, 12.0))))
	var step := long_side / float(n)
	var seed_h := int(absf(wl.position.x) * 3.0 + absf(wl.position.y) * 7.0)
	for i in n:
		var s: SpriteLib.Spr = sp.walls[(seed_h + i * 5) % sp.walls.size()]
		var r := Rect2(wl.position + (Vector2(i * step, 0) if horizontal else Vector2(0, i * step)),
				Vector2(step, short_side) if horizontal else Vector2(short_side, step))
		c.draw_texture_rect_region(s.tex, r, s.r)
