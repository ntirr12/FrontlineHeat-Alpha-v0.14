class_name Hud
extends Node2D
## HUD SAAT BERMAIN (koordinat layar). Dibagi tiga lapis supaya hemat:
##   Hud (induk)      : bar tiket, bendera, panel senjata, penanda, overlay  -> tiap frame
##   MiniMapView      : minimap + kill feed                                  -> ~7x per detik
##   Controls         : analog & tombol (transparansinya diatur di Pengaturan) -> tiap frame

const BUTTON_LABELS := ["GANTI", "NAIK", "COVER", "ITEM", "LEMPAR", "RELOAD", "SKILL", "TEMBAK"]

# ------------------------------------------------------------------ minimap (redraw jarang)
class MiniMapView extends Node2D:
	var hud: Hud
	var _acc := 0.0

	func tick(dt: float) -> void:
		_acc -= dt
		if _acc <= 0.0:
			_acc = .15
			queue_redraw()

	func _draw() -> void:
		var t0 := Time.get_ticks_usec() if hud.g.profile_on else 0
		hud.paint_minimap(self)
		if hud.g.profile_on:
			hud.g.draw_us += Time.get_ticks_usec() - t0

# ------------------------------------------------------------------ analog & tombol
class Controls extends Node2D:
	var hud: Hud

	func _draw() -> void:
		var t0 := Time.get_ticks_usec() if hud.g.profile_on else 0
		hud.paint_controls(self)
		if hud.g.profile_on:
			hud.g.draw_us += Time.get_ticks_usec() - t0

var g: Game
var ui := UiKit.new()
var _minimap: MiniMapView
var _controls: Controls
var _vignette: ImageTexture
var _icons: IconAtlas                     # ikon tombol yang dibake sekali (lihat icon_atlas.gd)


func setup(game: Game) -> void:
	g = game
	_vignette = Gfx.vignette()
	_minimap = MiniMapView.new()
	_minimap.hud = self
	add_child(_minimap)
	_controls = Controls.new()
	_controls.hud = self
	add_child(_controls)
	_icons = IconAtlas.new()
	add_child(_icons)
	_icons.build(ui)


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_RESUMED or what == NOTIFICATION_WM_WINDOW_FOCUS_IN:
		if _icons != null:
			_icons.rebake()               # konteks grafis HP dapat hilang saat aplikasi di latar belakang


func rebuild() -> void:
	pass


func invalidate(_r: Rect2) -> void:
	pass


func clear() -> void:
	pass


func refresh() -> void:
	var playing := g.mode != Game.Mode.MENU
	_minimap.visible = playing
	_controls.visible = playing and not g.selecting and not g.paused and g.mode == Game.Mode.PLAY
	_controls.modulate.a = g.prefs.control_alpha
	if playing:
		_minimap.tick(get_process_delta_time())
		_controls.queue_redraw()
	queue_redraw()


func _draw() -> void:
	var t0 := Time.get_ticks_usec() if g.profile_on else 0
	_draw_all()
	if g.profile_on:
		g.draw_us += Time.get_ticks_usec() - t0


func _draw_all() -> void:
	draw_texture_rect(_vignette, Rect2(Vector2.ZERO, g.vs), false, Color(1, 1, 1, .75))
	if g.mode == Game.Mode.MENU or g.selecting:
		return
	var vs := g.vs
	var pl := g.player
	if g.prefs.show_fps:
		ui.left(self, "%d fps  Q%d  AI %d/%d%s" % [Engine.get_frames_per_second(), g.quality_level, g.ai_alive[1], g.ai_alive[2], "  DEV" if g.dev else ""], Vector2(vs.x - g.margin_r - 230, vs.y - 8), 15, Color(1, 1, 1, .55))
	_top_bar(vs.x / 2.0)
	draw_rect(Rect2(Vector2.ZERO, vs), Color(1, 0, 0, g.hurt_flash * .3))
	if g.damage_dir_t > 0.0 and pl != null:
		var al := clampf(g.damage_dir_t, 0.0, 1.0)
		draw_arc(vs / 2.0, minf(vs.y * .36, 230.0), g.damage_dir - .35, g.damage_dir + .35, 12, Color(1, .2, .15, al * .85), 10)
	if pl != null and pl.flash_t > 0.0:
		draw_rect(Rect2(Vector2.ZERO, vs), Color(1, 1, 1, clampf(pl.flash_t / 2.0, 0.0, 1.0)))
	if g.hit_marker_t > 0.0:
		var hc := vs / 2.0
		draw_line(hc + Vector2(-10, -10), hc + Vector2(10, 10), Color.WHITE, 3)
		draw_line(hc + Vector2(10, -10), hc + Vector2(-10, 10), Color.WHITE, 3)
	if g.kill_marker_t > 0.0:
		var kc := vs / 2.0
		draw_line(kc + Vector2(-16, -16), kc + Vector2(16, 16), Color(1, .25, .2), 5)
		draw_line(kc + Vector2(16, -16), kc + Vector2(-16, 16), Color(1, .25, .2), 5)
	var drone := g.player_drone
	if drone != null:
		draw_rect(Rect2(Vector2.ZERO, vs), Color(0, .2, 0, .1))
		var good := drone.signal_q > .5
		ui.left(self, "DRONE FPV  ALT %d  SINYAL %d%%" % [int(drone.alt), int(drone.signal_q * 100)], Vector2(vs.x / 2 - 170, vs.y - 60), 22, Color(.4, 1, .4) if good else Color(1, .4, .3))
		draw_rect(Rect2(vs.x / 2 - 170, vs.y - 50, 340 * drone.signal_q, 8), Color(.4, 1, .4) if good else Color(1, .4, .3))
		ui.center(self, "analog kanan ke bawah sampai mentok = NYELONAP & LEDAK  |  tombol BATAL = keluar", 110, 18)
	if pl == null:
		if not g.selecting and g.mode == Game.Mode.PLAY and not g.paused:
			ui.center(self, "GUGUR - respawn %d" % int(ceil(g.respawn_t)), vs.y * .45, 44, Color(1, .4, .4))
		return
	_panel(pl)
	if g.tip != "" and not g.selecting and g.mode == Game.Mode.PLAY:
		ui.rbox(self, Rect2(vs.x / 2 - 390, vs.y - 176, 780, 46), Color(0, 0, 0, .55), Color(1, .85, .3, .5), 2, 12)
		ui.center(self, g.tip, vs.y - 144, 24, Color(1, .95, .7))
	if g.mode == Game.Mode.PLAY and pl.hp < pl.max_hp * .3:
		draw_rect(Rect2(Vector2.ZERO, vs), Color(.8, 0, 0, .10 + .08 * sin(g.time * 6.0)))


# ============================================================ bar atas
func _top_bar(cxm: float) -> void:
	var vs := g.vs
	var bw := 360.0
	var x0 := cxm - bw / 2.0
	ui.rbox(self, Rect2(x0 - 4, 8, bw + 8, 34), Color(0, 0, 0, .5), Color(1, 1, 1, .2), 2, 10)
	var h2 := bw / 2.0 - 2.0
	var f1 := h2 * clampf(float(g.tickets[1]) / float(maxi(1, g.tickets_max[1])), 0.0, 1.0)
	var f2 := h2 * clampf(float(g.tickets[2]) / float(maxi(1, g.tickets_max[2])), 0.0, 1.0)
	draw_rect(Rect2(x0, 12, f1, 26), Cfg.TEAM_COLORS[1].darkened(.1))
	draw_rect(Rect2(x0 + bw - f2, 12, f2, 26), Cfg.TEAM_COLORS[2].darkened(.1))
	draw_line(Vector2(cxm, 12), Vector2(cxm, 38), Color(1, 1, 1, .5), 2)
	ui.left(self, str(maxi(g.tickets[1], 0)), Vector2(x0 + 8, 33), 22)
	ui.right(self, str(maxi(g.tickets[2], 0)), Vector2(x0 + bw - 68, 33), 60, 22)
	var flags := g.objectives.flags
	for i in flags.size():
		var fxp := cxm - (flags.size() - 1) * 17.0 + i * 34.0
		var f := flags[i]
		var fcl: Color = Cfg.TEAM_COLORS[f.owner_team] if f.owner_team > 0 else Color(.6, .6, .6)
		draw_circle(Vector2(fxp, 68), 13, fcl.darkened(.25))
		draw_arc(Vector2(fxp, 68), 13, 0, TAU, 16, Color.WHITE, 2)
		draw_string(ui.font, Vector2(fxp - 13, 74), "ABCDE"[i], HORIZONTAL_ALIGNMENT_CENTER, 26, 17, Color.WHITE)
		var cv := absf(f.capture)
		if cv > 0.0 and cv < 1.0:
			draw_arc(Vector2(fxp, 68), 17, -PI / 2, -PI / 2 + TAU * cv, 20, Cfg.TEAM_COLORS[1 if f.capture > 0.0 else 2], 3)
	ui.center(self, "KILL " + str(g.kills) + ("   STREAK " + str(g.streak) if g.streak >= 2 else ""), 104, 20)
	if g.msg_t > 0.0:
		var al := clampf(g.msg_t, 0.0, 1.0)
		ui.rbox(self, Rect2(cxm - 310, vs.y * .2 - 36, 620, 52), Color(0, 0, 0, .45 * al), Color(0, 0, 0, 0), 0, 12)
		ui.center(self, g.msg, vs.y * .2, 32, Color(1, .9, .4, al))


# ============================================================ minimap + kill feed
func paint_minimap(c: CanvasItem) -> void:
	var mw := 210.0
	var s := mw / Cfg.MAP_W
	var o := Vector2(g.margin_l, 12)
	var mh := Cfg.MAP_H * s
	ui.rbox(c, Rect2(o - Vector2(3, 3), Vector2(mw + 6, mh + 6)), Color(0, 0, 0, .55), Color(1, 1, 1, .25), 2, 6)
	for b in g.world.buildings:
		c.draw_rect(Rect2(o + b.position * s, b.size * s), Color(.55, .55, .55, .75))
	for u in g.units:
		if u.mount == null and u.hp > 0.0:
			c.draw_rect(Rect2(o + u.pos * s - Vector2(1.5, 1.5), Vector2(3, 3)), Cfg.TEAM_COLORS[u.team])
	for v in g.vehicles:
		if not v.dead:
			c.draw_rect(Rect2(o + v.pos * s - Vector2(3, 3), Vector2(6, 6)), Cfg.TEAM_COLORS[v.team])
	for cr in g.crates:                                             # v14: peti suplai sekutu (hijau = medis, kuning = amunisi)
		if cr.drop_t <= 0.0 and cr.team == 1:
			c.draw_rect(Rect2(o + cr.pos * s - Vector2(2, 2), Vector2(4, 4)), Color(.4, 1, .5) if cr.kind == 0 else Color(1, .85, .4))
	for al in g.airlifts:                                           # v14: C-17 yang sedang melintas
		var ap := o + al.pos * s
		c.draw_rect(Rect2(ap - Vector2(4, 1.5), Vector2(8, 3)), Cfg.TEAM_COLORS[al.team].lightened(.35))
	var ring := Gfx.ring()                                          # cincin bertekstur: semua cincin minimap = 1 draw call
	for sv in g.salvos:                                             # v14: area hantaman MLRS
		var sc := o + sv.pos * s
		var sh: float = sv.radius * s * 1.1
		c.draw_texture_rect(ring, Rect2(sc.x - sh, sc.y - sh, sh * 2.0, sh * 2.0), false, Color(1, .5, .15, .85))
	for f in g.objectives.flags:
		var fc := o + f.pos * s
		c.draw_texture_rect(ring, Rect2(fc.x - 6.0, fc.y - 6.0, 12.0, 12.0), false, Cfg.TEAM_COLORS[f.owner_team] if f.owner_team > 0 else Color(.7, .7, .7))
	for a in g.barrages:                                            # zona serangan terlihat di minimap
		var bc := o + a.pos * s
		var bh := a.radius * s * 1.06
		c.draw_texture_rect(ring, Rect2(bc.x - bh, bc.y - bh, bh * 2.0, bh * 2.0), false, Color(1, .35, .2, .8))
	for f in g.objectives.flags:
		c.draw_string(ui.font, o + f.pos * s + Vector2(-6, -7), "ABCDE"[f.index], HORIZONTAL_ALIGNMENT_CENTER, 12, 11, Color(1, 1, 1, .8))
	c.draw_rect(Rect2(o + (g.cam - g.vs / (2.0 * g.zoom)) * s, g.vs / g.zoom * s), Color(1, 1, 1, .3), false, 1.0)
	if g.player != null:
		var pp := o + g.player.pos * s
		var dd := Vector2.RIGHT.rotated(g.player.angle)
		c.draw_colored_polygon(PackedVector2Array([pp + dd * 7, pp + dd.orthogonal() * 4 - dd * 4, pp - dd.orthogonal() * 4 - dd * 4]), Color.WHITE)
	var fy := o.y + mh + 30.0
	for k in g.kill_feed:
		c.draw_string(ui.font, Vector2(g.margin_l, fy), k.text, HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(k.color, clampf(k.t, 0.0, 1.0)))
		fy += 24.0


# ============================================================ analog & tombol
## Digambar PER LAPIS agar draw call minimal: semua cakram -> semua cincin -> semua ikon -> kotak -> teks.
## (draw_circle/draw_arc tidak bisa digabung; cakram/cincin bertekstur dari Gfx bisa.)
func paint_controls(c: CanvasItem) -> void:
	var inp := g.input
	var vs := g.vs
	var r := inp.stick_radius()
	var pl := g.player
	var fixed := g.prefs.stick_style == 1
	var ga := .18 + .1 * sin(g.time * 3.0)
	var hard := Gfx.disc_hard()
	var ring := Gfx.ring()
	var pp := inp.pause_pos()
	var discs: Array = []                 # [pos, radius, warna]
	var rings: Array = []
	var texts: Array = []                 # [jenis, ...]  jenis 0 = ui.center, 1 = draw_string
	discs.append([pp, 32.0, Color(0, 0, 0, .45)])
	rings.append([pp, 32.0, Color(1, 1, 1, .55)])
	if pl != null:
		# ---- petunjuk analog: tetap = selalu tampak samar; melayang = hanya saat tutorial
		var show_hint := inp.touches.is_empty() and not inp.throwing
		if show_hint and (fixed or g.prefs.tutorial):
			var mb := inp.move_base() if fixed else Vector2(vs.x * .17, vs.y * .68)
			var ab := inp.aim_base() if fixed else Vector2(vs.x * .64, vs.y * .7)
			var strength := .16 if fixed else ga
			rings.append([mb, r, Color(1, 1, 1, strength)])
			discs.append([mb, r * .38, Color(1, 1, 1, strength * .5)])
			texts.append([0, "GERAK", mb.y + 8, 22, Color(1, 1, 1, strength + .2), mb.x - 70, 140])
			rings.append([ab, r, Color(1, .4, .35, strength)])
			if g.prefs.fire_mode != 2:
				discs.append([ab, r * .38, Color(1, .4, .35, strength * .5)])
				texts.append([0, "BIDIK / TEMBAK", ab.y + 8, 22, Color(1, .7, .65, strength + .2), ab.x - 90, 180])
			else:
				texts.append([0, "BIDIK", ab.y + 8, 22, Color(1, .7, .65, strength + .2), ab.x - 90, 180])
		# ---- analog yang sedang disentuh
		for t: TouchInput.Touch in inp.touches.values():
			if t.role == TouchInput.Role.FIRE:
				continue
			discs.append([t.base, r, Color(1, 1, 1, .07)])
			rings.append([t.base, r, Color(1, 1, 1, .4)])
			var kn := (t.pos - t.base).limit_length(r)
			var firing := false
			if t.role == TouchInput.Role.AIM and g.prefs.fire_mode < 2:
				var dz: float = Cfg.DEADZONE[g.prefs.deadzone]
				var thr := r * (dz + (.96 if g.prefs.fire_mode == 0 else .4) * (1.0 - dz))
				rings.append([t.base, thr, Color(1, .35, .3, .4)])
				firing = kn.length() >= thr - 1.0
			discs.append([t.base + kn, r * .38, Color(1, .4, .35, .6) if firing else Color(1, 1, 1, .4)])
		# ---- tombol TEMBAK
		if inp.fire_button_visible():
			var fp := inp.fire_pos()
			var fr := inp.fire_radius()
			var held := false
			var knob := Vector2.ZERO
			for t: TouchInput.Touch in inp.touches.values():
				if t.role == TouchInput.Role.FIRE:
					held = true
					knob = (t.pos - t.base).limit_length(fr * .8)
			discs.append([fp, fr, Color(.8, .15, .1, .55 if held else .32)])
			rings.append([fp, fr, Color(1, .5, .45, .9)])
			if held:
				discs.append([fp + knob, fr * .45, Color(1, .75, .7, .7)])
			texts.append([2, 7, fp, fr * .8, false])                 # jenis 2 = ikon
			texts.append([0, "TEMBAK", fp.y + fr * .62, 14, Color(1, 1, 1, .9), fp.x - fr, fr * 2.0])
		# ---- tombol aksi
		var br := inp.button_radius()
		var near_wall := g.world.near_wall(pl.pos)
		var prompt := g.vehicle_prompt
		for i in 7:
			var bp := inp.button_pos(i)
			var in_veh := pl.mount is Vehicle
			var veh_skill_on := in_veh and (pl.mount as Vehicle).boost_t > 0.0
			var veh_skill_wait := in_veh and (pl.mount as Vehicle).skill_cd > 0.0
			var on := (i == 2 and pl.in_cover) or (i == 4 and inp.throwing) or (i == 6 and (pl.disguise_t > 0.0 or pl.jammer_on or veh_skill_on))
			var dim := (i == 2 and not pl.in_cover and not near_wall) \
				or (i == 6 and not in_veh and pl.cls != Cfg.Cls.SPY and pl.cls != Cfg.Cls.ELITE and pl.cls != Cfg.Cls.SECRET) \
				or (i == 6 and veh_skill_wait)                          # v14: skill kendaraan sedang jeda
			var hl := i == 1 and prompt != "" and prompt != "TURUN" and prompt != "BATAL"
			discs.append([bp, br, Color(.2, .6, 1, .65) if on else Color(0, 0, 0, .25 if dim else .5)])
			rings.append([bp, br, Color(1, 1, 1, .3 if dim else .8)])
			if hl:
				rings.append([bp, br + 6.0 + sin(g.time * 8.0) * 3.0, Color(1, .9, .3, .9)])
			texts.append([2, i, bp + Vector2(0, -br * .18), br, dim])
			var label: String = BUTTON_LABELS[i]
			if i == 1 and prompt != "":
				label = prompt
			if i == 6 and pl.mount is Vehicle:
				var mv := pl.mount as Vehicle
				label = ("BOOST" if Cfg.VEH_SKILL_BOOST[mv.kind] else "ASAP") + ((" %d" % int(ceil(mv.skill_cd))) if mv.skill_cd > 0.0 else "")
			texts.append([1, bp + Vector2(-br, br * .66), label, br * 2.0, int(12.0 * inp.scale_factor() + 3.0), Color(1, 1, 1, .4 if dim else .95)])
	for d: Array in discs:                                              # lapis 1: semua cakram = 1 draw call
		var dp: Vector2 = d[0]
		var dr: float = d[1]
		c.draw_texture_rect(hard, Rect2(dp.x - dr, dp.y - dr, dr * 2.0, dr * 2.0), false, d[2])
	for d: Array in rings:                                              # lapis 2: semua cincin = 1 draw call
		var rp: Vector2 = d[0]
		var rr: float = d[1] * 1.06
		c.draw_texture_rect(ring, Rect2(rp.x - rr, rp.y - rr, rr * 2.0, rr * 2.0), false, d[2])
	for t: Array in texts:                                              # lapis 3: ikon (tekstur atlas ikon atau vektor cadangan)
		if t[0] == 2:
			if _icons != null and _icons.ok:
				_icons.draw_icon(c, t[1], t[2], t[3], t[4])
			else:
				ui.icon(c, t[1], t[2], t[3], t[4])
	c.draw_rect(Rect2(pp + Vector2(-9, -11), Vector2(6, 22)), Color.WHITE)    # lapis 4: ikon jeda
	c.draw_rect(Rect2(pp + Vector2(3, -11), Vector2(6, 22)), Color.WHITE)
	for t: Array in texts:                                              # lapis 5: teks
		if t[0] == 0:
			ui.center(c, t[1], t[2], t[3], t[4], t[5], t[6])
		elif t[0] == 1:
			c.draw_string(ui.font, t[1], t[2], HORIZONTAL_ALIGNMENT_CENTER, t[3], t[4], t[5])


# ============================================================ panel bawah (kelas, HP, senjata, item)
func _panel(pl: Unit) -> void:
	var vs := g.vs
	var cxm := vs.x / 2.0
	var pw := 380.0
	var ph := 112.0
	var px := cxm - pw / 2.0
	var py := vs.y - ph - 10.0
	ui.rbox(self, Rect2(px, py, pw, ph), Color(0, 0, 0, .45), Color(1, 1, 1, .16), 2, 14)
	ui.left(self, Cfg.CLASS_NAMES[pl.cls], Vector2(px + 14, py + 26), 20, Cfg.CLASS_COLOR[pl.cls])
	var skill := ""
	match pl.cls:
		Cfg.Cls.SPY:
			skill = ("SAMARAN %d" % int(pl.disguise_t)) if pl.disguise_t > 0.0 else ("SAMARAN SIAP" if pl.skill_cd <= 0.0 else ("CD %d" % int(pl.skill_cd)))
		Cfg.Cls.ELITE:
			skill = "JAMMER ON" if pl.jammer_on else "JAMMER OFF"
		Cfg.Cls.SECRET:
			skill = ("TANK CD %d" % int(pl.skill_cd)) if pl.skill_cd > 0.0 else "TANK SIAP"
	if pl.mount is Vehicle:                                          # v14: status skill kendaraan
		var mv2 := pl.mount as Vehicle
		var sname := "BOOST" if Cfg.VEH_SKILL_BOOST[mv2.kind] else "TIRAI ASAP"
		skill = ("%s %d" % [sname, int(ceil(mv2.skill_cd))]) if mv2.skill_cd > 0.0 else (sname + " SIAP")
		if mv2.kind == Cfg.Veh.MEDEVAC:
			skill = "SEMBUHKAN " + skill
	if skill != "":
		ui.right(self, skill, Vector2(px + pw - 184, py + 26), 170, 18, Color(.7, .4, 1))
	var hpf := clampf(pl.hp / pl.max_hp, 0.0, 1.0)
	ui.rbox(self, Rect2(px + 14, py + 34, pw - 28, 14), Color(0, 0, 0, .5), Color(0, 0, 0, 0), 0, 6)
	if hpf > .04:
		ui.rbox(self, Rect2(px + 14, py + 34, (pw - 28) * hpf, 14), Color(.3, .9, .3) if hpf > .3 else Color(1, .3, .25), Color(0, 0, 0, 0), 0, 6)
	var txt := ""
	if pl.mount != null:
		if pl.mount is Vehicle:
			var v := pl.mount as Vehicle
			txt = Cfg.VEH_NAMES[v.kind][v.weapon]
		else:
			txt = "TOW TURRET" if (pl.mount as Turret).type == 1 else "TWIN MG"
	elif pl.weapon == 0:
		txt = ("EXPLOSIVE AR" if pl.cls == Cfg.Cls.SECRET else "M4A1") + "  %d/30%s" % [pl.ammo, " RELOAD" if pl.reload_t > 0.0 else ""]
	elif pl.javelin_max == 0:
		txt = ("M203 x%d" % pl.m203) if pl.cls == Cfg.Cls.ASSAULT else ("PISAU" if pl.cls == Cfg.Cls.SPY else "PISTOL")
	else:
		txt = "JAVELIN x%d  LOCK %d%%" % [pl.javelin, int(clampf(pl.lock_t / float(Cfg.LOCK_TIME[pl.cls]), 0.0, 1.0) * 100.0)]
	ui.left(self, txt, Vector2(px + 14, py + 78), 24)
	var item := g.player_ctl.item
	var extra := ""
	if item < 4:
		extra = "x" + str(pl.grenades[item])
	elif item == Cfg.Item.C4:
		extra = "x" + str(pl.c4)
	elif item >= Cfg.Item.SANDBAG and (item < Cfg.Item.DROP_MG or item == Cfg.Item.BUNKER):
		extra = "BP " + str(int(pl.build_points)) + "/" + str(Cfg.ITEM_BUILD_COST[item])
	else:
		extra = (str(int(maxf(0.0, pl.radio_cd))) + "s") if pl.radio_cd > 0.0 else "SIAP"
	ui.left(self, Cfg.ITEM_NAMES[item] + "  " + extra, Vector2(px + 14, py + 102), 18, Color(1, .85, .3))
	if pl.mount == null and pl.weapon == 0 and pl.ammo <= 6 and pl.reload_t <= 0.0 and pl.cls != Cfg.Cls.JUGGERNAUT:
		ui.center(self, "RELOAD!", py - 14, 26, Color(1, .4, .3, .6 + .4 * sin(g.time * 10.0)))
	if pl.sabotage_target != null:
		draw_rect(Rect2(vs.x / 2 - 80, vs.y * .6, 160 * pl.sabotage_t / 4.0, 10), Color(1, .6, .2))
		ui.center(self, "SABOTASE...", vs.y * .6 - 8, 18)
	if pl.cls == Cfg.Cls.JUGGERNAUT:
		draw_rect(Rect2(px, py - 34, pw, 10), Color(0, 0, 0, .5))
		draw_rect(Rect2(px, py - 34, pw * pl.heat / 10.0, 10), Color(1, .3, .1) if pl.overheated else Color(1, .8, .2))
		if pl.overheated:
			ui.center(self, "OVERHEAT", py - 40, 18, Color(1, .3, .2), px, pw)
