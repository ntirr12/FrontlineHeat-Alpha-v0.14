class_name UiKit
extends RefCounted
## Alat gambar UI bersama (kotak membulat, teks tengah/kiri/kanan, tombol, slider).
## Dipakai oleh Hud dan Menus. Semua fungsi menerima `c` = CanvasItem yang sedang menggambar.

var font: Font = ThemeDB.fallback_font
var _box := StyleBoxFlat.new()


func rbox(c: CanvasItem, r: Rect2, col: Color, border := Color(0, 0, 0, 0), bw := 0, radius := 14) -> void:
	_box.bg_color = col
	_box.border_color = border
	_box.set_border_width_all(bw)
	_box.set_corner_radius_all(radius)
	c.draw_style_box(_box, r)


## Teks rata tengah pada lebar w mulai dari x0 (default seluruh layar).
func center(c: CanvasItem, s: String, y: float, size: int, col := Color.WHITE, x0 := 0.0, w := -1.0) -> void:
	var ww := w if w > 0.0 else c.get_viewport_rect().size.x
	c.draw_string(font, Vector2(x0, y), s, HORIZONTAL_ALIGNMENT_CENTER, ww, size, col)


func left(c: CanvasItem, s: String, p: Vector2, size: int, col := Color.WHITE) -> void:
	c.draw_string(font, p, s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, col)


func right(c: CanvasItem, s: String, p: Vector2, w: float, size: int, col := Color.WHITE) -> void:
	c.draw_string(font, p, s, HORIZONTAL_ALIGNMENT_RIGHT, w, size, col)


func panel(c: CanvasItem, r: Rect2) -> void:
	rbox(c, r, Color(.06, .08, .11, .94), Color(1, 1, 1, .14), 2, 18)


## Tombol UI. Mengembalikan data tombol untuk didaftarkan oleh pemanggil (hit-test saat tap).
func button(c: CanvasItem, r: Rect2, label: String, id: String, col := Color(.16, .36, .62), size := 26, enabled := true, highlight := false) -> Dictionary:
	rbox(c, r, Color(col, .94) if enabled else Color(.2, .2, .24, .9), Color(1, 1, 1, .9 if highlight else .3), 3 if highlight else 2, 12)
	c.draw_string(font, Vector2(r.position.x, r.position.y + r.size.y / 2.0 + size * .35), label, HORIZONTAL_ALIGNMENT_CENTER, r.size.x, size, Color.WHITE if enabled else Color(.55, .55, .58))
	return {"r": r, "id": id, "en": enabled}


func slider(c: CanvasItem, r: Rect2, id: String, v: float, label := "") -> Dictionary:
	var cy := r.position.y + r.size.y / 2.0
	rbox(c, Rect2(r.position.x, cy - 5, r.size.x, 10), Color(0, 0, 0, .55), Color(1, 1, 1, .3), 1, 5)
	rbox(c, Rect2(r.position.x, cy - 5, maxf(10.0, r.size.x * v), 10), Color(.3, .7, 1), Color(0, 0, 0, 0), 0, 5)
	c.draw_circle(Vector2(r.position.x + r.size.x * v, cy), 15, Color.WHITE)
	c.draw_string(font, Vector2(r.position.x, r.end.y + 16), label if label != "" else "%d%%" % int(v * 100), HORIZONTAL_ALIGNMENT_CENTER, r.size.x, 16, Color(.8, .85, .95))
	return {"r": Rect2(r.position.x - 12, r.position.y - 8, r.size.x + 24, r.size.y + 16), "id": id, "en": true, "tr": r}


## Ikon tombol aksi (0 GANTI, 1 NAIK, 2 COVER, 3 ITEM, 4 LEMPAR, 5 RELOAD, 6 SKILL, 7 TEMBAK).
func icon(c: CanvasItem, i: int, pos: Vector2, br: float, dim: bool) -> void:
	var k := br / 44.0
	var col := Color(1, 1, 1, .45 if dim else .95)
	var dk := Color(0, 0, 0, .5)
	match i:
		0:
			c.draw_rect(Rect2(pos + Vector2(-16, -8) * k, Vector2(32, 7) * k), col)
			c.draw_rect(Rect2(pos + Vector2(-20, -9) * k, Vector2(9, 12) * k), col)
			c.draw_rect(Rect2(pos + Vector2(-2, -2) * k, Vector2(6, 10) * k), col)
		1:
			c.draw_rect(Rect2(pos + Vector2(-18, -10) * k, Vector2(36, 14) * k), col)
			c.draw_rect(Rect2(pos + Vector2(-10, -18) * k, Vector2(20, 9) * k), col)
			c.draw_circle(pos + Vector2(-10, 5) * k, 5 * k, dk)
			c.draw_circle(pos + Vector2(10, 5) * k, 5 * k, dk)
		2:
			c.draw_colored_polygon(PackedVector2Array([pos + Vector2(-13, -14) * k, pos + Vector2(13, -14) * k, pos + Vector2(13, 2) * k, pos + Vector2(0, 15) * k, pos + Vector2(-13, 2) * k]), col)
		3:
			c.draw_rect(Rect2(pos + Vector2(-13, -13) * k, Vector2(26, 26) * k), col)
			c.draw_line(pos + Vector2(-13, 0) * k, pos + Vector2(13, 0) * k, dk, 2 * k)
			c.draw_line(pos + Vector2(0, -13) * k, pos + Vector2(0, 13) * k, dk, 2 * k)
		4:
			c.draw_circle(pos + Vector2(0, 3) * k, 11 * k, col)
			c.draw_rect(Rect2(pos + Vector2(-4, -12) * k, Vector2(8, 6) * k), col)
			c.draw_line(pos + Vector2(4, -10) * k, pos + Vector2(13, -14) * k, col, 3 * k)
		5:
			c.draw_arc(pos, 12 * k, .6, 5.4, 16, col, 3 * k)
			c.draw_colored_polygon(PackedVector2Array([pos + Vector2(9, -14) * k, pos + Vector2(17, -5) * k, pos + Vector2(5, -4) * k]), col)
		6:
			var pts := PackedVector2Array()
			for j in 10:
				pts.append(pos + Vector2.from_angle(-PI / 2 + j * PI / 5) * (15.0 if j % 2 == 0 else 6.5) * k)
			c.draw_colored_polygon(pts, col)
		7:                                                    # TEMBAK: pusat bidik
			c.draw_arc(pos, 15 * k, 0, TAU, 20, col, 3 * k)
			c.draw_circle(pos, 4 * k, col)
			for a in 4:
				c.draw_line(pos + Vector2.from_angle(a * PI / 2) * 10 * k, pos + Vector2.from_angle(a * PI / 2) * 21 * k, col, 3 * k)
