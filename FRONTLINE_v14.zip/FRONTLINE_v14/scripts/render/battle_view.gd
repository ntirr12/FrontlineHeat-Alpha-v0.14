class_name BattleView
extends Node2D
## LAPISAN DINAMIS: segala yang bergerak/berubah tiap frame - bendera, bangunan buatan, kendaraan,
## prajurit, peluru, efek, zona bahaya, jet, garis bidik. Digambar dalam koordinat DUNIA (kamera
## diurus oleh transform view_root), dan hanya benda di dalam layar yang digambar.
##
## KENAPA GAMBARNYA BERKELOMPOK (penting untuk HP kelas bawah):
##   Godot menggabungkan perintah gambar berurutan yang memakai tekstur yang sama menjadi SATU draw call.
##   Kalau tiap prajurit digambar utuh (bayangan, lingkaran, badan, penanda) perintah selang-seling antara
##   tekstur atlas dan bentuk vektor, sehingga batch terputus 4-5 kali per prajurit.
##   Karena itu prajurit/kendaraan/efek digambar PER LAPIS: semua bayangan, lalu semua cakram tim, lalu semua badan,
##   dst. Lingkaran/cincin memakai tekstur kecil dari Gfx (soft_disc/ring), bukan draw_circle/draw_arc.
##   Hasil ukur: draw call per frame turun drastis (lihat docs/CHANGELOG.md), tampilan sama atau lebih baik
##   (bayangan tidak lagi menimpa prajurit di dekatnya).
## Peluru senapan digabung per tim menjadi SATU draw_multiline agar ratusan peluru tetap ringan.

const HALF_PI := PI * .5
const SHADOW := Color(0, 0, 0, .28)

var g: Game
var _font: Font = ThemeDB.fallback_font
var _vr := Rect2()          # kotak layar (+ margin) dalam koordinat dunia
var _t := 0.0
var _ql := 0
var _sp: SpriteBank = null   # bank sprite (null = pakai gambar vektor)

# ---- buffer yang dipakai ulang tiap frame (tanpa alokasi)
var _ul: Array[Unit] = []                  # prajurit bersprite yang terlihat
var _us: Array[SpriteLib.Spr] = []         # sprite masing-masing (paralel dengan _ul)
var _ik := PackedFloat32Array()            # skala sprite per divisi (dihitung sekali)
var _vl: Array[Vehicle] = []               # kendaraan bersprite yang terlihat
var _vsets: Array[SpriteBank.VehSet] = []  # set sprite masing-masing (paralel dengan _vl)
var _fxb: Array = []                       # efek per jenis (bucket) untuk digambar per lapis
var _ln_p := PackedVector2Array()          # garis percikan (digabung jadi satu draw_multiline_colors)
var _ln_c := PackedColorArray()
var _gl_p := PackedVector2Array()          # lapisan cahaya aditif: pusat
var _gl_s := PackedFloat32Array()          #                       setengah ukuran
var _gl_c := PackedColorArray()            #                       warna
var _glow: GlowLayer = null


## Lapisan anak bermaterial ADITIF (cahaya menumpuk jadi lebih terang): kilatan ledakan, inti api, bara.
class GlowLayer extends Node2D:
	var view: BattleView

	func _draw() -> void:
		var tex := Gfx.glow()
		for i in view._gl_p.size():
			var h := view._gl_s[i]
			var c := view._gl_p[i]
			draw_texture_rect(tex, Rect2(c.x - h, c.y - h, h * 2.0, h * 2.0), false, view._gl_c[i])


func setup(game: Game) -> void:
	g = game
	for i in Fx.TYPE_COUNT:
		_fxb.append([])
	_glow = GlowLayer.new()
	_glow.view = self
	var m := CanvasItemMaterial.new()
	m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	_glow.material = m
	add_child(_glow)


func refresh() -> void:
	queue_redraw()


func rebuild() -> void:
	pass


func invalidate(_r: Rect2) -> void:
	pass


func clear() -> void:
	pass


func _tc(team: int) -> Color:
	return Cfg.TEAM_COLORS[team]


func _draw() -> void:
	var t0 := Time.get_ticks_usec() if g.profile_on else 0
	_draw_all()
	if g.profile_on:
		g.draw_us += Time.get_ticks_usec() - t0


func _draw_all() -> void:
	_t = g.time
	_ql = g.quality_level
	_sp = g.sprites if g.sprites.ok else null
	_vr = Rect2(g.cam - g.vs / (2.0 * g.zoom) - Vector2(150, 150), g.vs / g.zoom + Vector2(300, 300))
	if _ik.is_empty():
		for c in Cfg.CLASS_NAMES.size():
			_ik.append(SpriteDefs.INF_SCALE * float(SpriteDefs.CLASS_SCALE[c]))
	_draw_flags()
	_draw_structures()
	_draw_small_objects()
	_draw_vehicles()
	_draw_drones()
	_draw_units()
	_draw_bullets()
	_draw_fx()
	_draw_smoke_and_grenades()
	_draw_barrages()
	_draw_player_overlays()
	_draw_jets()
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	_glow.queue_redraw()                 # lapisan cahaya digambar setelah isinya terisi oleh _draw_fx


# ============================================================ bendera
func _draw_flags() -> void:
	for f in g.objectives.flags:
		if not _vr.has_point(f.pos):
			continue
		var fc: Color = _tc(f.owner_team) if f.owner_team > 0 else Color(.7, .7, .7)
		var p := f.pos
		draw_circle(p, 120, Color(fc, .12))
		draw_arc(p, 120, 0, TAU, 40, Color(fc, .6), 3)
		var cv := absf(f.capture)
		if cv > 0.0 and cv < 1.0:
			draw_arc(p, 100, -PI / 2, -PI / 2 + TAU * cv, 32, Color(_tc(1 if f.capture > 0.0 else 2), .9), 6)
		draw_line(p, p + Vector2(0, -60), Color(.9, .9, .9), 4)
		draw_colored_polygon(PackedVector2Array([p + Vector2(0, -60), p + Vector2(40 + sin(_t * 3.0) * 4.0, -50), p + Vector2(0, -38)]), fc)
		draw_string(_font, p + Vector2(-20, -72), "ABCDE"[f.index], HORIZONTAL_ALIGNMENT_CENTER, 40, 26, Color(1, 1, 1, .9))


# ============================================================ turret & bangunan
func _draw_structures() -> void:
	for q in g.turrets:
		if not _vr.has_point(q.pos):
			continue
		if _sp != null and _draw_turret_spr(q):
			continue
		var tc: Color = _tc(q.team).darkened(.3) if not q.dead else Color(.12, .12, .12)
		draw_arc(q.pos, 24, 0, TAU, 16, Color(.55, .5, .38), 8)
		draw_circle(q.pos, 15, tc)
		if not q.dead:
			draw_set_transform(q.pos, q.aim, Vector2.ONE)
			if q.type == 1:
				draw_rect(Rect2(0, -5, 38, 10), Color(.07, .07, .08))
				draw_circle(Vector2(38, 0), 4, Color(.6, .1, .1))
			else:
				draw_line(Vector2(0, -7), Vector2(32, -7), Color(.07, .07, .08), 4)
				draw_line(Vector2(0, 7), Vector2(32, 7), Color(.07, .07, .08), 4)
				draw_rect(Rect2(10, -13, 6, 26), Color(.35, .35, .38))
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			if q.hp < q.max_hp:
				draw_rect(Rect2(q.pos + Vector2(-20, -34), Vector2(40 * q.hp / q.max_hp, 4)), Color(.3, 1, .3))
	for s in g.structs:
		if not _vr.has_point(s.pos):
			continue
		if _sp != null and _draw_struct_spr(s):
			continue
		var p := s.pos
		var tc := _tc(s.team)
		match s.kind:
			Cfg.Item.TOWER:
				draw_circle(p, 16, tc.darkened(.4))
				draw_arc(p, 16, 0, TAU, 12, Color.WHITE, 2)
				draw_line(p, p + Vector2(0, -46), Color(.9, .9, .9), 3)
				draw_arc(p + Vector2(0, -46), 7 + sin(_t * 4.0) * 2.0, 0, TAU, 10, Color(tc, .8), 2)
				_hp_bar(p + Vector2(-18, 22), 36, s)
			Cfg.Item.TRAP:
				draw_line(p + Vector2(-22, -22), p + Vector2(22, 22), Color(.2, .2, .22), 6)
				draw_line(p + Vector2(22, -22), p + Vector2(-22, 22), Color(.2, .2, .22), 6)
				draw_line(p + Vector2(-26, 0), p + Vector2(26, 0), Color(.35, .35, .4), 5)
				draw_arc(p, 8, 0, TAU, 8, tc, 2)
			Cfg.Item.BUNKER:
				draw_circle(p, 56, Color(.3, .3, .33))
				draw_circle(p, 44, Color(.4, .4, .43))
				draw_arc(p, 56, 0, TAU, 24, tc, 4)
				for i in 4:
					draw_line(p + Vector2.from_angle(i * PI / 2 + PI / 4) * 40, p + Vector2.from_angle(i * PI / 2 + PI / 4) * 52, Color(.08, .08, .08), 6)
				_hp_bar(p + Vector2(-30, 62), 60, s)
			Cfg.Item.DRONE_ST:
				draw_rect(Rect2(p - Vector2(16, 10), Vector2(32, 20)), tc.darkened(.5))
				draw_circle(p, 5, Color(.9, .9, .9))
				if s.timer > 0.0:
					draw_arc(p, 20, 0, TAU * (1.0 - s.timer / 25.0), 12, Color(1, .8, .2), 3)
			Cfg.Item.JAMMER:
				draw_circle(p, 9, tc.darkened(.4))
				draw_line(p, p + Vector2(0, -30), Color(.9, .9, .9), 3)
				draw_arc(p + Vector2(0, -30), 9, PI, TAU, 8, Color(1, .6, .2), 3)
				if s.team == 1:
					draw_arc(p, 260, 0, TAU, 40, Color(1, .6, .2, .15), 2)
					draw_arc(p, 520, 0, TAU, 48, Color(1, .6, .2, .1), 2)
			Cfg.Item.WIRE:
				for i in 4:
					draw_line(p + Vector2(-34 + i * 17, -9 if i % 2 == 0 else 9), p + Vector2(-17 + i * 17, 9 if i % 2 == 0 else -9), Color(.55, .55, .58), 2)


# ---- versi bersprite (dipanggil lebih dulu; false = benda ini belum punya sprite -> pakai gambar vektor)
func _draw_turret_spr(q: Turret) -> bool:
	var gun: SpriteLib.Spr = (_sp.tur.get(q.type, {}) as Dictionary).get(q.team, null)
	if gun == null or _sp.ring == null:
		return false
	var col := Color.WHITE if not q.dead else Color(.32, .3, .3)
	if _ql < 2:
		draw_set_transform(q.pos + Vector2(3, 4), 0.0, Vector2.ONE)
		_sp.ring.blit(self, 2.1, Color(0, 0, 0, .25))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)       # WAJIB: kembalikan transform sebelum menggambar koordinat dunia
	draw_circle(q.pos, 22.0, Color(_tc(q.team), .22 if not q.dead else .06))     # lingkaran warna tim
	draw_set_transform(q.pos, 0.0, Vector2.ONE)
	_sp.ring.blit(self, 2.1, col)
	if not q.dead:
		var kick := clampf((q.shot_t - 1.3) / .2, 0.0, 1.0) * 2.5                # sentakan tembak
		draw_set_transform(q.pos - Vector2.RIGHT.rotated(q.aim) * kick, q.aim + PI * .5, Vector2.ONE)
		gun.blit(self, SpriteDefs.TURRET_SCALE, col)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if not q.dead and q.hp < q.max_hp:
		draw_rect(Rect2(q.pos + Vector2(-20, -34), Vector2(40 * q.hp / q.max_hp, 4)), Color(.3, 1, .3))
	return true


func _draw_struct_spr(s: Structure) -> bool:
	var p := s.pos
	var tc := _tc(s.team)
	match s.kind:
		Cfg.Item.TOWER:
			var t: SpriteLib.Spr = _sp.tower[s.team]
			if t == null:
				return false
			draw_circle(p, 24, Color(tc, .22))
			draw_set_transform(p, 0.0, Vector2.ONE)
			t.blit(self, 1.0)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			draw_line(p, p + Vector2(0, -46), Color(.9, .9, .9), 3)
			draw_arc(p + Vector2(0, -46), 7 + sin(_t * 4.0) * 2.0, 0, TAU, 10, Color(tc, .8), 2)
			_hp_bar(p + Vector2(-18, 26), 36, s)
		Cfg.Item.TRAP:
			if _sp.trap == null:
				return false
			draw_circle(p, 26, Color(tc, .2))
			draw_set_transform(p, 0.0, Vector2.ONE)
			_sp.trap.blit(self, 2.0)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		Cfg.Item.WIRE:
			if _sp.wire == null:
				return false
			draw_set_transform(p, 0.0, Vector2.ONE)
			_sp.wire.blit(self, 1.8)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		Cfg.Item.BUNKER:
			if _sp.bunker == null:
				return false
			draw_set_transform(p, 0.0, Vector2.ONE)
			if _sp.bunker_cover != null:
				_sp.bunker_cover.blit(self, 2.4, Color(1, 1, 1, .92))
			_sp.bunker.blit(self, 2.4)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			draw_arc(p, 56, 0, TAU, 24, tc, 4)
			_hp_bar(p + Vector2(-30, 62), 60, s)
		Cfg.Item.DRONE_ST:
			if _sp.depot == null:
				return false
			draw_circle(p, 24, Color(tc, .2))
			draw_set_transform(p, 0.0, Vector2.ONE)
			_sp.depot.blit(self, .9)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			if s.timer > 0.0:
				draw_arc(p, 26, 0, TAU * (1.0 - s.timer / 25.0), 12, Color(1, .8, .2), 3)
		_:
			return false                  # JAMMER dll: tetap gambar vektor
	return true


func _hp_bar(p: Vector2, w: float, e: Entity) -> void:
	if e.hp < e.max_hp:
		draw_rect(Rect2(p, Vector2(w * e.hp / e.max_hp, 4)), Color(.3, 1, .3))


func _draw_small_objects() -> void:
	for c in g.charges:
		draw_rect(Rect2(c.pos - Vector2(5, 5), Vector2(10, 10)), Color(.2, .2, .2))
		if int(_t * 4.0) % 2 == 0:
			draw_circle(c.pos, 3, Color(1, .1, .1))
	for m in g.mines:
		draw_circle(m.pos, 7, Color(.25, .25, .2, .3))
		draw_circle(m.pos, 2, Color(.8, .2, .2, .3))
	for b in g.beams:
		draw_line(b.a, b.b, Color(.6, 1, 1, b.t * 2.8), 7)
		draw_line(b.a, b.b, Color(1, 1, 1, b.t * 2.8), 2)
	for n in g.nukes:
		draw_arc(n.pos, 150, 0, TAU, 48, Color(1, 1, 1, .4 + .5 * sin(_t * 14.0)), 5)
		draw_arc(n.pos, 150 * (n.t / 4.0), 0, TAU, 32, Color(1, .3, .1, .8), 3)
		draw_string(_font, n.pos + Vector2(-80, -160), "NUKE %d" % int(5 - n.t), HORIZONTAL_ALIGNMENT_CENTER, 160, 26, Color(1, .4, .3))
	for a in g.drops:
		var c := a.pos + Vector2(0, -(3.0 - a.t) * 120.0)
		draw_rect(Rect2(c - Vector2(8, 6), Vector2(16, 12)), Color(.5, .4, .2))
		if _sp != null and _sp.parachute != null:
			draw_set_transform(c + Vector2(0, -30), 0.0, Vector2.ONE)
			_sp.parachute.blit(self, 1.5)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		else:
			draw_arc(c + Vector2(0, -26), 22, PI, TAU, 10, Color(.9, .9, .9), 3)
		draw_arc(a.pos, 30, 0, TAU, 12, Color(1, 1, 1, .3), 2)


# ============================================================ kendaraan
## Kendaraan bersprite digambar PER LAPIS (lihat catatan di atas kelas): bayangan -> cakram+cincin tim -> badan ->
## laras (mundur saat menembak) -> turret -> detail vektor -> api bangkai & bar HP.
## Jenis tanpa sprite memakai gambar vektor lama (_draw_vehicle).
func _draw_vehicles() -> void:
	_vl.clear()
	_vsets.clear()
	for v in g.vehicles:
		if not _vr.has_point(v.pos):
			continue
		var vs: SpriteBank.VehSet = _sp.veh_set(v.kind, v.team) if _sp != null else null
		if vs == null:
			_draw_vehicle(v)
		else:
			_vl.append(v)
			_vsets.append(vs)
	var n := _vl.size()
	if n == 0:
		return
	if _ql < 2:                                                                    # 1) bayangan = siluet badan
		for i in n:
			var v := _vl[i]
			var vs := _vsets[i]
			var hull: SpriteLib.Spr = vs.wreck if (v.dead and vs.wreck != null) else vs.body
			draw_set_transform(v.pos + Vector2(7, 10), v.heading + HALF_PI, Vector2.ONE)
			hull.blit(self, vs.scale, Color(0, 0, 0, .3))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)                             # WAJIB: transform kembali sebelum koordinat dunia
	var disc := Gfx.soft_disc()
	var ring := Gfx.ring()
	for i in n:                                                                    # 2) cakram + cincin warna tim: kawan/lawan jelas
		var v := _vl[i]
		if v.dead:
			continue
		var h := v.radius() * 1.12
		draw_texture_rect(disc, Rect2(v.pos.x - h, v.pos.y - h, h * 2.0, h * 2.0), false, Color(_tc(v.team), .2))
	for i in n:
		var v := _vl[i]
		if v.dead:
			continue
		var h := v.radius() * 1.08
		draw_texture_rect(ring, Rect2(v.pos.x - h, v.pos.y - h, h * 2.0, h * 2.0), false, Color(_tc(v.team), .85))
	for i in n:                                                                    # 2b) aura penyembuh MEDEVAC (berdenyut saat ada yang disembuhkan)
		var v := _vl[i]
		if v.kind == Cfg.Veh.MEDEVAC and not v.dead and v.driver != null:
			var ah: float = Cfg.MEDEVAC_RADIUS * (.97 + .03 * sin(_t * 3.0))
			draw_texture_rect(ring, Rect2(v.pos.x - ah, v.pos.y - ah, ah * 2.0, ah * 2.0), false, Color(.4, 1, .55, .10 + v.pulse * .32))
	for i in n:                                                                    # 3) badan
		var v := _vl[i]
		var vs := _vsets[i]
		var hull: SpriteLib.Spr = vs.wreck if (v.dead and vs.wreck != null) else vs.body
		var tint := Color.WHITE if v.dead else Color.WHITE.lerp(_tc(v.team).lightened(.15), SpriteDefs.TEAM_TINT)
		draw_set_transform(v.pos, v.heading + HALF_PI, Vector2.ONE)
		hull.blit(self, vs.scale, tint)
	for i in n:                                                                    # 4) laras
		var v := _vl[i]
		var vs := _vsets[i]
		if v.dead or vs.barrel == null:
			continue
		var tk := vs.scale * vs.tscale
		var fwd := Vector2.RIGHT.rotated(v.aim)
		var trot := v.aim + HALF_PI
		var tp := v.pos + (vs.tpos * vs.scale).rotated(v.heading + HALF_PI)
		var tint := Color.WHITE.lerp(_tc(v.team).lightened(.15), SpriteDefs.TEAM_TINT)
		draw_set_transform(tp + (vs.bpos * tk).rotated(trot) - fwd * _kick(v), trot, Vector2.ONE)
		vs.barrel.blit_xy(self, tk, tk * vs.bstretch, tint)
	for i in n:                                                                    # 5) turret
		var v := _vl[i]
		var vs := _vsets[i]
		if v.dead:
			continue
		var tur: SpriteLib.Spr = vs.turret2 if (v.weapon == 1 and vs.turret2 != null) else vs.turret
		if tur == null:
			continue
		var fwd := Vector2.RIGHT.rotated(v.aim)
		var tp := v.pos + (vs.tpos * vs.scale).rotated(v.heading + HALF_PI)
		var tint := Color.WHITE.lerp(_tc(v.team).lightened(.15), SpriteDefs.TEAM_TINT)
		draw_set_transform(tp - fwd * _kick(v) * .4, v.aim + HALF_PI, Vector2.ONE)
		tur.blit(self, vs.scale * vs.tscale, tint)
	for i in n:                                                                    # 6) detail vektor kecil
		var v := _vl[i]
		if v.dead:
			continue
		draw_set_transform(v.pos, v.aim, Vector2.ONE)
		if v.kind == Cfg.Veh.RAILGUN:                                              # kilau rel pemercepat
			draw_line(Vector2(18, 0), Vector2(62, 0), Color(.2, .9, 1, .5 + .2 * sin(_t * 9.0)), 3)
		elif v.kind == Cfg.Veh.BRADLEY and v.weapon == 1:                          # penanda mode rudal TOW
			draw_rect(Rect2(10, -21, 16, 5), Color(.6, .1, .1))
		if Cfg.VEH_SEATS[v.kind] > 1 and v.gunner != null:                         # senapan mesin penembak
			var vs := _vsets[i]
			var tp := v.pos + (vs.tpos * vs.scale).rotated(v.heading + HALF_PI)
			draw_set_transform(tp, v.gunner_aim, Vector2.ONE)
			draw_line(Vector2(3, 0), Vector2(29, 0), Color(.07, .07, .08), 4)
			draw_circle(Vector2.ZERO, 5.5, Color(.07, .07, .08))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	for i in n:                                                                    # 7) api bangkai (sprite beranimasi) & bar HP
		var v := _vl[i]
		if v.dead and _ql < 2 and not _sp.fire.is_empty():
			var fr: SpriteLib.Spr = _sp.fire[int(_t * 11.0 + v.pos.x * .05) % _sp.fire.size()]
			draw_set_transform(v.pos + Vector2(sin(_t * 5.0 + v.pos.y) * 4.0, -4.0), 0.0, Vector2.ONE)
			fr.blit_base(self, 1.0)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	for i in n:
		_veh_bar(_vl[i])


## Sentakan mundur laras/turret saat baru menembak (px).
func _kick(v: Vehicle) -> float:
	var big := v.kind == Cfg.Veh.TANK or v.kind == Cfg.Veh.RAILGUN or v.kind == Cfg.Veh.SPG
	return clampf((v.shot_t - 1.3) / .2, 0.0, 1.0) * ((10.0 if v.kind == Cfg.Veh.SPG else 8.0) if big else 2.5)


## Bar HP kendaraan (di atas badan, ikut ukuran kendaraan) + penanda BOOST aktif.
func _veh_bar(v: Vehicle) -> void:
	if v.dead:
		return
	if v.hp < v.max_hp:
		var bw := v.radius() * 1.5
		var by := -v.radius() * 1.4
		draw_rect(Rect2(v.pos + Vector2(-bw * .5 - 1, by - 1), Vector2(bw + 2, 8)), Color(0, 0, 0, .45))
		var f := clampf(v.hp / v.max_hp, 0.0, 1.0)
		draw_rect(Rect2(v.pos + Vector2(-bw * .5, by), Vector2(bw * f, 6)), Color(.3, 1, .3) if f > .3 else Color(1, .35, .25))
	if v.boost_t > 0.0:
		draw_string(_font, v.pos + Vector2(-30, v.radius() * 1.4 + 22.0), "BOOST", HORIZONTAL_ALIGNMENT_CENTER, 60, 14, Color(1, .8, .3, .9))


func _draw_vehicle(v: Vehicle) -> void:
	var dead := v.dead
	var c: Color = _tc(v.team).darkened(.45) if not dead else Color(.12, .12, .12)
	if v.kind == Cfg.Veh.RAILGUN and not dead:
		c = Color(.1, .35, .4)
	var lt := c.lightened(.25)
	var dk := Color(.07, .07, .08)
	var gl := Color(.5, .7, .85, .85) if not dead else dk
	var vsc := Vector2.ONE * Cfg.VEH_SCALE                                       # v14: kendaraan diperbesar juga pada gambar vektor
	draw_set_transform(v.pos, v.heading, vsc)
	draw_circle(Vector2(5, 7), v.radius() / Cfg.VEH_SCALE + 3.0, Color(0, 0, 0, .22))
	match v.kind:
		Cfg.Veh.HUMVEE_MG, Cfg.Veh.HUMVEE_AT:
			for sx in [-17, 17]:
				for sy in [-19, 14]:
					draw_rect(Rect2(sx - 7, sy, 14, 5), dk)
			draw_rect(Rect2(-29, -15, 58, 30), c)
			draw_rect(Rect2(14, -13, 15, 26), lt)
			draw_rect(Rect2(3, -12, 10, 24), gl)
			draw_rect(Rect2(-29, -15, 58, 30), dk, false, 2)
		Cfg.Veh.TANK:
			draw_rect(Rect2(-43, -32, 88, 12), dk)
			draw_rect(Rect2(-43, 20, 88, 12), dk)
			for i in 7:
				draw_circle(Vector2(-37 + i * 13, -26), 4.5, Color(.28, .28, .3))
				draw_circle(Vector2(-37 + i * 13, 26), 4.5, Color(.28, .28, .3))
			draw_colored_polygon(PackedVector2Array([Vector2(-40, -21), Vector2(32, -21), Vector2(47, -9), Vector2(47, 9), Vector2(32, 21), Vector2(-40, 21)]), c)
			draw_rect(Rect2(-40, -12, 12, 24), lt)
		_:
			draw_rect(Rect2(-40, -29, 80, 9), dk)
			draw_rect(Rect2(-40, 20, 80, 9), dk)
			for i in 6:
				draw_circle(Vector2(-33 + i * 13, -25), 4, Color(.28, .28, .3))
				draw_circle(Vector2(-33 + i * 13, 25), 4, Color(.28, .28, .3))
			draw_colored_polygon(PackedVector2Array([Vector2(-38, -21), Vector2(28, -21), Vector2(42, -11), Vector2(42, 11), Vector2(28, 21), Vector2(-38, 21)]), c)
			draw_rect(Rect2(-38, -21, 76, 6), lt)
			draw_rect(Rect2(-38, 15, 76, 6), lt)
	if not dead:
		draw_set_transform(v.pos, v.aim, vsc)
		match v.kind:
			Cfg.Veh.HUMVEE_MG:
				draw_circle(Vector2.ZERO, 8, lt)
				draw_line(Vector2.ZERO, Vector2(28, 0), dk, 4)
			Cfg.Veh.HUMVEE_AT:
				draw_rect(Rect2(-9, -8, 18, 16), lt)
				if v.weapon == 0:
					draw_rect(Rect2(-8, -4, 36, 8), dk)
					draw_circle(Vector2(28, 0), 4, Color(.6, .1, .1))
				else:
					draw_line(Vector2.ZERO, Vector2(26, 0), dk, 3)
			Cfg.Veh.RAILGUN:
				draw_line(Vector2.ZERO, Vector2(84, 0), Color(.2, .9, 1), 5)
				draw_line(Vector2.ZERO, Vector2(60, 0), dk, 9)
				draw_circle(Vector2.ZERO, 14, Color(.15, .45, .5))
				draw_circle(Vector2(84, 0), 4, Color(.7, 1, 1))
			Cfg.Veh.TANK:
				draw_line(Vector2.ZERO, Vector2(70, 0), dk, 8)
				draw_rect(Rect2(60, -6, 12, 12), dk)
				draw_colored_polygon(PackedVector2Array([Vector2(-22, -17), Vector2(14, -17), Vector2(26, -8), Vector2(26, 8), Vector2(14, 17), Vector2(-22, 17)]), lt)
				draw_circle(Vector2(-8, -8), 5, dk)
				draw_circle(Vector2(-8, 9), 4.5, c)
				draw_set_transform(v.pos, v.gunner_aim if v.gunner != null else v.aim, vsc)
				draw_line(Vector2(-8, -8), Vector2(8, -8), dk, 3)
			_:
				draw_line(Vector2(0, 2), Vector2(50, 2), dk, 4)
				draw_rect(Rect2(-14, -12, 28, 24), lt)
				draw_rect(Rect2(-10, -23, 24, 9), dk)
				draw_rect(Rect2(-10, 14, 24, 9), dk)
				if v.weapon == 1:
					draw_rect(Rect2(10, -21, 16, 5), Color(.6, .1, .1))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if dead and _ql < 2:
		var fo := Vector2(sin(_t * 9.0 + v.pos.x) * 7.0, cos(_t * 7.0 + v.pos.y) * 7.0)
		draw_circle(v.pos + fo, 8.0 + sin(_t * 13.0) * 2.5, Color(1, .45, .1, .75))
		draw_circle(v.pos + fo * .5, 4.0, Color(1, .9, .3, .85))
	_veh_bar(v)


func _draw_drones() -> void:
	var list: Array = g.ai_drones.duplicate()
	if g.player_drone != null:
		list.append(g.player_drone)
	for d: BO.Drone in list:
		var up := d.pos + Vector2(0, -d.alt * .35)
		draw_circle(d.pos, 9, Color(0, 0, 0, .3))
		draw_line(d.pos, up, Color(1, 1, 1, .2), 1)
		for sx in [-1, 1]:
			for sy in [-1, 1]:
				draw_arc(up + Vector2(sx * 10, sy * 10), 6, 0, TAU, 8, Color(.9, .9, .9, .8), 2)
		draw_line(up + Vector2(-10, -10), up + Vector2(10, 10), Color(.1, .1, .1), 3)
		draw_line(up + Vector2(10, -10), up + Vector2(-10, 10), Color(.1, .1, .1), 3)
		draw_circle(up, 4, Color(1, .2, .2) if d.team == 2 else Color(.3, .6, 1))


# ============================================================ prajurit
## Prajurit bersprite digambar PER LAPIS: bayangan -> cakram tim -> badan -> penanda divisi -> cincin status ->
## bar HP & tanda seru. Faksi & skin mengikuti tim + biome (lihat SpriteDefs). Frame 1 = sedang menembak.
## Animasi jalan = goyang & tekan-regang ringan (sprite sumber tidak punya frame jalan).
## Prajurit yang spritenya tidak ada memakai _draw_unit (vektor, per prajurit).
func _draw_units() -> void:
	_ul.clear()
	_us.clear()
	for u in g.units:
		if u.mount != null or u.hp <= 0.0 or not _vr.has_point(u.pos):
			continue
		if _sp != null:
			var tv := 3 - u.team if u.disguise_t > 0.0 else u.team       # Spy menyamar -> tampil sebagai musuh
			var frames: Array = (_sp.inf[tv] as Array)[u.cls]
			if not frames.is_empty():
				_ul.append(u)
				_us.append(frames[1] if (u.shot_t > 1.38 and frames.size() > 1) else frames[0])
				continue
		_draw_unit(u)
	var n := _ul.size()
	if n == 0:
		return
	var disc := Gfx.soft_disc()
	var ring := Gfx.ring()
	if _ql < 2:                                                                    # 1) bayangan
		for i in n:
			var u := _ul[i]
			draw_set_transform(u.pos + Vector2(3, 4), u.angle + HALF_PI, Vector2.ONE)
			_us[i].blit(self, _unit_k(u), SHADOW)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)                             # WAJIB: transform kembali sebelum koordinat dunia
	for i in n:                                                                    # 2) cakram warna tim di bawah kaki
		var u := _ul[i]
		var h := (_unit_r(u) + 1.0) * 1.2
		draw_texture_rect(disc, Rect2(u.pos.x - h, u.pos.y - h, h * 2.0, h * 2.0), false, Color(_tc(3 - u.team if u.disguise_t > 0.0 else u.team), .32))
	for i in n:                                                                    # 3) badan
		var u := _ul[i]
		var wob := 0.0
		var sq := 1.0
		if u.move_anim_t > 0.0 and _ql < 2:
			var ph := _t * 14.0 + u.pos.x * .03
			wob = sin(ph) * .1
			sq = 1.0 + cos(ph * 2.0) * .035
		var k := _unit_k(u)
		draw_set_transform(u.pos, u.angle + HALF_PI + wob, Vector2.ONE)
		_us[i].blit_xy(self, k, k * sq)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	for i in n:                                                                    # 4) penanda divisi
		var u := _ul[i]
		if u.cls > 0:
			var r := _unit_r(u)
			var c: Color = Cfg.CLASS_COLOR[u.cls]
			draw_texture_rect(disc, Rect2(u.pos.x - r * .85 - 3.1, u.pos.y - r * .85 - 3.1, 6.2, 6.2), false, c)
	for i in n:                                                                    # 5) cincin status
		var u := _ul[i]
		var p := u.pos
		if u.in_cover:
			draw_texture_rect(ring, Rect2(p.x - 15, p.y - 15, 30, 30), false, Color(.4, .85, 1))
		if u.flash_t > 0.0:
			draw_texture_rect(ring, Rect2(p.x - 20, p.y - 20, 40, 40), false, Color.WHITE)
		if not u.is_ai:
			var h := _unit_r(u) + 5.6
			draw_texture_rect(ring, Rect2(p.x - h, p.y - h, h * 2.0, h * 2.0), false, Color.WHITE)
			if u.spawn_protect > 0.0:
				var h2 := _unit_r(u) + 12.6
				draw_texture_rect(ring, Rect2(p.x - h2, p.y - h2, h2 * 2.0, h2 * 2.0), false, Color(.4, .9, 1, .5 + .4 * sin(_t * 12.0)))
	for i in n:                                                                    # 6) bar HP (AI yang terluka)
		var u := _ul[i]
		if u.is_ai and u.hp < u.max_hp:
			draw_rect(Rect2(u.pos + Vector2(-12, -20), Vector2(24 * u.hp / u.max_hp, 3)), Color(.3, 1, .3))
	if _ql < 2:                                                                    # 7) "!" saat baru sadar ada musuh (memperjelas perilaku AI)
		for i in n:
			var u := _ul[i]
			if u.is_ai and u.react_t > 0.0 and u.target != null:
				draw_string(_font, u.pos + Vector2(-4, -24), "!", HORIZONTAL_ALIGNMENT_CENTER, 8, 16, Color(1, .85, .2))


func _unit_k(u: Unit) -> float:
	return _ik[u.cls] * (.86 if u.in_cover else 1.0)


func _unit_r(u: Unit) -> float:
	return float(Cfg.CLASS_RADIUS[u.cls]) if not u.in_cover else 9.0


## Prajurit gambar vektor penuh (fallback bila atlas/sprite tidak ada).
func _draw_unit(u: Unit) -> void:
	var c: Color = _tc(3 - u.team if u.disguise_t > 0.0 else u.team)
	var p := u.pos
	var r := _unit_r(u)
	_draw_unit_body_vec(u, c, p, r)
	if u.in_cover:
		draw_arc(p, 14, 0, TAU, 16, Color(.4, .85, 1), 2)
	if u.flash_t > 0.0:
		draw_arc(p, 18, 0, TAU, 16, Color.WHITE, 3)
	if not u.is_ai:
		draw_arc(p, r + 5.0, 0, TAU, 20, Color.WHITE, 2)
		if u.spawn_protect > 0.0:
			draw_arc(p, r + 11.0, 0, TAU, 24, Color(.4, .9, 1, .5 + .4 * sin(_t * 12.0)), 3)
	elif u.hp < u.max_hp:
		draw_rect(Rect2(p + Vector2(-12, -20), Vector2(24 * u.hp / u.max_hp, 3)), Color(.3, 1, .3))
	if u.is_ai and u.react_t > 0.0 and u.target != null and _ql < 2:
		draw_string(_font, p + Vector2(-4, -24), "!", HORIZONTAL_ALIGNMENT_CENTER, 8, 16, Color(1, .85, .2))


## Prajurit gambar vektor (fallback bila atlas tidak ada).
func _draw_unit_body_vec(u: Unit, c: Color, p: Vector2, r: float) -> void:
	var d := Vector2.RIGHT.rotated(u.angle)
	var n := d.orthogonal()
	if _ql < 2:
		draw_circle(p + Vector2(3, 4), r, Color(0, 0, 0, .26))
	if u.move_anim_t > 0.0 and _ql < 2:
		var sw := sin(_t * 14.0 + p.x * .03) * 5.0
		draw_circle(p + d * sw + n * 5.0, 3.2, Color(.08, .08, .08))
		draw_circle(p - d * sw - n * 5.0, 3.2, Color(.08, .08, .08))
	draw_line(p + n * 4.0, p + n * 4.0 + d * 21.0, Color(.08, .08, .08), 4)
	draw_circle(p, r, c.darkened(.25))
	draw_circle(p + d * 1.5, r * .68, c)
	if u.cls > 0:
		draw_circle(p + Vector2(0, -4), 3, Cfg.CLASS_COLOR[u.cls])


# ============================================================ peluru & efek
func _draw_bullets() -> void:
	var glow := [PackedVector2Array(), PackedVector2Array(), PackedVector2Array()]
	var core := [PackedVector2Array(), PackedVector2Array(), PackedVector2Array()]
	for b in g.combat.bullets:
		if not _vr.has_point(b.pos):
			continue
		if b.kind == Cfg.Bul.RIFLE or b.kind == Cfg.Bul.EXPLO:
			var gp: PackedVector2Array = glow[b.team]
			gp.append(b.pos)
			gp.append(b.pos - b.vel * .03)
			var cp: PackedVector2Array = core[b.team]
			cp.append(b.pos)
			cp.append(b.pos - b.vel * .025)
		else:
			var big := b.kind == Cfg.Bul.SHELL
			draw_circle(b.pos, 6.0 if big else 5.0, Color(1, .5, .1, .35))
			draw_circle(b.pos, 5.0 if big else 4.0, Color(1, .6, .2))
	var glow_col := [Color(1, .8, .3, .35), Color(.45, .75, 1, .38), Color(1, .5, .35, .38)]
	var core_col := [Color(1, .95, .6), Color(.8, .93, 1), Color(1, .88, .7)]
	for t in [1, 2]:
		if _ql < 2 and (glow[t] as PackedVector2Array).size() > 0:
			draw_multiline(glow[t], glow_col[t], 5.0)
		if (core[t] as PackedVector2Array).size() > 0:
			draw_multiline(core[t], core_col[t], 2.0)


## Semua efek digambar PER LAPIS dari bawah ke atas (bukan urut kemunculan), agar sprite berurutan memakai
## tekstur atlas yang sama dan bisa digabung engine. Cahaya terang (kilatan, inti api, bara) dikumpulkan
## ke lapisan aditif (GlowLayer) dan digambar sesudah semuanya.
func _draw_fx() -> void:
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	for bk: Array in _fxb:
		bk.clear()
	_gl_p.clear()
	_gl_s.clear()
	_gl_c.clear()
	_ln_p.clear()
	_ln_c.clear()
	for f in g.fx.active:
		if _vr.has_point(f.pos):
			(_fxb[f.type] as Array).append(f)
	var disc := Gfx.soft_disc()
	var glow_on := _ql < 2
	for f: Fx in _fxb[Fx.Type.BLOOD]:
		var k := f.t / f.life
		if _sp != null and not _sp.blood.is_empty():
			var bs: SpriteLib.Spr = _sp.blood[int(absf(f.pos.x + f.pos.y)) % _sp.blood.size()]
			_fx_quad(bs, f.pos, f.radius * 2.6 * (.6 + k * .5), Color(1, 1, 1, 1.0 - k))
		else:
			_disc(disc, f.pos, f.radius * (.3 + k * .9), Color(f.color, f.color.a * (1.0 - k)))
	for f: Fx in _fxb[Fx.Type.DUST]:                                               # debu: gumpalan yang melebar, naik pelan, memudar
		var k := f.t / f.life
		var a: float = f.color.a * (1.0 - k) * minf(1.0, k * 8.0)
		var at := f.pos + f.vel * k
		if _sp != null and _sp.smoke_b != null:
			_fx_quad(_sp.smoke_b, at, f.radius * (.9 + k * 1.7), Color(f.color.r, f.color.g, f.color.b, a))
		else:
			_disc(disc, at, f.radius * (.5 + k), Color(f.color, a))
	for f: Fx in _fxb[Fx.Type.SMOKE]:
		var k := f.t / f.life
		var a: float = f.color.a * (1.0 - k) * minf(1.0, k * 6.0)
		var sat: Vector2 = f.pos + (f.vel * k if f.vel != Vector2.ZERO else Vector2(0, -k * 30.0))    # vel = total naiknya asap (kolom asap tinggi)
		if _sp != null and _sp.smoke_b != null:
			_fx_quad(_sp.smoke_b, sat, f.radius * (.9 + k * 1.8), Color(minf(f.color.r * 1.5, 1.0), minf(f.color.g * 1.5, 1.0), minf(f.color.b * 1.5, 1.0), a))
		else:
			_disc(disc, sat, f.radius * (.45 + k * .9), Color(f.color, a))
	for f: Fx in _fxb[Fx.Type.EXPLOSION]:
		var k := f.t / f.life
		var fr: Array = []
		var mult := 2.4
		if _sp != null:
			if f.radius >= 60.0 and not _sp.expl_m.is_empty():
				fr = _sp.expl_m
				mult = 2.7
			elif not _sp.expl_s.is_empty():
				fr = _sp.expl_s
		if fr.is_empty():
			_disc(disc, f.pos, f.radius * (.3 + k * .9), Color(f.color, f.color.a * (1.0 - k)))
		else:
			_fx_quad(fr[mini(int(k * fr.size()), fr.size() - 1)], f.pos, f.radius * mult, Color.WHITE)
		if glow_on:
			_glow_add(f.pos, f.radius * 1.9, Color(1, .62, .25, .5 * (1.0 - k)))
	for f: Fx in _fxb[Fx.Type.PUFF]:
		var k := f.t / f.life
		_disc(disc, f.pos, f.radius * (.3 + k * .9), Color(f.color, f.color.a * (1.0 - k)))
	# ---- semburan api: lidah api tekstur (bertransform sendiri) + cahaya aditif di bawahnya
	var flame := Gfx.flame()
	for f: Fx in _fxb[Fx.Type.FLAME]:
		var k := f.t / f.life
		var env := minf(k * 7.0, 1.0) * pow(1.0 - k, .75)                            # cepat menyembur, lalu mengecil
		var flick := 1.0 + .22 * sin(_t * 38.0 + f.pos.x * .7)
		var ln := f.radius * 2.9 * env * flick                                       # panjang terlihat (px)
		if ln < 2.0:
			continue
		var hh := ln / .6                                                            # tinggi quad (titik panas di 72% dari atas)
		var ww := hh * .4
		var at := f.pos + f.vel * k
		draw_set_transform(at, f.rot + HALF_PI, Vector2.ONE)
		draw_texture_rect(flame, Rect2(-ww * .5, -hh * .72, ww, hh), false, Color(1, 1, 1, 1.0 - k * .45))
		if glow_on:
			_glow_add(at + Vector2.from_angle(f.rot) * ln * .3, ln * .95, Color(1, .5, .15, .55 * env))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	for f: Fx in _fxb[Fx.Type.DEBRIS]:                                               # serpihan: lengkung naik-turun + berputar
		var k := f.t / f.life
		var at := f.pos + f.vel * k + Vector2(0, -sin(PI * k) * f.vel.length() * .3)
		draw_set_transform(at, f.rot + f.spin * k, Vector2.ONE)
		var w := f.radius * (1.0 - k * .3)
		draw_texture_rect(disc, Rect2(-w, -w * .55, w * 2.0, w * 1.1), false, Color(f.color, 1.0 - k * k))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	for f: Fx in _fxb[Fx.Type.TURRET]:                                               # turret terlempar: membumbung, berputar, jatuh
		_draw_flying_turret(f)
	for f: Fx in _fxb[Fx.Type.BODY]:                                                 # prajurit terlempar ledakan
		_draw_flying_body(f)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	for f: Fx in _fxb[Fx.Type.SPARK]:                                                # percikan: semua garis digabung jadi SATU draw call
		var k := f.t / f.life
		var sp := f.pos + f.vel * k
		_ln_p.append(sp)
		_ln_p.append(sp - f.vel.normalized() * 9.0 * (1.0 - k))
		_ln_c.append(Color(f.color, 1.0 - k))            # satu warna per GARIS (bukan per titik) - sebelumnya dobel sehingga percikan tidak pernah tergambar
	if _ln_p.size() > 0:
		draw_multiline_colors(_ln_p, _ln_c, 2.0)
	for f: Fx in _fxb[Fx.Type.EMBER]:                                                # bara: titik oranye + cahaya
		var k := f.t / f.life
		var at := f.pos + f.vel * k + Vector2(sin(f.t * 9.0 + f.pos.x) * 4.0, 0)
		_disc(disc, at, f.radius * (1.0 - k * .5), Color(1, .55, .15, 1.0 - k))
		if glow_on:
			_glow_add(at, f.radius * 4.0, Color(1, .5, .1, .5 * (1.0 - k)))
	var ring := Gfx.ring()
	for f: Fx in _fxb[Fx.Type.RING]:
		var k := f.t / f.life
		var h := f.radius * (.15 + k * .95) * 1.06
		draw_texture_rect(ring, Rect2(f.pos.x - h, f.pos.y - h, h * 2.0, h * 2.0), false, Color(f.color, f.color.a * (1.0 - k)))
	for f: Fx in _fxb[Fx.Type.MUZZLE]:
		var k := f.t / f.life
		var ms: SpriteLib.Spr = null
		if _sp != null:
			ms = _sp.muzzle_r
			if f.radius >= 20.0 and not _sp.muzzle_t.is_empty():
				ms = _sp.muzzle_t[mini(int(k * _sp.muzzle_t.size()), _sp.muzzle_t.size() - 1)]
		if ms == null:
			_disc(disc, f.pos, f.radius * (.3 + k * .9), Color(f.color, f.color.a * (1.0 - k)))
		else:
			draw_set_transform(f.pos, f.vel.angle() + HALF_PI, Vector2.ONE)
			ms.blit_base(self, 1.0 if f.radius >= 20.0 else 1.1, Color(1, 1, 1, 1.0 - k * .6))
		if glow_on and f.radius >= 20.0:
			_glow_add(f.pos, f.radius * 2.2, Color(1, .75, .35, .45 * (1.0 - k)))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	for f: Fx in _fxb[Fx.Type.FLASH]:                                                # kilatan: hanya di lapisan cahaya
		var k := f.t / f.life
		if glow_on or f.radius >= 100.0:
			_glow_add(f.pos, f.radius * (.6 + k * .6), Color(f.color.r, f.color.g, f.color.b, f.color.a * (1.0 - k) * (1.0 - k)))


func _glow_add(c: Vector2, half: float, col: Color) -> void:
	_gl_p.append(c)
	_gl_s.append(half)
	_gl_c.append(col)


## Lingkaran lembut dari tekstur bersama (pengganti draw_circle agar bisa digabung jadi satu draw call).
func _disc(tex: Texture2D, c: Vector2, r: float, col: Color) -> void:
	var h := r * 1.18
	draw_texture_rect(tex, Rect2(c.x - h, c.y - h, h * 2.0, h * 2.0), false, col)


func _draw_flying_turret(f: Fx) -> void:
	var k := f.t / f.life
	var gp := f.pos + f.vel * k                                  # posisi bayangan di tanah
	var h := sin(PI * k) * f.radius                              # tinggi (px layar ke atas)
	var sc := 1.0 + .3 * sin(PI * k)                             # makin tinggi makin dekat ke kamera
	var rot := f.rot + f.spin * k + HALF_PI
	var vs: SpriteBank.VehSet = _sp.veh_set(f.aux, f.aux2) if _sp != null else null
	if vs != null and vs.turret != null:
		var tk := vs.scale * vs.tscale * sc
		draw_set_transform(gp + Vector2(4, 6), rot, Vector2.ONE)
		vs.turret.blit(self, vs.scale * vs.tscale, Color(0, 0, 0, .3))
		draw_set_transform(gp + Vector2(0, -h), rot, Vector2.ONE)
		vs.turret.blit(self, tk, Color(.5, .45, .42))           # hangus
	else:
		_disc(Gfx.soft_disc(), gp + Vector2(0, -h), 15.0 * sc, Color(.2, .2, .2))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _draw_flying_body(f: Fx) -> void:
	var k := f.t / f.life
	var gp := f.pos + f.vel * k
	var h := sin(PI * k) * 24.0
	var col := Color(f.color).lerp(Color(.25, .2, .2), .5)
	if _sp != null and not _sp.corpses.is_empty():
		var cs: SpriteLib.Spr = _sp.corpses[int(absf(f.pos.x + f.pos.y)) % _sp.corpses.size()]
		draw_set_transform(gp + Vector2(0, -h), f.rot + f.spin * k, Vector2.ONE)
		cs.blit(self, 30.0 / maxf(cs.size.y, 1.0), Color(col.lightened(.45), 1.0))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	else:
		_disc(Gfx.soft_disc(), gp + Vector2(0, -h), 9.0, col)


## Gambar satu sprite efek berpusat di `c`, lebar `w` dunia (tinggi mengikuti rasio). Tanpa draw_set_transform.
func _fx_quad(s: SpriteLib.Spr, c: Vector2, w: float, mod: Color) -> void:
	var h := w * s.size.y / s.size.x
	draw_texture_rect_region(s.tex, Rect2(c - Vector2(w, h) * .5, Vector2(w, h)), s.r, mod)


func _draw_smoke_and_grenades() -> void:
	for c in g.smokes:
		for i in (6 if _ql == 0 else 3):
			var off := Vector2(cos(i * 1.3 + _t * .3), sin(i * 2.1 + _t * .3)) * c.radius * .5
			if _sp != null and _sp.smoke != null:
				_fx_quad(_sp.smoke, c.pos + off, c.radius * 1.55, Color(1, 1, 1, .62 * minf(1.0, c.t / 2.0)))
			else:
				draw_circle(c.pos + off, c.radius * .65, Color(.85, .85, .85, .5 * minf(1.0, c.t / 2.0)))
	var cols := [Color(.2, .4, .2), Color.WHITE, Color(.7, .7, .7), Color(.7, .7, .7)]
	for gr in g.grenades:
		draw_circle(gr.pos, 3, Color(0, 0, 0, .3))
		draw_circle(gr.pos + Vector2(0, -sin(gr.t / .9 * PI) * 40.0), 5, cols[gr.kind])


func _draw_barrages() -> void:
	for a in g.barrages:
		var pulse := .5 + .4 * sin(_t * 8.0)
		if a.team == 0 or a.ambient:                     # artileri liar: zona bahaya untuk semua pihak
			draw_arc(a.pos, a.radius, 0, TAU, 36, Color(1, .55, .15, pulse), 4)
			draw_circle(a.pos, a.radius, Color(1, .3, .1, .05))
		else:
			draw_arc(a.pos, a.radius, 0, TAU, 40, Color(1, .2, .2, pulse), 4)
			draw_string(_font, a.pos + Vector2(-90, -a.radius - 10.0), "AIRSTRIKE", HORIZONTAL_ALIGNMENT_CENTER, 180, 22, Color(1, .3, .3))


func _draw_jets() -> void:
	for j in g.jets:
		if not _vr.grow(600.0).has_point(j.pos):
			continue
		var ang := j.dir.angle()
		var js: SpriteLib.Spr = null
		if _sp != null:
			var pair: Array = _sp.jets.get(j.team, _sp.jets.get(0, []))
			if pair.size() == 2:
				js = pair[0 if j.bombs > 0 else 1]
		if js != null:
			draw_set_transform(j.pos + Vector2(40, 110), ang + PI * .5, Vector2.ONE)       # bayangan di tanah
			js.blit(self, SpriteDefs.JET_SCALE * .9, Color(0, 0, 0, .2))
			draw_set_transform(j.pos, ang + PI * .5, Vector2.ONE)
			js.blit(self, SpriteDefs.JET_SCALE)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			continue
		draw_set_transform(j.pos + Vector2(30, 90), ang, Vector2.ONE)       # bayangan di tanah
		draw_colored_polygon(PackedVector2Array([Vector2(46, 0), Vector2(-28, -30), Vector2(-12, 0), Vector2(-28, 30)]), Color(0, 0, 0, .18))
		draw_set_transform(j.pos, ang, Vector2.ONE)
		draw_colored_polygon(PackedVector2Array([Vector2(48, 0), Vector2(-28, -32), Vector2(-12, 0), Vector2(-28, 32)]), Color(.12, .13, .16, .92))
		draw_colored_polygon(PackedVector2Array([Vector2(20, 0), Vector2(-4, -8), Vector2(-4, 8)]), Color(.3, .35, .4, .9))
		draw_circle(Vector2(-14, 0), 5, Color(1, .6, .2, .8))                # nyala mesin
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


# ============================================================ overlay pemain (garis bidik, lemparan, panah tujuan)
func _draw_player_overlays() -> void:
	var pl := g.player
	if pl == null:
		return
	var inp := g.input
	if g.player_drone == null and not inp.throwing and (inp.aim.length() > .2 or inp.fire_hold_no_aim):
		var an := inp.aim.angle() if inp.aim.length() > .2 else pl.angle
		var src := pl.pos
		var rng := 520.0
		if pl.mount != null:
			an = pl.mount.aim
			src = pl.mount.pos
			rng = 700.0
		var dd := Vector2.RIGHT.rotated(an)
		var e2 := src + dd * rng
		draw_dashed_line(src + dd * 26.0, e2, Color(1, .3, .3, .55), 2, 12)
		draw_arc(e2, 12, 0, TAU, 16, Color(1, .3, .3, .9), 2)
		draw_line(e2 - Vector2(18, 0), e2 + Vector2(18, 0), Color(1, .3, .3, .9), 2)
		draw_line(e2 - Vector2(0, 18), e2 + Vector2(0, 18), Color(1, .3, .3, .9), 2)
	if inp.throwing and pl.mount == null:
		var item := g.player_ctl.item
		var dp := g.player_ctl.throw_destination(inp.throw_vec)
		draw_dashed_line(pl.pos, dp, Color(1, 1, .5, .8), 3, 10)
		draw_arc(dp, Cfg.ITEM_RADIUS[item], 0, TAU, 36, Color(1, .6, .2, .9) if item != Cfg.Item.FLASH else Color(1, 1, 1, .8), 3)
		if item == Cfg.Item.SMOKE:
			draw_arc(dp, 170, 0, TAU, 36, Color(1, .2, .2, .8), 3)
		if item == Cfg.Item.MLRS:                                    # v14: oval hantaman memanjang searah tembakan (dari markas ke sasaran)
			var back := Objectives.base_pos(pl.team) - dp
			var sdir := (-back).normalized() if back.length() > 1.0 else Vector2.RIGHT
			draw_set_transform(dp, sdir.angle(), Vector2(1.15, .85))
			draw_arc(Vector2.ZERO, Cfg.MLRS_RADIUS, 0.0, TAU, 40, Color(1, .45, .2, .9), 3)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			draw_string(_font, dp + Vector2(-80, -Cfg.MLRS_RADIUS - 8.0), "MLRS", HORIZONTAL_ALIGNMENT_CENTER, 160, 22, Color(1, .6, .3))
		elif item == Cfg.Item.PARADROP:
			draw_arc(dp, Cfg.PARADROP_SPREAD + 30.0, 0, TAU, 36, Color(.4, .75, 1, .9), 3)
			draw_string(_font, dp + Vector2(-80, -Cfg.PARADROP_SPREAD - 40.0), "TERJUN C-17", HORIZONTAL_ALIGNMENT_CENTER, 160, 22, Color(.55, .85, 1))
		elif item == Cfg.Item.DROP_SUPPLY:
			draw_string(_font, dp + Vector2(-60, -48.0), "SUPLAI", HORIZONTAL_ALIGNMENT_CENTER, 120, 20, Color(.55, 1, .65))
		draw_circle(dp, 5, Color.WHITE)
	var goal := g.objectives.nearest_target(pl.pos)
	var dg := goal - pl.pos
	if dg.length() > 300.0:
		var ar := dg.normalized()
		var b0 := pl.pos + ar * 60.0
		draw_colored_polygon(PackedVector2Array([b0 + ar * 16.0, b0 + ar.orthogonal() * 8.0, b0 - ar.orthogonal() * 8.0]), Color(1, .85, .3, .8))
	if pl.weapon == 1 and pl.mount == null and pl.lock_target != null:
		var lp := pl.lock_target.pos
		var lq := clampf(pl.lock_t / float(Cfg.LOCK_TIME[pl.cls]), 0.0, 1.0)
		draw_rect(Rect2(lp - Vector2(40, 40), Vector2(80, 80)), Color(1, 1.0 - lq, 1.0 - lq), false, 3)
		draw_arc(lp, 50, 0, TAU * lq, 24, Color(1, .2, .2), 4)
