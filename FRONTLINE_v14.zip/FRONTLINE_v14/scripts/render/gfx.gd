class_name Gfx
extends RefCounted
# Tekstur prosedural: tanah (tileable, 128x128, dipakai berulang tiap 256 px dunia)
# dan vignette layar. Dibuat sekali per match, murah di runtime.


static func _grid(r: RandomNumberGenerator, n: int) -> PackedFloat32Array:
	var g := PackedFloat32Array()
	g.resize(n * n)
	for i in n * n:
		g[i] = r.randf()
	return g


# Value-noise yang membungkus (wrap) di tepi => tile mulus.
static func _vn(g: PackedFloat32Array, n: int, u: float, v: float) -> float:
	var x := u * n
	var y := v * n
	var x0 := int(floor(x))
	var y0 := int(floor(y))
	var wx := x - x0
	var wy := y - y0
	wx = wx * wx * (3.0 - 2.0 * wx)
	wy = wy * wy * (3.0 - 2.0 * wy)
	var x1 := (x0 + 1) % n
	var y1 := (y0 + 1) % n
	x0 = x0 % n
	y0 = y0 % n
	var a := lerpf(g[y0 * n + x0], g[y0 * n + x1], wx)
	var b := lerpf(g[y1 * n + x0], g[y1 * n + x1], wx)
	return lerpf(a, b, wy)


static func ground(c1: Color, c2: Color, sd: int) -> ImageTexture:
	var N := 128
	var r := RandomNumberGenerator.new()
	r.seed = sd
	var g1 := _grid(r, 6)
	var g2 := _grid(r, 14)
	var g3 := _grid(r, 32)
	var img := Image.create_empty(N, N, false, Image.FORMAT_RGBA8)
	for y in N:
		for x in N:
			var u := x / float(N)
			var v := y / float(N)
			var n := _vn(g1, 6, u, v) * 0.5 + _vn(g2, 14, u, v) * 0.32 + _vn(g3, 32, u, v) * 0.18
			n = clampf((n - 0.5) * 1.6 + 0.5 + (r.randf() - 0.5) * 0.06, 0.0, 1.0)
			img.set_pixel(x, y, c1.lerp(c2, n))
	return ImageTexture.create_from_image(img)


static func vignette() -> ImageTexture:
	var w := 96
	var h := 54
	var img := Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	for y in h:
		for x in w:
			var dx := (x + 0.5) / w * 2.0 - 1.0
			var dy := (y + 0.5) / h * 2.0 - 1.0
			var d := sqrt(dx * dx * 0.8 + dy * dy * 1.1)
			var a := smoothstep(0.55, 1.35, d) * 0.75
			img.set_pixel(x, y, Color(0, 0, 0, a))
	return ImageTexture.create_from_image(img)


# ============================================================ v13: tekstur efek kecil (dipakai ulang oleh banyak efek)
# Dibuat dengan GradientTexture2D bawaan engine (dihitung native, bukan loop GDScript) dan di-cache.
# KENAPA: lingkaran/busur yang digambar lewat draw_circle/draw_arc masing-masing menjadi satu draw call.
# Dengan satu tekstur yang sama, ratusan lingkaran berurutan digabung engine menjadi SATU draw call.
static var _soft_disc: Texture2D = null
static var _hard_disc: Texture2D = null
static var _ring: Texture2D = null
static var _glow: Texture2D = null
static var _flame: Texture2D = null


static func _grad(offsets: Array, colors: Array, w: int, h: int, from: Vector2, to: Vector2) -> GradientTexture2D:
	var gr := Gradient.new()
	gr.offsets = PackedFloat32Array(offsets)
	gr.colors = PackedColorArray(colors)
	var t := GradientTexture2D.new()
	t.gradient = gr
	t.width = w
	t.height = h
	t.fill = GradientTexture2D.FILL_RADIAL
	t.fill_from = from
	t.fill_to = to
	return t


## Cakram putih bertepi lembut (alpha 1 di tengah). Warna & alpha diatur lewat modulate saat digambar.
static func soft_disc() -> Texture2D:
	if _soft_disc == null:
		_soft_disc = _grad([0.0, 0.68, 1.0], [Color.WHITE, Color.WHITE, Color(1, 1, 1, 0)], 64, 64, Vector2(.5, .5), Vector2(.5, 0.0))
	return _soft_disc


## Cincin tipis putih (pengganti draw_arc 360 derajat).
static func ring() -> Texture2D:
	if _ring == null:
		_ring = _grad([0.0, 0.82, 0.88, 0.93, 0.985], [Color(1, 1, 1, 0), Color(1, 1, 1, 0), Color(1, 1, 1, 1), Color(1, 1, 1, 1), Color(1, 1, 1, 0)],
				64, 64, Vector2(.5, .5), Vector2(.5, 0.0))
	return _ring


## Cahaya lembut tanpa tepi tegas (untuk lapisan aditif: kilatan ledakan, inti api).
static func glow() -> Texture2D:
	if _glow == null:
		_glow = _grad([0.0, 0.35, 1.0], [Color(1, 1, 1, 1), Color(1, 1, 1, .45), Color(1, 1, 1, 0)], 64, 64, Vector2(.5, .5), Vector2(.5, 0.0))
	return _glow


## Lidah api: pusat panas di dekat dasar, memanjang ke ATAS tekstur. Titik panas = (0.5, 0.72) dari tinggi tekstur.
static func flame() -> Texture2D:
	if _flame == null:
		_flame = _grad([0.0, 0.3, 0.62, 1.0],
				[Color(1, 1, .88, 1), Color(1, .72, .22, .95), Color(1, .34, .06, .55), Color(.45, .08, 0, 0)],
				48, 96, Vector2(.5, .72), Vector2(.5, .12))
	return _flame


## Cakram putih bertepi TEGAS (pengganti draw_circle yang tidak bisa digabung draw call-nya: satu lingkaran = satu draw call).
## Ratusan cakram ini berurutan = SATU draw call. Warna & alpha lewat modulate saat digambar.
static func disc_hard() -> Texture2D:
	if _hard_disc == null:
		_hard_disc = _grad([0.0, 0.93, 1.0], [Color.WHITE, Color.WHITE, Color(1, 1, 1, 0)], 64, 64, Vector2(.5, .5), Vector2(.5, 0.0))
	return _hard_disc
