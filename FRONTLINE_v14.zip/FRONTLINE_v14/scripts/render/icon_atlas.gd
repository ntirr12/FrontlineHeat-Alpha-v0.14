class_name IconAtlas
extends Node
## ATLAS IKON TOMBOL: 8 ikon tombol (UiKit.icon) digambar SEKALI ke satu tekstur lewat SubViewport,
## lalu dipakai sebagai quad bertekstur. Tiap ikon vektor biasa butuh 3-6 draw call; sebagai quad jadi
## ratusan ikon = 1 draw call (semuanya satu tekstur).
## Bila tekstur tidak tersedia (mode headless/tes) `ok` = false dan pemanggil memakai gambar vektor biasa.
## Ikon redup (dim) = ikon biasa dengan modulate alpha lebih kecil, jadi tidak perlu dibake dua kali.

const CELL := 96                     # ukuran satu sel (px)
const COUNT := 8
const BAKE_BR := 88.0                # ikon dibake pada br=88 (skala 2x) supaya tetap tajam saat diperkecil

var ok := false
var _vp: SubViewport
var _ui: UiKit


class Painter extends Node2D:
	var atlas: IconAtlas

	func _draw() -> void:
		for i in IconAtlas.COUNT:
			atlas._ui.icon(self, i, Vector2(IconAtlas.CELL * (i + .5), IconAtlas.CELL * .5), IconAtlas.BAKE_BR, false)


func build(ui: UiKit) -> void:
	if DisplayServer.get_name() == "headless":
		return
	_ui = ui
	_vp = SubViewport.new()
	_vp.size = Vector2i(CELL * COUNT, CELL)
	_vp.transparent_bg = true
	_vp.disable_3d = true
	_vp.render_target_update_mode = SubViewport.UPDATE_ONCE
	var p := Painter.new()
	p.atlas = self
	_vp.add_child(p)
	add_child(_vp)
	ok = true


## Render ulang (dipanggil bila aplikasi kembali dari latar belakang: konteks grafis HP bisa hilang).
func rebake() -> void:
	if ok:
		_vp.render_target_update_mode = SubViewport.UPDATE_ONCE
		_vp.get_child(0).queue_redraw()


## Gambar ikon i berpusat di pos berukuran setara UiKit.icon(..., br, ...). dim = redup.
func draw_icon(c: CanvasItem, i: int, pos: Vector2, br: float, dim: bool) -> void:
	var s := CELL * br / BAKE_BR
	c.draw_texture_rect_region(_vp.get_texture(), Rect2(pos.x - s * .5, pos.y - s * .5, s, s),
			Rect2(i * CELL, 0, CELL, CELL), Color(1, 1, 1, .47 if dim else 1.0))
