class_name SpriteBank
extends RefCounted
## BANK SPRITE SIAP GAMBAR.
## Dibuat ulang tiap pertandingan baru (skin gurun/hijau bergantung biome). Semua pencarian nama
## dilakukan SEKALI di resolve(); saat menggambar (60x/detik) renderer cuma mengambil objek dari array,
## jadi tidak ada operasi teks sama sekali di jalur panas.
##
## Bila sebuah sprite tidak ditemukan, field-nya null / array kosong -> renderer memakai gambar vektor lama
## untuk benda itu saja. Jadi aset yang belum lengkap tidak pernah merusak permainan.

## Rangkaian sprite satu kendaraan (badan + turret + laras + bangkai).
class VehSet extends RefCounted:
	var body: SpriteLib.Spr
	var turret: SpriteLib.Spr
	var turret2: SpriteLib.Spr          # turret untuk senjata ke-2 (weapon == 1); null = pakai turret
	var barrel: SpriteLib.Spr
	var wreck: SpriteLib.Spr
	var scale := 1.5
	var tscale := 1.0
	var bstretch := 1.0
	var tpos := Vector2.ZERO            # posisi turret (piksel sprite; sumbu y sudah dibalik: positif = ke bawah)
	var bpos := Vector2.ZERO

var ok := false
var skin := "tan"
var biome := 0

# ---- prajurit & kendaraan
var inf: Array = []                     # inf[tim][divisi] -> Array[Spr] (frame 0 diam, 1 menembak)
var veh: Dictionary = {}                # veh[Cfg.Veh][tim] -> VehSet
var tur: Dictionary = {}                # tur[tipe][tim] -> Spr
var jets: Dictionary = {}               # tim -> [Spr pembom, Spr hiasan]
var mlrs: Dictionary = {}               # tim -> VehSet peluncur MLRS panggilan radio (v14)
var c17: Dictionary = {}                # tim -> Spr pesawat angkut (v14)

# ---- bangunan buatan
var ring: SpriteLib.Spr                 # cincin karung pasir di bawah turret
var tower: Array = [null, null, null]   # per tim
var trap: SpriteLib.Spr
var wire: SpriteLib.Spr
var wire_d: SpriteLib.Spr
var bunker: SpriteLib.Spr
var bunker_cover: SpriteLib.Spr
var bunker_d: SpriteLib.Spr
var depot: SpriteLib.Spr

# ---- efek
var expl_s: Array[SpriteLib.Spr] = []
var expl_m: Array[SpriteLib.Spr] = []
var fire: Array[SpriteLib.Spr] = []
var muzzle_t: Array[SpriteLib.Spr] = []
var muzzle_r: SpriteLib.Spr
var smoke: SpriteLib.Spr
var smoke_b: SpriteLib.Spr
var dirt: SpriteLib.Spr
var parachute: SpriteLib.Spr
var canopy: SpriteLib.Spr               # v14: kanopi penerjun
var crate_med: SpriteLib.Spr            # v14: peti medis (salib hijau)
var crate: SpriteLib.Spr                # v14: peti amunisi
var rocket: SpriteLib.Spr               # v14: roket MLRS

# ---- detail atap gedung
var roof_fans: SpriteLib.Spr
var roof_grill: SpriteLib.Spr
var roof_tech: SpriteLib.Spr

# ---- dekor peta & bekas di tanah
var trees: Array[SpriteLib.Spr] = []          # pohon biasa; di biome SALJU otomatis varian bersalju
var rocks: Array[SpriteLib.Spr] = []
var bushes: Array[SpriteLib.Spr] = []
var cacti: Array[SpriteLib.Spr] = []
var craters: Array[SpriteLib.Spr] = []
var walls: Array[SpriteLib.Spr] = []
var decal_craters: Array[SpriteLib.Spr] = []
var blood: Array[SpriteLib.Spr] = []
var corpses: Array[SpriteLib.Spr] = []


## Menyusun ulang seluruh bank. Dipanggil Game tiap pertandingan baru (biome sudah diketahui).
func resolve(biome_index: int) -> void:
	ok = SpriteLib.load_atlas()
	if not ok:
		return
	biome = biome_index
	skin = "tan" if biome_index == 1 else "grn"      # GURUN = tan, HUTAN & SALJU = hijau
	_resolve_units()
	_resolve_vehicles()
	_resolve_buildings()
	_resolve_fx()
	_resolve_props()


func _resolve_units() -> void:
	inf = [[], [], []]
	for team in [1, 2]:
		var set_name: String = SpriteDefs.INF_SET[team][0 if skin == "tan" else 1]
		var per_cls := []
		for cls in SpriteDefs.CLASS_ROLE.size():
			var base := "inf/%s_%s" % [set_name, SpriteDefs.CLASS_ROLE[cls]]
			per_cls.append(SpriteLib.frames(base, team, skin, false))     # false = pusat massa piksel
		inf[team] = per_cls


func _resolve_vehicles() -> void:
	veh.clear()
	for kind in SpriteDefs.VEHICLES:
		veh[kind] = {}
		for team in [1, 2]:
			var d: Dictionary = SpriteDefs.VEHICLES[kind][team]
			var pre := "veh/%s/" % d.id
			var vs := VehSet.new()
			vs.body = SpriteLib.find(pre + d.body, team, skin)
			if vs.body == null:
				continue                                  # tanpa badan -> pakai gambar vektor
			vs.turret = SpriteLib.find(pre + d.turret, team, skin) if d.has("turret") else null     # MEDEVAC tanpa turret
			vs.turret2 = SpriteLib.find(pre + d.turret2, team, skin) if d.has("turret2") else null
			vs.barrel = SpriteLib.find(pre + d.barrel, team, skin) if d.has("barrel") else null
			vs.wreck = SpriteLib.find(pre + "wreck", team, skin)
			vs.scale = float(d.scale) * Cfg.VEH_SCALE            # v14: semua kendaraan diperbesar (lihat Cfg.VEH_SCALE)
			vs.tscale = d.get("tscale", 1.0)
			vs.bstretch = d.get("bstretch", 1.0)
			var tp: Vector2 = d.get("tpos", Vector2.ZERO)
			var bp: Vector2 = d.get("bpos", Vector2.ZERO)
			vs.tpos = Vector2(tp.x, -tp.y)
			vs.bpos = Vector2(bp.x, -bp.y)
			veh[kind][team] = vs
	mlrs.clear()
	for team in [1, 2]:
		var m: Dictionary = SpriteDefs.MLRS[team]
		var mv := VehSet.new()
		mv.body = SpriteLib.find("veh/%s/%s" % [m.id, m.body], team, skin)
		if mv.body == null:
			continue
		mv.turret = SpriteLib.find("veh/%s/%s" % [m.id, m.turret], team, skin)
		mv.scale = float(m.scale) * Cfg.VEH_SCALE
		var mp: Vector2 = m.get("tpos", Vector2.ZERO)
		mv.tpos = Vector2(mp.x, -mp.y)
		mlrs[team] = mv
	c17.clear()
	for team in [1, 2]:
		c17[team] = SpriteLib.find("air/c17", team)
	tur.clear()
	for ty in SpriteDefs.TURRETS:
		tur[ty] = {}
		for team in [1, 2]:
			tur[ty][team] = SpriteLib.find(SpriteDefs.TURRETS[ty][team], team, skin)
	jets.clear()
	for team in SpriteDefs.JETS:
		var pair := []
		for nm: String in SpriteDefs.JETS[team]:
			pair.append(SpriteLib.find(nm))
		jets[team] = pair


func _resolve_buildings() -> void:
	ring = SpriteLib.find("tur/ring")
	for team in [1, 2]:
		tower[team] = SpriteLib.find("bld/tower", team)
	trap = SpriteLib.find("bld/trap")
	wire = SpriteLib.find("bld/wire")
	wire_d = SpriteLib.find("bld/wire_d")
	bunker = SpriteLib.find("bld/bunker")
	bunker_cover = SpriteLib.find("bld/bunker_cover")
	bunker_d = SpriteLib.find("bld/bunker_d")
	depot = SpriteLib.find("bld/depot")


func _resolve_fx() -> void:
	expl_s = SpriteLib.frames("fx/expl_s")
	expl_m = SpriteLib.frames("fx/expl_m")
	fire = SpriteLib.frames("fx/fire")
	muzzle_t = SpriteLib.frames("fx/muzzle_t")
	muzzle_r = SpriteLib.find("fx/muzzle_r")
	smoke = SpriteLib.find("fx/smoke")
	smoke_b = SpriteLib.find("fx/smoke_b")
	dirt = SpriteLib.find("fx/dirt")
	parachute = SpriteLib.find("fx/parachute")
	canopy = SpriteLib.find("fx/canopy")
	crate_med = SpriteLib.find("fx/crate_med")
	crate = SpriteLib.find("fx/crate")
	rocket = SpriteLib.find("fx/rocket")


func _resolve_props() -> void:
	trees = _list(SpriteDefs.TREES_SNOW if biome == 2 else SpriteDefs.TREES)
	if trees.is_empty():
		trees = _list(SpriteDefs.TREES)
	rocks = _list(SpriteDefs.ROCKS)
	bushes = _list(SpriteDefs.BUSHES)
	cacti = _list(SpriteDefs.CACTI)
	craters = _list(SpriteDefs.CRATERS)
	walls = _list(SpriteDefs.WALL_BLOCKS)
	roof_fans = SpriteLib.find("roof/fans", 0, skin)
	roof_grill = SpriteLib.find("roof/grill", 0, skin)
	roof_tech = SpriteLib.find("roof/tech", 0, skin)
	decal_craters = _list(["fx/crater_l", "fx/crater_m", "fx/crater_x"])
	blood = _list(["fx/blood1", "fx/blood2", "fx/blood3", "fx/blood4"])
	corpses = _list(["fx/corpse1", "fx/infantryd", "fx/infantryd2", "fx/infd", "fx/infd2"])


func _list(names: Array) -> Array[SpriteLib.Spr]:
	var out: Array[SpriteLib.Spr] = []
	for n: String in names:
		var s := SpriteLib.find(n)
		if s != null:
			out.append(s)
	return out


## Rangkaian kendaraan untuk (jenis, tim). null bila tidak ada -> pakai gambar vektor.
func veh_set(kind: int, team: int) -> VehSet:
	if not ok or not veh.has(kind):
		return null
	return (veh[kind] as Dictionary).get(team, null)
