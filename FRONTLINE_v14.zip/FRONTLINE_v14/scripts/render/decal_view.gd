class_name DecalView
extends Node2D
## BEKAS LEDAKAN, MAYAT, DARAH di tanah. Digambar ulang hanya ~3x per detik (bukan tiap frame):
## perintah gambar disimpan Godot sehingga pergerakan kamera tidak memicu gambar ulang.

var g: Game
var _t := 0.0


func setup(game: Game) -> void:
	g = game


func clear() -> void:
	queue_redraw()


func rebuild() -> void:
	pass


func invalidate(_r: Rect2) -> void:
	pass


func refresh() -> void:
	_t -= get_process_delta_time()
	if _t <= 0.0 or g.decals_dirty:
		_t = .33
		g.decals_dirty = false
		queue_redraw()


func _draw() -> void:
	var t0 := Time.get_ticks_usec() if g.profile_on else 0
	var sp: SpriteBank = g.sprites if g.sprites.ok else null       # null = gambar vektor lama
	for dc in g.decals:
		var fade := 1.0 - clampf((dc.t - (dc.life - 8.0)) / 8.0, 0.0, 1.0)
		var h := int(absf(dc.pos.x) * 3.0 + absf(dc.pos.y) * 5.0)           # variasi deterministik per bekas
		var s: SpriteLib.Spr = _pick(sp, dc, h)
		if s == null:
			_draw_vec(dc, fade)
			continue
		var mod := Color(1, 1, 1, fade * .95)
		var k: float = dc.radius * 2.3 / s.size.x
		if dc.kind == 1:
			mod = Color(1, 1, 1).lerp(dc.color.lightened(.45), .5)           # mayat: nuansa warna tim
			mod.a = fade * .95
			k = 30.0 / s.size.y                                              # mayat ukuran tetap (rapi, tidak bergantung radius)
		elif dc.kind == 2:
			mod.a = fade * .8
		draw_set_transform(dc.pos, float(h % 628) * .01, Vector2.ONE)
		s.blit(self, k, mod)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if g.profile_on:
		g.draw_us += Time.get_ticks_usec() - t0


## Pilih sprite untuk satu bekas (null = tidak ada sprite -> gambar vektor).
func _pick(sp: SpriteBank, dc: BO.Mark, h: int) -> SpriteLib.Spr:
	if sp == null:
		return null
	match dc.kind:
		0:
			if sp.decal_craters.size() < 3:
				return null
			return sp.decal_craters[1] if dc.radius < 20.0 else (sp.decal_craters[0] if dc.radius < 70.0 else sp.decal_craters[2])
		1:
			return sp.corpses[h % sp.corpses.size()] if not sp.corpses.is_empty() else null
		3:
			return null                                  # bekas hantaman peluru: bintik gelap sederhana (lihat _draw_vec)
		_:
			return sp.blood[h % sp.blood.size()] if not sp.blood.is_empty() else null


func _draw_vec(dc: BO.Mark, fade: float) -> void:
	if dc.kind == 3:
		var r := dc.radius
		draw_texture_rect(Gfx.soft_disc(), Rect2(dc.pos - Vector2(r, r), Vector2(r * 2.0, r * 2.0)), false, Color(0, 0, 0, .3 * fade))
	elif dc.kind == 0:
		draw_circle(dc.pos, dc.radius, Color(0, 0, 0, .2 * fade))
		draw_circle(dc.pos, dc.radius * .55, Color(0, 0, 0, .22 * fade))
	else:
		draw_circle(dc.pos, dc.radius, Color(dc.color, .7 * fade))
