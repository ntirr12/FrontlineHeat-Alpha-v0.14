class_name AirView
extends Node2D
## LAPISAN UDARA (v14): semua yang melayang di atas medan perang.
##   - peti suplai (di tanah & saat dijatuhkan)         - peluncur MLRS (HIMARS / Uragan) + penanda area hantaman
##   - roket MLRS yang melengkung di udara + bayangannya - penerjun & kanopi, penanda zona terjun
##   - pesawat C-17 beserta bayangannya
## Logikanya ada di systems/air_support.gd; di sini HANYA menggambar. Bila tidak ada satu pun benda udara,
## _draw() langsung keluar (nol biaya di pertempuran biasa). Tanpa atlas sprite, semuanya memakai gambar vektor sederhana.

const HALF_PI := PI * .5
const ALT_PX := 175.0                    # tinggi tampak penerjun di awal lompatan (px layar)

var g: Game
var _font: Font = ThemeDB.fallback_font
var _vr := Rect2()
var _sp: SpriteBank = null
var _t := 0.0


func setup(game: Game) -> void:
	g = game


var _was_empty := false


func refresh() -> void:
	var empty := g.airlifts.is_empty() and g.chutes.is_empty() and g.crates.is_empty() and g.salvos.is_empty() and g.rockets.is_empty()
	if empty and _was_empty:
		return                           # tidak ada yang perlu digambar dan kanvas sudah kosong
	_was_empty = empty                   # satu kali redraw terakhir (kosong) menghapus gambar lama
	queue_redraw()


func rebuild() -> void:
	pass


func invalidate(_r: Rect2) -> void:
	pass


func clear() -> void:
	pass


func _tc(team: int) -> Color:
	return Cfg.TEAM_COLORS[team]


func _draw() -> void:
	if _was_empty:
		return
	var t0 := Time.get_ticks_usec() if g.profile_on else 0
	_t = g.time
	_sp = g.sprites if g.sprites.ok else null
	_vr = Rect2(g.cam - g.vs / (2.0 * g.zoom) - Vector2(260, 260), g.vs / g.zoom + Vector2(520, 520))
	# URUTAN GAMBAR DIATUR PER TEKSTUR (batching Godot menggabungkan gambar berurutan yang teksturnya sama):
	#   1) cakram lembut (bayangan, nyala roket)  2) atlas efek (peti, roket, kanopi)  3) atlas unit (prajurit, peluncur, C-17)  4) garis/teks
	_pass_soft()
	_pass_fx_sprites()
	_pass_unit_sprites()
	_pass_lines()
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if g.profile_on:
		g.draw_us += Time.get_ticks_usec() - t0


## Gambar satu sprite berpusat di c dengan lebar w (dunia), tinggi mengikuti rasio, tanpa rotasi.
func _quad(s: SpriteLib.Spr, c: Vector2, w: float, mod: Color = Color.WHITE) -> void:
	var h := w * s.size.y / s.size.x
	draw_texture_rect_region(s.tex, Rect2(c - Vector2(w, h) * .5, Vector2(w, h)), s.r, mod)


func _shadow(d: Texture2D, c: Vector2, r: float, a: float) -> void:
	draw_texture_rect(d, Rect2(c.x - r, c.y - r * .7, r * 2.0, r * 1.4), false, Color(0, 0, 0, a))


## Posisi tanah, ketinggian tampak, dan kemekaran kanopi sebuah penerjun pada saat ini.
func _chute_pose(c: BO.Chute) -> Dictionary:
	var k := clampf(c.t / c.fall, 0.0, 1.0)
	var gk := 1.0 - (1.0 - k) * (1.0 - k)                                       # meluncur horizontal cepat, lalu pelan
	return {gp = c.start.lerp(c.pos, gk), alt = (1.0 - k) * ALT_PX, open = clampf(k * 9.0, .35, 1.0),
		sway = sin(_t * 2.6 + c.phase) * .1 * (1.0 - k * .7)}


# ---------------------------------------------------------------- PASS 1: cakram lembut
func _pass_soft() -> void:
	var d := Gfx.soft_disc()
	for c in g.crates:
		if _vr.has_point(c.pos):
			_shadow(d, c.pos + Vector2(3, 4), 16.0, .3)
	for c in g.chutes:
		var pose := _chute_pose(c)
		if _vr.has_point(pose.gp):
			_shadow(d, pose.gp + Vector2(4, 4), 14.0 * pose.open, .28)
	for r in g.rockets:
		var gp := AirSupport.rocket_ground_pos(r)
		if not _vr.has_point(gp):
			continue
		_shadow(d, gp, 7.0, .3)
		var ap := AirSupport.rocket_air_pos(r)
		draw_texture_rect(d, Rect2(ap.x - 10, ap.y - 8, 20, 26), false, Color(1, .72, .28, .55))     # nyala motor roket


# ---------------------------------------------------------------- PASS 2: atlas efek (peti, roket, kanopi)
func _pass_fx_sprites() -> void:
	if _sp == null:
		return
	for c in g.crates:
		if not _vr.has_point(c.pos) or (c.t > Cfg.CRATE_LIFE - 10.0 and int(_t * 6.0) % 2 == 0):
			continue
		var s: SpriteLib.Spr = _sp.crate_med if c.kind == 0 else _sp.crate
		if s != null:
			_quad(s, c.pos + Vector2(0, -clampf(c.drop_t / 2.5, 0.0, 1.0) * 150.0), 30.0)
	for r in g.rockets:
		if _sp.rocket == null or not _vr.has_point(AirSupport.rocket_ground_pos(r)):
			continue
		var k := clampf(r.t / r.flight, 0.0, 1.0)
		var tang: Vector2 = (r.to - r.from) / r.flight + Vector2(0, -cos(PI * k) * PI * r.arc / r.flight)
		draw_set_transform(AirSupport.rocket_air_pos(r), tang.angle() + HALF_PI, Vector2.ONE)
		_sp.rocket.blit(self, 1.0 * (1.0 + .35 * sin(PI * k)))                  # makin tinggi makin besar
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	for c in g.chutes:
		var pose := _chute_pose(c)
		if not _vr.has_point(pose.gp):
			continue
		var body: Vector2 = pose.gp + Vector2(0, -pose.alt)
		if c.crate and _sp.crate_med != null:
			_quad(_sp.crate_med, body + Vector2(0, 16.0 * pose.open), 28.0)
		if _sp.canopy != null:
			draw_set_transform(body + Vector2(0, -22.0 * pose.open), pose.sway, Vector2.ONE)
			_quad(_sp.canopy, Vector2.ZERO, 62.0 * pose.open, Color.WHITE.lerp(_tc(c.team).lightened(.3), .3))
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


# ---------------------------------------------------------------- PASS 3: atlas unit (prajurit, peluncur, C-17)
func _pass_unit_sprites() -> void:
	for c in g.chutes:                                                          # prajurit yang menggantung di bawah kanopi
		if c.crate:
			continue
		var pose := _chute_pose(c)
		if not _vr.has_point(pose.gp):
			continue
		var frames: Array = []
		if _sp != null and _sp.inf.size() > c.team and (_sp.inf[c.team] as Array).size() > 0:
			frames = (_sp.inf[c.team] as Array)[0]
		if frames.is_empty():
			continue
		draw_set_transform(pose.gp + Vector2(0, -pose.alt + 14.0 * pose.open), 0.0, Vector2.ONE)
		(frames[0] as SpriteLib.Spr).blit(self, SpriteDefs.INF_SCALE * .8)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	for s in g.salvos:                                                          # peluncur masuk, menembak, lalu pergi
		_draw_launcher(s)
	for a in g.airlifts:
		_draw_plane(a)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _draw_launcher(s: BO.Salvo) -> void:
	var end_t := Cfg.MLRS_WARMUP + float(s.count) * Cfg.MLRS_FIRE_GAP
	var slide_in := clampf(s.t / (Cfg.MLRS_WARMUP * .7), 0.0, 1.0)
	var slide_out := clampf((s.t - end_t - .5) / 1.6, 0.0, 1.0)
	var p: Vector2 = s.origin - s.dir * (1.0 - ease(slide_in, .35)) * 260.0 - s.dir * slide_out * slide_out * 520.0
	if not _vr.has_point(p):
		return
	var ang: float = s.dir.angle() + HALF_PI
	var vs: SpriteBank.VehSet = _sp.mlrs.get(s.team, null) if _sp != null else null
	var firing: bool = s.t >= Cfg.MLRS_WARMUP and s.t < end_t + .3
	var kick := (.5 + .5 * sin(_t * 40.0)) * 2.0 if firing else 0.0
	if vs != null:
		draw_set_transform(p + Vector2(6, 9), ang, Vector2.ONE)
		vs.body.blit(self, vs.scale, Color(0, 0, 0, .3))
		draw_set_transform(p, ang, Vector2.ONE)
		var tint := Color.WHITE.lerp(_tc(s.team).lightened(.15), SpriteDefs.TEAM_TINT)
		vs.body.blit(self, vs.scale, tint)
		if vs.turret != null:
			draw_set_transform(p + (vs.tpos * vs.scale).rotated(ang) - s.dir * kick, ang, Vector2.ONE)
			vs.turret.blit(self, vs.scale, tint)
	else:
		draw_set_transform(p, s.dir.angle(), Vector2.ONE)
		draw_rect(Rect2(-60, -22, 120, 44), _tc(s.team).darkened(.5))
		draw_rect(Rect2(-10, -16, 60, 32), Color(.15, .15, .17))


func _draw_plane(a: BO.Airlift) -> void:
	if not _vr.grow(220.0).has_point(a.pos):
		return
	var ang := a.dir.angle() + HALF_PI
	var spr: SpriteLib.Spr = _sp.c17.get(a.team, null) if _sp != null else null
	var tint: Color = SpriteDefs.C17_TINT.get(a.team, Color.WHITE)
	if spr != null:
		draw_set_transform(a.pos + Vector2(70, 170), ang, Vector2.ONE)                   # bayangan jauh di tanah (pesawat tinggi)
		spr.blit(self, SpriteDefs.C17_SCALE * .92, Color(0, 0, 0, .22))
		draw_set_transform(a.pos, ang, Vector2.ONE)
		spr.blit(self, SpriteDefs.C17_SCALE, tint)
	else:
		var poly := PackedVector2Array([Vector2(130, 0), Vector2(-90, -150), Vector2(-60, 0), Vector2(-90, 150)])
		draw_set_transform(a.pos + Vector2(60, 150), a.dir.angle(), Vector2.ONE)
		draw_colored_polygon(poly, Color(0, 0, 0, .2))
		draw_set_transform(a.pos, a.dir.angle(), Vector2.ONE)
		draw_colored_polygon(poly, Color(.3, .33, .38))


# ---------------------------------------------------------------- PASS 4: garis, busur, teks (tanpa tekstur)
func _pass_lines() -> void:
	var ring := Gfx.ring()
	for c in g.crates:                                                          # cincin penanda peti (berdenyut)
		if c.drop_t > 0.0 or not _vr.has_point(c.pos) or (c.t > Cfg.CRATE_LIFE - 10.0 and int(_t * 6.0) % 2 == 0):
			continue
		var pulse := .5 + .5 * sin(_t * 4.0 + c.pos.x)
		var rr := 30.0 + pulse * 4.0
		draw_texture_rect(ring, Rect2(c.pos.x - rr, c.pos.y - rr, rr * 2.0, rr * 2.0), false, Color(.5, 1, .6, .35 + pulse * .25) if c.kind == 0 else Color(1, .85, .45, .35 + pulse * .25))
		if _sp == null:
			draw_rect(Rect2(c.pos - Vector2(11, 11), Vector2(22, 22)), Color(.55, .48, .3))
	for a in g.airlifts:                                                        # zona terjun selama pesawat melintas
		if a.troops > 0 or a.crates > 0:
			var col := Color(.4, .75, 1, .55 + .25 * sin(_t * 6.0)) if a.team == 1 else Color(1, .35, .3, .55 + .25 * sin(_t * 6.0))
			draw_arc(a.dz, Cfg.PARADROP_SPREAD + 30.0, 0.0, TAU, 40, col, 3.0)
			draw_string(_font, a.dz + Vector2(-100, -Cfg.PARADROP_SPREAD - 40.0), "TERJUN" if a.team == 1 else "MUSUH TERJUN", HORIZONTAL_ALIGNMENT_CENTER, 200, 22, col)
		if _sp != null and _sp.c17.get(a.team, null) != null and _vr.grow(220.0).has_point(a.pos):
			draw_set_transform(a.pos, a.dir.angle(), Vector2.ONE)
			for ey in [-70.0, -37.0, 40.0, 72.0]:                              # kontrail tipis di belakang 4 mesin C-17 (nose ke +x)
				draw_line(Vector2(52, ey), Vector2(-120, ey), Color(1, 1, 1, .2), 2.0)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	for c in g.chutes:                                                          # tali kanopi
		var pose := _chute_pose(c)
		if not _vr.has_point(pose.gp):
			continue
		var body: Vector2 = pose.gp + Vector2(0, -pose.alt)
		var cp := body + Vector2(0, -22.0 * pose.open)
		draw_line(body + Vector2(0, 4), cp + Vector2(-16 * pose.open, 4), Color(1, 1, 1, .35), 1.0)
		draw_line(body + Vector2(0, 4), cp + Vector2(16 * pose.open, 4), Color(1, 1, 1, .35), 1.0)
		if _sp == null:
			draw_arc(cp, 24.0 * pose.open, PI, TAU, 12, Color(.9, .9, .9), 4.0)
	for s in g.salvos:                                                          # area hantaman MLRS: oval + hitung mundur
		var wait := Cfg.MLRS_WARMUP - s.t
		if s.fired >= s.count and s.t > Cfg.MLRS_WARMUP + float(s.count) * Cfg.MLRS_FIRE_GAP + 1.0:
			continue
		var pulse := .5 + .4 * sin(_t * 8.0)
		var col := Color(1, .55, .2, pulse) if (s.team == 1 or s.ambient) else Color(1, .2, .2, pulse)
		draw_set_transform(s.pos, s.dir.angle(), Vector2(1.15, .85))               # oval memanjang searah tembakan
		draw_arc(Vector2.ZERO, s.radius, 0.0, TAU, 44, col, 4.0)
		draw_arc(Vector2.ZERO, s.radius * .45, 0.0, TAU, 28, Color(col, col.a * .6), 2.0)
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		draw_line(s.pos - Vector2(14, 0), s.pos + Vector2(14, 0), Color(col, .9), 2.0)
		draw_line(s.pos - Vector2(0, 14), s.pos + Vector2(0, 14), Color(col, .9), 2.0)
		var label := "MLRS %d" % int(ceil(maxf(wait, 0.0))) if wait > 0.0 else "MLRS"
		if s.ambient and s.team != 1:
			label = "ROKET!"
		draw_string(_font, s.pos + Vector2(-90, -s.radius * .85 - 12.0), label, HORIZONTAL_ALIGNMENT_CENTER, 180, 22, Color(1, .45, .3))
