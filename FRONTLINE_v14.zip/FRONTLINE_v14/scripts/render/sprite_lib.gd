class_name SpriteLib
extends RefCounted
## PEMUAT ATLAS & PENCARI SPRITE.
## Gambar-gambar kecil sudah digabung jadi 2 atlas (assets/atlas/*.png) oleh tools/build_atlas.py,
## dan daftar posisinya ada di scripts/data/atlas_data.gd (dibuat otomatis).
##
## ATURAN EMAS: kalau atlas tidak ada / dimatikan (Cfg.USE_SPRITES = false), `ready` = false dan SEMUA
## penggambar otomatis memakai gambar vektor lama. Jadi game tidak pernah "kosong" tanpa gambar.
##
## Pemakaian (dari kode lain):
##   var s := SpriteLib.find("veh/us_abrams/body", team, skin)     # -> Spr atau null
##   draw_texture_rect_region(s.tex, Rect2(-s.anchor * k, s.size * k), s.r)    # k = skala dunia

## Satu sprite siap gambar. Dibuat SEKALI (saat pertandingan dimulai), dipakai ribuan kali per detik,
## sehingga saat menggambar tidak ada operasi teks sama sekali.
class Spr extends RefCounted:
	var tex: Texture2D
	var r := Rect2()              # kotak di dalam atlas (piksel atlas)
	var size := Vector2.ONE       # ukuran sprite ASLI (piksel sumber); dikali skala dunia saat digambar
	var anchor := Vector2.ZERO    # titik di sprite (piksel sumber) yang diletakkan di posisi benda

	## Gambar di titik asal transform canvas saat ini. k = piksel dunia per piksel sumber.
	func blit(ci: CanvasItem, k: float, mod: Color = Color.WHITE) -> void:
		ci.draw_texture_rect_region(tex, Rect2(-anchor * k, size * k), r, mod)

	## Pangkal sprite (tengah-bawah) diletakkan di titik asal; sprite memanjang ke ATAS. Untuk muzzle flash.
	func blit_base(ci: CanvasItem, k: float, mod: Color = Color.WHITE) -> void:
		ci.draw_texture_rect_region(tex, Rect2(Vector2(-size.x * .5, -size.y) * k, size * k), r, mod)

	## Seperti blit() tapi dengan skala berbeda untuk lebar & tinggi (efek memanjang/menyusut).
	func blit_xy(ci: CanvasItem, kx: float, ky: float, mod: Color = Color.WHITE) -> void:
		ci.draw_texture_rect_region(tex, Rect2(Vector2(-anchor.x * kx, -anchor.y * ky), Vector2(size.x * kx, size.y * ky)), r, mod)


static var ready := false
## Saklar runtime: true = paksa gambar vektor (untuk uji / opsi pengaturan). Berlaku di pertandingan berikutnya.
static var disabled := false
static var _tex: Array[Texture2D] = []


## Memuat atlas. Aman dipanggil berkali-kali. Mengembalikan true bila sprite bisa dipakai.
static func load_atlas() -> bool:
	if disabled or not Cfg.USE_SPRITES:
		return false
	if ready:
		return true
	var list: Array[Texture2D] = []
	for f: String in AtlasData.FILES:
		var t := load(f) as Texture2D
		if t == null:
			push_warning("Atlas tidak ditemukan (%s) -> memakai gambar vektor" % f)
			return false
		list.append(t)
	_tex = list
	ready = true
	return true


static func has(key: String) -> bool:
	return ready and AtlasData.SPRITES.has(key)


## Ambil sprite berdasarkan kunci persis. centered=false -> titik pusat = pusat massa piksel (infanteri).
static func get_spr(key: String, centered := true) -> Spr:
	if not has(key):
		return null
	var a: Array = AtlasData.SPRITES[key]
	var s := Spr.new()
	s.tex = _tex[int(a[0])]
	s.r = Rect2(a[1], a[2], a[3], a[4])
	s.size = Vector2(a[5], a[6])
	s.anchor = s.size * .5 if centered else Vector2(a[7], a[8])
	return s


## Kunci terbaik untuk `base`: base_skin@tim -> base_skin -> base@tim -> base, lalu skin lain.
## Mengembalikan "" bila tidak ada satu pun.
static func resolve_key(base: String, team := 0, skin := "tan") -> String:
	var other := "grn" if skin == "tan" else "tan"
	for sk: String in [skin, other, ""]:
		var stem := base if sk == "" else base + "_" + sk
		var cands: Array[String] = []
		if team > 0:
			cands.append("%s@%d" % [stem, team])
		cands.append(stem)
		for k in cands:
			if has(k) or has(k + "#0"):
				return k
	return ""


## Satu sprite (tanpa animasi). null bila tidak ada.
static func find(base: String, team := 0, skin := "tan", centered := true) -> Spr:
	var k := resolve_key(base, team, skin)
	return get_spr(k, centered) if k != "" and has(k) else null


## Semua frame animasi base#0, base#1, ... (kosong bila tidak ada).
static func frames(base: String, team := 0, skin := "tan", centered := true) -> Array[Spr]:
	var out: Array[Spr] = []
	var k := resolve_key(base, team, skin)
	if k == "":
		return out
	if has(k):
		out.append(get_spr(k, centered))
		return out
	var i := 0
	while has("%s#%d" % [k, i]):
		out.append(get_spr("%s#%d" % [k, i], centered))
		i += 1
	return out
