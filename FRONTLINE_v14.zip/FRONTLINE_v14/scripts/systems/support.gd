class_name Support
extends RefCounted
## ALAT BANTU PERANG: granat, smoke, airstrike/artileri, ranjau, C4, nuke, bangunan engineer,
## paket udara, drone FPV, skill divisi, perbaikan.
## Semua benda dikelola dalam daftar milik Game (g.grenades, g.barrages, g.mines, dst).

var g: Game


func _init(game: Game) -> void:
	g = game


# ================================================================ bahaya (untuk AI)
## Tandai area berbahaya agar AI musuh lari darinya (granat, airstrike, C4, nuke).
## Zona bahaya untuk AI. Bila AI tidak diizinkan menghindar (Cfg.AI_DODGE_DANGER = false, bawaan v13)
## zona tidak dibuat sama sekali, jadi tidak ada alokasi objek dan AI tidak pernah "tahu" bom akan jatuh.
func add_alert(p: Vector2, radius: float, seconds: float, team: int) -> void:
	if not Cfg.AI_DODGE_DANGER:
		return
	var a := BO.Alert.new()
	a.pos = p
	a.radius = radius
	a.t = seconds
	a.team = team
	g.alerts.append(a)


# ================================================================ granat & asap
func throw_grenade(u: Unit, dest: Vector2, kind: int, by_player: bool) -> void:
	if u.pos.distance_to(g.cam) < 900.0:
		g.sfx(10, u.pos)
	var gr := BO.Grenade.new()
	gr.pos = u.pos
	gr.from = u.pos
	gr.dest = dest
	gr.kind = kind
	gr.team = u.team
	gr.by_player = by_player
	g.grenades.append(gr)
	if kind != 3:
		add_alert(dest, 130.0 if kind == 0 else 190.0, 1.4, u.team)


func update_grenades(dt: float) -> void:
	var i := 0
	while i < g.grenades.size():
		var gr := g.grenades[i]
		gr.t += dt
		if gr.t >= .9:
			match gr.kind:
				0:
					g.combat.explode(gr.dest, 120, 140, gr.team, gr.by_player)
				1:
					g.fx.spawn(gr.dest, .5, 260, Color(1, 1, 1, .9))
					for u in g.units:
						if u.hp > 0.0 and u.mount == null and u.pos.distance_to(gr.dest) < 380.0 and g.world.los(u.pos, gr.dest):
							u.flash_t = 4.0
				3:                                   # asap saja (taktik mundur AI), tanpa airstrike
					var cover_smoke := BO.Smoke.new()
					cover_smoke.pos = gr.dest
					cover_smoke.radius = 95.0
					cover_smoke.t = 9.0
					g.smokes.append(cover_smoke)
				_:
					var sm := BO.Smoke.new()
					sm.pos = gr.dest
					g.smokes.append(sm)
					call_barrage(gr.dest, gr.team, gr.by_player, 14, 170.0, false, Vector2.RIGHT)
			g.grenades[i] = g.grenades[g.grenades.size() - 1]
			g.grenades.pop_back()
		else:
			gr.pos = gr.from.lerp(gr.dest, gr.t / .9)
			i += 1
	i = 0
	while i < g.smokes.size():
		g.smokes[i].t -= dt
		if g.smokes[i].t <= 0.0:
			g.smokes.remove_at(i)
		else:
			i += 1


# ================================================================ airstrike / artileri
func call_barrage(p: Vector2, team: int, by_player: bool, count: int, radius: float, carpet: bool, dir: Vector2, ambient := false, damage := 170.0) -> void:
	var b := BO.Barrage.new()
	b.pos = p
	b.team = team
	b.by_player = by_player
	b.count = count
	b.radius = radius
	b.carpet = carpet
	b.dir = dir
	b.ambient = ambient
	b.damage = damage
	g.barrages.append(b)
	add_alert(p, radius + Cfg.DANGER_FLEE_PAD, 5.0 + count * .15, team)
	if ambient:
		g.sfx(12, p)                                   # desing peluru artileri jatuh


func update_barrages(dt: float) -> void:
	var i := 0
	while i < g.barrages.size():
		var a := g.barrages[i]
		a.t += dt
		var start_delay := 1.8 if a.ambient else 3.0
		if a.t >= 1.5 and not a.jet_played and not a.ambient:
			a.jet_played = true
			g.sfx(11, a.pos)
			spawn_jet(a.pos - a.dir.normalized() * 1100.0, a.dir, 0, a.team)
		while a.fired < int((a.t - start_delay) / .15) and a.fired < a.count:
			var impact: Vector2
			if not a.carpet:
				impact = a.pos + Vector2(randf_range(-a.radius, a.radius), randf_range(-a.radius, a.radius)).limit_length(a.radius)
			else:
				impact = a.pos + a.dir * (a.fired * (a.radius * 1.8 / a.count) - a.radius * .9)
			g.combat.explode(impact, 95, a.damage, a.team, a.by_player)
			a.fired += 1
		if a.fired >= a.count:
			g.barrages[i] = g.barrages[g.barrages.size() - 1]
			g.barrages.pop_back()
		else:
			i += 1


## Jet yang melintas. bombs > 0 = menjatuhkan bom di sepanjang lintasan.
func spawn_jet(start: Vector2, dir: Vector2, bombs: int, team: int) -> void:
	var j := BO.Jet.new()
	j.pos = start
	j.dir = dir.normalized()
	j.bombs = bombs
	j.team = team
	j.life = 5.5
	g.jets.append(j)


func update_jets(dt: float) -> void:
	var i := 0
	while i < g.jets.size():
		var j := g.jets[i]
		j.pos += j.dir * j.speed * dt
		j.life -= dt
		if j.bombs > 0:
			j.bomb_t -= dt
			if j.bomb_t <= 0.0 and j.pos.x > 0.0 and j.pos.x < Cfg.MAP_W and j.pos.y > 0.0 and j.pos.y < Cfg.MAP_H:
				j.bomb_t = 0.22
				j.bombs -= 1
				g.combat.explode(j.pos + Vector2(randf_range(-30, 30), randf_range(-30, 30)), 90, 160, j.team, false)
		if j.life <= 0.0:
			g.jets[i] = g.jets[g.jets.size() - 1]
			g.jets.pop_back()
		else:
			i += 1


# ================================================================ bangunan
func has_tower(team: int, p: Vector2) -> bool:
	for s in g.structs:
		if s.kind == Cfg.Item.TOWER and s.team == team and s.hp > 0.0 and s.pos.distance_squared_to(p) < 1000000.0:
			return true
	return false


func build(kind: int, p: Vector2, dir: Vector2, team: int) -> void:
	match kind:
		Cfg.Item.SANDBAG:
			var vertical := absf(dir.x) > absf(dir.y)
			var r := Rect2(p - (Vector2(12, 55) if vertical else Vector2(55, 12)), Vector2(24, 110) if vertical else Vector2(110, 24))
			g.world.add_wall(r)
		Cfg.Item.WIRE, Cfg.Item.TRAP, Cfg.Item.TOWER, Cfg.Item.DRONE_ST, Cfg.Item.JAMMER:
			g.structs.append(Structure.create(kind, p, team))
		Cfg.Item.TURRET_MG, Cfg.Item.TURRET_TOW:
			g.turrets.append(Turret.create(kind - Cfg.Item.TURRET_MG, p, team, dir.angle()))
		_:
			g.structs.append(Structure.create(Cfg.Item.BUNKER, p, team))


# ================================================================ item pemain
## Pemain melepas tombol LEMPAR dengan item terpilih. dest = titik sasaran, dir = arah bidik.
func use_item(u: Unit, item: int, dest: Vector2, dir: Vector2) -> void:
	if item == Cfg.Item.C4:
		if u.c4 > 0:
			u.c4 -= 1
			var c := BO.Charge.new()
			c.pos = dest
			c.team = u.team
			c.by_player = true
			g.charges.append(c)
			add_alert(dest, 170.0, 6.0, u.team)
		return
	if item == Cfg.Item.NUKE:
		if u.radio_cd <= 0.0:
			u.radio_cd = 120.0
			var n := BO.Nuke.new()
			n.pos = dest
			n.by_player = true
			g.nukes.append(n)
			add_alert(dest, 480.0, 4.5, u.team)
			g.say("NUKE TAKTIS DALAM 4 DETIK", 3.0)
		return
	if item == Cfg.Item.MLRS or item == Cfg.Item.PARADROP or item == Cfg.Item.DROP_SUPPLY:
		_use_air_support(u, item, dest)
		return
	if item >= Cfg.Item.DROP_MG and item <= Cfg.Item.DROP_VEH:
		if u.radio_cd > 0.0:
			return
		if u.cls != Cfg.Cls.ELITE and not has_tower(u.team, u.pos):
			g.say("DI LUAR JANGKAUAN MENARA RADIO", 2.0)
			return
		u.radio_cd = (20.0 if item < Cfg.Item.DROP_VEH else 90.0) * (.6 if u.cls == Cfg.Cls.ELITE else 1.0)
		var d := BO.Drop.new()
		d.pos = dest
		d.kind = item
		d.team = u.team
		g.drops.append(d)
		g.say("PAKET UDARA DIKIRIM", 2.0)
		return
	if item >= Cfg.Item.SANDBAG and item <= Cfg.Item.BUNKER:
		if item == Cfg.Item.BUNKER and g.objectives.friendly_flag_near(dest, u.team) == null:
			g.say("BUNKER HARUS DI FLAG MILIKMU", 2.0)
		elif u.build_points >= Cfg.ITEM_BUILD_COST[item]:
			u.build_points -= Cfg.ITEM_BUILD_COST[item]
			build(item, dest, dir, u.team)
		return
	if item >= Cfg.Item.BARRAGE:
		if u.radio_cd > 0.0:
			return
		if u.cls != Cfg.Cls.ELITE and not has_tower(u.team, u.pos):
			g.say("DI LUAR JANGKAUAN MENARA RADIO", 2.0)
			return
		u.radio_cd = 12.0 if u.cls == Cfg.Cls.ELITE else 20.0
		call_barrage(dest, u.team, true, 26, 260.0, item == Cfg.Item.CARPET, dir.normalized())
		g.say("AIRSTRIKE DIPANGGIL", 2.0)
		return
	if u.grenades[item] <= 0:
		return
	u.grenades[item] -= 1
	if item == Cfg.Item.MINE:
		var m := BO.Mine.new()
		m.pos = u.pos + dir.normalized() * 30.0
		m.team = u.team
		m.by_player = true
		g.mines.append(m)
	else:
		throw_grenade(u, dest, item, true)


## v14: item radio baru - MLRS, bantuan terjun C-17, paket suplai. Aturannya sama dengan airstrike (butuh menara radio, kecuali Elite).
func _use_air_support(u: Unit, item: int, dest: Vector2) -> void:
	if u.radio_cd > 0.0:
		return
	if u.cls != Cfg.Cls.ELITE and not has_tower(u.team, u.pos):
		g.say("DI LUAR JANGKAUAN MENARA RADIO", 2.0)
		return
	var k := .6 if u.cls == Cfg.Cls.ELITE else 1.0
	match item:
		Cfg.Item.MLRS:
			u.radio_cd = Cfg.MLRS_CD * k
			g.air.call_mlrs(dest, u.team, true)
			g.say("MLRS DIPANGGIL - ROKET DALAM %d DETIK" % int(Cfg.MLRS_WARMUP + 1.0), 2.5)
		Cfg.Item.PARADROP:
			u.radio_cd = Cfg.PARADROP_CD * k
			g.air.call_airlift(dest, u.team, true)
			g.say("C-17 DALAM PERJALANAN - REGU TERJUN", 2.5)
		_:
			u.radio_cd = Cfg.SUPPLY_CD * k
			var d := BO.Drop.new()
			d.pos = dest
			d.kind = Cfg.Item.DROP_SUPPLY
			d.team = u.team
			g.drops.append(d)
			g.say("PAKET SUPLAI DIKIRIM", 2.0)


# ================================================================ pembaruan benda statis
func update_objects(dt: float) -> void:
	_update_mines()
	_update_wires(dt)
	var i := 0
	while i < g.structs.size():
		if g.structs[i].hp <= 0.0:
			g.structs.remove_at(i)
		else:
			g.structs[i].timer -= dt
			i += 1
	for n in g.nukes:
		n.t += dt
	i = 0
	while i < g.nukes.size():
		if g.nukes[i].t >= 4.0:
			g.combat.nuke(g.nukes[i])
			g.nukes.remove_at(i)
		else:
			i += 1
	i = 0
	while i < g.beams.size():
		g.beams[i].t -= dt
		if g.beams[i].t <= 0.0:
			g.beams.remove_at(i)
		else:
			i += 1
	i = 0
	while i < g.charges.size():
		var c := g.charges[i]
		c.t -= dt
		if c.t <= 0.0:
			g.combat.explode(c.pos, 140, 420, c.team, c.by_player)
			g.charges.remove_at(i)
		else:
			i += 1
	_update_drops(dt)


func _update_mines() -> void:
	var i := 0
	while i < g.mines.size():
		var m := g.mines[i]
		var hit := false
		for u in g.units:
			if u.team != m.team and u.hp > 0.0 and u.mount == null and u.pos.distance_squared_to(m.pos) < 484.0:
				hit = true
				break
		if not hit:
			for v in g.vehicles:
				if v.team != m.team and not v.dead and v.pos.distance_to(m.pos) < v.radius() + 6.0:
					hit = true
					break
		if hit:
			g.mines.remove_at(i)
			g.combat.explode(m.pos, 100, 230, m.team, m.by_player)
		else:
			i += 1


func _update_wires(dt: float) -> void:
	for w in g.structs:
		if w.kind != Cfg.Item.WIRE:
			continue
		for v in g.vehicles:
			if v.team != w.team and not v.dead and absf(v.speed) > 20.0 and v.pos.distance_to(w.pos) < v.radius() + 10.0:
				w.hp = 0.0
		if w.timer <= 0.0:
			for u in g.units:
				if u.team != w.team and u.hp > 0.0 and u.mount == null and u.pos.distance_squared_to(w.pos) < 1600.0:
					g.combat.hurt(u, 9.0, false, w.pos)
					w.timer = .4
					break


func _update_drops(dt: float) -> void:
	var i := 0
	while i < g.drops.size():
		var a := g.drops[i]
		a.t += dt
		if a.t > 3.0:
			if a.kind == Cfg.Item.DROP_SUPPLY:
				g.air.spawn_crate(a.pos + Vector2(-24, 0), a.team, 0)        # satu peti medis + satu peti amunisi
				g.air.spawn_crate(a.pos + Vector2(24, 0), a.team, 1)
			elif a.kind < Cfg.Item.DROP_VEH:
				build(Cfg.Item.TURRET_MG + (a.kind - Cfg.Item.DROP_MG), a.pos, Vector2.RIGHT.rotated(0.0 if a.team == 1 else PI), a.team)
			else:
				var k: int = [Cfg.Veh.HUMVEE_MG, Cfg.Veh.HUMVEE_AT][randi() % 2]
				g.vehicles.append(Vehicle.create(k, a.pos, a.team, 0.0))
			g.fx.spawn(a.pos, .6, 60, Color(.8, .8, .8, .7))
			g.drops.remove_at(i)
		else:
			i += 1


# ================================================================ drone FPV
func spawn_player_drone(station: Structure) -> void:
	var d := BO.Drone.new()
	d.pos = station.pos
	d.home = station.pos
	d.team = station.team
	d.player_owned = true
	g.player_drone = d
	g.say("DRONE FPV AKTIF", 2.0)


## Satu langkah drone. m = arah gerak, ay = "tuas" ketinggian (>0.96 = menukik & meledak).
func update_drone(d: BO.Drone, dt: float, m: Vector2, ay: float) -> bool:
	var sg := 1.0 - clampf((d.pos.distance_to(d.home) - 500.0) / 500.0, 0.0, 1.0)
	for j in g.structs:
		if j.kind == Cfg.Item.JAMMER and j.team != d.team and j.hp > 0.0:
			var jd := j.pos.distance_to(d.pos)
			if jd < 260.0:
				d.crash = true
			elif jd < 520.0:
				sg = minf(sg, (jd - 260.0) / 260.0)
	for e in g.units:
		if e.cls == Cfg.Cls.ELITE and e.jammer_on and e.team != d.team and e.hp > 0.0:
			var ed := e.pos.distance_to(d.pos)
			if ed < 130.0:
				d.crash = true
			elif ed < 260.0:
				sg = minf(sg, (ed - 130.0) / 130.0)
	if sg <= .02:
		d.crash = true
	d.signal_q = sg
	d.pos += m * 260.0 * sg * dt + Vector2.from_angle(randf() * TAU) * (1.0 - sg) * 230.0 * dt
	d.alt = minf(100.0, d.alt - ay * 70.0 * sg * dt - (120.0 * dt if ay > .96 else 0.0) - ((1.0 - sg) * 20.0 + (80.0 if d.crash else 0.0)) * dt)
	d.pos = Vector2(clampf(d.pos.x, 10.0, Cfg.MAP_W - 10.0), clampf(d.pos.y, 10.0, Cfg.MAP_H - 10.0))
	var hit := d.alt <= 0.0
	if d.alt < 30.0 and not d.crash and g.world.bullet_hits_building(d.pos):
		hit = true
	if hit:
		if d.crash:
			g.fx.spawn(d.pos, .4, 30, Color(.5, .5, .5, .8))
		else:
			g.combat.explode(d.pos, 130, 220, d.team, d.player_owned)
	return hit


## Stasiun drone milik AI meluncurkan drone kamikaze ke musuh terdekat.
func update_ai_drones(dt: float) -> void:
	for q in g.structs:
		if q.kind != Cfg.Item.DRONE_ST or q.timer > 0.0:
			continue
		if randf() < .12 * dt and (q.team == 2 or g.player == null or q.pos.distance_to(g.player.pos) > 200.0):
			var best: Unit = null
			var bd := 750.0
			for u in g.units:
				if u.team != q.team and u.hp > 0.0 and u.pos.distance_to(q.pos) < bd:
					bd = u.pos.distance_to(q.pos)
					best = u
			if best != null:
				q.timer = 30.0
				var d := BO.Drone.new()
				d.pos = q.pos
				d.home = q.pos
				d.team = q.team
				d.target = best
				g.ai_drones.append(d)
	for d in g.ai_drones:
		if d.target == null or d.target.hp <= 0.0:
			d.target = null
			var bd := 700.0
			for u in g.units:
				if u.team != d.team and u.hp > 0.0 and u.pos.distance_to(d.pos) < bd:
					bd = u.pos.distance_to(d.pos)
					d.target = u
		var m := Vector2.ZERO
		var ay := -.3
		if d.target != null:
			var dd := d.target.pos - d.pos
			m = dd.normalized()
			ay = 1.0 if dd.length() < 110.0 else clampf((d.alt - 40.0) / 30.0, -.5, .5)
		if update_drone(d, dt, m, ay):
			d.done = true
	var keep: Array[BO.Drone] = []
	for d in g.ai_drones:
		if not d.done:
			keep.append(d)
	g.ai_drones = keep


# ================================================================ skill divisi
func use_skill(u: Unit) -> void:
	match u.cls:
		Cfg.Cls.SPY:
			if u.disguise_t > 0.0:
				u.disguise_t = 0.0
				u.skill_cd = 10.0
			elif u.skill_cd <= 0.0:
				var n := 0
				for o in g.units:
					if o.team != u.team and o.hp > 0.0 and o.pos.distance_to(u.pos) < 400.0:
						n += 1
				u.disguise_t = 15.0 if n >= 4 else 20.0
				u.suspicion = 0.0
				u.skill_cd = 30.0
		Cfg.Cls.ELITE:
			u.jammer_on = not u.jammer_on
		Cfg.Cls.SECRET:
			if u.skill_cd <= 0.0 and u.mount == null:
				u.skill_cd = 90.0
				var spawn_pos := u.pos + Vector2.RIGHT.rotated(u.angle) * 120.0
				var v := Vehicle.create(Cfg.Veh.RAILGUN, spawn_pos, u.team, u.angle)
				v.respawn_t = 9999.0                      # tank summon tidak hidup lagi setelah hancur
				g.vehicles.append(v)
				g.fx.spawn(spawn_pos, .8, 90, Color(.3, 1, 1, .8))
				g.say("TANK RAILGUN DISUMMON", 2.0)


# ================================================================ perbaikan (Engineer/Elite, pemain & AI)
## Cari aset sekutu rusak (tiap 0,5 dtk) dan perbaiki bila dekat. Mengembalikan posisi aset atau Vector2.INF.
func repair(u: Unit, dt: float) -> Vector2:
	u.repair_t -= dt
	if u.repair_t <= 0.0:
		u.repair_t = .5
		u.repair_target = null
		var bd := 1400.0
		for x in g.vehicles:
			bd = _repair_pick(u, x, bd)
		for x in g.turrets:
			bd = _repair_pick(u, x, bd)
		for x in g.structs:
			bd = _repair_pick(u, x, bd)
	var best := u.repair_target
	if best == null:
		return Vector2.INF
	if not best.is_alive() or best.hp >= best.max_hp:
		u.repair_target = null
		u.repair_t = 0.0
		return Vector2.INF
	if best.pos.distance_to(u.pos) < 95.0:
		best.hp = minf(best.max_hp, best.hp + 35.0 * dt)
		if randf() < .3:
			g.fx.spawn(best.pos + Vector2(randf_range(-15, 15), randf_range(-15, 15)), .2, 8, Color(.4, 1, .5))
	return best.pos


func _repair_pick(u: Unit, x: Entity, bd: float) -> float:
	if x.team == u.team and x.is_alive() and x.hp < x.max_hp:
		var d := x.pos.distance_to(u.pos)
		if d < bd:
			u.repair_target = x
			return d
	return bd


# ================================================================ AI membangun
func ai_build(u: Unit) -> void:
	var near_flag := g.objectives.friendly_flag_near(u.pos, u.team) != null
	var want := (u.build_points >= 40.0 and randf() < .01 and not near_flag) \
		or (u.build_points >= 90.0 and near_flag and _count_team(Cfg.Item.BUNKER) < 6)
	if not want or g.turrets.size() >= 16 or g.world.walls.size() >= 300:
		return
	var choice: int = [Cfg.Item.SANDBAG, Cfg.Item.SANDBAG, Cfg.Item.TRAP, Cfg.Item.TURRET_MG, Cfg.Item.TURRET_TOW][randi() % 5]
	if u.build_points >= 90.0 and near_flag:
		choice = Cfg.Item.BUNKER
	if u.build_points >= Cfg.ITEM_BUILD_COST[choice]:
		u.build_points -= Cfg.ITEM_BUILD_COST[choice]
		var dir := Vector2.RIGHT.rotated(u.angle)
		build(choice, u.pos + dir * 70.0, dir, u.team)


func _count_team(kind: int) -> int:
	var n := 0
	for s in g.structs:
		if s.kind == kind:
			n += 1
	return n
