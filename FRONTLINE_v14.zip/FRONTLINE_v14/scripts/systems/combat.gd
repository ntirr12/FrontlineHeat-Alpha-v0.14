class_name Combat
extends RefCounted
## SISTEM TEMPUR: peluru, ledakan, kerusakan, kematian.
## Peluru memakai pool (didaur ulang) dan tabrakan lewat SpatialGrid, jadi tetap ringan
## walau ratusan peluru terbang bersamaan.
##
## v13 - ALUR SATU PELURU (baca ini dulu sebelum mengubah apa pun):
##   1. shoot()       : peluru dibuat. Bila penembak membidik sasaran, umur peluru dipas supaya JATUH KE TANAH di sekitar
##                      sasaran (bukan terbang lurus sampai ujung peta).
##   2. _step_bullet(): tiap frame peluru menyapu SEGMEN prev -> pos. Semua tabrakan dites sepanjang segmen itu
##                      (gedung, prajurit, kendaraan, turret) dan yang PALING AWAL menang. Tidak ada lagi peluru
##                      yang melompati sasaran di antara dua frame.
##   3. Bila kena      : senapan = kerusakan langsung. Peluru ledak = KENA LANGSUNG (Cfg.DIRECT_DMG) + ledakan area.
##   4. Bila tidak kena: habis umur = jatuh ke tanah. Senapan -> debu/bekas hantaman. Peluru ledak -> tetap meledak,
##                      jadi sasaran di dekatnya kena ledakan area (kerusakan splash).

enum Hit { NONE, BUILDING, UNIT, VEHICLE, TURRET }

var g: Game
var bullets: Array[Bullet] = []
var _pool: Array[Bullet] = []
var _near: Array = []                  # buffer kueri (dipakai ulang)
var death_stats := {}                  # (hanya saat g.profile_on) sumber kematian prajurit: untuk menyetel keseimbangan
var _cur_r := -1                       # radius ledakan yang sedang diproses (label statistik)
var _sw_t := 2.0                       # hasil sapuan prajurit: titik tabrak (0..1) pada segmen


func _init(game: Game) -> void:
	g = game


# ================================================================ menembak
## land_dist > 0 : jarak ke sasaran yang dibidik. Peluru jatuh sedikit di depan/di belakang sasaran itu
##                 (Cfg.GROUND_OVERSHOOT) bila tidak mengenai apa pun. -1 = tidak ada sasaran (terbang sampai jangkauan).
## dmg_mult      : pengali kerusakan (mis. senapan mesin kendaraan).
func shoot(p: Vector2, ang: float, team: int, kind: int, target: Entity, by_player: bool, land_dist := -1.0, dmg_mult := 1.0) -> Bullet:
	g.sfx(Cfg.BUL_SOUND[kind], p)
	if bullets.size() >= Cfg.MAX_BULLETS:
		return null
	var b: Bullet = _pool.pop_back() if not _pool.is_empty() else Bullet.new()
	var speed: float = Cfg.BUL_SPEED[kind]
	b.pos = p
	b.prev = p
	b.vel = Vector2.RIGHT.rotated(ang) * speed
	b.team = team
	b.kind = kind
	b.life = Cfg.BUL_LIFE[kind]
	b.target = target
	b.by_player = by_player
	b.cover_roll = -1
	b.dmg_mult = dmg_mult
	b.supp_last = null
	if kind != Cfg.Bul.JAVELIN and kind != Cfg.Bul.TOW:               # rudal terpandu tidak dipas umurnya
		if land_dist > 0.0:
			var t := (land_dist + randf_range(Cfg.GROUND_OVERSHOOT.x, Cfg.GROUND_OVERSHOOT.y)) / speed
			b.life = clampf(t, 0.06, b.life)
		elif kind == Cfg.Bul.SHELL:
			b.life = minf(b.life, Cfg.SHELL_DEFAULT_RANGE / speed)
		elif Cfg.BUL_ARC[kind]:
			b.life = minf(b.life, Cfg.ARTY_DEFAULT_RANGE / speed)         # artileri tanpa sasaran: jatuh di jarak standar
	b.life0 = b.life
	bullets.append(b)
	g.note_gunfire(p)
	return b


## Tebakan jarak sasaran untuk tembakan PEMAIN / penembak yang tidak punya `target`:
## musuh terdekat yang berada dekat garis bidik (<= AIM_LATERAL px di samping). -1 bila tidak ada.
func aim_distance_for(p: Vector2, ang: float, team: int, max_d := 760.0) -> float:
	var enemy := 3 - team
	if enemy < 1 or enemy > 2:
		return -1.0
	var dir := Vector2.RIGHT.rotated(ang)
	var best := 1e9
	g.grid.query(enemy, p + dir * (max_d * .5), max_d * .5 + 60.0, _near)
	for o: Unit in _near:
		var rel := o.pos - p
		var along := rel.dot(dir)
		if along > 25.0 and along < max_d and along < best and absf(rel.cross(dir)) < Cfg.AIM_LATERAL:
			best = along
	for v in g.vehicles:
		if v.team == enemy and not v.dead:
			var rel := v.pos - p
			var along := rel.dot(dir)
			if along > 25.0 and along < max_d and along < best and absf(rel.cross(dir)) < v.radius() + 40.0:
				best = along
	return best if best < 1e8 else -1.0


func update_bullets(dt: float) -> void:
	var i := 0
	while i < bullets.size():
		var b := bullets[i]
		if _step_bullet(b, dt):
			_pool.append(b)
			bullets[i] = bullets[bullets.size() - 1]
			bullets.pop_back()
		else:
			i += 1


# ================================================================ satu langkah peluru
## Mengembalikan true bila peluru selesai (kena / jatuh / keluar peta).
func _step_bullet(b: Bullet, dt: float) -> bool:
	b.life -= dt
	if Cfg.BUL_ARC[b.kind]:                                 # v14: peluru lengkung (howitzer, peluru asap): terbang di atas segalanya, meledak saat mendarat
		b.prev = b.pos
		b.pos += b.vel * dt
		if b.pos.x < -60.0 or b.pos.y < -60.0 or b.pos.x > Cfg.MAP_W + 60.0 or b.pos.y > Cfg.MAP_H + 60.0:
			return true
		g.vfx.shell_trail(b.pos, b.vel)
		if b.life > 0.0:
			return false
		_land(b)
		return true
	if b.kind == Cfg.Bul.TOW:
		var shooter := b.target as Platform
		if shooter != null and not shooter.dead:
			b.vel = b.vel.rotated(clampf(angle_difference(b.vel.angle(), shooter.aim), -1.5 * dt, 1.5 * dt))
		if randf() < .5:
			g.fx.spawn(b.pos, .6, 6, Color(.9, .9, .9, .8))
	elif b.kind == Cfg.Bul.JAVELIN:
		var t := b.target
		if t != null and t.is_alive():
			b.vel = b.vel.rotated(clampf(angle_difference(b.vel.angle(), (t.pos - b.pos).angle()), -2.6 * dt, 2.6 * dt))
		if randf() < .5:
			g.fx.spawn(b.pos, .5, 7, Color(.8, .8, .8, .8))
	var from := b.pos
	var to := from + b.vel * dt
	b.prev = from
	if to.x < -60.0 or to.y < -60.0 or to.x > Cfg.MAP_W + 60.0 or to.y > Cfg.MAP_H + 60.0:
		return true                                      # keluar peta: hilang diam-diam
	var seg := to - from
	var seg2 := seg.length_squared()
	var rifle := b.kind == Cfg.Bul.RIFLE or b.kind == Cfg.Bul.EXPLO

	# ---- cari tabrakan PALING AWAL sepanjang segmen (t = 0..1)
	var best_t := 2.0
	var hit := Hit.NONE
	var hit_unit: Unit = null
	var hit_veh: Vehicle = null
	var hit_tur: Turret = null
	var entry := g.world.bullet_sweep(from, to)
	if entry != Vector2.INF:
		best_t = (entry - from).length() / maxf(sqrt(seg2), .001)
		hit = Hit.BUILDING
	var uh := _sweep_infantry(b, from, seg, seg2, rifle)
	if uh != null and _sw_t < best_t:
		best_t = _sw_t
		hit = Hit.UNIT
		hit_unit = uh
	for v in g.vehicles:
		if v.team != b.team and not v.dead:
			var tv := _seg_circle(from, seg, seg2, v.pos, v.radius() + 3.0)
			if tv >= 0.0 and tv < best_t:
				best_t = tv
				hit = Hit.VEHICLE
				hit_veh = v
	for q in g.turrets:
		if q.team != b.team and not q.dead:
			var tq := _seg_circle(from, seg, seg2, q.pos, 22.0)
			if tq >= 0.0 and tq < best_t:
				best_t = tq
				hit = Hit.TURRET
				hit_tur = q

	if hit == Hit.NONE:
		b.pos = to
		if b.life > 0.0:
			return false
		_land(b)                                          # habis umur = jatuh ke tanah
		return true
	b.pos = entry if hit == Hit.BUILDING else from + seg * best_t
	_resolve_hit(b, hit, hit_unit, hit_veh, hit_tur)
	return true


## Titik masuk (0..1) segmen ke lingkaran, atau -1 bila tidak berpotongan. Dipakai semua tes tabrakan peluru.
func _seg_circle(from: Vector2, seg: Vector2, seg2: float, c: Vector2, r: float) -> float:
	var f := from - c
	var cc := f.length_squared() - r * r
	if cc <= 0.0:
		return 0.0                                        # sudah di dalam
	if seg2 < .0001:
		return -1.0
	var bb := f.dot(seg)
	if bb >= 0.0:
		return -1.0                                       # menjauh dari lingkaran
	var disc := bb * bb - seg2 * cc
	if disc < 0.0:
		return -1.0
	var t := (-bb - sqrt(disc)) / seg2
	return t if t <= 1.0 else -1.0


## Sapuan terhadap prajurit musuh di sel grid yang dilewati segmen. Mengembalikan prajurit yang kena paling awal
## (titiknya di _sw_t) atau null. Sekaligus menekan (suppress) AI musuh yang dilewati peluru dengan nyaris.
func _sweep_infantry(b: Bullet, from: Vector2, seg: Vector2, seg2: float, rifle: bool) -> Unit:
	var enemy := 3 - b.team
	if enemy < 1 or enemy > 2:
		return null
	var cs := SpatialGrid.CELL
	var to := from + seg
	var pad := 22.0 + Cfg.SUPPRESS_NEAR
	var gx0 := maxi(int((minf(from.x, to.x) - pad) / cs), 0)
	var gx1 := int((maxf(from.x, to.x) + pad) / cs)
	var gy0 := maxi(int((minf(from.y, to.y) - pad) / cs), 0)
	var gy1 := int((maxf(from.y, to.y) + pad) / cs)
	var best: Unit = null
	_sw_t = 2.0
	for gx in range(gx0, gx1 + 1):
		for gy in range(gy0, gy1 + 1):
			for u: Unit in g.grid.cell(enemy, gx, gy):
				if u.hp <= 0.0:
					continue
				var ur := float(Cfg.CLASS_RADIUS[u.cls]) + 3.0
				var t := _seg_circle(from, seg, seg2, u.pos, ur)
				if t < 0.0:
					# lewat dengan nyaris: tekan AI (hanya peluru senapan, sekali per peluru per prajurit)
					if rifle and u.is_ai and b.supp_last != u:
						var tc := clampf(-(from - u.pos).dot(seg) / maxf(seg2, .0001), 0.0, 1.0)
						var rr := ur + Cfg.SUPPRESS_NEAR
						if (from + seg * tc).distance_squared_to(u.pos) < rr * rr:
							b.supp_last = u
							u.suppress = minf(1.5, u.suppress + Cfg.SUPPRESS_ADD)
					continue
				if t < _sw_t:
					_sw_t = t
					best = u
	return best


# ================================================================ peluru mengenai sesuatu
func _resolve_hit(b: Bullet, hit: int, u: Unit, v: Vehicle, q: Turret) -> void:
	var dir := b.vel.normalized()
	var kind := b.kind
	var rifle := kind == Cfg.Bul.RIFLE
	var lite := kind == Cfg.Bul.EXPLO
	match hit:
		Hit.BUILDING:
			if rifle:
				g.vfx.impact(b.pos, Vfx.Surf.BUILDING, dir)
			else:
				explode(b.pos, Cfg.BLAST_RADIUS[kind], Cfg.BLAST_DMG[kind], b.team, b.by_player, lite)
		Hit.UNIT:
			if (u.in_cover or u.in_bunker) and u.exposed_t <= 0.0:
				if b.cover_roll < 0:
					b.cover_roll = 1 if randf() < Cfg.COVER_PASS_CHANCE else 0
				if b.cover_roll == 0:
					# peluru menghantam karung pasir/dinding di depan prajurit: berhenti di situ (tidak tembus & terbang jauh)
					g.vfx.impact(b.pos, Vfx.Surf.COVER, dir)
					if not rifle:
						explode(b.pos, Cfg.BLAST_RADIUS[kind], Cfg.BLAST_DMG[kind], b.team, b.by_player, lite)
					return
			if rifle:
				var dmg := 999.0 if (g.cheat("ohk") and b.by_player) else Cfg.RIFLE_DMG * b.dmg_mult
				hurt(u, dmg, b.by_player, b.pos - b.vel * 0.4)
				g.fx.spawn(b.pos, .15, 5, Color(1, .9, .4))
			else:
				var dd: float = Cfg.DIRECT_DMG[kind] * (.5 if u.cls == Cfg.Cls.DESTROYER else 1.0)
				hurt(u, dd, b.by_player, b.pos - b.vel * 0.4, true)
				explode(b.pos, Cfg.BLAST_RADIUS[kind], Cfg.BLAST_DMG[kind], b.team, b.by_player, lite, u)
		Hit.VEHICLE:
			if rifle:
				g.vehicle_sys.damage(v, Cfg.RIFLE_DMG_VEH[v.kind])
				g.vfx.vehicle_hit(b.pos, dir)
			else:
				g.vehicle_sys.damage(v, Cfg.DIRECT_DMG[kind])
				explode(b.pos, Cfg.BLAST_RADIUS[kind], Cfg.BLAST_DMG[kind], b.team, b.by_player, lite, v)
		Hit.TURRET:
			if rifle:
				g.vehicle_sys.damage_turret(q, Cfg.RIFLE_DMG_TURRET)
				g.vfx.vehicle_hit(b.pos, dir)
			else:
				g.vehicle_sys.damage_turret(q, Cfg.DIRECT_DMG[kind] * .9)
				explode(b.pos, Cfg.BLAST_RADIUS[kind], Cfg.BLAST_DMG[kind], b.team, b.by_player, lite, q)


## Peluru habis umur tanpa mengenai apa pun: jatuh ke tanah.
func _land(b: Bullet) -> void:
	var kind := b.kind
	if kind == Cfg.Bul.SMOKESHELL:                         # peluru asap: tirai asap besar di titik jatuh, tanpa kerusakan
		var sm := BO.Smoke.new()
		sm.pos = b.pos
		sm.radius = 135.0
		sm.t = 15.0
		g.smokes.append(sm)
		g.vfx.smoke_screen(b.pos)
		g.sfx(1, b.pos)
		return
	if kind == Cfg.Bul.RIFLE:
		g.vfx.impact(b.pos, Vfx.Surf.GROUND, b.vel.normalized())
	else:
		explode(b.pos, Cfg.BLAST_RADIUS[kind], Cfg.BLAST_DMG[kind], b.team, b.by_player, kind == Cfg.Bul.EXPLO)


# ================================================================ ledakan
## direct = sasaran yang sudah menerima KENA LANGSUNG (tidak dihitung dua kali oleh ledakan area).
func explode(p: Vector2, radius: float, dmg: float, team: int, by_player: bool, lite := false, direct: Entity = null) -> void:
	g.vfx.blast(p, radius, lite)
	if not lite:
		g.sfx(1, p)
		g.shake = maxf(g.shake, clampf(500.0 - p.distance_to(g.cam), 0.0, 500.0) / 30.0 * clampf(radius / 110.0, .6, 1.6))
		g.note_gunfire(p)
	_cur_r = int(radius)
	var press := radius * 1.8
	for u in g.units:
		if u.team == team or u.hp <= 0.0 or u.mount != null or u == direct:
			continue
		var d := u.pos.distance_to(p)
		if d < radius:
			hurt(u, dmg * (1.0 - d / radius * .6) * (.5 if u.cls == Cfg.Cls.DESTROYER else 1.0), by_player, p, true)
		if u.is_ai and u.hp > 0.0 and d < press and not lite:
			u.suppress = minf(1.5, u.suppress + .9 * (1.0 - d / press))      # ledakan dekat = merunduk (bukan lari menghindar)
	for v in g.vehicles:
		if v.team == team or v.dead or v == direct:
			continue
		var d := v.pos.distance_to(p)
		if d < radius + 30.0:
			g.vehicle_sys.damage(v, dmg * (1.0 - d / (radius + 30.0) * .5) * Cfg.VEH_SPLASH_RESIST[v.kind])
	for q in g.turrets:
		if q.team == team or q.dead or q == direct:
			continue
		var d := q.pos.distance_to(p)
		if d < radius + 20.0:
			g.vehicle_sys.damage_turret(q, dmg * (1.0 - d / (radius + 20.0) * .5))
	for s in g.structs:
		if s.team == team:
			continue
		var d := s.pos.distance_to(p)
		if d < radius + 20.0:
			s.hp -= dmg * (1.0 - d / (radius + 20.0) * .5)
	g.world.cut_walls(p, radius * .7 + 30.0)
	_cur_r = -1


# ================================================================ kerusakan prajurit
## src = posisi asal serangan (opsional) agar AI tahu ke mana harus menoleh.
## blast = kerusakan berasal dari ledakan (tubuh yang tewas akan terlempar).
func hurt(u: Unit, dmg: float, by_player: bool, src: Vector2 = Vector2.INF, blast := false) -> void:
	if u.hp <= 0.0:
		return
	if g.cheat("god") and not u.is_ai:
		return
	if not u.is_ai:
		if u.spawn_protect > 0.0:
			return
		dmg *= Cfg.DIFF_DMG[g.prefs.difficulty]
	if by_player and g.hit_marker_t <= 0.0:
		g.ui_sfx(3)
	u.hp -= dmg
	u.regen_t = 0.0
	u.alert_t = 4.0
	if by_player:
		g.hit_marker_t = .25
	if src != Vector2.INF:
		u.hurt_from = src
		u.hurt_t = 4.0
		if not u.is_ai:
			g.damage_dir = (src - u.pos).angle()
			g.damage_dir_t = 1.2
	g.fx.spawn(u.pos, .25, 9, Color(.8, .1, .1), Fx.Type.BLOOD)
	if not u.is_ai:
		if g.hurt_flash < .3:
			g.ui_sfx(9)
		g.hurt_flash = .6
		g.haptic(40)
	if u.hp <= 0.0:
		_on_death(u, by_player, src, blast)


func _on_death(u: Unit, by_player: bool, src: Vector2, blast: bool) -> void:
	if g.profile_on:
		var key := ("ledakan_r%d" % _cur_r) if _cur_r >= 0 else ("kena_langsung/lindas/rail" if blast else "peluru_senapan")
		death_stats[key] = death_stats.get(key, 0) + 1
	g.tickets[u.team] -= 1
	g.units_dirty = true
	g.death_effects(u, src, blast)
	if by_player:
		g.register_kill(u)
	if u.mount != null:
		g.vehicle_sys.vacate(u)
	if u.squad != null:
		u.squad = null
	if not u.is_ai:
		g.on_player_died()


# ================================================================ railgun & nuke
func rail(p: Vector2, ang: float, team: int, by_player: bool) -> void:
	var d := Vector2.RIGHT.rotated(ang)
	var e := g.world.ray_stop(p, d, 1000.0)
	var beam := BO.Beam.new()
	beam.a = p
	beam.b = e
	g.beams.append(beam)
	g.sfx(1, p)
	g.shake = maxf(g.shake, 8.0)
	for u in g.units:
		if u.team != team and u.hp > 0.0 and u.mount == null and Geometry2D.get_closest_point_to_segment(u.pos, p, e).distance_to(u.pos) < 22.0:
			hurt(u, 320.0, by_player, p, true)
	for v in g.vehicles:
		if v.team != team and not v.dead and Geometry2D.get_closest_point_to_segment(v.pos, p, e).distance_to(v.pos) < v.radius():
			g.vehicle_sys.damage(v, 420.0)
	for q in g.turrets:
		if q.team != team and not q.dead and Geometry2D.get_closest_point_to_segment(q.pos, p, e).distance_to(q.pos) < 24.0:
			g.vehicle_sys.damage_turret(q, 320.0)
	g.fx.spawn(e, .3, 60.0, Color(.7, 1, 1, .8), Fx.Type.FLASH)          # percikan di ujung sinar
	g.vfx.impact(e, Vfx.Surf.BUILDING, d)


func nuke(n: BO.Nuke) -> void:
	var p := n.pos
	g.fx.spawn(p, 1.6, 340, Color(1, 1, 1, .95))
	g.fx.spawn(p, 2.6, 260, Color(1, .5, .1, .9))
	g.fx.spawn(p, 1.0, 300, Color(1, .6, .2), Fx.Type.EXPLOSION)      # bola api bersprite di awal ledakan nuklir
	g.fx.spawn(p, 3.5, 180, Color(.2, .2, .2, .8))
	g.fx.spawn(p, 1.2, 420, Color(1, .9, .6, .5), Fx.Type.RING)
	g.fx.spawn(p, .5, 620, Color(1, .95, .8, .9), Fx.Type.FLASH)
	g.shake = 18.0
	g.add_decal(p, 170.0, 120.0, 0, Color.BLACK)
	for u in g.units:
		var d := u.pos.distance_to(p)
		if u.hp > 0.0 and d < 150.0:
			hurt(u, 99999.0, n.by_player, p, true)
		elif u.hp > 0.0 and d < 900.0:
			u.flash_t = maxf(u.flash_t, 2.5)
	for v in g.vehicles:
		if not v.dead and v.pos.distance_to(p) < 150.0 + v.radius():
			g.vehicle_sys.damage(v, 99999.0)
	for q in g.turrets:
		if not q.dead and q.pos.distance_to(p) < 170.0:
			g.vehicle_sys.damage_turret(q, 99999.0)
	for s in g.structs:
		if s.pos.distance_to(p) < 170.0:
			s.hp = 0.0
	g.world.cut_walls(p, 170.0)
