class_name World
extends RefCounted
## DUNIA STATIS: gedung, tembok, jalan, dekor, bendera + semua kueri ruang:
##  - blocked()   : apakah titik/lingkaran menabrak gedung/tembok/tepi peta
##  - los()       : apakah dua titik saling terlihat (gedung & asap menghalangi)
##  - find_path() : jalur A* untuk AI (infanteri / kendaraan)
##  - find_cover(): titik berlindung terbaik terhadap suatu ancaman
## Semua kueri dibuat murah (grid) karena dipanggil ratusan kali per detik.

## Dipancarkan saat tembok hancur/bertambah, supaya renderer menggambar ulang potongan peta itu.
signal region_changed(rect: Rect2)

var biome := 0
var buildings: Array[Rect2] = []
var walls: Array[Rect2] = []
var walls_initial: Array[Rect2] = []
var flag_positions: Array[Vector2] = []
var roads: Array = []                  # Array[PackedVector2Array]
var decor: Array = []                  # Array[Dictionary] {p, r, k, v}; k: 0 pohon 1 semak 2 batu 3 kawah
var smokes: Array[BO.Smoke] = []       # diisi Game; asap menghalangi LOS

var nav_inf: AStarGrid2D
var nav_veh: AStarGrid2D

var _block_grid: Dictionary = {}       # sel -> Array[Rect2] (gedung+tembok, dilebarkan 40)
var _wall_grid: Dictionary = {}        # sel -> Array[Rect2] (tembok saja, dilebarkan 60) untuk COVER
var _bullet_grid: Dictionary = {}      # sel -> Array[Rect2] (gedung saja) untuk peluru
var _los_cells := PackedByteArray()    # 1 = ada gedung di sel 32px
var _cnt_inf := PackedInt32Array()     # penghitung rintangan per sel navigasi
var _cnt_veh := PackedInt32Array()
var _cover_grid: Dictionary = {}       # sel -> Array[Vector4] (x, y, pusat rintangan x, y)


# ================================================================ pembuatan
func generate(seed_value: int, biome_index: int) -> void:
	biome = biome_index
	var m := MapGenerator.gen(seed_value, Cfg.MAP_W, Cfg.MAP_H)
	buildings.assign(m.B)
	walls_initial.assign(m.WL)
	flag_positions.assign(m.FLP)
	roads = m.RD
	decor = m.DEC
	reset_walls()


## Kembalikan tembok ke kondisi awal (awal misi baru).
func reset_walls() -> void:
	walls = walls_initial.duplicate()
	smokes.clear()
	_rebuild_grids()
	_build_los()
	_build_nav()
	_build_cover_points()


func _rebuild_grids() -> void:
	_block_grid.clear()
	_wall_grid.clear()
	_bullet_grid.clear()
	for b in buildings:
		_register(_block_grid, b, 40.0)
		_register(_bullet_grid, b, 0.0)
	for w in walls:
		_register(_block_grid, w, 40.0)
		_register(_wall_grid, w, 60.0)


func _register(grid: Dictionary, r: Rect2, margin: float) -> void:
	var e := r.grow(margin)
	var cs := Cfg.COARSE_CELL
	for x in range(int(e.position.x / cs), int(e.end.x / cs) + 1):
		for y in range(int(e.position.y / cs), int(e.end.y / cs) + 1):
			var k := Vector2i(x, y)
			if not grid.has(k):
				grid[k] = []
			grid[k].append(r)


func _cell_of(p: Vector2) -> Vector2i:
	return Vector2i(int(p.x / Cfg.COARSE_CELL), int(p.y / Cfg.COARSE_CELL))


func _build_los() -> void:
	_los_cells.resize(Cfg.NAV_W * Cfg.NAV_H)
	_los_cells.fill(0)
	for b in buildings:
		var x0 := clampi(int(b.position.x / Cfg.NAV_CELL), 0, Cfg.NAV_W - 1)
		var x1 := clampi(int(b.end.x / Cfg.NAV_CELL), 0, Cfg.NAV_W - 1)
		var y0 := clampi(int(b.position.y / Cfg.NAV_CELL), 0, Cfg.NAV_H - 1)
		var y1 := clampi(int(b.end.y / Cfg.NAV_CELL), 0, Cfg.NAV_H - 1)
		for gx in range(x0, x1 + 1):
			for gy in range(y0, y1 + 1):
				_los_cells[gy * Cfg.NAV_W + gx] = 1


# ================================================================ kueri tabrakan
## Apakah lingkaran (p, r) menabrak gedung / tembok / tepi peta?
func blocked(p: Vector2, r: float) -> bool:
	if p.x < r or p.y < r or p.x > Cfg.MAP_W - r or p.y > Cfg.MAP_H - r:
		return true
	var list: Array = _block_grid.get(_cell_of(p), [])
	for b: Rect2 in list:
		var cx := clampf(p.x, b.position.x, b.end.x)
		var cy := clampf(p.y, b.position.y, b.end.y)
		var dx := cx - p.x
		var dy := cy - p.y
		if dx * dx + dy * dy < r * r:
			return true
	return false


## Garis lurus a->b bebas rintangan untuk benda berjari-jari r?
func walkable(a: Vector2, b: Vector2, r: float) -> bool:
	var d := b - a
	var n := int(d.length() / 18.0) + 1
	for i in range(1, n + 1):
		if blocked(a + d * (float(i) / n), r):
			return false
	return true


## Dekat tembok/karung pasir (boleh COVER)?
func near_wall(p: Vector2) -> bool:
	var list: Array = _wall_grid.get(_cell_of(p), [])
	for w: Rect2 in list:
		var cx := clampf(p.x, w.position.x, w.end.x)
		var cy := clampf(p.y, w.position.y, w.end.y)
		if Vector2(cx, cy).distance_squared_to(p) < 2304.0:
			return true
	return false


## Apakah titik peluru menembus gedung?
func bullet_hits_building(p: Vector2) -> bool:
	var k := _cell_of(p)
	if not _bullet_grid.has(k):
		return false
	for r: Rect2 in _bullet_grid[k]:
		if r.has_point(p):
			return true
	return false


## v13: sapuan peluru a->b terhadap GEDUNG. Mengembalikan titik masuk pertama ke gedung, atau Vector2.INF bila bebas.
## Cepat: tiap titik uji dulu dicek ke grid 32px (_los_cells, satu pembacaan array) baru ke persegi gedung sebenarnya.
func bullet_sweep(a: Vector2, b: Vector2) -> Vector2:
	var d := b - a
	var n := int(d.length() / 8.0) + 1
	var step := d / float(n)
	var q := a
	for i in n:
		var prev := q
		q += step
		var gx := int(q.x / Cfg.NAV_CELL)
		var gy := int(q.y / Cfg.NAV_CELL)
		if gx < 0 or gy < 0 or gx >= Cfg.NAV_W or gy >= Cfg.NAV_H:
			continue
		if _los_cells[gy * Cfg.NAV_W + gx] != 0 and bullet_hits_building(q):
			return prev                              # titik terakhir yang masih di luar gedung (tepi gedung)
	return Vector2.INF


## Gedung penghalang pertama pada garis a->b? (dipakai peluru kendaraan/railgun). Mengembalikan titik berhenti.
func ray_stop(a: Vector2, dir: Vector2, length: float) -> Vector2:
	var i := 1
	while i * 30.0 <= length:
		var q := a + dir * (i * 30.0)
		if bullet_hits_building(q):
			return q
		i += 1
	return a + dir * length


## Garis pandang: gedung dan asap menghalangi. Murah (marching di grid 32px).
func los(a: Vector2, b: Vector2) -> bool:
	var d := b - a
	var dist := d.length()
	if dist > 8.0:
		var n := int(dist / 24.0) + 1
		var inc := d / n
		var p := a
		for i in range(1, n):
			p += inc
			var gx := int(p.x / Cfg.NAV_CELL)
			var gy := int(p.y / Cfg.NAV_CELL)
			if gx >= 0 and gy >= 0 and gx < Cfg.NAV_W and gy < Cfg.NAV_H and _los_cells[gy * Cfg.NAV_W + gx] != 0:
				return false
	for c in smokes:
		if Geometry2D.get_closest_point_to_segment(c.pos, a, b).distance_squared_to(c.pos) < c.radius * c.radius:
			return false
	return true


# ================================================================ tembok dinamis
## Hancurkan tembok yang pusatnya dalam radius. Mengembalikan true bila ada yang hancur.
func cut_walls(p: Vector2, radius: float) -> bool:
	var keep: Array[Rect2] = []
	var changed := false
	var r2 := radius * radius
	for w in walls:
		if w.get_center().distance_squared_to(p) > r2:
			keep.append(w)
		else:
			changed = true
			_nav_rect(w, false)
			region_changed.emit(w.grow(14.0))
	if changed:
		walls = keep
		_rebuild_grids()
	return changed


## Tambah tembok (sandbag buatan engineer).
func add_wall(r: Rect2) -> void:
	walls.append(r)
	_register(_block_grid, r, 40.0)
	_register(_wall_grid, r, 60.0)
	_nav_rect(r, true)
	region_changed.emit(r.grow(14.0))


# ================================================================ navigasi A*
func _nav_new() -> AStarGrid2D:
	var g := AStarGrid2D.new()
	g.region = Rect2i(0, 0, Cfg.NAV_W, Cfg.NAV_H)
	g.cell_size = Vector2(Cfg.NAV_CELL, Cfg.NAV_CELL)
	g.offset = Vector2(Cfg.NAV_CELL * .5, Cfg.NAV_CELL * .5)
	g.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
	g.update()
	return g


func _build_nav() -> void:
	nav_inf = _nav_new()
	nav_veh = _nav_new()
	_cnt_inf.resize(Cfg.NAV_W * Cfg.NAV_H)
	_cnt_inf.fill(0)
	_cnt_veh.resize(Cfg.NAV_W * Cfg.NAV_H)
	_cnt_veh.fill(0)
	for r in buildings:
		_nav_rect(r, true)
	for r in walls:
		_nav_rect(r, true)


func _nav_rect(r: Rect2, add: bool) -> void:
	_nav_cells(r, 12.0, _cnt_inf, nav_inf, add)     # infanteri: rintangan digemukkan 12 px
	_nav_cells(r, Cfg.NAV_VEH_CLEAR, _cnt_veh, nav_veh, add)     # kendaraan: lihat Cfg.NAV_VEH_CLEAR


# Penghitung per sel agar penghapusan satu tembok tidak membuka sel yang masih tertutup rintangan lain.
func _nav_cells(r: Rect2, margin: float, cnt: PackedInt32Array, g: AStarGrid2D, add: bool) -> void:
	var e := r.grow(margin)
	var x0 := clampi(int(floor(e.position.x / Cfg.NAV_CELL)), 0, Cfg.NAV_W - 1)
	var x1 := clampi(int(floor(e.end.x / Cfg.NAV_CELL)), 0, Cfg.NAV_W - 1)
	var y0 := clampi(int(floor(e.position.y / Cfg.NAV_CELL)), 0, Cfg.NAV_H - 1)
	var y1 := clampi(int(floor(e.end.y / Cfg.NAV_CELL)), 0, Cfg.NAV_H - 1)
	for gx in range(x0, x1 + 1):
		for gy in range(y0, y1 + 1):
			var k := gy * Cfg.NAV_W + gx
			if add:
				cnt[k] += 1
				if cnt[k] == 1:
					g.set_point_solid(Vector2i(gx, gy), true)
			else:
				cnt[k] = maxi(0, cnt[k] - 1)
				if cnt[k] == 0:
					g.set_point_solid(Vector2i(gx, gy), false)


## Sel bebas terdekat (bila titik berada di sel padat).
func _free_cell(g: AStarGrid2D, p: Vector2) -> Vector2i:
	var c := Vector2i(clampi(int(p.x / Cfg.NAV_CELL), 0, Cfg.NAV_W - 1), clampi(int(p.y / Cfg.NAV_CELL), 0, Cfg.NAV_H - 1))
	if not g.is_point_solid(c):
		return c
	for rad in range(1, 8):
		for dx in range(-rad, rad + 1):
			for dy in range(-rad, rad + 1):
				if maxi(absi(dx), absi(dy)) != rad:
					continue
				var q := Vector2i(c.x + dx, c.y + dy)
				if g.is_in_boundsv(q) and not g.is_point_solid(q):
					return q
	return c


## Jalur A* dari a ke b. Kosong bila tidak ada jalur.
func find_path(a: Vector2, b: Vector2, vehicle: bool) -> PackedVector2Array:
	var g := nav_veh if vehicle else nav_inf
	var pth := g.get_point_path(_free_cell(g, a), _free_cell(g, b))
	return pth if pth.size() > 1 else PackedVector2Array()


# ================================================================ titik berlindung
func _build_cover_points() -> void:
	_cover_grid.clear()
	for b in buildings:
		_add_cover_around(b, 40.0)
	for w in walls:
		_add_cover_around(w, 30.0)


func _add_cover_around(r: Rect2, off: float) -> void:
	var c := r.get_center()
	var e := r.grow(off)
	var pts := [e.position, Vector2(e.end.x, e.position.y), e.end, Vector2(e.position.x, e.end.y),
		Vector2(c.x, e.position.y), Vector2(c.x, e.end.y), Vector2(e.position.x, c.y), Vector2(e.end.x, c.y)]
	for p: Vector2 in pts:
		if blocked(p, 13.0):
			continue
		var k := _cell_of(p)
		if not _cover_grid.has(k):
			_cover_grid[k] = []
		_cover_grid[k].append(Vector4(p.x, p.y, c.x, c.y))


## Titik berlindung di dekat `from` yang menaruh rintangan di antara dirinya dan `threat`.
## Mengembalikan Vector2.INF bila tidak ada.
func find_cover(from: Vector2, threat: Vector2, max_dist: float) -> Vector2:
	var best := Vector2.INF
	var best_score := 1e9
	var c0 := _cell_of(from)
	var span := int(max_dist / Cfg.COARSE_CELL) + 1
	for dx in range(-span, span + 1):
		for dy in range(-span, span + 1):
			var list: Array = _cover_grid.get(Vector2i(c0.x + dx, c0.y + dy), [])
			for v: Vector4 in list:
				var p := Vector2(v.x, v.y)
				var d := p.distance_to(from)
				if d > max_dist:
					continue
				var obs := Vector2(v.z, v.w)
				var away := (p - obs).normalized()
				var toward := (threat - obs).normalized()
				if away.dot(toward) > -0.25:
					continue                      # rintangan tidak berada di antara kita dan ancaman
				if p.distance_to(threat) < 120.0:
					continue
				var score := d + p.distance_to(threat) * -0.1 + randf() * 40.0
				if score < best_score:
					best_score = score
					best = p
	return best
