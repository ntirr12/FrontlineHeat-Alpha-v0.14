class_name Director
extends RefCounted
## DIRECTOR PERTEMPURAN ("sutradara" yang menjaga medan tetap ramai & tidak membosankan).
##  1. PEMANAS : bila pemain sepi musuh > DIR_CALM_TIME detik, tarik regu terdekat (dua tim) ke area pemain.
##  2. ARTILERI AMBIEN : peluru artileri jatuh acak di bendera yang diperebutkan (prajurit lari berhamburan).
##  3. KEJADIAN BESAR : serbuan jet, hujan artileri, salvo MLRS, pasukan bantuan terjun (C-17 + payung, v14).
##  4. PENYEIMBANG : tim yang kalah jumlah bendera mendapat bantuan lebih sering.
## Frekuensi diatur menu "KEKACAUAN" (Cfg.CHAOS_MULT).

var g: Game
var calm_t := 0.0
var _pull_cd := 0.0
var _event_t := 20.0
var _shell_t := 8.0
var _flyover_t := 15.0
var _near_buf: Array = []


func _init(game: Game) -> void:
	g = game


func reset() -> void:
	calm_t = 0.0
	_pull_cd = 8.0
	_event_t = randf_range(14.0, 24.0)
	_shell_t = randf_range(6.0, 10.0)
	_flyover_t = randf_range(10.0, 20.0)


func update(dt: float) -> void:
	var cm: float = Cfg.CHAOS_MULT[g.prefs.chaos]
	_pull_cd -= dt
	_update_calm(dt)
	if g.player != null and calm_t > Cfg.DIR_CALM_TIME / sqrt(cm) and _pull_cd <= 0.0:
		_pull_action()
	_event_t -= dt * cm
	if _event_t <= 0.0:
		_event_t = randf_range(Cfg.DIR_EVENT_GAP[0], Cfg.DIR_EVENT_GAP[1])
		_big_event()
	_shell_t -= dt * cm
	if _shell_t <= 0.0:
		_shell_t = randf_range(Cfg.DIR_AMBIENT_SHELL_GAP[0], Cfg.DIR_AMBIENT_SHELL_GAP[1])
		_ambient_shell()
	_flyover_t -= dt * cm
	if _flyover_t <= 0.0:
		_flyover_t = randf_range(Cfg.DIR_FLYOVER_GAP[0], Cfg.DIR_FLYOVER_GAP[1])
		_flyover()


func _update_calm(dt: float) -> void:
	if g.player == null:
		calm_t = 0.0
		return
	g.grid.query(3 - g.player.team, g.player.pos, 650.0, _near_buf)
	var enemies := 0
	for o: Unit in _near_buf:
		if o.pos.distance_squared_to(g.player.pos) < 422500.0:
			enemies += 1
	if enemies > 0 or g.gunfire_t > 0.0:
		calm_t = 0.0
	else:
		calm_t += dt


## Pemain sepi terlalu lama: tarik regu musuh (dan sekutu) mendekat supaya ada pertempuran.
func _pull_action() -> void:
	_pull_cd = 14.0
	calm_t = 0.0
	var p := g.player.pos
	var dir_to_enemy := (Objectives.base_pos(2) - p).normalized()
	var spot := p + dir_to_enemy * 520.0
	spot.x = clampf(spot.x, 120.0, Cfg.MAP_W - 120.0)
	spot.y = clampf(spot.y, 120.0, Cfg.MAP_H - 120.0)
	g.planner.redirect_nearest(2, spot, 2)
	g.planner.redirect_nearest(1, p + dir_to_enemy * 220.0, 1)


# ---------------------------------------------------------------- kejadian besar
func _big_event() -> void:
	var flags := g.objectives.flags
	if flags.is_empty():
		return
	var contested := _most_contested_flag()
	var roll := randf()
	var weaker := 2 if g.objectives.count_owned(1) > g.objectives.count_owned(2) else 1
	if roll < .30:
		_artillery_barrage(contested)
	elif roll < .52:
		_jet_run(contested)
	elif roll < .66:
		_mlrs_salvo(contested)
	else:
		_reinforcement(weaker, contested)


func _most_contested_flag() -> Flag:
	var best: Flag = null
	var bs := -1.0
	for f in g.objectives.flags:
		var c := [0, 0, 0]
		for u in g.units:
			if u.hp > 0.0 and u.pos.distance_squared_to(f.pos) < 250000.0:
				c[u.team] += 1
		var score := float(mini(c[1], c[2])) * 2.0 + float(c[1] + c[2]) * .3 + randf()
		if score > bs:
			bs = score
			best = f
	return best


func _artillery_barrage(f: Flag) -> void:
	var team := 1 if randf() < .5 else 2
	var p := f.pos + Vector2.from_angle(randf() * TAU) * randf_range(0.0, 120.0)
	g.support.call_barrage(p, team, false, randi_range(14, 22), 230.0, false, Vector2.RIGHT, true, Cfg.DIR_AMBIENT_DMG)
	if g.player != null and g.player.pos.distance_to(p) < 900.0:
		g.say("ARTILERI! MENJAUH DARI ZONA MERAH!", 2.5)


func _jet_run(f: Flag) -> void:
	var from_left := randf() < .5
	var team := 2 if from_left else 1                 # jet menyerang ke arah wilayah lawan
	var y := clampf(f.pos.y + randf_range(-160.0, 160.0), 200.0, Cfg.MAP_H - 200.0)
	var start := Vector2(-200.0 if from_left else Cfg.MAP_W + 200.0, y)
	var dir := Vector2.RIGHT if from_left else Vector2.LEFT
	g.support.spawn_jet(start, dir, 14, 1 if from_left else 2)
	g.sfx(11, Vector2(f.pos.x, y))
	if g.player != null and absf(g.player.pos.y - y) < 600.0:
		g.say("JET TEMPUR LEWAT! CARI PERLINDUNGAN!", 2.5)
	g.support.add_alert(Vector2(f.pos.x, y), 700.0, 4.0, 0)


## Salvo MLRS acak di bendera yang diperebutkan (satu tim menembak ke arah musuhnya).
func _mlrs_salvo(f: Flag) -> void:
	var team := 1 if randf() < .5 else 2
	var p := f.pos + Vector2.from_angle(randf() * TAU) * randf_range(0.0, 140.0)
	g.air.call_mlrs(p, team, false, true, randi_range(10, 14))
	if g.player != null and g.player.pos.distance_to(p) < 900.0:
		g.say("MLRS! ROKET AKAN JATUH - MENJAUH!", 2.5)


## Pasukan bantuan terjun payung (pesawat C-17) di bendera kontes untuk tim yang sedang tertinggal.
func _reinforcement(team: int, f: Flag) -> void:
	if g.tickets[team] <= 8:
		return
	g.air.call_airlift(f.pos, team, false)
	if team == 1:
		g.say("C-17 DATANG! PASUKAN BANTUAN TERJUN DI FLAG " + "ABCDE"[f.index], 3.0)
	else:
		g.feed("MUSUH TERJUN DI FLAG " + "ABCDE"[f.index], Color(1, .45, .4))


## Satu peluru artileri liar: peringatan dulu (desing + lingkaran bahaya), lalu meledak.
func _ambient_shell() -> void:
	var f := _most_contested_flag()
	if f == null:
		return
	var p := f.pos + Vector2.from_angle(randf() * TAU) * randf_range(60.0, 260.0)
	g.support.call_barrage(p, 0, false, randi_range(2, 4), 90.0, false, Vector2.RIGHT, true, 120.0)


func _flyover() -> void:
	var from_left := randf() < .5
	var start := Vector2(-300.0 if from_left else Cfg.MAP_W + 300.0, randf_range(300.0, Cfg.MAP_H - 300.0))
	g.support.spawn_jet(start, Vector2.RIGHT if from_left else Vector2.LEFT, 0, 0)
	if g.player != null and g.player.pos.distance_to(Vector2(clampf(g.player.pos.x, 0, Cfg.MAP_W), start.y)) < 1100.0:
		g.sfx(11, g.player.pos)
