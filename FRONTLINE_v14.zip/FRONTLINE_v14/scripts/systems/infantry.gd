class_name Infantry
extends RefCounted
## SENJATA & TIMER PRAJURIT (pemain maupun AI).
##  tick(u, dt)          : turunkan semua timer, regenerasi amunisi/granat. Dipanggil tiap frame.
##  fire(u, trigger, dt) : urus tembak, reload, overheat, Javelin, M203, pisau.
## Keputusan "kapan menembak" ada di pemain (PlayerCtl) atau otak AI (AiBrain).

var g: Game


func _init(game: Game) -> void:
	g = game


## Timer yang harus berjalan setiap frame untuk setiap prajurit hidup.
func tick(u: Unit, dt: float) -> void:
	u.fire_cd -= dt
	u.exposed_t -= dt
	u.shot_t -= dt
	u.alert_t -= dt
	u.flash_t -= dt
	u.radio_cd -= dt
	u.spawn_protect -= dt
	u.move_anim_t -= dt
	u.hurt_t -= dt
	u.regen_t += dt
	u.build_points = minf(100.0, u.build_points + 3.0 * dt)
	u.grenade_regen += dt
	if u.cls == Cfg.Cls.SPY:
		_spy_update(u, dt)
	elif u.cls == Cfg.Cls.SECRET or u.cls == Cfg.Cls.ELITE:
		u.skill_cd -= dt
	if g.cheat("amo") and not u.is_ai:
		u.ammo = 30
		u.javelin = u.javelin_max
		u.radio_cd = 0.0
		u.build_points = 100.0
		u.c4 = 9
		u.m203 = 4
		u.grenades = [9, 9, 9, 9]
		u.heat = 0.0
		u.skill_cd = 0.0
	if u.grenade_regen > 20.0:                    # granat/flash/smoke pulih pelan
		u.grenade_regen = 0.0
		var cap := [3, 2, 1]
		for i in 3:
			if u.grenades[i] < cap[i]:
				u.grenades[i] += 1
				break
	if u.javelin < u.javelin_max:
		u.javelin_regen += dt
		if u.javelin_regen > (3.5 if u.cls == Cfg.Cls.DESTROYER else 7.0):
			u.javelin += 1
			u.javelin_regen = 0.0
	if u.hp < u.max_hp and u.regen_t > (5.0 if not u.is_ai else 4.0):
		u.hp = minf(u.max_hp, u.hp + (25.0 if not u.is_ai else 9.0) * dt)


func fire(u: Unit, trigger: bool, dt: float) -> void:
	if u.flash_t > 0.0:
		trigger = false
	if u.cls == Cfg.Cls.JUGGERNAUT:
		if trigger and not u.overheated:
			u.heat += dt
		else:
			u.heat = maxf(0.0, u.heat - dt * .8)
		if u.heat >= 10.0:
			u.overheated = true
		if u.overheated and u.heat < 4.0:
			u.overheated = false
		if u.overheated:
			trigger = false
		u.ammo = 30
	if u.reload_t > 0.0:
		u.reload_t -= dt
		if u.reload_t <= 0.0:
			u.ammo = 30
		return
	if u.weapon == 0:
		_fire_primary(u, trigger)
	elif u.javelin_max == 0:
		_fire_secondary(u, trigger, dt)
	else:
		_update_lock(u, dt)
		if trigger and u.fire_cd <= 0.0 and u.javelin > 0 and u.lock_t > Cfg.LOCK_TIME[u.cls]:
			u.javelin -= 1
			u.fire_cd = .6
			u.lock_t = 0.0
			g.combat.shoot(u.pos, u.angle, u.team, Cfg.Bul.JAVELIN, u.lock_target, not u.is_ai)
			u.exposed_t = .5
			u.shot_t = 1.5


func _fire_primary(u: Unit, trigger: bool) -> void:
	if u.ammo <= 0:
		u.reload_t = 1.8
		if not u.is_ai:
			g.ui_sfx(7)
		return
	if not trigger or u.fire_cd > 0.0:
		return
	u.ammo -= 1
	var spread: float
	if u.is_ai:
		u.fire_cd = .06 if u.cls == Cfg.Cls.JUGGERNAUT else (.1 if u.cls == Cfg.Cls.SUPPORT else .13)
		var dist := 300.0
		if u.aim_point != Vector2.INF:
			dist = u.pos.distance_to(u.aim_point)
		elif u.target != null:
			dist = u.pos.distance_to(u.target.pos)
		var mult: float = Cfg.DIFF_AIM[g.prefs.difficulty] if u.team == 2 else 1.0
		var moving := 1.35 if u.move_anim_t > 0.0 else 1.0
		spread = (Cfg.AI_BASE_SPREAD + dist * Cfg.AI_SPREAD_PER_PX) * mult * moving * (1.0 + u.suppress * .8)   # tertekan = kurang akurat
		if u.cls == Cfg.Cls.JUGGERNAUT:
			spread *= 1.6
	else:
		u.fire_cd = .04 if u.cls == Cfg.Cls.JUGGERNAUT else (.075 if u.cls == Cfg.Cls.SUPPORT else (.11 if u.cls == Cfg.Cls.SECRET else .095))
		spread = .09 if u.cls == Cfg.Cls.JUGGERNAUT else .05
	var muzzle := u.pos + Vector2.RIGHT.rotated(u.angle) * 18.0
	var kind := Cfg.Bul.EXPLO if u.cls == Cfg.Cls.SECRET else Cfg.Bul.RIFLE
	var b := g.combat.shoot(muzzle, u.angle + randf_range(-spread, spread), u.team, kind, null, not u.is_ai, _land_dist(u, muzzle))
	if b != null and u.cls == Cfg.Cls.SUPPORT:
		b.life = minf(b.life, .34)                    # SMG: jangkauan pendek
	u.exposed_t = .5
	u.shot_t = 1.5
	g.fx.spawn(muzzle, .07, 7, Color(1, .9, .5), Fx.Type.MUZZLE, Vector2.from_angle(u.angle))


## Jarak ke sasaran yang dibidik (untuk titik jatuh peluru yang meleset). AI: titik bidik yang dicatat otaknya.
## Pemain: musuh terdekat di garis bidik. -1 = tidak ada sasaran (peluru terbang sampai jangkauan).
func _land_dist(u: Unit, muzzle: Vector2) -> float:
	if u.is_ai:
		return muzzle.distance_to(u.aim_point) if u.aim_point != Vector2.INF else -1.0
	return g.combat.aim_distance_for(muzzle, u.angle, u.team)


func _fire_secondary(u: Unit, trigger: bool, dt: float) -> void:
	if u.cls == Cfg.Cls.ASSAULT and u.m203 < 4:
		u.m203_regen += dt
		if u.m203_regen > 6.0:
			u.m203 += 1
			u.m203_regen = 0.0
	if not trigger or u.fire_cd > 0.0:
		return
	var muzzle := u.pos + Vector2.RIGHT.rotated(u.angle) * 18.0
	if u.cls == Cfg.Cls.ASSAULT:
		if u.m203 > 0:
			u.m203 -= 1
			u.fire_cd = 1.0
			u.exposed_t = .5
			u.shot_t = 1.5
			g.combat.shoot(muzzle, u.angle, u.team, Cfg.Bul.M203, null, not u.is_ai, _land_dist(u, muzzle))
	elif u.cls == Cfg.Cls.SPY:
		knife(u)
	else:
		u.fire_cd = .28
		u.exposed_t = .5
		u.shot_t = 1.5
		g.combat.shoot(muzzle, u.angle + randf_range(-.02, .02), u.team, Cfg.Bul.RIFLE, null, not u.is_ai, _land_dist(u, muzzle))


# ================================================================ Javelin lock
func _update_lock(u: Unit, dt: float) -> void:
	var best: Entity = null
	var range_px := 1100.0 if u.cls == Cfg.Cls.DESTROYER else 800.0
	for v in g.vehicles:
		if v.team != u.team and not v.dead and v.pos.distance_to(u.pos) < range_px \
				and absf(angle_difference(u.angle, (v.pos - u.pos).angle())) < .3 and g.world.los(u.pos, v.pos):
			best = v
	if best == null:
		u.lock_target = null
		u.lock_t = 0.0
		return
	if best != u.lock_target:
		u.lock_target = best
		u.lock_t = 0.0
	u.lock_t += dt


# ================================================================ Spy
func knife(u: Unit) -> void:
	u.fire_cd = .7
	for o in g.units:
		if o.team != u.team and o.hp > 0.0 and o.mount == null and o.pos.distance_to(u.pos) < 44.0:
			var from_behind := absf(angle_difference(o.angle, (u.pos - o.pos).angle())) > 1.6
			if (o.is_ai and o.target == null) or from_behind:
				g.combat.hurt(o, 999.0, not u.is_ai, u.pos)
				g.fx.spawn(o.pos, .3, 12, Color(.7, .1, .1), Fx.Type.BLOOD)
			else:
				g.combat.hurt(o, 45.0, not u.is_ai, u.pos)
				blow(u)
			return


## Samaran terbongkar: musuh di sekitar langsung waspada.
func blow(u: Unit) -> void:
	u.disguise_t = 0.0
	u.suspicion = 0.0
	u.skill_cd = maxf(u.skill_cd, 15.0)
	for o in g.units:
		if o.team != u.team and o.pos.distance_to(u.pos) < 350.0:
			o.alert_t = 4.0


func sabotage_target(u: Unit) -> Entity:
	for q in g.turrets:
		if q.team != u.team and not q.dead and q.pos.distance_to(u.pos) < 75.0:
			return q
	for s in g.structs:
		if s.team != u.team and s.hp > 0.0 and s.pos.distance_to(u.pos) < 75.0 \
				and (s.kind == Cfg.Item.JAMMER or s.kind == Cfg.Item.DRONE_ST or s.kind == Cfg.Item.TOWER):
			return s
	return null


func _spy_update(u: Unit, dt: float) -> void:
	u.skill_cd -= dt
	if u.sabotage_target != null:
		var x := u.sabotage_target
		if u.pos.distance_to(x.pos) > 85.0 or not x.is_alive():
			u.sabotage_target = null
			u.sabotage_t = 0.0
		else:
			u.sabotage_t += dt
			if u.sabotage_t >= 4.0:
				if x is Platform:
					var pf := x as Platform
					pf.dead = true
					pf.respawn_t = Cfg.TURRET_RESPAWN
					if pf.driver != null:
						g.vehicle_sys.vacate(pf.driver)
				else:
					x.hp = 0.0
				u.sabotage_target = null
				u.sabotage_t = 0.0
	if u.disguise_t > 0.0:
		u.disguise_t -= dt
		var rr := 220.0 if u.sabotage_target != null else 90.0
		var near := false
		for o in g.units:
			if o.team != u.team and o.hp > 0.0 and o.mount == null and o.pos.distance_squared_to(u.pos) < rr * rr:
				near = true
				break
		u.suspicion = u.suspicion + dt if near else maxf(0.0, u.suspicion - dt)
		if u.suspicion >= 5.0 or u.exposed_t > 0.0:
			blow(u)
