class_name VehicleSys
extends RefCounted
## KENDARAAN & TURRET: gerak, tembak, kerusakan, naik/turun.
## Pemain dan AI memakai fungsi `drive()` yang sama (hanya sumber input yang beda).

var g: Game
var _near: Array = []


func _init(game: Game) -> void:
	g = game


# ================================================================ update per frame
func update_vehicle(v: Vehicle, dt: float) -> void:
	if v.dead:
		v.respawn_t -= dt
		g.vfx.wreck_tick(v, dt)                       # kolom asap hitam + semburan api berkala
		if v.respawn_t <= 0.0:
			v.hp = v.max_hp
			v.dead = false
			v.pos = v.home
			v.speed = 0.0
			v.burn_t = 0.0
			v.skill_cd = 0.0
			v.boost_t = 0.0
		return
	v.cooldown -= dt
	v.shot_t -= dt
	v.gunner_cd -= dt
	v.skill_cd = maxf(0.0, v.skill_cd - dt)
	v.boost_t = maxf(0.0, v.boost_t - dt)
	g.vfx.track_dust(v, dt)                           # debu roda/rantai (makin cepat makin tebal) + api knalpot saat boost
	g.vfx.damaged_tick(v, dt)                         # berasap/menyala saat HP rendah
	if v.kind == Cfg.Veh.MEDEVAC:
		_medevac_tick(v, dt)
	if v.driver != null:
		v.driver.pos = v.pos
		_crush(v, dt)
	else:
		v.speed = 0.0
	if v.gunner != null:
		v.gunner.pos = v.pos
		if v.gunner_cd <= 0.0:
			_gunner_fire(v)


## MEDEVAC berawak menyembuhkan prajurit sekutu di sekitarnya (2x lebih cepat saat berhenti).
func _medevac_tick(v: Vehicle, dt: float) -> void:
	v.heal_t -= dt
	v.pulse = maxf(0.0, v.pulse - dt * 1.3)
	if v.driver == null or v.heal_t > 0.0:
		return
	v.heal_t = .25
	var amt: float = Cfg.MEDEVAC_HEAL * (2.0 if absf(v.speed) < Cfg.MEDEVAC_IDLE_SPEED else 1.0) * .25
	var r2: float = Cfg.MEDEVAC_RADIUS * Cfg.MEDEVAC_RADIUS
	var healed := 0
	g.grid.query(v.team, v.pos, Cfg.MEDEVAC_RADIUS, _near)
	for o: Unit in _near:
		if o.hp > 0.0 and o.hp < o.max_hp and o.mount == null and o.pos.distance_squared_to(v.pos) < r2:
			o.hp = minf(o.max_hp, o.hp + amt)
			healed += 1
			if healed <= 3:
				g.vfx.heal_spark(o.pos)
	if healed > 0:
		v.pulse = 1.0


func _gunner_fire(v: Vehicle) -> void:
	var enemy := 3 - v.team
	g.grid.query(enemy, v.pos, 520.0, _near)
	var best: Unit = null
	var bd := 520.0
	for o: Unit in _near:
		var d := o.pos.distance_to(v.pos)
		if d < bd and g.world.los(v.pos, o.pos):
			bd = d
			best = o
	if best != null:
		v.gunner_aim = (best.pos - v.pos).angle()
		v.gunner_cd = .11
		v.shot_t = 1.5
		g.combat.shoot(v.pos + Vector2.RIGHT.rotated(v.gunner_aim) * v.radius() * .5, v.gunner_aim + randf_range(-.08, .08), v.team, Cfg.Bul.RIFLE, null, false, bd, Cfg.GUNNER_DMG)


## Kendaraan melindas prajurit musuh yang ada di jalurnya (hanya bila cukup cepat).
func _crush(v: Vehicle, dt: float) -> void:
	v.crush_cd -= dt
	if v.crush_cd > 0.0 or absf(v.speed) < Cfg.VEH_CRUSH_SPEED:
		return
	v.crush_cd = .2
	var enemy := 3 - v.team
	if enemy < 1 or enemy > 2:
		return
	var by_player := not v.driver.is_ai
	g.grid.query(enemy, v.pos, v.radius() + 10.0, _near)
	for o: Unit in _near:
		if o.hp > 0.0 and o.mount == null and o.pos.distance_to(v.pos) < v.radius() * .9 + 6.0:
			g.combat.hurt(o, Cfg.VEH_CRUSH_DMG, by_player, v.pos, true)


## Jarak ke sasaran yang dibidik penembak kendaraan/turret (untuk titik jatuh peluru yang meleset).
## AI: titik bidik yang dicatat otaknya. Pemain: musuh terdekat di garis bidik. -1 = tidak ada sasaran.
func _land_dist(mz: Vector2, aim: float, team: int, who: Unit, max_d := 760.0) -> float:
	if who == null:
		return -1.0
	if who.is_ai:
		return mz.distance_to(who.aim_point) if who.aim_point != Vector2.INF else -1.0
	return g.combat.aim_distance_for(mz, aim, team, max_d)


func update_turret(q: Turret, dt: float) -> void:
	q.cooldown -= dt
	q.shot_t -= dt
	if q.dead:
		q.respawn_t -= dt
		if q.respawn_t <= 0.0:
			q.hp = q.max_hp
			q.dead = false
		return
	if q.driver != null:
		q.driver.pos = q.pos


## Mengemudikan kendaraan: m = vektor gerak (-1..1), a = vektor bidik. Tembak bila |a| > 0.96.
## back = true: mundur lurus (dipakai AI menjaga jarak dari sasaran), badan tidak berputar.
func drive(v: Vehicle, m: Vector2, a: Vector2, dt: float, back := false) -> void:
	var mx: float = Cfg.VEH_SPEED[v.kind]
	var tr: float = Cfg.VEH_TURN[v.kind]
	if v.boost_t > 0.0:
		mx *= Cfg.VEH_BOOST_MULT                      # BOOST aktif
	elif v.hp < v.max_hp * Cfg.VEH_LIMP_HP:
		mx *= Cfg.VEH_LIMP_MULT                       # mesin rusak: pincang
	if back:
		v.speed = move_toward(v.speed, -mx * .45, mx * .9 * dt)
	elif m.length() > .15:
		var df := angle_difference(v.heading, m.angle())
		v.heading += clampf(df, -tr * dt, tr * dt)
		v.speed = move_toward(v.speed, m.length() * mx * clampf(cos(df) + .25, 0.0, 1.0), mx * .9 * dt)
	else:
		v.speed = move_toward(v.speed, 0.0, mx * dt)
	var step := Vector2.RIGHT.rotated(v.heading) * v.speed * dt
	var q := v.pos + step
	if not g.blocked(q, v.radius()):
		v.pos = q
	else:
		# Menyentuh tembok/gedung: coba MELUNCUR menyamping (sumbu x atau y) sebelum memantul mundur.
		var qx := Vector2(q.x, v.pos.y)
		var qy := Vector2(v.pos.x, q.y)
		if absf(step.x) > .01 and not g.blocked(qx, v.radius()):
			v.pos = qx
			v.speed *= .7
		elif absf(step.y) > .01 and not g.blocked(qy, v.radius()):
			v.pos = qy
			v.speed *= .7
		else:
			v.speed *= -.2
	if a.length() > .2:
		v.aim = lerp_angle(v.aim, a.angle(), 5.0 * dt)
	elif m.length() > .15:
		v.aim = lerp_angle(v.aim, v.heading, 2.0 * dt)
	if a.length() > .96 and v.cooldown <= 0.0 and v.armed():
		var by_player := v.driver != null and not v.driver.is_ai
		var sk: int = Cfg.VEH_SHOT[v.kind][v.weapon]
		var mz := v.pos + Vector2.RIGHT.rotated(v.aim) * float(Cfg.VEH_MUZZLE[v.kind])
		var arty := sk == Cfg.Bul.HOWITZER or sk == Cfg.Bul.SMOKESHELL
		v.cooldown = Cfg.VEH_COOLDOWN[v.kind][v.weapon]
		if (sk == Cfg.Bul.SHELL or sk == Cfg.Bul.TOW or sk == Cfg.Bul.HOWITZER) and v.driver != null and v.driver.is_ai:
			v.cooldown += randf_range(Cfg.AI_VEH_FIRE_GAP.x, Cfg.AI_VEH_FIRE_GAP.y)      # AI mengincar ulang sasaran, tidak menembak metronom
		v.shot_t = 1.5
		if sk == Cfg.SHOT_RAIL:
			g.combat.rail(mz, v.aim, v.team, by_player)
		else:
			var spread := randf_range(-.07, .07) if sk == Cfg.Bul.RIFLE else 0.0
			var land := _land_dist(mz, v.aim, v.team, v.driver, Cfg.ARTY_AIM_RANGE if arty else 760.0)
			g.combat.shoot(mz, v.aim + spread, v.team, sk, v if sk == Cfg.Bul.TOW else null, by_player, land, Cfg.VEH_GUN_DMG[v.kind] if sk == Cfg.Bul.RIFLE else 1.0)
		var big := sk != Cfg.Bul.RIFLE
		g.fx.spawn(mz, .25 if big else .07, (34.0 if sk == Cfg.Bul.HOWITZER else 24.0) if big else 8.0, Color(1, .9, .5), Fx.Type.MUZZLE, Vector2.from_angle(v.aim))
		if sk == Cfg.Bul.SHELL or sk == Cfg.Bul.HOWITZER or sk == Cfg.SHOT_RAIL:
			g.vfx.gun_blast(mz, v.aim)                # debu tersembur di tanah saat meriam menembak
		if sk == Cfg.Bul.HOWITZER or sk == Cfg.Bul.SMOKESHELL:
			g.vfx.barrel_smoke(mz, v.aim)             # asap tebal keluar dari laras artileri
		if sk > 0 and by_player:
			g.shake = maxf(g.shake, 11.0 if sk == Cfg.Bul.HOWITZER else 7.0)


## Skill kendaraan (tombol SKILL saat menyetir): BOOST untuk kendaraan ringan, TIRAI ASAP untuk lapis baja.
func vehicle_skill(v: Vehicle) -> bool:
	if v.dead or v.skill_cd > 0.0:
		return false
	v.skill_cd = Cfg.VEH_SKILL_CD[v.kind]
	if Cfg.VEH_SKILL_BOOST[v.kind]:
		v.boost_t = Cfg.VEH_BOOST_TIME
		g.vfx.boost_burst(v)
	else:
		var sm := BO.Smoke.new()
		sm.pos = v.pos
		sm.radius = Cfg.VEH_SMOKE_RADIUS
		sm.t = Cfg.VEH_SMOKE_TIME
		g.smokes.append(sm)
		g.vfx.smoke_screen(v.pos)
	return true


func turret_fire(q: Turret) -> void:
	if q.cooldown > 0.0:
		return
	var d := Vector2.RIGHT.rotated(q.aim)
	var by_player := q.driver != null and not q.driver.is_ai
	q.shot_t = 1.5
	if q.type == 1:
		q.cooldown = 4.0
		g.combat.shoot(q.pos + d * 34.0, q.aim, q.team, Cfg.Bul.TOW, q, by_player)
		return
	q.cooldown = .06
	q.alt = not q.alt
	var mz := q.pos + d * 30.0 + d.orthogonal() * (7.0 if q.alt else -7.0)
	g.combat.shoot(mz, q.aim + randf_range(-.04, .04), q.team, Cfg.Bul.RIFLE, null, by_player, _land_dist(mz, q.aim, q.team, q.driver))
	g.fx.spawn(mz, .06, 7, Color(1, .9, .5), Fx.Type.MUZZLE, d)


# ================================================================ kerusakan
func damage(v: Vehicle, d: float) -> void:
	if v.dead:
		return
	if g.cheat("god") and v.driver != null and not v.driver.is_ai:
		return
	v.hp -= d
	if d >= 15.0:
		g.fx.spawn(v.pos, .2, 12, Color(1, .8, .3))     # kilat tanda kena hantaman besar (tembakan senapan punya percikan sendiri di titik kena)
	if v.hp <= 0.0:
		v.dead = true
		v.respawn_t = Cfg.VEH_RESPAWN
		for x in [v.driver, v.gunner]:
			if x != null:
				x.mount = null
				x.seat = 0
		v.driver = null
		v.gunner = null
		g.combat.explode(v.pos, 120, 90, 0, false)
		g.vfx.vehicle_destroyed(v)                        # semburan api, turret terlempar, ledakan susulan
		if v.kind == Cfg.Veh.MEDEVAC:
			g.air.spawn_crate(v.pos + Vector2.from_angle(randf() * TAU) * 40.0, v.team, 0)   # muatan medis selamat: peti di dekat bangkai


func damage_turret(q: Turret, d: float) -> void:
	if q.dead:
		return
	if g.cheat("god") and q.driver != null and not q.driver.is_ai:
		return
	q.hp -= d
	g.fx.spawn(q.pos, .15, 9, Color(1, .8, .3))
	if q.hp <= 0.0:
		q.dead = true
		q.respawn_t = Cfg.TURRET_RESPAWN
		if q.driver != null:
			q.driver.mount = null
			q.driver = null
		g.combat.explode(q.pos, 70, 70, 0, false)


# ================================================================ naik / turun
## Prajurit keluar dari kendaraan/turret (dipanggil saat mati atau menekan TURUN).
func vacate(u: Unit) -> void:
	var m := u.mount
	if m == null:
		return
	if m is Vehicle:
		var v := m as Vehicle
		if v.driver == u:
			v.driver = null
		if v.gunner == u:
			v.gunner = null
	else:
		m.driver = null
	u.mount = null
	u.seat = 0


## Turun dari kendaraan dan taruh prajurit di sisi yang tidak terhalang.
func dismount(u: Unit) -> void:
	var m := u.mount
	if m == null:
		return
	vacate(u)
	if m is Vehicle:
		var v := m as Vehicle
		var d := Vector2.RIGHT.rotated(v.heading + PI / 2.0) * (v.radius() + 30.0)
		u.pos = v.pos + d if not g.blocked(v.pos + d, 12.0) else v.pos - d


func board(u: Unit, p: Platform, as_gunner := false) -> void:
	if as_gunner and p is Vehicle:
		(p as Vehicle).gunner = u
		u.seat = 1
	else:
		p.driver = u
		u.seat = 0
	u.mount = p
	u.pos = p.pos


## Cari kendaraan/turret kosong terdekat dalam jangkauan naik (untuk tombol NAIK pemain).
func find_boardable(u: Unit) -> Platform:
	for v in g.vehicles:
		if v.team == u.team and not v.dead and v.driver == null and v.pos.distance_to(u.pos) < v.radius() + 52.0:
			return v
	for q in g.turrets:
		if q.team == u.team and not q.dead and q.driver == null and q.pos.distance_to(u.pos) < 80.0:
			return q
	return null
