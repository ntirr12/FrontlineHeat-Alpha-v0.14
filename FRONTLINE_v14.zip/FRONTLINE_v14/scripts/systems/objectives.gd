class_name Objectives
extends RefCounted
## SASARAN MISI: 5 bendera, tiket tim, penyembuhan di markas/bunker, dan titik spawn.
## Aturan: tim dengan bendera lebih banyak menguras tiket lawan tiap 5 detik; mati = -1 tiket.

var g: Game
var flags: Array[Flag] = []
var _tick := 0.0
var _bleed := 0.0


func _init(game: Game) -> void:
	g = game


func setup(positions: Array[Vector2]) -> void:
	flags.clear()
	for i in positions.size():
		var f := Flag.new()
		f.pos = positions[i]
		f.index = i
		flags.append(f)
	_tick = 0.0
	_bleed = 0.0


func reset_owners() -> void:
	for f in flags:
		f.capture = 0.0
		f.owner_team = 0


static func base_pos(team: int) -> Vector2:
	return Vector2(Cfg.HQ_OFFSET, Cfg.MAP_H / 2.0) if team == 1 else Vector2(Cfg.MAP_W - Cfg.HQ_OFFSET, Cfg.MAP_H / 2.0)


func update(dt: float) -> void:
	_tick += dt
	if _tick < .1:
		return
	var step := _tick
	_tick = 0.0
	var owned := [0, 0, 0]
	for f in flags:
		var c := [0, 0, 0]
		for u in g.units:
			if u.hp > 0.0 and u.pos.distance_squared_to(f.pos) < 14400.0:
				c[u.team] += 1
		if c[1] != c[2]:
			var attacker := 1 if c[1] > c[2] else 2
			var slow := 1.0
			for s in g.structs:                          # bunker musuh memperlambat perebutan
				if s.kind == Cfg.Item.BUNKER and s.team != attacker and s.pos.distance_squared_to(f.pos) < 40000.0:
					slow = .2
			f.capture = clampf(f.capture + (1.0 if attacker == 1 else -1.0) * .14 * step * minf(absf(c[1] - c[2]), 3.0) * slow, -1.0, 1.0)
		var old := f.owner_team
		if f.capture >= 1.0:
			f.owner_team = 1
		elif f.capture <= -1.0:
			f.owner_team = 2
		elif (f.owner_team == 1 and f.capture < .5) or (f.owner_team == 2 and f.capture > -.5):
			f.owner_team = 0
		if f.owner_team != old and f.owner_team != 0:
			g.on_flag_captured(f)
		if f.owner_team != 0:
			owned[f.owner_team] += 1
	# ---- penyembuhan di markas / bunker (juga menandai prajurit yang berlindung di bunker)
	var bunkers: Array[Structure] = []
	for s in g.structs:
		if s.kind == Cfg.Item.BUNKER and s.hp > 0.0:
			bunkers.append(s)
	for u in g.units:
		if u.hp <= 0.0:
			continue
		u.in_bunker = false
		for s in bunkers:
			if s.team == u.team and s.pos.distance_squared_to(u.pos) < 3025.0:
				u.in_bunker = true
				break
		if u.hp < u.max_hp and (u.in_bunker or u.pos.distance_squared_to(base_pos(u.team)) < 28900.0):
			u.hp = minf(u.max_hp, u.hp + 14.0 * step)
	# ---- tiket menetes
	_bleed += step
	if _bleed > 5.0:
		_bleed = 0.0
		if owned[1] > owned[2]:
			g.tickets[2] -= 1
		elif owned[2] > owned[1]:
			g.tickets[1] -= 1


## Bendera milik `team` dalam 220 px dari p (tanpa bunker lain dekat bendera itu), atau null.
func friendly_flag_near(p: Vector2, team: int) -> Flag:
	for f in flags:
		if f.owner_team == team and f.pos.distance_squared_to(p) < 48400.0:
			for s in g.structs:
				if s.kind == Cfg.Item.BUNKER and s.pos.distance_squared_to(f.pos) < 40000.0:
					return null
			return f
	return null


## Titik spawn AI: bendera milik tim yang paling dekat markas lawan (garis depan), kecuali sedang diserbu.
func spawn_point(team: int) -> Vector2:
	var best: Flag = null
	var bd := 1e9
	for f in flags:
		if f.owner_team != team:
			continue
		var enemies := 0
		for o in g.units:
			if o.team != team and o.hp > 0.0 and o.pos.distance_squared_to(f.pos) < 62500.0:
				enemies += 1
		if enemies > 0:
			continue
		var d := f.pos.distance_to(base_pos(3 - team))
		if d < bd:
			bd = d
			best = f
	if best != null and randf() < .85:
		return best.pos + Vector2(randf_range(-80, 80), randf_range(-80, 80))
	return base_pos(team) + Vector2(randf_range(-90, 90), randf_range(-300, 300))


## Sasaran terdekat untuk panah petunjuk pemain: bendera yang belum dimiliki tim 1, atau markas musuh.
func nearest_target(p: Vector2) -> Vector2:
	var best := Objectives.base_pos(2)
	var bd := 1e9
	var all_owned := true
	for f in flags:
		if f.owner_team != 1:
			all_owned = false
			var d := f.pos.distance_squared_to(p)
			if d < bd:
				bd = d
				best = f.pos
	return best if not all_owned or flags.is_empty() else Objectives.base_pos(2)


func count_owned(team: int) -> int:
	var n := 0
	for f in flags:
		if f.owner_team == team:
			n += 1
	return n
