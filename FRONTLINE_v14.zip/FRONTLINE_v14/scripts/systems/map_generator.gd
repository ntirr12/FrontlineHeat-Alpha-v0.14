class_name MapGenerator
extends RefCounted
## Generator peta acak (deterministik per seed): jalan, gedung, tembok/karung pasir, bendera, dekor.
#
# gen(seed, W, H) -> {B: gedung[Rect2], WL: tembok[Rect2], FLP: posisi bendera[Vector2],
#                     RD: jalan[PackedVector2Array], DEC: dekor[{p,r,k,v}]}
# k dekor: 0 pohon, 1 semak, 2 batu, 3 kawah.


static func _road(r: RandomNumberGenerator, a: Vector2, b: Vector2) -> PackedVector2Array:
	var pts := PackedVector2Array()
	var n := maxi(5, int(a.distance_to(b) / 260.0))
	var nrm := (b - a).normalized().orthogonal()
	var ph := r.randf() * 6.0
	var am := r.randf_range(40.0, 110.0)
	for i in range(n + 1):
		var k := float(i) / n
		pts.append(a.lerp(b, k) + nrm * sin(k * 5.0 + ph) * am * sin(k * PI))
	return pts


# Titik rapat sepanjang jalan (tiap <= 80 px) untuk uji jarak.
static func _dense(rd: PackedVector2Array) -> Array:
	var out: Array = []
	for i in range(rd.size() - 1):
		var a := rd[i]
		var b := rd[i + 1]
		var n := maxi(1, int(a.distance_to(b) / 80.0))
		for j in range(n):
			out.append(a.lerp(b, float(j) / n))
	out.append(rd[rd.size() - 1])
	return out


static func _free(p: Vector2, rad: float, B: Array, WL: Array, fp: Array, roads: Array, b1: Vector2, b2: Vector2, W: float, H: float) -> bool:
	if p.x < 60.0 or p.y < 60.0 or p.x > W - 60.0 or p.y > H - 60.0:
		return false
	if p.distance_to(b1) < 260.0 or p.distance_to(b2) < 260.0:
		return false
	for f in fp:
		if p.distance_to(f) < 200.0:
			return false
	for b in B:
		if b.grow(rad + 14.0).has_point(p):
			return false
	for w in WL:
		if w.grow(rad + 6.0).has_point(p):
			return false
	var lim := (rad + 38.0) * (rad + 38.0)
	for q in roads:
		if p.distance_squared_to(q) < lim:
			return false
	return true


static func gen(sd: int, W: float, H: float) -> Dictionary:
	var r := RandomNumberGenerator.new()
	r.seed = sd
	var b1 := Vector2(Cfg.HQ_OFFSET, H / 2.0)
	var b2 := Vector2(W - Cfg.HQ_OFFSET, H / 2.0)
	var fp: Array = []
	for q in [Vector2(.5, .5), Vector2(.36, .22), Vector2(.36, .78), Vector2(.64, .22), Vector2(.64, .78)]:
		fp.append(Vector2(W * q.x, H * q.y))

	# --- jalan: HQ -> bendera kiri -> tengah -> bendera kanan -> HQ lawan
	var RD: Array = []
	var links := [[b1, fp[1]], [b1, fp[2]], [fp[1], fp[0]], [fp[2], fp[0]], [fp[0], fp[3]], [fp[0], fp[4]], [fp[3], b2], [fp[4], b2]]
	var dense: Array = []
	for l in links:
		var rd := _road(r, l[0], l[1])
		RD.append(rd)
		dense.append_array(_dense(rd))

	# --- gedung (tidak menutup jalan / bendera / markas)
	var B: Array = []
	var tries := 0
	while B.size() < 42 and tries < 160:
		tries += 1
		var s := Vector2(r.randf_range(90.0, 260.0), r.randf_range(80.0, 220.0))
		var rc := Rect2(Vector2(r.randf_range(700.0, W - 700.0), r.randf_range(80.0, H - 80.0)) - s / 2.0, s)
		var ok := true
		for f in fp:
			if rc.grow(150.0).has_point(f):
				ok = false
				break
		if ok:
			var gr := rc.grow(60.0)
			for q in dense:
				if gr.has_point(q):
					ok = false
					break
		if ok:
			for o in B:
				if o.grow(30.0).intersects(rc):
					ok = false
					break
		if ok:
			B.append(rc)

	# --- tembok / karung pasir
	var WL: Array = []
	for bx in [b1.x + 330.0, b2.x - 330.0]:
		for y in range(int(H / 2.0) - 700, int(H / 2.0) + 701, 200):
			WL.append(Rect2(bx - 12.0, y - 55.0, 24.0, 110.0))
	for y in range(300, int(H) - 200, 400):
		for x in [.43, .57]:
			WL.append(Rect2(W * x - 55.0, y - 12.0, 110.0, 24.0))
	for f in fp:
		WL = WL.filter(func(w): return not w.grow(150.0).has_point(f))
	for f in fp:
		for dx in [-1, 1]:
			for dy in [-1, 1]:
				WL.append(Rect2(f + Vector2(dx * 150.0 - 55.0, dy * 170.0 - 12.0), Vector2(110.0, 24.0)))
				WL.append(Rect2(f + Vector2(dx * 205.0 - 12.0, dy * 115.0 - 55.0), Vector2(24.0, 110.0)))
	var wk: Array = []
	for w in WL:
		var hit := false
		for b in B:
			if b.grow(8.0).intersects(w):
				hit = true
				break
		if not hit:
			wk.append(w)
	WL = wk

	# --- dekor
	var DEC: Array = []
	for c in r.randi_range(9, 13):
		var cp := Vector2(r.randf_range(300.0, W - 300.0), r.randf_range(200.0, H - 200.0))
		var cr := r.randf_range(160.0, 420.0)
		for i in r.randi_range(8, 18):
			var p := cp + Vector2.from_angle(r.randf() * TAU) * r.randf() * cr
			var rad := r.randf_range(20.0, 36.0)
			if _free(p, rad, B, WL, fp, dense, b1, b2, W, H):
				DEC.append({p = p, r = rad, k = 0, v = r.randf()})
	for i in 70:
		var p := Vector2(r.randf_range(60.0, W - 60.0), r.randf_range(60.0, H - 60.0))
		var rad := r.randf_range(10.0, 16.0)
		if _free(p, rad, B, WL, fp, dense, b1, b2, W, H):
			DEC.append({p = p, r = rad, k = 1, v = r.randf()})
	for i in 40:
		var p := Vector2(r.randf_range(60.0, W - 60.0), r.randf_range(60.0, H - 60.0))
		var rad := r.randf_range(12.0, 22.0)
		if _free(p, rad, B, WL, fp, dense, b1, b2, W, H):
			DEC.append({p = p, r = rad, k = 2, v = r.randf()})
	for i in 26:
		var p := Vector2(r.randf_range(60.0, W - 60.0), r.randf_range(60.0, H - 60.0))
		var rad := r.randf_range(28.0, 60.0)
		if _free(p, rad, B, WL, fp, dense, b1, b2, W, H):
			DEC.append({p = p, r = rad, k = 3, v = r.randf()})

	return {B = B, WL = WL, FLP = fp, RD = RD, DEC = DEC}
