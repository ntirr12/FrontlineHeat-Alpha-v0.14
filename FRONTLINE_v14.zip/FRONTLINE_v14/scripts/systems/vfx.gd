class_name Vfx
extends RefCounted
## EFEK PERTEMPURAN: semua "bumbu" visual yang membuat pertempuran terasa nyata.
##   impact()              peluru jatuh ke tanah / kena gedung / kena baja / kena karung pasir
##   blast()               ledakan berlapis: bola api, kilatan, asap, semburan tanah, serpihan, kawah
##   vehicle_destroyed()   kendaraan meledak: semburan api dari panel/palka, turret terlempar, ledakan susulan
##   wreck_tick()          bangkai terbakar: kolom asap hitam + semburan api berkala
##   damaged_tick()        kendaraan rusak parah: berasap lalu menyala
##   body_launch()         prajurit yang tewas karena ledakan terlempar
##   gun_blast()           debu tersembur di tanah saat meriam menembak
## v14 menambah: track_dust() debu roda/rantai & api knalpot boost, boost_burst(), smoke_screen(), heal_spark() (MEDEVAC),
##   barrel_smoke() & shell_trail() (artileri), rocket_trail() / launch_blast() (MLRS), chute_land() (penerjun mendarat).
##
## Semuanya hanya memakai Fx pool (batas jumlah per kualitas, efek kecil dibuang lebih dulu) dan jauh dari kamera
## otomatis tidak dibuat. Satu-satunya efek yang memengaruhi permainan adalah ledakan susulan kecil bangkai
## kendaraan (bahaya mendekat ke bangkai yang terbakar). Mau ubah tampilan? Ubah angka di sini; mau ubah
## keseimbangan? Lihat Cfg.

enum Surf { GROUND, BUILDING, ARMOR, COVER }
enum EvtKind { POP, TURRET_LAND, DUST_LAND, TRAIL }

## Posisi palka/panel tiap kendaraan (koordinat badan: x = maju, y = kanan), sumber semburan api saat meledak.
## Urutan menentukan prioritas: pada kualitas rendah hanya beberapa yang pertama dipakai.
const HATCHES := [
	[Vector2(-4, 0), Vector2(12, -8), Vector2(12, 8)],                                   # HUMVEE_MG
	[Vector2(-16, -11), Vector2(-16, 11), Vector2(-30, 0), Vector2(10, 0), Vector2(26, 0)],      # TANK (panel di belakang turret)
	[Vector2(-4, 0), Vector2(12, -8), Vector2(12, 8)],                                   # HUMVEE_AT
	[Vector2(-14, -10), Vector2(-14, 10), Vector2(8, 0), Vector2(-30, 0)],               # BRADLEY
	[Vector2(-16, -11), Vector2(-16, 11), Vector2(-30, 0), Vector2(10, 0), Vector2(26, 0)],      # RAILGUN
	[Vector2(-16, -9), Vector2(-16, 9), Vector2(8, 0), Vector2(-30, 0)],                 # APC
	[Vector2(-18, -11), Vector2(-18, 11), Vector2(-34, 0), Vector2(10, 0)],              # SPG
	[Vector2(-6, 0), Vector2(12, -8), Vector2(12, 8)],                                   # MEDEVAC
]


## Peristiwa tertunda (ledakan susulan, turret mendarat). Kecil dan jarang, jadi objek biasa sudah cukup.
class Evt extends RefCounted:
	var t := 0.0
	var kind := 0
	var pos := Vector2.ZERO
	var a := 0.0               # serbaguna: indeks / ukuran
	var team := 0
	var vk := 0


var g: Game
var _evts: Array[Evt] = []
var _budget := 6                       # sisa efek hantaman peluru pada frame ini (mencegah banjir efek saat tembakan rapat)
var _dust := Color(.6, .52, .38, .6)   # warna debu mengikuti biome


func _init(game: Game) -> void:
	g = game


## Awal pertandingan: bersihkan peristiwa tertunda & sesuaikan warna debu dengan biome.
func reset() -> void:
	_evts.clear()
	var b: Dictionary = Cfg.BIOMES[clampi(g.world.biome, 0, Cfg.BIOMES.size() - 1)]
	_dust = (b.g2 as Color).lerp(Color(.55, .5, .42), .45)
	_dust.a = .6


func update(dt: float) -> void:
	_budget = [6, 4, 2][g.quality_level]
	var i := 0
	while i < _evts.size():
		var e := _evts[i]
		e.t -= dt
		if e.t <= 0.0:
			_fire(e)
			_evts[i] = _evts[_evts.size() - 1]
			_evts.pop_back()
		else:
			i += 1


func _later(delay: float, kind: int, p: Vector2, a := 0.0, team := 0, vk := 0) -> void:
	if _evts.size() >= 48:
		return
	var e := Evt.new()
	e.t = delay
	e.kind = kind
	e.pos = p
	e.a = a
	e.team = team
	e.vk = vk
	_evts.append(e)


func _fire(e: Evt) -> void:
	match e.kind:
		EvtKind.POP:
			g.combat.explode(e.pos, 54.0, 38.0, 0, false, true)        # ledakan susulan kecil (amunisi meledak)
			_flame(e.pos, Vector2(0, -1).rotated(randf_range(-.6, .6)), randf_range(34.0, 54.0), randf_range(.45, .75))
			for i in [5, 3, 1][g.quality_level]:
				g.fx.spawn(e.pos, .5, 6.0, Color(1, .75, .3), Fx.Type.SPARK, Vector2.from_angle(randf() * TAU) * randf_range(40.0, 90.0))
			if e.a < 2.0:
				g.sfx(1, e.pos)
			_shake(e.pos, 9.0)
		EvtKind.TURRET_LAND:
			g.fx.spawn(e.pos, .5, 40.0, Color(1, .95, .85, .5), Fx.Type.RING)
			g.fx.spawn(e.pos, .6, 22.0, _dust, Fx.Type.DUST, Vector2(0, -16))
			_debris(e.pos, 4, 70.0, Color(.18, .17, .16))
			g.add_decal(e.pos, 15.0, 60.0, 0, Color.BLACK)
			g.sfx(1, e.pos)
			_shake(e.pos, 11.0)
		EvtKind.DUST_LAND:
			g.fx.spawn(e.pos, .45, 11.0, _dust, Fx.Type.DUST, Vector2(0, -10))
		EvtKind.TRAIL:
			g.fx.spawn(e.pos, .8, 12.0, Color(.15, .15, .15, .75), Fx.Type.SMOKE)       # jejak asap di belakang turret yang terlempar


func _shake(p: Vector2, strength: float) -> void:
	g.shake = maxf(g.shake, clampf(600.0 - p.distance_to(g.cam), 0.0, 600.0) / 600.0 * strength)


# ================================================================ peluru mengenai sesuatu
## Efek hantaman peluru senapan. dir = arah terbang peluru (untuk serpihan yang memantul ke belakang).
func impact(p: Vector2, surf: int, dir: Vector2) -> void:
	if _budget <= 0:
		return
	_budget -= 1
	var ql := g.quality_level
	match surf:
		Surf.GROUND:
			g.fx.spawn(p, .36, 7.0, _dust, Fx.Type.DUST, Vector2(0, -9))
			if ql < 2 and randi() % 3 == 0:
				_debris(p, 1, 22.0, _dust.darkened(.35), -dir)
			if ql < 2 and randi() % 6 == 0 and g.decals.size() < Cfg.MAX_DECALS - 25:
				g.add_decal(p, randf_range(3.0, 5.0), 14.0, 3, Color.BLACK, false)    # bekas hantaman kecil (tidak memicu gambar ulang cepat)
		Surf.BUILDING:
			g.fx.spawn(p, .22, 5.0, Color(1, .85, .5), Fx.Type.SPARK, (-dir + Vector2(randf_range(-.6, .6), randf_range(-.6, .6))).normalized() * 26.0)
			g.fx.spawn(p, .3, 6.0, Color(.62, .6, .56, .6), Fx.Type.DUST, Vector2(0, -7))
		Surf.ARMOR:
			for i in [3, 2, 1][ql]:
				g.fx.spawn(p, .2, 5.0, Color(1, .95, .65), Fx.Type.SPARK, (-dir + Vector2(randf_range(-1, 1), randf_range(-1, 1))).normalized() * randf_range(20.0, 42.0))
		Surf.COVER:
			g.fx.spawn(p, .3, 6.0, _dust.lightened(.15), Fx.Type.DUST, Vector2(0, -8))
			if ql < 2:
				_debris(p, 1, 20.0, Color(.5, .42, .3), -dir)


## Ujung laras: debu tersembur ke samping saat meriam besar menembak.
func gun_blast(mz: Vector2, aim: float) -> void:
	if g.quality_level == 2:
		return
	var side := Vector2.from_angle(aim + PI * .5)
	g.fx.spawn(mz, .5, 14.0, _dust, Fx.Type.DUST, side * 34.0 + Vector2(0, -8))
	g.fx.spawn(mz, .5, 14.0, _dust, Fx.Type.DUST, -side * 34.0 + Vector2(0, -8))


# ================================================================ ledakan
## Visual ledakan menurut ukuran. Kerusakan diurus Combat.explode(), fungsi ini murni tampilan.
func blast(p: Vector2, radius: float, lite: bool) -> void:
	var ql := g.quality_level
	if lite:
		g.fx.spawn(p, .25, radius, Color(1, .6, .2), Fx.Type.EXPLOSION)
		g.fx.spawn(p, .35, radius * .6, _dust, Fx.Type.DUST, Vector2(0, -12))
		return
	g.fx.spawn(p, .6, radius, Color(1, .55, .1), Fx.Type.EXPLOSION)
	g.fx.spawn(p, 1.2, radius * .8, Color(.3, .3, .3, .8), Fx.Type.SMOKE)
	if ql < 2 or radius >= 100.0:
		g.fx.spawn(p, .16, radius * 1.5, Color(1, .85, .5, .85), Fx.Type.FLASH)          # kilatan terang (lapisan aditif)
	if radius >= 90.0:
		g.fx.spawn(p, .5, radius * 1.6, Color(1, .9, .6, .55), Fx.Type.RING)
	for i in [8, 4, 0][ql]:
		g.fx.spawn(p, .45, radius * .25, Color(1, .7, .2), Fx.Type.SPARK, Vector2.from_angle(randf() * TAU) * randf_range(radius * .5, radius * 1.3))
	if ql < 2:
		for i in 2:
			g.fx.spawn(p + Vector2(randf_range(-radius, radius), randf_range(-radius, radius)) * .4, 1.6, radius * .55, Color(.25, .25, .25, .7), Fx.Type.SMOKE)
		# semburan tanah: gumpalan debu menyebar keluar + serpihan terlempar
		for i in [4, 2][ql]:
			var d := Vector2.from_angle(randf() * TAU)
			g.fx.spawn(p + d * radius * .2, .7, radius * .45, _dust, Fx.Type.DUST, d * radius * .7 + Vector2(0, -radius * .25))
		_debris(p, [9, 5][ql], radius * 1.1, Color(.2, .17, .14))
	if radius >= 70.0 and p.distance_to(g.cam) < 1500.0:
		g.add_decal(p + Vector2(randf_range(-6, 6), randf_range(-6, 6)), radius * .5, 90.0, 0, Color.BLACK)


## n serpihan yang terlempar melengkung lalu jatuh. `dir` = arah dominan (INF = ke segala arah).
func _debris(p: Vector2, n: int, reach: float, color: Color, dir := Vector2.INF) -> void:
	for i in n:
		var d := Vector2.from_angle(randf() * TAU) if dir == Vector2.INF else (dir + Vector2(randf_range(-.7, .7), randf_range(-.7, .7))).normalized()
		g.fx.spawn(p, randf_range(.4, .8), randf_range(2.0, 3.6), color, Fx.Type.DEBRIS, d * reach * randf_range(.4, 1.0), randf() * TAU, randf_range(-9.0, 9.0))


## Satu lidah api. dir = arah (dunia), len = panjang px, life = detik.
func _flame(p: Vector2, dir: Vector2, len: float, life: float) -> void:
	g.fx.spawn(p, life, len * .5, Color.WHITE, Fx.Type.FLAME, dir * 10.0, dir.angle())


# ================================================================ kendaraan
## Dipanggil sekali saat HP kendaraan habis. Ledakan utama (kerusakan area) dilakukan pemanggil lewat Combat.explode().
func vehicle_destroyed(v: Vehicle) -> void:
	var ql := g.quality_level
	var heavy := v.kind == Cfg.Veh.TANK or v.kind == Cfg.Veh.RAILGUN or v.kind == Cfg.Veh.BRADLEY or v.kind == Cfg.Veh.APC or v.kind == Cfg.Veh.SPG
	var p := v.pos
	v.burn_t = 0.0
	g.fx.spawn(p, .24, 150.0 if heavy else 100.0, Color(1, .95, .75, .9), Fx.Type.FLASH)
	g.fx.spawn(p, .6, 170.0 if heavy else 110.0, Color(1, .9, .6, .5), Fx.Type.RING)
	# ---- semburan api dari panel/palka: naik ke atas layar + sedikit keluar dari badan (seperti panel ledak sungguhan)
	var hs: Array = HATCHES[v.kind]
	var jets := mini(hs.size(), [hs.size(), 3, 2][ql])
	for i in jets:
		var h: Vector2 = (hs[i] as Vector2).rotated(v.heading) * Cfg.VEH_SCALE
		var out := h.normalized() if h.length() > 1.0 else Vector2.from_angle(randf() * TAU)
		var dir := (out * .45 + Vector2(0, -1.0)).normalized()
		var len := randf_range(80.0, 130.0) if heavy else randf_range(50.0, 80.0)
		_flame(p + h, dir, len, randf_range(.7, 1.15))
	for i in [10, 5, 2][ql]:                                      # bara beterbangan
		g.fx.spawn(p + Vector2(randf_range(-12, 12), randf_range(-12, 12)), randf_range(.7, 1.3), 3.0, Color(1, .6, .2), Fx.Type.EMBER,
				Vector2(randf_range(-40.0, 40.0), randf_range(-110.0, -50.0)))
	_debris(p, [10, 6, 3][ql], 120.0 if heavy else 85.0, Color(.12, .12, .12))
	_shake(p, 16.0 if heavy else 11.0)
	# ---- turret terlempar (kendaraan lapis baja berturret)
	if heavy:
		var d := Vector2.from_angle(randf() * TAU) * randf_range(100.0, 190.0)
		g.fx.spawn(p, 1.0, 62.0, Color.WHITE, Fx.Type.TURRET, d, v.aim, randf_range(-5.0, 5.0), v.kind, v.team)
		_later(1.0, EvtKind.TURRET_LAND, p + d, 0.0, v.team, v.kind)
		if ql < 2:
			for i in 6:                                                   # jejak asap sepanjang lintasan turret
				var kk := (i + 1) * .13
				_later(kk, EvtKind.TRAIL, p + d * kk + Vector2(0, -sin(PI * kk) * 62.0))
	# ---- ledakan susulan (amunisi terbakar)
	var pops: int = [4 if heavy else 2, 3 if heavy else 1, 1][ql]
	for i in pops:
		var off := Vector2.from_angle(randf() * TAU) * randf_range(0.0, float(Cfg.VEH_RADIUS[v.kind]) * .7)
		_later(.35 + i * randf_range(.3, .5), EvtKind.POP, p + off, float(i), v.team, v.kind)


## Bangkai terbakar: kolom asap hitam naik + semburan api berkala beberapa detik pertama.
func wreck_tick(v: Vehicle, dt: float) -> void:
	v.burn_t += dt
	v.fx_t -= dt
	if v.fx_t > 0.0:
		return
	var ql := g.quality_level
	v.fx_t = [.16, .28, .5][ql]
	g.fx.spawn(v.pos + Vector2(randf_range(-14, 14), randf_range(-14, 14)), 2.6, 24.0, Color(.1, .1, .1, .9), Fx.Type.SMOKE, Vector2(randf_range(-14.0, 14.0), -88.0))     # kolom asap hitam yang naik tinggi
	if v.burn_t < 8.0 and randf() < (.45 if ql < 2 else .3):          # kualitas rendah: tetap ada api, hanya lebih jarang
		var hs: Array = HATCHES[v.kind]
		var h: Vector2 = (hs[randi() % hs.size()] as Vector2).rotated(v.heading) * Cfg.VEH_SCALE
		_flame(v.pos + h, Vector2(randf_range(-.25, .25), -1.0).normalized(), randf_range(36.0, 66.0), randf_range(.5, .9))
		if randf() < .4:
			g.fx.spawn(v.pos + h, randf_range(.7, 1.2), 3.0, Color(1, .6, .2), Fx.Type.EMBER, Vector2(randf_range(-30.0, 30.0), randf_range(-100.0, -45.0)))


## Kendaraan masih hidup tapi rusak parah: berasap (<50% HP), lalu menyala (<25% HP).
func damaged_tick(v: Vehicle, dt: float) -> void:
	var hf := v.hp / v.max_hp
	if hf > .5 or g.quality_level == 2:
		return
	v.fx_t -= dt
	if v.fx_t > 0.0:
		return
	v.fx_t = lerpf(.14, .42, clampf(hf * 2.0, 0.0, 1.0))
	var at := v.pos + Vector2.RIGHT.rotated(v.heading + float(v.kind % 2) * PI) * v.radius() * .3
	g.fx.spawn(at, 1.1, 11.0, Color(.3, .3, .3, .6) if hf > .25 else Color(.14, .14, .14, .75), Fx.Type.SMOKE)
	if hf <= .25 and randf() < .5:
		_flame(at, Vector2(randf_range(-.2, .2), -1.0).normalized(), randf_range(26.0, 44.0), randf_range(.35, .6))


## v14: debu roda/rantai di belakang kendaraan yang melaju (makin cepat makin tebal). Saat BOOST: api knalpot.
func track_dust(v: Vehicle, dt: float) -> void:
	v.dust_t -= dt
	if v.dust_t > 0.0:
		return
	var ql := g.quality_level
	var sp := absf(v.speed)
	if sp < 55.0:
		return
	var k := clampf(sp / float(Cfg.VEH_SPEED[v.kind]), .3, 1.6)
	v.dust_t = [.07, .11, .22][ql] / k
	var sg := signf(v.speed)
	var fwd := Vector2.RIGHT.rotated(v.heading)
	var rear := v.pos - fwd * v.radius() * .85 * sg
	var side := fwd.orthogonal() * v.radius() * .55
	g.fx.spawn(rear + side, .6 + k * .25, 7.0 + v.radius() * .16 * k, _dust, Fx.Type.DUST, -fwd * 22.0 * sg + Vector2(0, -9))
	if ql == 0:
		g.fx.spawn(rear - side, .6 + k * .25, 7.0 + v.radius() * .16 * k, _dust, Fx.Type.DUST, -fwd * 22.0 * sg + Vector2(0, -9))
	if v.boost_t > 0.0 and ql < 2:
		_flame(rear, -fwd * sg, 20.0, .22)


## Awal BOOST: semburan api knalpot + cincin kejut kecil.
func boost_burst(v: Vehicle) -> void:
	var fwd := Vector2.RIGHT.rotated(v.heading)
	var rear := v.pos - fwd * v.radius()
	g.fx.spawn(rear, .35, 54.0, Color(1, .9, .6, .5), Fx.Type.RING)
	_flame(rear, -fwd, 34.0, .4)
	for i in [6, 3, 1][g.quality_level]:
		g.fx.spawn(rear, .4, 5.0, Color(1, .8, .4), Fx.Type.SPARK, -fwd.rotated(randf_range(-.6, .6)) * randf_range(50.0, 100.0))
	_shake(v.pos, 4.0)


## Tirai asap dilepas (kendaraan lapis baja / peluru asap): letusan gumpalan putih di sekitar titik p.
func smoke_screen(p: Vector2) -> void:
	for i in [9, 5, 3][g.quality_level]:
		var d := Vector2.from_angle(randf() * TAU)
		g.fx.spawn(p + d * randf_range(10.0, 60.0), randf_range(1.6, 2.4), randf_range(34.0, 52.0), Color(.88, .88, .9, .75), Fx.Type.SMOKE, d * 26.0 + Vector2(0, -18))
	g.fx.spawn(p, .5, 90.0, Color(1, 1, 1, .4), Fx.Type.RING)


## Kilau hijau kecil di atas prajurit yang sedang disembuhkan MEDEVAC.
func heal_spark(p: Vector2) -> void:
	if g.quality_level == 2:
		return
	g.fx.spawn(p + Vector2(randf_range(-8, 8), -14.0), .5, 7.0, Color(.45, 1, .6, .85), Fx.Type.PUFF)


## Asap tebal dari laras artileri setelah menembak.
func barrel_smoke(mz: Vector2, aim: float) -> void:
	var d := Vector2.from_angle(aim)
	g.fx.spawn(mz + d * 8.0, 1.2, 24.0, Color(.78, .78, .75, .65), Fx.Type.SMOKE, d * 30.0 + Vector2(0, -16))
	if g.quality_level < 2:
		g.fx.spawn(mz, .55, 66.0, Color(1, .9, .7, .45), Fx.Type.RING)


## Jejak asap tipis di belakang peluru lengkung yang terbang.
func shell_trail(p: Vector2, _vel: Vector2) -> void:
	if g.quality_level == 2 or randf() > .5:
		return
	g.fx.spawn(p, .55, 6.0, Color(.92, .92, .9, .5), Fx.Type.PUFF)


## Jejak asap & percikan di belakang roket MLRS (p = posisi roket di udara).
func rocket_trail(p: Vector2) -> void:
	g.fx.spawn(p, .85, 8.0, Color(.9, .9, .88, .55), Fx.Type.PUFF)
	if g.quality_level == 0 and randf() < .5:
		g.fx.spawn(p, .3, 4.0, Color(1, .75, .35), Fx.Type.SPARK, Vector2.from_angle(randf() * TAU) * 26.0)


## Letusan peluncuran roket (api + debu tersembur ke belakang). dir = arah tembak.
func launch_blast(p: Vector2, dir: Vector2) -> void:
	g.fx.spawn(p, .3, 30.0, Color(1, .85, .5), Fx.Type.MUZZLE, dir)
	g.fx.spawn(p, .5, 40.0, _dust, Fx.Type.DUST, -dir * 40.0 + Vector2(0, -8))
	if g.quality_level < 2:
		g.fx.spawn(p - dir * 14.0, 1.4, 22.0, Color(.85, .85, .83, .7), Fx.Type.SMOKE, -dir * 22.0 + Vector2(0, -20))


## Penerjun mendarat: debu + cincin kecil.
func chute_land(p: Vector2) -> void:
	g.fx.spawn(p, .5, 34.0, _dust, Fx.Type.DUST, Vector2(0, -12))
	g.fx.spawn(p, .35, 24.0, Color(1, 1, 1, .35), Fx.Type.RING)


## Cincin debu tiupan mesin pesawat di tanah di bawah C-17.
func plane_wash(p: Vector2, dir: Vector2) -> void:
	g.fx.spawn(p + dir * 20.0 + Vector2(0, 70), .8, 70.0, _dust, Fx.Type.DUST, Vector2(0, -6))


## Peti suplai diambil: kilau hijau naik + cincin.
func crate_pickup(p: Vector2) -> void:
	g.fx.spawn(p, .45, 34.0, Color(.5, 1, .6, .7), Fx.Type.RING)
	for i in [5, 3, 1][g.quality_level]:
		g.fx.spawn(p, .6, 5.0, Color(.55, 1, .65), Fx.Type.SPARK, Vector2(randf_range(-26.0, 26.0), randf_range(-60.0, -30.0)))


## Peluru kena kendaraan: percikan di titik kena (dipanggil Combat).
func vehicle_hit(p: Vector2, dir: Vector2) -> void:
	impact(p, Surf.ARMOR, dir)


# ================================================================ prajurit
## Prajurit tewas karena ledakan: tubuh terlempar menjauhi pusat ledakan. Mengembalikan titik jatuh (untuk mayat).
func body_launch(u: Unit, from: Vector2) -> Vector2:
	var dir := (u.pos - from).normalized()
	if dir == Vector2.ZERO:
		dir = Vector2.from_angle(randf() * TAU)
	var dist := randf_range(28.0, 85.0)
	var land := u.pos + dir * dist
	if g.world.blocked(land, 8.0):
		return u.pos
	if g.quality_level < 2:
		g.fx.spawn(u.pos, .5, 12.0, Cfg.TEAM_COLORS[u.team], Fx.Type.BODY, dir * dist, randf() * TAU, randf_range(-9.0, 9.0))
		_later(.5, EvtKind.DUST_LAND, land)
	return land
