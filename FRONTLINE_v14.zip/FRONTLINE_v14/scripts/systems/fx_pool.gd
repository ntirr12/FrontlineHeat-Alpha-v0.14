class_name FxPool
extends RefCounted
## Kumpulan partikel efek. Objek Fx didaur ulang agar tidak ada alokasi memori saat tempur ramai.
## v13: bila pool terisi >= 75%, efek kecil (debu, percikan, serpihan, bara) dibuang lebih dulu supaya
## efek PENTING (ledakan, api kendaraan, turret terlempar) tidak pernah kehabisan tempat.

var active: Array[Fx] = []
var _free: Array[Fx] = []
var quality := 0                     # 0 tinggi, 1 sedang, 2 rendah (diatur Game)
var cam_pos := Vector2.ZERO          # diperbarui Game tiap frame (untuk membuang efek jauh)
var zoom := 1.0


func spawn(p: Vector2, life: float, radius: float, color: Color, type: int = 0, vel: Vector2 = Vector2.ZERO,
		rot := 0.0, spin := 0.0, aux := 0, aux2 := 0) -> void:
	var cap: int = Cfg.MAX_FX[quality]
	var n := active.size()
	if n >= cap:
		return
	if n * 4 >= cap * 3 and Fx.LOW_PRIORITY[type]:
		return
	var lim: float = Cfg.FX_DIST[quality] / zoom
	if p.distance_squared_to(cam_pos) > lim * lim:
		return
	var f: Fx = _free.pop_back() if not _free.is_empty() else Fx.new()
	f.pos = p
	f.t = 0.0
	f.life = life
	f.radius = radius
	f.color = color
	f.type = type
	f.vel = vel
	f.rot = rot
	f.spin = spin
	f.aux = aux
	f.aux2 = aux2
	active.append(f)


func update(dt: float) -> void:
	var i := 0
	while i < active.size():
		var f := active[i]
		f.t += dt
		if f.t >= f.life:
			_free.append(f)
			active[i] = active[active.size() - 1]     # hapus cepat (tukar dengan elemen terakhir)
			active.pop_back()
		else:
			i += 1


func clear() -> void:
	_free.append_array(active)
	active.clear()
