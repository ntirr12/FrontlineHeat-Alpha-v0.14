class_name PlayerCtl
extends RefCounted
## KONTROL PEMAIN: menerjemahkan input analog/tombol (TouchInput) menjadi gerak, bidik, tembak,
## naik kendaraan, ganti item, lempar, skill. AI memakai kode yang berbeda (AiBrain).

const AIM_TURN_RATE := [999.0, 18.0, 9.0]       # rad/detik untuk CEPAT / SEDANG / LAMBAT

var g: Game
var item := 0                                   # item terpilih (nilai Cfg.Item)
var _assist_target: Entity = null
var _assist_t := 0.0


func _init(game: Game) -> void:
	g = game


func reset_for_class(c: int) -> void:
	item = Cfg.CLASS_ITEMS[c][0]


# ================================================================ per frame
func update(u: Unit, dt: float) -> void:
	var inp := g.input
	if g.player_drone != null:
		return                                   # sedang menerbangkan drone: badan diam
	var aim := inp.aim
	var fire := inp.fire
	# bantuan bidik (arah), tembak otomatis (bila musuh tepat di garis bidik)
	if u.mount != null:
		var src := u.mount.pos
		if aim.length() > .2 and g.prefs.aim_assist > 0:
			aim = Vector2.from_angle(_assist(src, aim.angle(), dt)) * aim.length()
		if u.mount is Vehicle:
			var v := u.mount as Vehicle
			if g.cheat("amo"):
				v.cooldown = 0.0
			g.vehicle_sys.drive(v, inp.move, _fire_vector(aim, fire), dt)
		else:
			var q := u.mount as Turret
			if aim.length() > .2:
				q.aim = lerp_angle(q.aim, aim.angle(), 7.0 * dt)
			if fire:
				g.vehicle_sys.turret_fire(q)
		return
	# ---- berjalan kaki
	var spd: float = Cfg.CLASS_SPEED[u.cls] * (.36 if u.in_cover else 1.0) * (1.8 if g.cheat("spd") else 1.0)
	g.move_unit(u, inp.move * spd * dt)
	if aim.length() > .2:
		var want := _assist(u.pos, aim.angle(), dt)
		u.angle = _turn(u.angle, want, dt)
	elif inp.move.length() > .2:
		u.angle = lerp_angle(u.angle, inp.move.angle(), 10.0 * dt)
	if u.cls == Cfg.Cls.ENGINEER or u.cls == Cfg.Cls.ELITE:
		g.support.repair(u, dt)
	if u.in_cover and not g.world.near_wall(u.pos):
		u.in_cover = false
	if inp.fire_hold_no_aim and aim.length() <= .2:
		fire = true                              # tombol TEMBAK ditekan tanpa digeser: tembak ke arah hadap
	if g.prefs.auto_fire and not fire and aim.length() > .2 and _assist_target != null:
		fire = absf(angle_difference(u.angle, (_assist_target.pos - u.pos).angle())) < .12
	g.infantry.fire(u, fire, dt)


func _fire_vector(aim: Vector2, fire: bool) -> Vector2:
	if fire:
		return aim.normalized() if aim.length() > .01 else Vector2.RIGHT.rotated(g.player.angle)
	return aim.limit_length(.9)                  # < 0.96 supaya tidak menembak


func _turn(cur: float, want: float, dt: float) -> float:
	var rate: float = AIM_TURN_RATE[g.prefs.aim_speed]
	var diff := angle_difference(cur, want)
	return cur + clampf(diff, -rate * dt, rate * dt)


## Bantuan bidik: arahkan sedikit ke musuh terdekat di kerucut bidik.
func _assist(src: Vector2, ang: float, dt: float) -> float:
	if g.prefs.aim_assist == 0:
		_assist_target = null
		return ang
	_assist_t -= dt
	if _assist_t <= 0.0:
		_assist_t = .15
		_assist_target = null
		var cone := .2 if g.prefs.aim_assist == 1 else .38
		var bd := 1e9
		g.grid.query(2, src, 600.0, g.scratch)
		for o: Unit in g.scratch:
			var d := o.pos.distance_to(src)
			if o.hp > 0.0 and o.disguise_t <= 0.0 and d < 600.0 and d < bd and absf(angle_difference(ang, (o.pos - src).angle())) < cone and g.world.los(src, o.pos):
				bd = d
				_assist_target = o
		for v in g.vehicles:
			if v.team != 1 and not v.dead:
				var d := v.pos.distance_to(src)
				if d < 800.0 and d < bd and absf(angle_difference(ang, (v.pos - src).angle())) < cone and g.world.los(src, v.pos):
					bd = d
					_assist_target = v
	if _assist_target == null or not _assist_target.is_alive():
		return ang
	return lerp_angle(ang, (_assist_target.pos - src).angle(), .55 if g.prefs.aim_assist == 1 else .85)


# ================================================================ tombol aksi
## i: 0 GANTI, 1 NAIK/TURUN, 2 COVER, 3 ITEM, 5 RELOAD, 6 SKILL
func action(i: int) -> void:
	var u := g.player
	if u == null:
		return
	match i:
		0:
			if u.mount != null:
				if u.mount is Vehicle and (u.mount as Vehicle).kind > Cfg.Veh.TANK and (u.mount as Vehicle).armed():
					var v := u.mount as Vehicle
					v.weapon = 1 - v.weapon
			else:
				u.weapon = 1 - u.weapon
		1:
			use_vehicle()
		2:
			if u.mount == null:
				u.in_cover = not u.in_cover and g.world.near_wall(u.pos)
		3:
			var list: Array = Cfg.CLASS_ITEMS[u.cls]
			item = list[(list.find(item) + 1) % list.size()]
		5:
			if u.mount == null:
				u.ammo = 0
		6:
			if u.mount is Vehicle:
				g.vehicle_sys.vehicle_skill(u.mount as Vehicle)      # v14: skill kendaraan (BOOST / TIRAI ASAP)
			else:
				g.support.use_skill(u)


## NAIK / TURUN / SABOTASE / DRONE / BATAL drone, tergantung konteks.
func use_vehicle() -> void:
	if g.player_drone != null:
		g.player_drone = null
		return
	var u := g.player
	if u == null or u.cls == Cfg.Cls.JUGGERNAUT:
		return
	if u.cls == Cfg.Cls.SPY:
		var sx := g.infantry.sabotage_target(u)
		if sx != null:
			u.sabotage_target = sx
			u.sabotage_t = .01
			return
	if u.mount != null:
		g.vehicle_sys.dismount(u)
		return
	var p := g.vehicle_sys.find_boardable(u)
	if p != null:
		g.vehicle_sys.board(u, p)
		return
	for s in g.structs:
		if s.kind == Cfg.Item.DRONE_ST and s.team == 1 and s.timer <= 0.0 and s.pos.distance_to(u.pos) < 85.0:
			s.timer = 25.0
			g.support.spawn_player_drone(s)
			return


## Teks tombol NAIK sesuai konteks ("" = tidak ada aksi).
func vehicle_prompt() -> String:
	var u := g.player
	if u == null or u.cls == Cfg.Cls.JUGGERNAUT:
		return ""
	if g.player_drone != null:
		return "BATAL"
	if u.mount != null:
		return "TURUN"
	if g.vehicle_sys.find_boardable(u) != null:
		return "NAIK"
	for s in g.structs:
		if s.kind == Cfg.Item.DRONE_ST and s.team == 1 and s.timer <= 0.0 and s.pos.distance_to(u.pos) < 85.0:
			return "DRONE"
	if u.cls == Cfg.Cls.SPY and g.infantry.sabotage_target(u) != null:
		return "SABOTASE"
	return ""


## Tombol LEMPAR dilepas: gunakan item terpilih ke titik bidik.
func release_throw(throw_vec: Vector2) -> void:
	var u := g.player
	if u == null or u.mount != null:
		return
	var dir := throw_vec if throw_vec.length() > .2 else Vector2.RIGHT.rotated(u.angle) * .5
	var dest := u.pos + dir * float(Cfg.ITEM_RANGE[item])
	g.support.use_item(u, item, dest, dir)


## Vektor bidik lemparan (dipakai HUD untuk menggambar lintasan).
func throw_destination(throw_vec: Vector2) -> Vector2:
	var u := g.player
	var dir := throw_vec if throw_vec.length() > .2 else Vector2.RIGHT.rotated(u.angle) * .5
	return u.pos + dir * float(Cfg.ITEM_RANGE[item])
