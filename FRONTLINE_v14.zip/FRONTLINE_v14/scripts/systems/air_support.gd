class_name AirSupport
extends RefCounted
## BANTUAN UDARA & ARTILERI JARAK JAUH (v14). Tiga fitur, semuanya dipanggil lewat RADIO (menara radio / Elite):
##
##   1. BANTUAN TERJUN (RADIO: TERJUN C-17)
##      Pesawat C-17 melintas lewat titik sasaran, menerjunkan satu regu (Cfg.PARADROP_COUNT) + peti medis.
##      Penerjun melayang turun dengan kanopi lalu menjadi prajurit AI sekutu (gratis, tidak memakai tiket).
##      Director juga memakainya untuk bantuan pasukan kedua tim (lihat director.gd).
##   2. MLRS (RADIO: MLRS)
##      Dibidik persis seperti airstrike (geser tombol LEMPAR, lepas). Sebuah peluncur (HIMARS / Uragan) tiba di luar layar,
##      bersiap beberapa detik, lalu menembakkan salvo roket yang meluncur melengkung dan menghantam area sasaran.
##   3. PETI SUPLAI
##      Dari C-17, DROP: SUPLAI, atau MEDEVAC hancur. Prajurit sekutu yang menyentuhnya pulih HP-nya dan diisi ulang.
##
## Semua daftar benda (airlifts, chutes, crates, salvos, rockets) disimpan di Game; kelas datanya ada di entities/battle_objects.gd.
## Tampilan ada di render/air_view.gd. Angka keseimbangan ada di Cfg (cari "PARADROP", "MLRS", "CRATE").

var g: Game
var _batch_left: Dictionary = {}       # id regu terjun -> jumlah penerjun yang masih di udara
var _batch_open: Dictionary = {}       # id regu terjun -> sudah ada yang mendarat?
var _next_batch := 1
var _near: Array = []
var landed := 0                        # total penerjun yang sudah mendarat (statistik; dipakai tes)


func _init(game: Game) -> void:
	g = game


func reset() -> void:
	_batch_left.clear()
	_batch_open.clear()
	_next_batch = 1
	landed = 0


## Dipanggil Game.sim() sekali per frame.
func update(dt: float) -> void:
	if not g.airlifts.is_empty():
		_update_airlifts(dt)
	if not g.chutes.is_empty():
		_update_chutes(dt)
	if not g.salvos.is_empty():
		_update_salvos(dt)
	if not g.rockets.is_empty():
		_update_rockets(dt)
	if not g.crates.is_empty():
		_update_crates(dt)


# ================================================================ 1. BANTUAN TERJUN (C-17)
## dz = titik terjun. Pesawat terbang lurus ke arah wilayah lawan (tim 1 ke kanan, tim 2 ke kiri).
func call_airlift(dz: Vector2, team: int, by_player: bool, troops := Cfg.PARADROP_COUNT, crates := Cfg.PARADROP_CRATES) -> void:
	var a := BO.Airlift.new()
	a.dz = dz
	a.team = team
	a.by_player = by_player
	a.troops = troops
	a.total = troops
	a.crates = crates
	a.dir = Vector2.RIGHT if team == 1 else Vector2.LEFT
	a.pos = Vector2(dz.x - a.dir.x * Cfg.PARADROP_LEAD, dz.y)
	a.life = (Cfg.PARADROP_LEAD * 2.0 + 400.0) / Cfg.PARADROP_PLANE_SPEED
	a.batch = _next_batch
	_next_batch += 1
	_batch_left[a.batch] = 0
	_batch_open[a.batch] = false
	g.airlifts.append(a)
	g.sfx(11, dz)


func _update_airlifts(dt: float) -> void:
	var i := 0
	while i < g.airlifts.size():
		var a := g.airlifts[i]
		a.pos += a.dir * Cfg.PARADROP_PLANE_SPEED * dt
		a.life -= dt
		var along := (a.pos - a.dz).dot(a.dir)
		if not a.passed and along >= -float(a.total) * Cfg.PARADROP_JUMP_GAP * Cfg.PARADROP_PLANE_SPEED * .5:
			a.passed = true                              # penerjun keluar mengapit titik sasaran
		if a.passed and (a.troops > 0 or a.crates > 0):
			a.jump_t -= dt
			if a.jump_t <= 0.0:
				a.jump_t = Cfg.PARADROP_JUMP_GAP
				_release(a)
		if along > Cfg.PARADROP_LEAD or a.life <= 0.0:
			if a.troops > 0 and _batch_left.get(a.batch, 0) <= 0:
				_batch_left.erase(a.batch)
			g.airlifts[i] = g.airlifts[g.airlifts.size() - 1]
			g.airlifts.pop_back()
		else:
			i += 1
	# bunyi baling-baling/mesin & debu tiupan di bawah pesawat dekat kamera
	if g.quality_level < 2 and g.frame % 6 == 0:
		for a in g.airlifts:
			if a.pos.distance_squared_to(g.cam) < 1000000.0:
				g.vfx.plane_wash(a.pos, a.dir)


func _release(a: BO.Airlift) -> void:
	var c := BO.Chute.new()
	c.start = a.pos
	c.team = a.team
	c.fall = randf_range(Cfg.PARADROP_FALL.x, Cfg.PARADROP_FALL.y)
	c.phase = randf() * TAU
	c.batch = a.batch
	if a.troops > 0:
		a.troops -= 1
		c.pos = _landing_spot(a.dz)
		_batch_left[a.batch] = _batch_left.get(a.batch, 0) + 1
	else:
		a.crates -= 1
		c.crate = true
		c.pos = _landing_spot(a.dz) * .35 + a.dz * .65      # peti jatuh lebih dekat ke pusat
		c.fall *= .9
	g.chutes.append(c)


## Titik mendarat yang tidak terhalang (coba beberapa kali, terakhir pakai titik pusat).
func _landing_spot(dz: Vector2) -> Vector2:
	for k in 6:
		var p := dz + Vector2.from_angle(randf() * TAU) * randf_range(0.0, Cfg.PARADROP_SPREAD)
		p = Vector2(clampf(p.x, 60.0, Cfg.MAP_W - 60.0), clampf(p.y, 60.0, Cfg.MAP_H - 60.0))
		if not g.world.blocked(p, 14.0):
			return p
	return Vector2(clampf(dz.x, 60.0, Cfg.MAP_W - 60.0), clampf(dz.y, 60.0, Cfg.MAP_H - 60.0))


func _update_chutes(dt: float) -> void:
	var i := 0
	while i < g.chutes.size():
		var c := g.chutes[i]
		c.t += dt
		if c.t >= c.fall:
			_land_chute(c)
			g.chutes[i] = g.chutes[g.chutes.size() - 1]
			g.chutes.pop_back()
		else:
			i += 1


func _land_chute(c: BO.Chute) -> void:
	g.vfx.chute_land(c.pos)
	if c.crate:
		spawn_crate(c.pos, c.team, 0)
		return
	# prajurit pertama dari rombongan membuka regu baru; sisanya mengisi regu itu (maks SQUAD_SIZE per regu)
	if not _batch_open.get(c.batch, false):
		_batch_open[c.batch] = true
		g.planner.close_open(c.team)
	var u := g.spawn_ai(c.team, c.pos)
	landed += 1
	var left: int = _batch_left.get(c.batch, 1) - 1
	_batch_left[c.batch] = left
	if left <= 0:
		g.planner.close_open(c.team)
		_batch_left.erase(c.batch)
		_batch_open.erase(c.batch)


# ================================================================ 2. MLRS
## target = pusat area hantaman. Peluncur muncul MLRS_STANDOFF px di belakang target (ke arah markas sendiri).
func call_mlrs(target: Vector2, team: int, by_player: bool, ambient := false, count := Cfg.MLRS_ROCKETS) -> void:
	var s := BO.Salvo.new()
	s.pos = target
	s.team = team
	s.by_player = by_player
	s.ambient = ambient
	s.count = count
	s.radius = Cfg.MLRS_RADIUS
	var back := (Objectives.base_pos(team) - target)
	if back.length() < 10.0:
		back = Vector2.LEFT if team == 1 else Vector2.RIGHT
	back = back.normalized()
	var o := target + back * Cfg.MLRS_STANDOFF
	o = Vector2(clampf(o.x, 160.0, Cfg.MAP_W - 160.0), clampf(o.y, 160.0, Cfg.MAP_H - 160.0))
	for k in 8:                                              # geser bila di dalam bangunan
		if not g.world.blocked(o, 48.0):
			break
		o += Vector2.from_angle(randf() * TAU) * 90.0
		o = Vector2(clampf(o.x, 160.0, Cfg.MAP_W - 160.0), clampf(o.y, 160.0, Cfg.MAP_H - 160.0))
	if o.distance_to(target) < 450.0:                        # terlalu dekat: roket tidak sempat "terbang"
		o = target + back * 450.0
		o = Vector2(clampf(o.x, 160.0, Cfg.MAP_W - 160.0), clampf(o.y, 160.0, Cfg.MAP_H - 160.0))
	s.origin = o
	s.dir = (target - o).normalized() if target.distance_to(o) > 1.0 else Vector2.RIGHT
	g.salvos.append(s)
	g.support.add_alert(target, s.radius + Cfg.DANGER_FLEE_PAD, Cfg.MLRS_WARMUP + float(count) * Cfg.MLRS_FIRE_GAP + 2.5, team)
	if ambient:
		g.sfx(12, target)


func _update_salvos(dt: float) -> void:
	var i := 0
	while i < g.salvos.size():
		var s := g.salvos[i]
		s.t += dt
		var want := 0
		if s.t >= Cfg.MLRS_WARMUP:
			want = 1 + int((s.t - Cfg.MLRS_WARMUP) / Cfg.MLRS_FIRE_GAP)
		while s.fired < mini(want, s.count):
			_launch(s)
			s.fired += 1
		if s.t > Cfg.MLRS_WARMUP + float(s.count) * Cfg.MLRS_FIRE_GAP + 2.2:      # peluncur sudah pergi
			g.salvos[i] = g.salvos[g.salvos.size() - 1]
			g.salvos.pop_back()
		else:
			i += 1


func _launch(s: BO.Salvo) -> void:
	var r := BO.Rocket.new()
	var perp := s.dir.orthogonal()
	r.team = s.team
	r.by_player = s.by_player
	r.from = s.origin + s.dir * 44.0 + perp * randf_range(-16.0, 16.0)
	# sebaran oval: memanjang searah tembakan, agak sempit ke samping (pola salvo MLRS)
	var u := Vector2.from_angle(randf() * TAU) * sqrt(randf())
	r.to = s.pos + s.dir * u.x * s.radius * 1.15 + perp * u.y * s.radius * .85
	var dist := r.from.distance_to(r.to)
	r.flight = clampf(dist / Cfg.MLRS_SPEED, 1.2, 3.6)
	r.arc = clampf(dist * .17, 55.0, 250.0)
	g.rockets.append(r)
	g.vfx.launch_blast(r.from, s.dir)
	g.sfx(2, r.from)                                         # desis roket meluncur


func _update_rockets(dt: float) -> void:
	var i := 0
	while i < g.rockets.size():
		var r := g.rockets[i]
		r.t += dt
		var k := minf(r.t / r.flight, 1.0)
		r.trail_t -= dt
		if r.trail_t <= 0.0:
			r.trail_t = .05
			g.vfx.rocket_trail(rocket_air_pos(r))
		if not r.whistled and r.flight - r.t < .7:
			r.whistled = true
			g.sfx(12, r.to)                                  # desing sebelum jatuh
		if k >= 1.0:
			g.combat.explode(r.to, Cfg.MLRS_ROCKET_RADIUS, Cfg.MLRS_ROCKET_DMG, r.team, r.by_player)
			g.rockets[i] = g.rockets[g.rockets.size() - 1]
			g.rockets.pop_back()
		else:
			i += 1


## Posisi roket (layar-dunia) di udara: titik di tanah + lengkung ke atas.
static func rocket_ground_pos(r: BO.Rocket) -> Vector2:
	return r.from.lerp(r.to, clampf(r.t / r.flight, 0.0, 1.0))


static func rocket_air_pos(r: BO.Rocket) -> Vector2:
	var k := clampf(r.t / r.flight, 0.0, 1.0)
	return r.from.lerp(r.to, k) + Vector2(0, -sin(PI * k) * r.arc)


# ================================================================ 3. PETI SUPLAI
## kind: 0 medis (salib hijau), 1 amunisi. fall > 0 = masih jatuh dari udara (belum bisa diambil).
func spawn_crate(p: Vector2, team: int, kind: int, fall := 0.0) -> void:
	if g.crates.size() >= 24:
		g.crates.pop_front()
	var c := BO.Crate.new()
	c.pos = p
	c.team = team
	c.kind = kind
	c.drop_t = fall
	g.crates.append(c)


func _update_crates(dt: float) -> void:
	var i := 0
	var r2: float = Cfg.CRATE_PICKUP_R * Cfg.CRATE_PICKUP_R
	while i < g.crates.size():
		var c := g.crates[i]
		c.t += dt
		var used := false
		if c.drop_t > 0.0:
			c.drop_t -= dt
		elif c.team >= 1 and c.team <= 2:
			g.grid.query(c.team, c.pos, Cfg.CRATE_PICKUP_R + 6.0, _near)
			for u: Unit in _near:
				if u.hp > 0.0 and u.mount == null and u.pos.distance_squared_to(c.pos) < r2 and _can_use(u):
					_use(u, c)
					used = true
					break
		if used or c.t > Cfg.CRATE_LIFE:
			g.crates[i] = g.crates[g.crates.size() - 1]
			g.crates.pop_back()
		else:
			i += 1


## Peti hanya dipakai prajurit yang memang membutuhkannya (agar tidak terbuang oleh yang sudah penuh).
func _can_use(u: Unit) -> bool:
	return u.hp < u.max_hp * .97 or u.grenades[0] < 2 or (u.javelin_max > 0 and u.javelin < u.javelin_max)


func _use(u: Unit, c: BO.Crate) -> void:
	u.hp = minf(u.max_hp, u.hp + u.max_hp * Cfg.CRATE_HEAL)
	u.grenades[0] = mini(u.grenades[0] + Cfg.CRATE_GRENADES, 6)
	u.javelin = u.javelin_max
	u.m203 = 4
	if u.c4 > 0:
		u.c4 = mini(u.c4 + 1, 4)
	if u.cls == Cfg.Cls.ENGINEER or u.cls == Cfg.Cls.ELITE:
		u.build_points += Cfg.CRATE_BUILD_POINTS
	g.vfx.crate_pickup(c.pos)
	if not u.is_ai:
		g.say("PETI SUPLAI: HP PULIH, AMUNISI DIISI ULANG", 2.2)
		g.ui_sfx(4)
