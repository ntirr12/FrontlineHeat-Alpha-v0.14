class_name SpatialGrid
extends RefCounted
## Grid spasial prajurit (sel 96 px), dipisah per tim.
## Dibangun ulang tiap frame (murah). Dipakai untuk:
##  - tabrakan peluru (hanya cek prajurit di sel sekitar peluru)
##  - AI mencari musuh (hanya cek sel di sekitar AI, bukan semua prajurit)

const CELL := 96.0
const STRIDE := 128
const EMPTY := []                          # dipakai bersama untuk sel kosong (tidak mengalokasi array baru; JANGAN diubah isinya)

var _cells: Array = [{}, {}, {}]          # indeks tim -> {kunci sel: Array[Unit]}
var _touched: Array = [[], [], []]        # kunci sel yang terisi frame ini (untuk dibersihkan cepat)


func rebuild(units: Array[Unit]) -> void:
	for t in [1, 2]:
		var cells: Dictionary = _cells[t]
		for k in _touched[t]:
			(cells[k] as Array).clear()      # array dipakai ulang, tidak dialokasi lagi
		(_touched[t] as Array).clear()
	for u in units:
		if u.hp <= 0.0 or u.mount != null:
			continue
		var cells: Dictionary = _cells[u.team]
		var k := int(u.pos.x / CELL) + int(u.pos.y / CELL) * STRIDE
		var arr: Array
		if cells.has(k):
			arr = cells[k]
		else:
			arr = []
			cells[k] = arr
		if arr.is_empty():
			(_touched[u.team] as Array).append(k)
		arr.append(u)


## Isi `out` dengan prajurit tim `team` yang berada di sel-sel dalam radius dari `center`.
## (Granularitas sel: hasil bisa sedikit melebihi radius; periksa jarak sendiri.)
func query(team: int, center: Vector2, radius: float, out: Array) -> void:
	out.clear()
	var cells: Dictionary = _cells[team]
	var x0 := int((center.x - radius) / CELL)
	var x1 := int((center.x + radius) / CELL)
	var y0 := int((center.y - radius) / CELL)
	var y1 := int((center.y + radius) / CELL)
	for gx in range(maxi(x0, 0), x1 + 1):
		for gy in range(maxi(y0, 0), y1 + 1):
			var k := gx + gy * STRIDE
			if cells.has(k):
				var arr: Array = cells[k]
				if not arr.is_empty():
					out.append_array(arr)


## Ambil isi satu sel (untuk tabrakan peluru). Mengembalikan array kosong bila tidak ada.
func cell(team: int, gx: int, gy: int) -> Array:
	var k := gx + gy * STRIDE
	var cells: Dictionary = _cells[team]
	return cells[k] if cells.has(k) else EMPTY
