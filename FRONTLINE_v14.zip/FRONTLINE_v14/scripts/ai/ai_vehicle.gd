class_name AiVehicle
extends RefCounted
## AI untuk prajurit yang sedang menumpang: pengemudi kendaraan (seat 0), penembak (seat 1, otomatis),
## dan operator turret. Navigasi memakai grid kendaraan (lebih "gemuk") dari AiNav.

var g: Game


func _init(game: Game) -> void:
	g = game


## Persepsi dari posisi kendaraan (pos prajurit selalu disamakan dengan kendaraannya).
func think(u: Unit) -> void:
	g.brain.perceive(u)


func act(u: Unit, dt: float) -> void:
	u.aim_point = Vector2.INF
	var m := u.mount
	if m is Turret:
		_act_turret(u, m as Turret, dt)
	elif m is Vehicle and u.seat == 0:
		_act_drive(u, m as Vehicle, dt)


# ---- operator turret
func _act_turret(u: Unit, q: Turret, dt: float) -> void:
	u.angle = q.aim
	var tg := u.target
	if tg != null and tg.is_alive():
		u.turret_idle_t = 0.0
		var aim_at := tg.pos if u.can_see else u.last_known
		var ang := (aim_at - q.pos).angle()
		q.aim = lerp_angle(q.aim, ang, 5.0 * dt)
		if u.can_see and absf(angle_difference(q.aim, ang)) < .12 and q.pos.distance_squared_to(tg.pos) < 518400.0 \
				and g.world.los(q.pos, tg.pos):
			u.aim_point = tg.pos
			g.vehicle_sys.turret_fire(q)
	else:
		u.turret_idle_t += dt
		if u.turret_idle_t > 15.0:                 # lama tak ada musuh: turun, kembali bertempur sebagai infanteri
			g.vehicle_sys.vacate(u)
			u.board_cd = 45.0
			u.turret_idle_t = 0.0
			return
		q.aim += sin(g.time * .6 + q.pos.y) * .5 * dt


# ---- pengemudi
## Jarak berhenti & jarak mulai MUNDUR menjaga jarak (per jenis kendaraan). Tank menjaga jarak, tidak menyeruduk sasaran.
const STOP_DIST := [230.0, 400.0, 400.0, 400.0, 420.0, 330.0, 560.0, 520.0]     # v14: + APC, SPG, MEDEVAC (jaga jarak dari musuh)
const BACK_DIST := [120.0, 250.0, 240.0, 220.0, 260.0, 160.0, 330.0, 360.0]
const ENGAGE_DIST := [700.0, 700.0, 700.0, 700.0, 700.0, 700.0, 1050.0, 0.0]     # jarak mulai menembak (SPG jauh, MEDEVAC tidak menembak)


func _act_drive(u: Unit, v: Vehicle, dt: float) -> void:
	u.angle = v.aim                                 # awak melihat ke arah laras (dulu sudut ini tidak pernah diperbarui)
	var goal := u.goal if u.goal != Vector2.ZERO else Objectives.base_pos(3 - u.team)
	var aimv := Vector2.ZERO
	var stop := false
	var back := false
	var tg := u.target
	if tg != null and tg.is_alive():
		var tp := tg.pos if u.can_see else u.last_known
		goal = tp
		var d := tp.distance_to(v.pos)
		var ang := (tp - v.pos).angle()
		if v.kind > Cfg.Veh.TANK:                  # pilih senjata sesuai jenis target
			var vs_vehicle := tg is Vehicle
			if v.kind == Cfg.Veh.HUMVEE_AT:
				v.weapon = 0 if vs_vehicle else 1
			elif v.kind == Cfg.Veh.BRADLEY:
				v.weapon = 1 if vs_vehicle else 0
			else:
				v.weapon = 0                       # APC/SPG: senjata ke-2 = peluru asap (hanya untuk pemain)
		if d < float(STOP_DIST[v.kind]):
			stop = true
		if d < float(BACK_DIST[v.kind]) and u.can_see and u.side_t <= 0.0:
			back = true                             # terlalu dekat: mundur sambil terus membidik
			stop = false
		if d < float(ENGAGE_DIST[v.kind]) and u.can_see:
			var ok := absf(angle_difference(v.aim, ang)) < .1 and (g.world.los(v.pos, tp) or v.kind == Cfg.Veh.SPG)
			aimv = Vector2.RIGHT.rotated(ang) * (1.0 if ok else .6)
			u.aim_point = tp
	elif v.pos.distance_squared_to(goal) < 12100.0:
		stop = true                                 # sudah di tujuan: berhenti & menyapu torret
		v.aim += sin(g.time * .5 + v.pos.x) * .4 * dt
	_ai_skill(u, v, tg, goal)
	_check_stuck(u, v, dt, stop)
	var wp := g.ai_nav.next_waypoint(u, goal, dt, true, v.radius() * .85)
	var dir := (wp - v.pos).normalized()
	if u.side_t > 0.0:
		u.side_t -= dt
		dir = dir.rotated(-2.4)                    # putar balik bila terjebak
	g.vehicle_sys.drive(v, Vector2.ZERO if (stop or back) else dir, aimv, dt, back)


## v14: AI memakai skill kendaraan. Lapis baja yang terluka melepas tirai asap; kendaraan ringan boost saat jauh dari tujuan.
func _ai_skill(u: Unit, v: Vehicle, tg: Entity, goal: Vector2) -> void:
	if v.skill_cd > 0.0 or randf() > .06:                            # cek acak ~2x/dtk supaya AI tidak langsung memakai skill di frame yang sama
		return
	if Cfg.VEH_SKILL_BOOST[v.kind]:
		if tg == null and v.pos.distance_squared_to(goal) > 640000.0 and absf(v.speed) > 40.0:
			g.vehicle_sys.vehicle_skill(v)
	elif tg != null and u.can_see and v.hp < v.max_hp * .45:
		g.vehicle_sys.vehicle_skill(v)


func _check_stuck(u: Unit, v: Vehicle, dt: float, stop: bool) -> void:
	u.stuck_timer += dt
	if u.stuck_timer <= 1.0:
		return
	u.stuck_timer = 0.0
	if v.pos.distance_squared_to(u.last_pos) < 484.0 and not stop:
		u.stuck_count += 1
		u.path_refresh = 0.0
		u.direct_t = 0.0
		if u.stuck_count >= 2:
			u.side_t = 1.2
		if u.stuck_count >= 10:
			_recall(u, v)
	else:
		u.stuck_count = maxi(0, u.stuck_count - 1)
	u.last_pos = v.pos


## Kendaraan macet lama: kembalikan ke markas (di luar pandangan pemain, atau bila sudah sangat lama).
func _recall(u: Unit, v: Vehicle) -> void:
	var shown := g.player != null and v.pos.distance_squared_to(g.player.pos) < 640000.0
	if u.stuck_count >= 24 or not shown:
		v.pos = v.home
		v.speed = 0.0
		u.pos = v.pos
		u.last_pos = v.pos
		u.stuck_count = 0
		u.side_t = 0.0
		u.path_i = 0
		u.path = PackedVector2Array()
