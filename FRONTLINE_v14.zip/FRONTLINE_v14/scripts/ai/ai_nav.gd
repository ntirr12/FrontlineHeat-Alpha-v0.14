class_name AiNav
extends RefCounted
## NAVIGASI AI: berjalan ke tujuan memakai jalur A* yang di-cache, dilicinkan, dan anti-macet.
## Dipakai prajurit (walk) dan pengemudi kendaraan (next_waypoint dengan vehicle = true).
## Biaya dijaga kecil: jalur dihitung ulang hanya bila perlu, dan ada anggaran A* per frame.

var g: Game
var budget := 3            # sisa permintaan A* pada frame ini (di-reset Game tiap frame)


func _init(game: Game) -> void:
	g = game


## Titik berikutnya yang harus dituju unit: langsung ke tujuan bila terlihat, kalau tidak ikuti jalur A*.
func next_waypoint(u: Unit, goal: Vector2, dt: float, vehicle: bool, radius: float) -> Vector2:
	var p := u.pos
	u.direct_t -= dt
	var tick := false
	if u.direct_t <= 0.0:
		tick = true
		u.direct_t = .25 + randf() * .1
		u.direct_ok = p.distance_squared_to(goal) < 250000.0 and g.world.walkable(p, goal, radius)
	if u.direct_ok:
		if u.path.size() > 0:
			u.path = PackedVector2Array()
		return goal
	u.path_refresh -= dt
	if u.path.size() == 0 or u.path_goal.distance_squared_to(goal) > 6400.0 or u.path_refresh <= 0.0:
		if budget > 0:
			budget -= 1
			u.path_goal = goal
			u.path_i = 0
			var t0 := Time.get_ticks_usec() if g.profile_on else 0
			u.path = g.world.find_path(p, goal, vehicle)
			if g.profile_on:
				g._p("  astar", t0)
				g.prof["  astar_calls"] = [g.prof.get("  astar_calls", [0, 0])[0] + 1, 0]
			u.path_refresh = 2.5 + randf() * 1.5
		elif u.path.size() == 0:
			return goal
	var n := u.path.size()
	if n == 0:
		return goal
	while u.path_i < n - 1 and p.distance_squared_to(u.path[u.path_i]) < 576.0:
		u.path_i += 1
	if tick:                                   # pemotongan jalur: lompat ke titik terjauh yang masih terlihat
		for j in range(mini(n - 1, u.path_i + 6), u.path_i, -1):
			if g.world.walkable(p, u.path[j], radius):
				u.path_i = j
				break
	if u.path_i >= n - 1 and p.distance_squared_to(u.path[n - 1]) < 576.0:
		return goal
	return u.path[u.path_i]


## Prajurit berjalan ke `goal` dengan kecepatan = fraksi speed_frac dari kecepatan divisinya.
func walk(u: Unit, goal: Vector2, speed_frac: float, dt: float, face_move := true) -> void:
	var d := goal - u.pos
	if d.length_squared() < 576.0:
		u.stuck_count = 0
		return
	_check_stuck(u, dt)
	var wp := next_waypoint(u, goal, dt, false, 11.0)
	var dir := (wp - u.pos).normalized()
	if u.side_t > 0.0:                         # sedang menyamping untuk lepas dari macet
		u.side_t -= dt
		dir = dir.rotated(1.2 * u.side_sign)
	if u.sep != Vector2.ZERO:
		dir = (dir + u.sep).normalized()
	if face_move:
		u.angle = lerp_angle(u.angle, dir.angle(), 10.0 * dt)
	var spd: float = Cfg.CLASS_SPEED[u.cls] * speed_frac * (.4 if u.in_cover else 1.0)
	g.move_unit(u, dir * spd * dt)


## Bergerak lurus tanpa A* (menyamping, mundur, kabur dari bahaya).
func step(u: Unit, dir: Vector2, speed_frac: float, dt: float) -> void:
	if dir == Vector2.ZERO:
		return
	g.move_unit(u, dir.normalized() * Cfg.CLASS_SPEED[u.cls] * speed_frac * dt)


func _check_stuck(u: Unit, dt: float) -> void:
	u.stuck_timer += dt
	if u.stuck_timer <= .7:
		return
	u.stuck_timer = 0.0
	if u.pos.distance_squared_to(u.last_pos) < 144.0:
		u.stuck_count += 1
		u.path_refresh = 0.0
		u.direct_t = 0.0
		if u.stuck_count >= 2:
			u.side_t = .6
			u.side_sign = 1.0 if randf() < .5 else -1.0
		if u.stuck_count >= 14:
			unstick(u)
	else:
		u.stuck_count = maxi(0, u.stuck_count - 1)
	u.last_pos = u.pos


## Macet lama: pindahkan ke titik spawn depan (di luar pandangan pemain, atau bila sudah sangat lama).
func unstick(u: Unit) -> void:
	var shown := g.player != null and u.pos.distance_squared_to(g.player.pos) < 490000.0
	if u.stuck_count >= 30 or not shown:
		var q := g.objectives.spawn_point(u.team)
		u.pos = q
		u.last_pos = q
		u.stuck_count = 0
		u.side_t = 0.0
		u.path_i = 0
		u.path = PackedVector2Array()


## Dorongan menjauh dari rekan yang terlalu rapat (dihitung berkala, bukan tiap frame).
func update_separation(u: Unit) -> void:
	var push := Vector2.ZERO
	var n := 0
	g.grid.query(u.team, u.pos, 40.0, g.scratch)
	for o: Unit in g.scratch:
		if o == u:
			continue
		var d := u.pos - o.pos
		var l := d.length()
		if l < 30.0:
			push += d / maxf(l, 1.0) * (30.0 - l) / 30.0
			n += 1
			if n >= 4:
				break
	u.sep = push * .8
