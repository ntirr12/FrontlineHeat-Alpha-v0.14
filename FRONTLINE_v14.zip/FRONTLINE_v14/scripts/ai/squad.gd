class_name Squad
extends RefCounted
## Regu AI (maks Cfg.SQUAD_SIZE orang). Seluruh anggota bergerak ke satu tujuan
## yang sama dan saling menjaga jarak (formasi), sehingga terlihat seperti pasukan sungguhan
## dan hemat CPU: hanya pemimpin yang meminta jalur A*, anggota mengikuti.

var team := 1
var members: Array[Unit] = []
var leader: Unit = null
var flag_goal := -1                # indeks bendera tujuan; -1 = markas musuh
var goal := Vector2.ZERO
var path := PackedVector2Array()   # jalur milik pemimpin (dibagi ke anggota)
var path_goal := Vector2.ZERO
var path_age := 0.0
var closed := false                # true = sudah penuh/berangkat, tidak menerima anggota baru
var solo := false                  # regu tunggal pengemudi kendaraan (tidak digabung)
var defender := false              # true = regu penjaga bendera sendiri
var holding := false               # tujuan sekarang adalah bendera milik sendiri
var age := 0.0
var lag := 0.0                     # rata-rata jarak anggota yang sedang maju ke pemimpin (dihitung perencana)
var bound_period := 2.6            # lama satu "lompatan": separuh regu maju, separuh menahan & menembak
var bound_off := 0.0               # geser fase agar regu-regu tidak serempak
var flanker: Unit = null           # anggota yang sedang mengitari musuh (satu per regu)
var flank_ready_at := 0.0          # waktu game paling cepat manuver mengitari berikutnya


func _init() -> void:
	bound_period = randf_range(Cfg.AI_BOUND_PERIOD.x, Cfg.AI_BOUND_PERIOD.y)
	bound_off = randf() * 2.0


func prune() -> void:
	var alive: Array[Unit] = []
	for m in members:
		if m.hp > 0.0 and m.squad == self:
			alive.append(m)
	members = alive
	if leader == null or leader.hp <= 0.0 or leader.squad != self:
		leader = members[0] if not members.is_empty() else null


## Hitung rata-rata ketertinggalan anggota (hanya yang sedang berjalan maju, bukan yang bertempur).
func update_lag() -> void:
	var sum := 0.0
	var n := 0
	if leader != null:
		for m in members:
			if m != leader and m.mount == null and m.state == AiBrain.State.ADVANCE:
				sum += m.pos.distance_to(leader.pos)
				n += 1
	lag = sum / n if n > 0 else 0.0


func add(u: Unit) -> void:
	members.append(u)
	u.squad = self
	if leader == null:
		leader = u


func size() -> int:
	return members.size()


## Posisi formasi anggota ke-k: BAJI di belakang pemimpin, mengikuti arah hadap pemimpin
## (bukan cincin acak), jadi regu terlihat berbaris/menyebar seperti pasukan sungguhan.
func slot_offset(u: Unit) -> Vector2:
	var k := members.find(u)
	if k < 0:
		return Vector2.ZERO
	var fwd := Vector2.RIGHT.rotated(leader.angle) if leader != null else Vector2.RIGHT
	var side := fwd.orthogonal()
	var sgn := 1.0 if k % 2 == 1 else -1.0
	var rank := float(floori((k + 1) * 0.5))      # 1,1,2,2,...
	var s := Cfg.SQUAD_SPREAD / 70.0
	return (-fwd * (40.0 * rank + 8.0) + side * sgn * (38.0 * rank + 5.0 * float(k % 3))) * s
