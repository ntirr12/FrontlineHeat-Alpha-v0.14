class_name AiPlanner
extends RefCounted
## PERENCANA TIM: membentuk regu dan membagi mereka ke bendera.
## Aturan ringkas (tiap AI_PLAN_INTERVAL detik, per tim):
##  - Regu penyerang menuju bendera yang belum dikuasai (atau markas musuh bila hampir semua bendera kita).
##  - Regu penjaga menjaga bendera milik sendiri; makin banyak bila bendera itu sedang diserbu.
##  - Bendera yang sedang direbut musuh mendapat bantuan dari regu terdekat.
##  - Wilayah dekat pemain sedikit diutamakan agar selalu ada aksi di sekitarmu.

var g: Game
var squads: Array[Squad] = []
var _open: Array = [null, null, null]       # regu yang masih menerima anggota baru, per tim
var _anchor: Array = [Vector2.ZERO, Vector2.ZERO, Vector2.ZERO]   # titik spawn regu terbuka
var _plan_t := 1.0
var _counts: Array = [[], [], []]           # _counts[tim][bendera] = jumlah prajurit dalam 400px


func _init(game: Game) -> void:
	g = game


func reset() -> void:
	squads.clear()
	_open = [null, null, null]
	_plan_t = 1.0
	_counts = [[], [], []]


func update(dt: float) -> void:
	_plan_t -= dt
	if _plan_t <= 0.0:
		_plan_t = Cfg.AI_PLAN_INTERVAL
		plan()


## Tutup regu terbuka sehingga prajurit berikutnya membentuk regu baru.
func close_open(team: int) -> void:
	if _open[team] != null:
		(_open[team] as Squad).closed = true
	_open[team] = null


## Prajurit AI baru: masukkan ke regu terbuka (buat regu baru bila perlu). Mengembalikan titik spawn.
func spawn_position(team: int) -> Vector2:
	var sq: Squad = _open[team]
	if sq == null or sq.closed or sq.size() >= Cfg.SQUAD_SIZE:
		_anchor[team] = g.objectives.spawn_point(team)
	return (_anchor[team] as Vector2) + Vector2(randf_range(-60, 60), randf_range(-60, 60))


func assign_new(u: Unit) -> void:
	var sq: Squad = _open[u.team]
	if sq == null or sq.closed or sq.size() >= Cfg.SQUAD_SIZE:
		sq = Squad.new()
		sq.team = u.team
		sq.defender = randf() < .25
		squads.append(sq)
		_open[u.team] = sq
		sq.add(u)
		_pick_objective(sq)
	else:
		sq.add(u)
	if sq.size() >= Cfg.SQUAD_SIZE:
		sq.closed = true
	_apply(sq, u)


## Prajurit naik kendaraan sebagai pengemudi: jadikan regu tunggal agar kendaraan punya tujuannya sendiri.
func make_solo(u: Unit) -> void:
	if u.squad != null:
		u.squad.members.erase(u)
	var sq := Squad.new()
	sq.team = u.team
	sq.closed = true
	sq.solo = true
	sq.defender = false
	sq.add(u)
	squads.append(sq)
	_pick_objective(sq)
	_apply(sq, u)


func plan() -> void:
	var flags := g.objectives.flags
	var n := flags.size()
	for t in [1, 2]:
		_counts[t] = []
		for i in n:
			(_counts[t] as Array).append(0)
	for u in g.units:
		if u.hp <= 0.0:
			continue
		for i in n:
			if u.pos.distance_squared_to(flags[i].pos) < 160000.0:
				_counts[u.team][i] += 1
	_cleanup()
	for sq in squads:
		sq.update_lag()
	for team in [1, 2]:
		var mine: Array[Squad] = []
		for sq in squads:
			if sq.team == team:
				mine.append(sq)
		if mine.is_empty():
			continue
		var assigned := []
		for i in n + 1:
			assigned.append(0)
		var offset := randi() % mine.size()
		for k in mine.size():
			var sq := mine[(k + offset) % mine.size()]
			var idx := _pick_objective(sq, assigned)
			if idx >= 0:
				assigned[idx] += sq.size()


## Hapus regu kosong, gabungkan regu yang tinggal 1 orang ke regu terdekat.
func _cleanup() -> void:
	var alive: Array[Squad] = []
	for sq in squads:
		sq.prune()
		if sq.size() > 0:
			alive.append(sq)
		elif _open[sq.team] == sq:
			_open[sq.team] = null
	squads = alive
	for sq in squads:
		if sq.size() == 1 and sq.leader != null and sq.leader.mount == null and not sq.solo:
			var best: Squad = null
			var bd := 700.0 * 700.0
			for o in squads:
				if o != sq and o.team == sq.team and o.size() < Cfg.SQUAD_SIZE and o.size() > 0 and o.leader.mount == null:
					var d := o.leader.pos.distance_squared_to(sq.leader.pos)
					if d < bd:
						bd = d
						best = o
			if best != null:
				var u := sq.leader
				sq.members.clear()
				best.add(u)
				_apply(best, u)
	var kept: Array[Squad] = []
	for sq in squads:
		if sq.size() > 0:
			kept.append(sq)
	squads = kept


## Pilih tujuan terbaik untuk regu. Mengembalikan indeks bendera (n = markas musuh), atau -1.
func _pick_objective(sq: Squad, assigned: Array = []) -> int:
	if sq.leader == null:
		return -1
	var flags := g.objectives.flags
	var n := flags.size()
	var team := sq.team
	var enemy_counts: Array = _counts[3 - team] if not (_counts[3 - team] as Array).is_empty() else []
	var own_counts: Array = _counts[team] if not (_counts[team] as Array).is_empty() else []
	var owned := g.objectives.count_owned(team)
	var player_pos := g.player.pos if g.player != null else g.cam
	var best := -1
	var best_score := -1e9
	var best_pos := Vector2.ZERO
	for i in n + 1:
		var tp: Vector2
		var own := false
		var enemy_near := 0
		var own_near := 0
		var need := 0
		if i < n:
			var f := flags[i]
			tp = f.pos
			own = f.owner_team == team
			enemy_near = enemy_counts[i] if i < enemy_counts.size() else 0
			own_near = own_counts[i] if i < own_counts.size() else 0
			need = (2 + (2 if enemy_near > 0 else 0)) if own else (5 if f.owner_team != 0 else 4)
		else:
			if owned < n - 1:
				continue
			tp = Objectives.base_pos(3 - team)
			need = 6
		var already: int = assigned[i] if i < assigned.size() else 0
		var score := -sq.leader.pos.distance_to(tp) / 700.0 + clampf(float(need - already), -2.0, 4.0) * .55
		if i < n:
			if own:
				score += .9 if sq.defender else -.6
				if enemy_near > 0:
					score += .8
				if enemy_near > own_near:
					score += 1.2                  # bendera sedang direbut: bantu!
			elif sq.defender:
				score -= .2
			if tp.distance_to(player_pos) < 1600.0:
				score += .4
		if i == sq.flag_goal:
			score += .5                           # histeresis: jangan plin-plan
		if score > best_score:
			best_score = score
			best = i
			best_pos = tp
	if best < 0:
		return -1
	if best != sq.flag_goal or sq.goal == Vector2.ZERO or sq.leader.pos.distance_to(sq.goal) < 30.0:
		sq.flag_goal = best
		sq.goal = best_pos + Vector2.from_angle(randf() * TAU) * randf_range(15.0, 95.0)
		sq.path = PackedVector2Array()
	sq.holding = best < n and flags[best].owner_team == team
	for u in sq.members:
		_apply(sq, u)
	return best


## Salin tujuan & peran regu ke satu prajurit.
func _apply(sq: Squad, u: Unit) -> void:
	u.flag_goal = sq.flag_goal
	u.goal = sq.goal
	if sq.holding and sq.defender:
		u.role = 2
		u.post = sq.goal
	elif u.role == 2:
		u.role = randi() % 2                      # tidak lagi penjaga: jadi penyerbu / pejuang berlindung


## Tarik regu penyerang terdekat ke titik tertentu (dipakai Director agar aksi mendekat ke pemain).
func redirect_nearest(team: int, pos: Vector2, count: int) -> int:
	var cand: Array[Squad] = []
	for sq in squads:
		if sq.team == team and sq.leader != null and sq.leader.mount == null:
			cand.append(sq)
	cand.sort_custom(func(a: Squad, b: Squad) -> bool: return a.leader.pos.distance_squared_to(pos) < b.leader.pos.distance_squared_to(pos))
	var done := 0
	for sq in cand:
		if done >= count:
			break
		sq.goal = pos + Vector2.from_angle(randf() * TAU) * randf_range(40.0, 160.0)
		sq.holding = false
		sq.defender = false
		sq.flag_goal = -2                         # tujuan khusus: dibiarkan sampai perencana memilih ulang
		sq.path = PackedVector2Array()
		for u in sq.members:
			u.goal = sq.goal
			if u.role == 2:
				u.role = 0
		done += 1
	return done
