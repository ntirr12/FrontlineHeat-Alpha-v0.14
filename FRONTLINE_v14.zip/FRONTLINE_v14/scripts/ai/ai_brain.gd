class_name AiBrain
extends RefCounted
## OTAK PRAJURIT AI. Dua tahap:
##   think(u) : "berpikir" berkala (0,12-0,9 dtk tergantung jarak dari pemain) -> persepsi + pilih STATE.
##   act(u,dt): dijalankan tiap frame -> bergerak/membidik/menembak sesuai STATE.
##
## STATE (urutan prioritas keputusan):
##   DODGE   (v13: NONAKTIF, Cfg.AI_DODGE_DANGER) lari dari zona bahaya. AI tidak "tahu" strike akan jatuh;
##           yang ada hanyalah reaksi SETELAH ledakan/tembakan dekat: merunduk (suppress), bukan lari prediktif.
##   RETREAT HP rendah -> mundur ke bendera/markas sendiri sampai pulih
##   EVADE   ada kendaraan musuh & tidak punya senjata anti-tank -> berlindung/menjauh
##   COVER   berlindung di balik tembok/gedung, mengintip bergantian (juga dipilih saat DITEKAN tembakan)
##   ENGAGE  melihat musuh -> bidik, tembak per rentetan SAMBIL BERDIRI, bergerak di antara rentetan;
##           regu melompat bergantian (separuh maju, separuh menahan) dan satu anggota mengitari dari samping
##   HUNT    kehilangan musuh -> menuju posisi terakhir musuh terlihat (tidak "tahu" posisi asli),
##           beberapa detik pertama menembak penekan ke titik itu
##   CAPTURE sudah di lingkaran bendera tujuan -> jaga & rebut
##   ADVANCE bergerak ke tujuan regu (mengikuti pemimpin regu)
##   BOARD   menuju kendaraan/turret kosong
##   SPY     perilaku khusus divisi Spy

enum State { ADVANCE, ENGAGE, COVER, HUNT, RETREAT, CAPTURE, DODGE, EVADE, BOARD, SPY }

# Jarak ideal bertempur per divisi: x = terlalu dekat (mundur), y = terlalu jauh (maju)
const IDEAL := [Vector2(150, 380), Vector2(260, 620), Vector2(120, 300), Vector2(70, 230),
	Vector2(120, 330), Vector2(50, 200), Vector2(150, 420), Vector2(150, 420)]
const FIRE_RANGE := [520.0, 520.0, 520.0, 260.0, 640.0, 520.0, 520.0, 520.0]

var g: Game
var vehicle_ai: AiVehicle


func _init(game: Game) -> void:
	g = game
	vehicle_ai = AiVehicle.new(game)


# ================================================================ pintu masuk per frame
func update(u: Unit, dt: float) -> void:
	u.memory_t -= dt
	u.board_cd -= dt
	u.grenade_cd -= dt
	u.danger_t -= dt
	u.retreat_t -= dt
	u.suppress = maxf(0.0, u.suppress - dt * Cfg.SUPPRESS_DECAY)
	u.pause_t = maxf(0.0, u.pause_t - dt)
	u.flank_t = maxf(0.0, u.flank_t - dt)
	if u.flash_t > 0.0:
		return                                    # buta oleh flashbang
	u.scan_t -= dt
	if u.scan_t <= 0.0:
		var near := g.player != null and u.pos.distance_squared_to(g.player.pos) < Cfg.AI_NEAR_DIST * Cfg.AI_NEAR_DIST
		var table: Array = Cfg.AI_NEAR_THINK if near else Cfg.AI_FAR_THINK
		u.scan_t = float(table[g.quality_level]) * (1.0 + randf() * .35)
		think(u)
	if u.mount != null:
		vehicle_ai.act(u, dt)
	else:
		_act(u, dt)


# ================================================================ BERPIKIR
func think(u: Unit) -> void:
	if u.mount != null:
		vehicle_ai.think(u)
		return
	g.ai_nav.update_separation(u)
	if _check_danger(u):
		return
	perceive(u)
	if u.target == null:
		_consider_boarding(u)
	_choose_state(u)


## Ada zona bahaya musuh di dekat kita? -> lari.
func _check_danger(u: Unit) -> bool:
	if not Cfg.AI_DODGE_DANGER:
		return false
	for a in g.alerts:
		if a.team == u.team:
			continue
		var d := u.pos.distance_to(a.pos)
		if d < a.radius + Cfg.DANGER_FLEE_PAD:
			var away := (u.pos - a.pos).normalized()
			if away == Vector2.ZERO:
				away = Vector2.from_angle(randf() * TAU)
			u.danger_flee = away
			u.danger_t = clampf(a.t, .6, 2.5)
			u.state = State.DODGE
			return true
	return false


func perceive(u: Unit) -> void:
	if u.target != null and not u.target.is_alive():
		u.target = null
		u.can_see = false
	var f := _find_target(u)
	if f != null:
		if u.target == null or f != u.target:
			if u.target == null:                   # kontak baru -> butuh waktu bereaksi
				var react := randf_range(Cfg.AI_REACT_MIN, Cfg.AI_REACT_MAX)
				u.react_t = react * (Cfg.DIFF_REACT[g.prefs.difficulty] if u.team == 2 else 1.0)
			u.target = f
		u.memory_t = 3.0
		u.last_known = f.pos
		u.has_last_known = true
		u.can_see = true
	else:
		u.can_see = false
		if u.memory_t <= 0.0:
			u.target = null
	if u.hurt_t > 0.0 and u.target == null:        # ditembak dari arah tak terlihat: balas / cek ke sana
		u.last_known = u.hurt_from
		u.has_last_known = true
		u.memory_t = maxf(u.memory_t, 2.0)


func _find_target(u: Unit) -> Entity:
	var best: Entity = null
	var bd := 1e9
	var enemy := 3 - u.team
	var sight: float = Cfg.AI_SIGHT * (1.35 if u.mount != null else 1.0)     # awak kendaraan punya optik: melihat lebih jauh
	g.grid.query(enemy, u.pos, sight, g.scratch)
	for o: Unit in g.scratch:
		if o.hp <= 0.0 or o.disguise_t > 0.0:      # Spy yang menyamar tidak dikenali
			continue
		var d := o.pos.distance_to(u.pos)
		if d < sight and d < bd and sees_unit(u, o, d) and g.world.los(u.pos, o.pos):
			bd = d
			best = o
	var jav := u.javelin > 0
	for v in g.vehicles:
		if v.team == enemy and not v.dead:
			var d := v.pos.distance_to(u.pos)
			var bias := 250.0 if jav else 0.0
			if d < (1000.0 if jav else Cfg.AI_SIGHT_VEH) and d - bias < bd and sees_platform(u, v, d) and g.world.los(u.pos, v.pos):
				bd = d - bias
				best = v
	for q in g.turrets:
		if q.team == enemy and not q.dead and q.driver != null:
			var d := q.pos.distance_to(u.pos)
			if d < 650.0 and d < bd and sees_platform(u, q, d) and g.world.los(u.pos, q.pos):
				bd = d
				best = q
	return best


## Aturan penglihatan: tidak melihat sesuatu hanya karena "ada di peta".
func sees_unit(u: Unit, o: Unit, d: float) -> bool:
	if o.in_bunker and d > 220.0 and o.shot_t <= 0.0:
		return false
	return u.alert_t > 0.0 or d < 120.0 or (o.shot_t > 0.0 and d < 380.0) \
		or absf(angle_difference(u.angle, (o.pos - u.pos).angle())) < .9


func sees_platform(u: Unit, o: Platform, d: float) -> bool:
	return u.alert_t > 0.0 or d < 120.0 or (o.shot_t > 0.0 and d < 600.0) \
		or absf(angle_difference(u.angle, (o.pos - u.pos).angle())) < .9


## Rusher kosong tanpa musuh boleh naik kendaraan kosong; penjaga boleh mengisi turret kosong.
func _consider_boarding(u: Unit) -> void:
	if u.board_cd > 0.0 or u.board_target != null or u.cls == Cfg.Cls.JUGGERNAUT:
		return
	if u.role == 0 and u.cls != Cfg.Cls.DESTROYER and randf() < Cfg.AI_VEHICLE_BOARD_CHANCE:
		for v in g.vehicles:
			if v.team == u.team and not v.dead and (v.driver == null or v.has_free_gunner_seat()) \
					and v.pos.distance_squared_to(u.pos) < 490000.0 and v.kind != Cfg.Veh.RAILGUN:
				u.board_target = v
				return
	if u.role == 2 and randf() < .4:
		for q in g.turrets:
			if q.team == u.team and not q.dead and q.driver == null and q.pos.distance_squared_to(u.pos) < 490000.0 \
					and g.threat_near(q.pos, u.team):
				u.board_target = q
				return


## Kendaraan/turret target naik masih bisa dimasuki?
func _board_valid(p: Platform) -> bool:
	if p.dead:
		return false
	if p is Vehicle:
		var v := p as Vehicle
		return v.driver == null or v.has_free_gunner_seat()
	return p.driver == null


func _choose_state(u: Unit) -> void:
	var tg := u.target
	var hp_frac := u.hp / u.max_hp
	# ---- naik kendaraan
	if u.board_target != null:
		if not _board_valid(u.board_target):
			u.board_target = null
		elif tg == null:
			u.state = State.BOARD
			return
	# ---- Spy: perilaku sendiri
	if u.cls == Cfg.Cls.SPY and tg == null:
		u.state = State.SPY
		return
	# ---- mundur bila HP rendah (dengan histeresis)
	if u.retreating:
		if hp_frac >= Cfg.AI_RECOVER_HP or u.retreat_t <= 0.0:
			u.retreating = false
	elif hp_frac < Cfg.AI_RETREAT_HP and not u.stubborn and (tg != null or u.hurt_t > 0.0) and u.cls != Cfg.Cls.JUGGERNAUT:
		u.retreating = true
		u.retreat_t = 18.0
		u.retreat_pos = _safe_point(u)
	if u.retreating:
		if u.state != State.RETREAT and tg != null and u.can_see:
			_smoke_screen(u, tg)                      # baru mulai mundur & masih terlihat: tutup dengan asap
		u.state = State.RETREAT
		return
	# ---- tertekan tembakan (peluru nyaris kena / ledakan dekat): merunduk ke cover terdekat. BUKAN lari menghindar.
	if tg != null and u.suppress >= Cfg.SUPPRESS_PIN and u.cls != Cfg.Cls.JUGGERNAUT and not (u.stubborn and randf() < .7):
		if not u.has_cover or u.state != State.COVER or u.cover_pos.distance_squared_to(u.pos) > 40000.0:
			u.cover_pos = g.world.find_cover(u.pos, tg.pos, 170.0)
			u.has_cover = u.cover_pos != Vector2.INF
		if u.has_cover:
			u.state = State.COVER
			u.peeking = false
			u.peek_t = randf_range(.9, 1.7)
			return
	# ---- ada musuh terlihat
	if tg != null and u.can_see:
		if tg is Vehicle and u.javelin <= 0 and u.cls != Cfg.Cls.JUGGERNAUT and u.cls != Cfg.Cls.SPY:
			u.state = State.EVADE
			u.cover_pos = g.world.find_cover(u.pos, tg.pos, 400.0)
			return
		if u.role == 1 or hp_frac < .6:
			if not u.has_cover or u.cover_pos.distance_squared_to(u.pos) > 90000.0 or u.state != State.COVER:
				u.cover_pos = g.world.find_cover(u.pos, tg.pos, 280.0)
				u.has_cover = u.cover_pos != Vector2.INF
			if u.has_cover:
				u.state = State.COVER
				return
		u.state = State.ENGAGE
		_maybe_flank(u, tg)
		return
	# ---- kehilangan musuh: periksa posisi terakhir
	if u.has_last_known and u.memory_t > 0.0:
		u.state = State.HUNT
		return
	u.has_last_known = false
	u.has_cover = false
	# ---- tidak ada musuh: lanjut ke tujuan
	var gp := u.goal if u.goal != Vector2.ZERO else Objectives.base_pos(3 - u.team)
	u.state = State.CAPTURE if u.pos.distance_squared_to(gp) < 12100.0 else State.ADVANCE
	# berhenti sejenak waspada (anggota regu saja, dan hanya bila regu tidak tertinggal) supaya gerak tidak seragam
	var sq := u.squad
	if u.state == State.ADVANCE and u.pause_t <= 0.0 and u.role != 2 and sq != null and u != sq.leader and sq.lag < 240.0 \
			and randf() < Cfg.AI_PAUSE_CHANCE:
		u.pause_t = randf_range(.6, 1.4)


## Satu anggota regu (rusher) mengitari musuh dari samping selagi rekan menahan di depan. Dipilih saat berpikir.
func _maybe_flank(u: Unit, tg: Entity) -> void:
	var sq := u.squad
	if u.flank_t > 0.0 or sq == null or sq.size() < 3 or u.role != 0 or not (tg is Unit):
		return
	if u.cls == Cfg.Cls.JUGGERNAUT or u.cls == Cfg.Cls.SPY or g.time < sq.flank_ready_at:
		return
	if sq.flanker != null and sq.flanker.hp > 0.0 and sq.flanker.flank_t > 0.0:
		return
	var d := u.pos.distance_to(tg.pos)
	if d < 200.0 or d > 520.0 or randf() > .5:
		return
	var dir := (tg.pos - u.pos) / d
	var side := 1.0 if randf() < .5 else -1.0
	for i in 2:
		var p := tg.pos + dir.orthogonal() * side * randf_range(Cfg.AI_FLANK_DIST.x, Cfg.AI_FLANK_DIST.y) - dir * randf_range(0.0, 50.0)
		if not g.world.blocked(p, 14.0):
			u.flank_pos = p
			u.flank_t = randf_range(Cfg.AI_FLANK_TIME.x, Cfg.AI_FLANK_TIME.y)
			sq.flanker = u
			sq.flank_ready_at = g.time + Cfg.AI_FLANK_COOLDOWN
			return
		side = -side


## Lempar granat asap ke arah musuh supaya garis pandang terputus saat mundur.
func _smoke_screen(u: Unit, tg: Entity) -> void:
	if u.grenades[2] <= 0:
		return
	var d := tg.pos - u.pos
	if d.length() > 520.0:
		return
	u.grenades[2] -= 1
	g.support.throw_grenade(u, u.pos + d.normalized() * minf(110.0, d.length() * .5), 3, false)


## Tempat aman untuk memulihkan diri: bendera milik sendiri terdekat yang jauh dari musuh, atau markas.
func _safe_point(u: Unit) -> Vector2:
	# 1) tempat berlindung terdekat yang memutus garis tembak (cepat dicapai, tidak ditembak dari belakang)
	var threat := Vector2.INF
	if u.target != null:
		threat = u.target.pos
	elif u.hurt_t > 0.0:
		threat = u.hurt_from
	if threat != Vector2.INF:
		var cover := g.world.find_cover(u.pos, threat, 340.0)
		if cover != Vector2.INF:
			u.retreat_t = 12.0
			return cover
	# 2) bendera milik sendiri / markas
	var best := Objectives.base_pos(u.team)
	var bd := u.pos.distance_to(best) + 400.0
	for f in g.objectives.flags:
		if f.owner_team == u.team:
			var d := u.pos.distance_to(f.pos)
			if d < bd and (u.target == null or f.pos.distance_to(u.target.pos) > 300.0):
				bd = d
				best = f.pos
	return best


# ================================================================ BERTINDAK (tiap frame)
func _act(u: Unit, dt: float) -> void:
	var trigger := false
	u.aim_point = Vector2.INF                      # diisi lagi oleh state yang membidik (agar peluru meleset jatuh di sekitar sasaran)
	var repair_pos := Vector2.INF
	if u.cls == Cfg.Cls.ENGINEER or u.cls == Cfg.Cls.ELITE:
		repair_pos = g.support.repair(u, dt)       # perbaiki aset sekutu rusak bila dekat
	match u.state:
		State.DODGE: _act_dodge(u, dt)
		State.RETREAT: _act_retreat(u, dt)
		State.EVADE: _act_evade(u, dt)
		State.COVER: trigger = _act_cover(u, dt)
		State.ENGAGE: trigger = _act_engage(u, dt)
		State.HUNT: trigger = _act_hunt(u, dt)
		State.CAPTURE:
			if repair_pos != Vector2.INF:
				g.ai_nav.walk(u, repair_pos, .8, dt)
			else:
				_act_capture(u, dt)
		State.BOARD: _act_board(u, dt)
		State.SPY:
			if not _act_spy(u, dt):
				_act_advance(u, dt)
		_:
			if repair_pos != Vector2.INF:
				g.ai_nav.walk(u, repair_pos, .9, dt)
			else:
				_act_advance(u, dt)
	if u.state != State.ENGAGE and u.state != State.COVER and u.state != State.RETREAT:
		u.weapon = 0
		u.in_cover = false
		if u.ammo < 10 and u.reload_t <= 0.0 and u.state != State.DODGE:
			u.ammo = 0                              # reload taktis saat tidak bertempur
	if (u.cls == Cfg.Cls.ENGINEER or u.cls == Cfg.Cls.ELITE) and (u.state == State.ADVANCE or u.state == State.CAPTURE):
		g.support.ai_build(u)
	if u.cls == Cfg.Cls.ELITE:
		u.jammer_on = true
	var before_exposed := u.exposed_t
	g.infantry.fire(u, trigger, dt)
	if u.exposed_t > before_exposed + 0.3 and u.burst_left > 0 and u.weapon == 0:
		u.burst_left -= 1                           # satu peluru keluar
		if u.burst_left <= 0:
			u.burst_pause = randf_range(Cfg.AI_BURST_PAUSE.x, Cfg.AI_BURST_PAUSE.y)


# ---- maju ke tujuan regu
func _act_advance(u: Unit, dt: float) -> void:
	if u.pause_t > 0.0:                                # berhenti sejenak, menyapu pandangan
		u.move_anim_t = 0.0
		u.scan_phase += dt * .9
		u.angle = lerp_angle(u.angle, u.scan_phase + float(u.slot_id), 2.5 * dt)
		return
	var dest := _squad_dest(u)
	var s := (.88 if u.role != 2 else .6) * u.pace
	var sq := u.squad
	if sq != null and sq.size() >= 2 and sq.leader != null and sq.leader.hp > 0.0:
		if u == sq.leader:
			s *= clampf(1.0 - (sq.lag - 220.0) / 500.0, .35, 1.0)      # pemimpin menunggu anggota yang tertinggal
		else:
			s += clampf((u.pos.distance_to(sq.leader.pos) - 140.0) / 500.0, 0.0, .3)   # anggota mengejar
	g.ai_nav.walk(u, dest, s, dt)


## Anggota regu mengikuti pemimpin (formasi); pemimpin menuju tujuan regu.
func _squad_dest(u: Unit) -> Vector2:
	var sq := u.squad
	var goal := u.goal if u.goal != Vector2.ZERO else Objectives.base_pos(3 - u.team)
	if sq != null and sq.leader != null and sq.leader != u and sq.leader.hp > 0.0 and sq.leader.mount == null:
		var dl := u.pos.distance_squared_to(sq.leader.pos)
		if dl < 810000.0 and u.pos.distance_squared_to(goal) > 22500.0:
			return sq.leader.pos + sq.slot_offset(u)
	return goal


# ---- berjaga/merebut di lingkaran bendera
func _act_capture(u: Unit, dt: float) -> void:
	u.wander_t -= dt
	if u.wander_t <= 0.0 or u.wander_pos == Vector2.ZERO:
		u.wander_t = randf_range(2.5, 5.0)
		var center := u.goal if u.goal != Vector2.ZERO else u.pos
		u.wander_pos = center + Vector2.from_angle(randf() * TAU) * randf_range(10.0, 85.0)
	if u.pos.distance_squared_to(u.wander_pos) > 900.0:
		g.ai_nav.walk(u, u.wander_pos, .45, dt)
	else:
		u.scan_phase += dt * .7                    # berhenti & menyapu pandangan
		u.angle = lerp_angle(u.angle, u.scan_phase + float(u.slot_id), 2.0 * dt)
		u.move_anim_t = 0.0


# ---- hunt: menuju posisi terakhir musuh terlihat
func _act_hunt(u: Unit, dt: float) -> bool:
	if u.pos.distance_squared_to(u.last_known) < 3600.0:
		u.has_last_known = false                    # sampai & tidak ada siapa-siapa
		u.memory_t = 0.0
		return false
	var fire := _blind_fire(u, dt)
	g.ai_nav.walk(u, u.last_known, (.5 if fire else .8) * u.pace, dt, not fire)
	return fire


## Beberapa detik setelah kehilangan musuh: tembak penekan ke titik terakhir musuh terlihat (peluru jatuh di sekitarnya
## dan menekan musuh yang bersembunyi di sana). Tidak semua prajurit melakukannya.
func _blind_fire(u: Unit, dt: float) -> bool:
	if u.memory_t < 3.0 - Cfg.AI_BLIND_FIRE_TIME or u.slot_id % 3 == 0 or u.cls == Cfg.Cls.SPY or u.cls == Cfg.Cls.DESTROYER:
		return false
	var d := u.pos.distance_to(u.last_known)
	if d < 80.0 or d > float(FIRE_RANGE[u.cls]) * .8:
		return false
	var ang := (u.last_known - u.pos).angle()
	_aim(u, ang, dt)
	u.aim_point = u.last_known
	u.weapon = 0
	if absf(angle_difference(u.angle, ang)) > .25:
		return false
	return _burst_gate(u, dt)


# ---- lari dari bahaya
func _act_dodge(u: Unit, dt: float) -> void:
	if u.danger_t <= 0.0:
		u.state = State.ADVANCE
		return
	u.angle = lerp_angle(u.angle, u.danger_flee.angle(), 12.0 * dt)
	g.ai_nav.step(u, u.danger_flee, 1.1, dt)


# ---- mundur memulihkan diri
func _act_retreat(u: Unit, dt: float) -> void:
	if u.pos.distance_squared_to(u.retreat_pos) > 900.0:
		u.in_cover = false
		g.ai_nav.walk(u, u.retreat_pos, 1.05, dt)
	else:
		u.move_anim_t = 0.0                         # menunggu pulih (base/bunker menyembuhkan lebih cepat)
		u.in_cover = g.world.near_wall(u.pos)


# ---- kendaraan musuh & kita tak punya senjata anti-tank
func _act_evade(u: Unit, dt: float) -> void:
	var tg := u.target
	if tg == null:
		return
	var away := (u.pos - tg.pos).normalized()
	if u.cover_pos != Vector2.INF and u.pos.distance_squared_to(u.cover_pos) > 400.0:
		g.ai_nav.walk(u, u.cover_pos, 1.0, dt)
	else:
		g.ai_nav.step(u, away, .9, dt)
		u.angle = lerp_angle(u.angle, away.angle(), 8.0 * dt)
	var d := u.pos.distance_to(tg.pos)               # granat ke tank bila cukup dekat
	if d < 320.0 and d > 90.0 and u.grenades[0] > 0 and u.grenade_cd <= 0.0 and u.can_see:
		u.grenade_cd = 5.0
		g.support.throw_grenade(u, tg.pos, 0, false)
		u.grenades[0] -= 1


# ---- naik kendaraan
func _act_board(u: Unit, dt: float) -> void:
	var bt := u.board_target
	if bt == null or bt.dead:
		u.board_target = null
		return
	g.ai_nav.walk(u, bt.pos, .95, dt)
	if u.pos.distance_squared_to(bt.pos) < 2304.0:
		var as_gunner := false
		if bt is Vehicle:
			var v := bt as Vehicle
			as_gunner = v.driver != null
			if v.driver != null and v.gunner != null:
				u.board_target = null
				return
		g.vehicle_sys.board(u, bt, as_gunner)
		u.board_target = null
		u.target = null
		u.state = State.ADVANCE
		u.turret_idle_t = 0.0
		if not as_gunner and bt is Vehicle:
			g.planner.make_solo(u)


# ---- bertempur
## Pola gerak natural: TEMBAK SAMBIL BERDIRI (lebih akurat), BERGERAK DI ANTARA rentetan.
## Jauh dari musuh: separuh regu menahan & menembak selagi separuh lagi maju (lalu bertukar).
func _act_engage(u: Unit, dt: float) -> bool:
	var tg := u.target
	if tg == null:
		return false
	var d := u.pos.distance_to(tg.pos)
	var ang := (tg.pos - u.pos).angle()
	_aim(u, ang, dt)
	u.aim_point = tg.pos
	var ideal: Vector2 = IDEAL[u.cls]
	u.strafe_t -= dt
	if u.strafe_t <= 0.0:
		u.strafe_t = randf_range(.8, 2.0)
		u.strafe_dir = 1.0 if randf() < .5 else -1.0
	var perp := Vector2.from_angle(ang + PI / 2.0) * u.strafe_dir
	var firing := u.burst_left > 0 and u.react_t <= 0.0 and u.can_see
	if u.suppress >= Cfg.SUPPRESS_PIN:
		u.move_anim_t = 0.0                               # tertekan & tak ada cover: merunduk di tempat
	elif u.flank_t > 0.0 and tg is Unit:
		if u.pos.distance_squared_to(u.flank_pos) < 2500.0:
			u.flank_t = 0.0                               # sudah di posisi samping
		else:
			g.ai_nav.walk(u, u.flank_pos, 1.0 * u.pace, dt, false)
	elif d > ideal.y:
		if _bound_hold(u, d):
			u.move_anim_t = 0.0                           # rekan sedang maju: kita menahan & menembak
		else:
			g.ai_nav.walk(u, tg.pos, .8 * u.pace, dt, false)      # maju mendekat (tetap menghadap musuh)
	elif d < ideal.x:
		g.ai_nav.step(u, -Vector2.from_angle(ang) + perp * .4, .65, dt)   # mundur sambil menyamping
	elif u.role != 2 and not firing:
		g.ai_nav.step(u, perp, .45, dt)                   # bergerak hanya di jeda antar-rentetan
	_special_tactics(u, tg, d)
	return _trigger(u, tg, d, ang, dt)


## Giliran regu: separuh anggota (genap/ganjil) menahan di tiap "lompatan", lalu bertukar. Hanya bila bisa menembak dari sini.
func _bound_hold(u: Unit, d: float) -> bool:
	var sq := u.squad
	if sq == null or sq.size() < 2 or not u.can_see or u.role == 2 or d > float(FIRE_RANGE[u.cls]):
		return false
	return (int(g.time / sq.bound_period + sq.bound_off) & 1) == (u.slot_id & 1)


# ---- berlindung & mengintip
func _act_cover(u: Unit, dt: float) -> bool:
	var tg := u.target
	if tg == null or u.cover_pos == Vector2.INF:
		u.state = State.ENGAGE
		return false
	var ang := (tg.pos - u.pos).angle()
	if u.pos.distance_squared_to(u.cover_pos) > 400.0:
		u.in_cover = false
		g.ai_nav.walk(u, u.cover_pos, 1.0, dt, false)
		u.angle = lerp_angle(u.angle, ang, 8.0 * dt)
		return false
	u.move_anim_t = 0.0
	u.in_cover = g.world.near_wall(u.pos)
	u.peek_t -= dt
	if u.peek_t <= 0.0:
		u.peeking = not u.peeking
		u.peek_t = 1.4 if u.peeking else randf_range(1.6, 2.6)
	_aim(u, ang, dt)
	if not u.peeking:
		return false
	u.aim_point = tg.pos
	var d := u.pos.distance_to(tg.pos)
	_special_tactics(u, tg, d)
	return _trigger(u, tg, d, ang, dt)


func _aim(u: Unit, ang: float, dt: float) -> void:
	var rate: float = 10.0 / (Cfg.DIFF_REACT[g.prefs.difficulty] if u.team == 2 else 1.0)
	u.angle = lerp_angle(u.angle, ang, rate * dt)


## Pilih senjata & putuskan menembak (rentetan pendek + jeda, setelah waktu reaksi).
func _trigger(u: Unit, tg: Entity, d: float, ang: float, dt: float) -> bool:
	u.react_t -= dt
	if tg is Vehicle or tg is Turret:
		u.weapon = 1 if u.javelin > 0 else 0
	elif u.cls == Cfg.Cls.ASSAULT and u.m203 > 0 and d > 180.0 and d < 420.0 and tg is Unit and (tg as Unit).in_cover:
		u.weapon = 1
	else:
		u.weapon = 0
	if u.react_t > 0.0 or not u.can_see:
		return false
	var range_px := 1100.0 if (u.weapon == 1 and u.javelin_max > 0) else float(FIRE_RANGE[u.cls])
	if d > range_px:
		return false
	var tol := .3 if u.weapon == 1 else .2
	if absf(angle_difference(u.angle, ang)) > tol:
		return false
	if u.weapon == 1:
		return true                                 # Javelin/M203: tembak begitu siap (lock dicek di Infantry)
	return _burst_gate(u, dt)


## Rentetan pendek + jeda: true selama masih ada peluru dalam rentetan yang sedang berjalan.
func _burst_gate(u: Unit, dt: float) -> bool:
	if u.burst_left <= 0:
		u.burst_pause -= dt
		if u.burst_pause <= 0.0:
			u.burst_left = randi_range(20, 40) if u.cls == Cfg.Cls.JUGGERNAUT else randi_range(Cfg.AI_BURST_MIN, Cfg.AI_BURST_MAX)
	return u.burst_left > 0


## Granat ke musuh yang berlindung/bergerombol, serangan udara oleh Support.
func _special_tactics(u: Unit, tg: Entity, d: float) -> void:
	if u.role != 2 and d > 110.0 and d < 320.0 and u.grenades[0] > 0 and u.grenade_cd <= 0.0 and u.can_see and randf() < .08:
		# granat itu untuk musuh yang berlindung/menetap; di tempat terbuka lebih sering ditembak saja
		var entrenched := tg is Turret or (tg is Unit and ((tg as Unit).in_cover or (tg as Unit).in_bunker))
		if entrenched or randf() < Cfg.AI_GRENADE_OPEN_CHANCE:
			u.grenade_cd = randf_range(Cfg.AI_GRENADE_CD.x, Cfg.AI_GRENADE_CD.y)
			u.grenades[0] -= 1
			g.support.throw_grenade(u, tg.pos, 0, false)
	if u.cls == Cfg.Cls.SUPPORT and u.radio_cd <= 0.0 and u.can_see and d > 200.0 and d < 900.0 and g.time >= g.radio_next[u.team]:
		u.radio_cd = Cfg.AI_RADIO_CD
		g.radio_next[u.team] = g.time + randf_range(Cfg.AI_RADIO_TEAM_GAP.x, Cfg.AI_RADIO_TEAM_GAP.y)
		if randf() < Cfg.AI_MLRS_CHANCE:
			g.air.call_mlrs(tg.pos, u.team, false)                       # v14: kadang AI memanggil MLRS, bukan airstrike
		else:
			g.support.call_barrage(tg.pos, u.team, false, 26, 260.0, randf() < .5, (tg.pos - u.pos).normalized())


# ---- spy
func _act_spy(u: Unit, dt: float) -> bool:
	if u.disguise_t <= 0.0 and u.skill_cd <= 0.0:
		u.disguise_t = 20.0
		u.skill_cd = 30.0
		u.suspicion = 0.0
	if u.sabotage_target == null:
		var x := g.infantry.sabotage_target(u)
		if x != null:
			u.sabotage_target = x
			u.sabotage_t = .01
	if u.sabotage_target != null:
		u.move_anim_t = 0.0
		return true
	var best: Entity = null
	var bd := 1800.0
	for q in g.turrets:
		if q.team != u.team and not q.dead and q.pos.distance_to(u.pos) < bd:
			bd = q.pos.distance_to(u.pos)
			best = q
	for s in g.structs:
		if s.team != u.team and s.hp > 0.0 and (s.kind == Cfg.Item.JAMMER or s.kind == Cfg.Item.DRONE_ST or s.kind == Cfg.Item.TOWER):
			var d := s.pos.distance_to(u.pos)
			if d < bd:
				bd = d
				best = s
	if best == null:
		return false
	g.ai_nav.walk(u, best.pos, .9, dt)
	return true
