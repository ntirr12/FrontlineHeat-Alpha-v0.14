# Changelog

## v14.0 - kendaraan baru, C-17 terjun payung, MLRS, suplai, efek
Tidak ada fitur lama yang dihapus. Semua angka baru ada di `scripts/data/cfg.gd` (cari `v14`).

**Kendaraan**
- **Semua kendaraan diperbesar** (`Cfg.VEH_SCALE = 1.45`, radius tabrakan +25-30%): tank ~64x130 px vs prajurit ~34x62 px (dulu ~44x90).
  Bar HP, bayangan, MG penembak, titik turun, jarak naik ikut menyesuaikan. Jarak aman navigasi kendaraan 30 -> 40 px (`Cfg.NAV_VEH_CLEAR`).
- **3 kendaraan baru** (tiap tim, parkir di kolom luar markas): **APC** (LAV-25 / BTR-82A: cepat, kanon 25mm, 2 kursi, senjata 2 = peluru asap),
  **SPG** (M109A6 / 2S3: howitzer 155mm, peluru lengkung ber-ledakan besar sampai ~1250 px, senjata 2 = peluru asap, lambat),
  **MEDEVAC** (Stryker M1133 / Ural-4320: tanpa senjata, menyembuhkan prajurit sekutu 190 px di sekitarnya, 2x saat berhenti; meninggalkan peti medis saat hancur).
- **Skill kendaraan** (tombol SKILL saat menyetir): BOOST x1,65 selama 2,4 dtk (Humvee, APC, MEDEVAC) atau TIRAI ASAP (tank, Bradley, railgun, SPG). AI memakainya juga.
- Mesin **pincang** (kecepatan x0,74) saat HP < 30%. Kursi penembak digeneralisasi (`Cfg.VEH_SEATS`): APC & MEDEVAC bisa diisi AI.
- Peluru baru `HOWITZER` & `SMOKESHELL` (`Cfg.BUL_ARC`): terbang lengkung di atas rintangan, meledak/berasap hanya saat mendarat. Penanda railgun di `VEH_SHOT` kini `Cfg.SHOT_RAIL = 99` (dulu angka 6 bentrok dengan jenis peluru baru).

**Bantuan udara & artileri (systems/air_support.gd, render/air_view.gd baru)**
- **RADIO: TERJUN C-17**: pesawat C-17 melintas di titik yang dibidik dan menerjunkan 1 regu (6 prajurit, gratis) + 1 peti medis. Penerjun melayang dengan kanopi lalu
  menjadi AI sekutu dan membentuk regu. Director juga memakai C-17 untuk bantuan kedua tim ("MUSUH TERJUN").
- **RADIO: MLRS**: dibidik persis seperti airstrike. Peluncur (HIMARS / Uragan) masuk dari belakang garis, bersiap 2,4 dtk, menembakkan 18 roket melengkung ke area oval
  (roket kecil, area luas). AI Support kadang memanggil MLRS, Director punya kejadian salvo MLRS acak.
- **DROP: SUPLAI** + **peti suplai** (dari C-17, DROP: SUPLAI, MEDEVAC hancur): sentuh = HP +60%, granat/rudal terisi, poin bangun. Musuh tidak bisa mengambil peti tim lain.
- **Hadiah kill streak**: tiap 5 kill = radio langsung siap + poin bangun.
- Item baru di `Cfg.Item` (MLRS, PARADROP, DROP_SUPPLY) untuk Support dan Elite. Halaman bantuan baru: KENDARAAN, BANTUAN RADIO.

**Efek**: debu roda/rantai (makin cepat makin tebal), api knalpot saat boost, tirai asap, asap laras & jejak peluru artileri, jejak asap + percikan roket,
semburan peluncuran roket, debu pendaratan penerjun, tiupan mesin C-17, kilau penyembuhan MEDEVAC, kilau pengambilan peti, penanda area MLRS (oval + hitung mundur).

**Bug fix**: percikan (`Fx.Type.SPARK`) tidak pernah tergambar sejak v13 karena `draw_multiline_colors` menerima 2 warna per garis (harus 1) -> sekarang semua percikan
ledakan/hantaman tampil. Teks bantuan "AI lari dari serangan udara" diperbaiki (sejak v13 AI tidak menghindar).

**Optimasi**: AirView tidak menggambar apa pun bila tidak ada benda udara; digambar per tekstur (batching) -> beban udara +18 draw call, bukan +46. Atlas unit 1024x1024 -> 1024x1536
(+2 MB VRAM, `SIZES` di `build_atlas.py` kini mengenal 1536); bangkai kendaraan baru tidak di-upscale 2x; C-17 diperkecil ke 180 px.
Ukur: draw-call 107 -> 115 (pertempuran biasa), simulasi 1,8 ms/frame (tetap), tempo ~112 gugur/menit (v13: 116).

**Tes baru**: `tests/air_test.gd` (kendaraan baru, skill, MEDEVAC, howitzer, C-17, MLRS, peti, kill streak, pemain menyetir), `tests/shots_air.gd` (foto visual),
`render_bench.gd` punya mode beban udara (`-- 1 30 0 2 air`).

## v13.0 - tembak & kerusakan, AI natural, kendaraan, efek, optimasi
**Aturan permainan berubah di titik-titik yang diminta**; sisanya (menu, kontrol, aset, suara, peta) tidak diubah.

**Sistem tembak (combat.gd, dirombak)**
- Perbaikan akar masalah "peluru menembus": peluru bergerak 37 px/frame (30 FPS) sementara tubuh prajurit 13 px dan tabrakan hanya
  dites di titik akhir. Kini tabrakan dites sepanjang segmen jalur peluru. Tes: 400/400 peluru kena sasaran 300px pada 20 FPS.
- Peluru yang membidik sasaran jatuh ke **tanah di sekitarnya** (debu + bekas hantaman) alih-alih terbang sampai ujung peta;
  berlaku untuk AI, pemain berjalan, dan kendaraan/turret. Peluru yang menghantam karung pasir/dinding berhenti di sana.
- Model **kena langsung** (`DIRECT_DMG`) + **splash** (`BLAST_*`); peluru meriam/granat yang meleset meledak di tanah dan tetap
  melukai sasaran di dekatnya. Ledakan membuat prajurit yang tewas **terlempar**.

**AI (ai_brain.gd, ai_vehicle.gd, squad.gd)**
- Tidak lagi menghindar dari strike/artileri/granat (`AI_DODGE_DANGER = false`; zona bahaya tidak dibuat sama sekali).
- Baru: tekanan tembakan (suppression) -> merunduk/cari cover, tembak sambil berdiri, lompat-maju bergantian, mengitari musuh,
  tembakan penekan ke posisi terakhir musuh, berhenti waspada, kecepatan pribadi, formasi baji. AI kendaraan: awak kini bisa
  melihat (sudut pandang diperbarui), pandangan 1,35x, menjaga jarak & mundur, jeda mengincar ulang.
- Penyeimbang karena strike tak bisa dihindari lagi: radio barrage per tim berjeda 40-75 dtk (dulu bisa 19 panggilan/150 dtk),
  artileri ambient 2x lebih jarang & damage 90 (dulu 150), granat AI berjeda 11-20 dtk dan terutama ke musuh yang berlindung.

**Kendaraan**: HP +50% (240/820/250/560/1000), lebih kebal senapan & ledakan kecil, senapan mesin x1,3-1,9, tembak lebih cepat,
sedikit lebih cepat & lincah, melindas infantri musuh, berasap/menyala saat rusak parah.

**Efek (vfx.gd baru)**: lihat docs/ARSITEKTUR.md 2c. Tank/IFV hancur: bola api, kilatan, 3-5 semburan api dari panel/palka, turret terlempar
(bayangan terpisah, putaran, jatuh + kawah), 1-4 ledakan susulan, asap hitam; hantaman baja/gedung/tanah/karung pasir; debu meriam.
Semua turun bertahap di kualitas sedang/rendah. Lapisan cahaya aditif untuk kilatan & api.

**Optimasi (hasil ukur Godot 4.7.2, 1280x720, render software di sandbox; BUKAN HP; asli = v12)**
| Ukuran | v12 | v13 |
|---|---|---|
| Draw call, 30 AI/tim, dekat markas | 297 | **107** (-64%) |
| Draw call, 44 AI/tim, dekat markas | 323 | **107** (-67%) |
| Draw call, 44 AI/tim, tengah baku tembak | 474 | **147** (-69%) |
| Primitif gambar per frame | 9.411 | **3.599** (-62%) |
| CPU simulasi per frame (44 AI/tim, kualitas sedang) | 4,0 ms | **3,1 ms** (-22%) |
| CPU skrip gambar per frame | 1,33 ms | **0,95 ms** (-29%; -38% di kualitas rendah) |
| Memori tekstur | 20,3 MB | 21,0 MB (+0,7 MB: tekstur efek kecil & atlas ikon) |
Sumber penghematan: terrain 238 -> ~63 draw call (digambar per lapis), HUD ~99 -> ~41 (cakram/cincin bertekstur + ikon dibake),
BattleView 40 -> 13 (prajurit/kendaraan/efek per lapis). Peluru yang beterbangan jauh lebih sedikit karena kini jatuh ke tanah.

**Catatan keseimbangan yang jujur**: peluru yang benar-benar mengenai membuat tempo gugur naik dari ~64 ke ~107 per menit
(`pace_test.gd`, 8 seed x 120 dtk). `TICKET_PER_AI` dinaikkan 7 -> 11 sehingga perkiraan lama misi ~7,5 menit (v12 ~8,8).
Kekompakan regu saat maju 200 -> ~220 px (batas 250). Semua knob ada di `docs/TUNING.md`.

**Efek samping yang disengaja**: karena peluru meriam AI kini benar-benar jatuh di dekat sasaran, duel tank AI saling menghancurkan (hidup lagi setelah `VEH_RESPAWN` 28 dtk).
`player_test.gd` kini memastikan tank hidup sebelum menguji naik/mengemudi.

**Tes baru**: `combat_test.gd` (19 pemeriksaan), `pace_test.gd`, `shots_vfx.gd`, `shots_compare.gd`; `ai_scenarios.gd` skenario 3 kini
membuktikan AI TIDAK menghindar. **Belum diuji di HP fisik**.

## v12.0 - aset sprite & suara
Aset dari `frontline_assets` dipasang di atas v11. **Aturan permainan, AI, dan angka tuning tidak diubah.**
Satu-satunya perubahan di luar `render/` dan `audio/` adalah parameter jenis efek pada beberapa pemanggilan `fx.spawn`
(muzzle/ledakan/darah), pemetaan `Cfg.BUL_SOUND` (peluru meriam kini memakai suara meriam), dan tiga baris suara di `main.gd`
(prajurit gugur, teriakan bendera).

**Tampilan**: sprite prajurit (8 divisi x 2 faksi), kendaraan (badan/turret/laras, skin per biome), turret, bunker, menara,
kawat, tank trap, depot, atap gedung (detail kipas/kisi/panel), pohon/semak/kaktus/batu, tembok blok, jet (A-10/F-15 vs Su-25/Su-27),
parasut, mayat/darah/kawah. Efek: ledakan beranimasi, muzzle searah tembakan, asap, api bangkai.
**Suara**: 21 sampel nyata (tembakan, meriam, ledakan, roket, gugur, teriakan perang), 2 lagu OGG.
**Alat**: `tools/build_atlas.py` (pengepak atlas + warna tim + hapus tanda tangan sprite + varian salju), `tools/build_audio.py`.
**Keamanan**: semua jalur gambar punya fallback vektor v11; `Cfg.USE_SPRITES` sebagai saklar.
**Tes baru**: `audio_test.gd`, `sprite_test.gd`, `shots_sprites.gd`, `render_bench.gd`.

Hasil ukur (Godot 4.7.2, render software di sandbox; bukan HP; detail di docs/ASET.md bagian 7):
- Draw-call: 409 -> 323 rata-rata (30 AI/tim); 375 -> 313, puncak 498 -> 353 (44 AI/tim).
- Primitif gambar per frame turun ~40%; waktu skrip gambar turun ~22%.
- Memori tekstur naik 8 MB (atlas). Biaya simulasi tidak berubah (2,1 ms, p99 3,8 ms).
- Semua tes lama lulus (player_test, ui_flow, sim_test, ai_scenarios setara v11).

## v11.0
Penyusunan ulang total dari satu file 2275 baris (`game.gd`) menjadi ~35 file bertipe dan ber-komentar. Semua fitur v10.1
dipertahankan (8 divisi, 5 kendaraan, 20 item, drone FPV, nuke, spy, dev mode, statistik, tutorial).

**AI**: regu, state machine, persepsi tanpa "wallhack", waktu reaksi, tembakan per rentetan, cover cerdas, mundur+asap,
hindari zona bahaya, evade kendaraan, Spy menyamar benar-benar tak dikenali, formasi mengikuti pemimpin.
**Pertempuran**: hingga 44 AI/tim, Director (artileri ambien, jet pembom, pasukan terjun, penarik aksi), tracer per tim,
ambien perang, tiket dihitung dari jumlah AI, preset Jumlah AI/Panjang/Kekacauan.
**Kontrol**: analog melayang/tetap, zona mati, kecepatan bidik, tombol TEMBAK yang bisa diseret, tembak otomatis,
transparansi kontrol; kendaraan meluncur di tembok; HUD disembunyikan saat memilih divisi.
**Optimasi**: lihat docs/ARSITEKTUR.md bagian 4.

Hasil ukur (Godot 4.7.2, CPU desktop, simulasi headless 5 menit; bukan HP):
- AI macet: 7,7% -> ~2,5% sampel.
- Biaya simulasi: 32 prajurit 1,17 ms (asli) -> 60 prajurit 1,9 ms; 88 prajurit (EPIK, kualitas rendah) 2,7 ms rata-rata, p99 ~4 ms.
- Skrip per frame (simulasi + gambar): asli 32 prajurit 4,8 ms; baru 45 prajurit 5,1 ms; 88 prajurit kualitas rendah 5,5 ms.
