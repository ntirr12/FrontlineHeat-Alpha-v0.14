# Panduan Aset FRONTLINE (v12)

Dokumen ini menjelaskan bagaimana gambar & suara dipasang, dan **cara mengganti/menambah aset tanpa merusak game**.
Cocok dibaca pemula: tidak perlu mengerti seluruh kode.

## 1. Gambaran besar (satu menit)

```
art_src/  (PNG sumber, ratusan file kecil)
   |   python tools/build_atlas.py     <- daftar sprite ada di tools/atlas_spec.py
   v
assets/atlas/units.png  fx.png          <- 2 gambar besar ("atlas"), total ~6 MB memori video
scripts/data/atlas_data.gd              <- posisi tiap sprite di atlas (dibuat otomatis, jangan diedit)
   |
   v
SpriteLib (render/sprite_lib.gd)        <- memuat atlas, mencari sprite berdasarkan nama
SpriteBank (render/sprite_bank.gd)      <- "bank" sprite siap gambar; disusun ulang tiap pertandingan
   |                                       (skin gurun/hijau dipilih dari biome)
   v
BattleView / TerrainView / DecalView    <- menggambar. Setiap benda: coba sprite dulu, kalau tidak ada -> gambar vektor lama
```

**Kenapa atlas?** Menggambar 300 gambar terpisah = ratusan perintah ke GPU per frame (lambat di HP lowend).
Satu atlas = hampir semua sprite digambar dalam beberapa perintah saja.

**Aturan emas (jaring pengaman):** kalau atlas hilang/rusak, atau `Cfg.USE_SPRITES = false`, game otomatis
kembali memakai gambar vektor lama (v11). Jadi aset tidak pernah bisa "mematikan" game.

## 2. Peta folder aset

| Folder / file | Isi | Diedit manual? |
|---|---|---|
| `art_src/` | PNG sumber yang dipakai (salinan terpilih dari paket aset, ~0,5 MB) | ya (tambah gambar baru di sini) |
| `tools/atlas_spec.py` | daftar sprite -> nama di game | **ya, ini file utamanya** |
| `tools/build_atlas.py` | pembangun atlas | jarang |
| `tools/build_audio.py` | konversi suara sumber -> WAV ringan | jarang |
| `assets/atlas/*.png` | hasil atlas | tidak (dibuat otomatis) |
| `assets/audio/sfx/*.wav`, `music/*.ogg` | suara siap pakai | tidak (dibuat otomatis) |
| `scripts/data/atlas_data.gd` | posisi sprite | **tidak** (dibuat otomatis) |
| `scripts/data/sprite_defs.gd` | benda game -> nama sprite, skala, posisi turret | **ya** |
| `scripts/data/audio_defs.gd` | nomor suara -> file | **ya** |

`art_src/` dan `tools/` berisi file `.gdignore` sehingga Godot tidak mengimpornya, dan tidak ikut ke APK.

## 3. Resep umum

Butuh Python 3 dan: `pip install pillow numpy soundfile soxr` (hanya untuk membangun ulang aset, bukan untuk menjalankan game).

### a. Mengganti tampilan sebuah kendaraan
1. Taruh PNG baru di `art_src/` (mis. `art_src/sprites/us/tank/m1a1.png`).
2. Di `tools/atlas_spec.py`, ubah path pada baris kendaraan itu, mis. blok `veh/us_abrams/...`.
3. `python tools/build_atlas.py`
4. Buka Godot (impor otomatis), jalankan. Selesai.
Kalau posisi turret/laras meleset, ubah `tpos` / `bpos` / `scale` di `scripts/data/sprite_defs.gd`
(satuan = piksel sprite; **maju = positif**).

### b. Menambah sprite baru
Tambah satu baris `add("nama/sprite", "path/ke/file.png", ...)` di `tools/atlas_spec.py`, bangun atlas,
lalu pakai `SpriteLib.find("nama/sprite")` di kode gambar.
Opsi: `frames=N` (strip animasi), `team=True` (ganti piksel hijau-murni jadi biru/merah), `crop=(x,y,w,h)`,
`fit=(w,h)` (perkecil), `up=1` (jangan di-upscale), `erase=[...]` (hapus tulisan), `tint=(warna, jumlah)`.

### c. Mengganti / menambah suara
- Nomor suara & asal filenya ada di `scripts/data/audio_defs.gd` (banyak varian = dipilih acak).
- Sumbernya didaftarkan di `tools/build_audio.py` (tabel `SFX`). Tambah baris, jalankan
  `python tools/build_audio.py --assets <folder paket aset>`, lalu tambahkan nama di `audio_defs.gd`.
- Suara UI (klik, kill, jingle) dan mesin kendaraan masih sintesis (`scripts/audio/synth.gd`); itu disengaja.

### d. Mematikan sprite sementara (untuk membandingkan / mencari bug)
`scripts/data/cfg.gd`: `const USE_SPRITES := false`.

## 4. Konsep yang perlu diketahui

- **Skin**: `tan` (gurun) dan `grn` (hijau). Biome GURUN memakai tan, HUTAN & SALJU memakai hijau.
  Pilihan terjadi satu kali di `SpriteBank.resolve()`. Bila sebuah kendaraan hanya punya satu skin, skin itu dipakai di semua biome.
- **Warna tim**: sprite sumber menandai warna tim dengan piksel hijau-murni. `build_atlas.py` mengganti piksel itu
  menjadi biru (tim 1) dan merah (tim 2) sekali saat build -> nama sprite berakhiran `@1` / `@2`. Tanpa shader, tanpa biaya runtime.
  Tambahan kejelasan kawan/lawan di game: cakram dan cincin warna tim di bawah kendaraan & prajurit.
- **Faksi**: tim 1 = AS, tim 2 = Rusia (`SpriteDefs.INF_SET`, `SpriteDefs.VEHICLES`). Spy yang menyamar tampil dengan sprite musuh.
- **Arah sprite**: semua sprite menghadap ATAS. Game memutar sprite dengan `sudut + PI/2`.
- **Upscale 2x**: pixel-art di grup `units` diperbesar 2x (nearest) di dalam atlas, lalu digambar dengan filter linear.
  Hasilnya tajam tetapi tidak "berkedip" saat diputar. Efek (`fx`) tidak di-upscale.
- **Jenis efek baru** (`Fx.Type`): `EXPLOSION`, `MUZZLE`, `BLOOD` ditambahkan di AKHIR enum agar nilai lama tidak bergeser.
  Tanpa atlas, ketiganya digambar sebagai lingkaran seperti v11.

## 5. Optimasi untuk HP lowend (dan kenapa fitur tidak berkurang)

| Teknik | Efek |
|---|---|
| Atlas 2 gambar (~6 MB VRAM, paket asli 27 MB) | draw-call sedikit; memori kecil |
| Hanya aset terpilih yang dipakai (109 PNG dari 3.155 file paket); `art_src/` tidak ikut APK | APK kecil (aset ~3,5 MB) |
| Warna tim dibake, skin dipilih saat start | nol biaya per frame |
| `SpriteBank` memetakan nama -> objek sekali per pertandingan | tidak ada operasi teks di jalur gambar |
| Peta statis (pohon, tembok, atap) tetap digambar sekali per potongan | sprite dekor tidak menambah biaya per frame |
| Efek 1 sprite per ledakan (bukan banyak lingkaran) | primitif gambar turun ~40% (lihat bagian 7) |
| Bayangan siluet, animasi jalan, api bangkai dimatikan di kualitas RENDAH (`Game.quality_level == 2`) | governor kualitas tetap bekerja |
| SFX = WAV mono 22 kHz (tanpa dekoding), musik OGG 8 kHz | CPU audio sangat kecil |
| Musik tidak lagi dibangkitkan sintesis di thread saat start | start lebih cepat di HP lemah |

## 6. Pelajaran teknis (jebakan yang sudah pernah terjadi)
- **Selalu reset transform setelah menggambar bayangan.** `draw_set_transform(pos, rot)` tetap aktif untuk semua gambar
  berikutnya. Bila setelah bayangan Anda memanggil `draw_circle(world_pos, ...)`, lingkaran itu tergambar jauh di luar layar.
  Kodenya sudah memakai pola: bayangan -> `draw_set_transform(ZERO, 0, ONE)` -> gambar koordinat dunia.
- **`_g.png` pada sprite sumber bukan team-mask**, melainkan skin hijau (woodland). Warna tim sebenarnya = piksel hijau-murni.
- **Klip mesin di paket aset tidak bisa di-loop** (klip sekali-putar yang meluruh), jadi mesin tetap sintesis.
- **Data atlas berupa `.gd`, bukan `.json`**: file non-resource tidak otomatis ikut ter-export di Godot.
- Satu sprite sumber (`m1aX`) memuat tulisan tanda tangan pembuatnya; `erase=` di `atlas_spec.py` menghapusnya saat build.

## 7. Hasil ukur (jujur)
Diukur dengan `tests/render_bench.gd` di Godot 4.7.2 Linux (renderer OpenGL, render software di sandbox, BUKAN HP):
draw-call, jumlah primitif, dan waktu skrip gambar bermakna di sini; fps absolut tidak.

| Skenario (selama ~8-14 dtk pertama) | v11 | v12 |
|---|---|---|
| 30 AI/tim, HUTAN: draw-call rata-rata / maks | 409 / 466 | **323 / 343** |
| 30 AI/tim: primitif per frame | 17.577 | **10.195** |
| 30 AI/tim: waktu skrip gambar | 1,57 ms | **1,22 ms** |
| 44 AI/tim (EPIK), GURUN: draw-call rata-rata / maks | 375 / 498 | **313 / 353** |
| 44 AI/tim: primitif per frame | 16.007 | **9.936** |
| 44 AI/tim: waktu skrip gambar | 1,52 ms | **1,16 ms** |
| Memori tekstur | 12,4 MB | 20,5 MB (**+8 MB**: atlas 6 MB + cadangan) |
| Biaya simulasi (sim_test 240 dtk) | 2,19 ms (p99 4,2) | 2,10 ms (p99 3,8) |

Artinya: sprite MENGURANGI beban gambar (satu sprite menggantikan banyak lingkaran/garis), dengan harga +8 MB memori video.
HP dengan RAM sangat kecil (<1 GB) perlu diuji; bila terlalu berat, kecilkan `up=2` menjadi `up=1` di `build_atlas.py`
(atlas units menjadi 4x lebih kecil, sprite sedikit lebih lembut).
**Belum diuji di HP fisik.**

## 8. Kalau ada yang aneh

| Gejala | Penyebab umum |
|---|---|
| Semua kembali berbentuk lingkaran/kotak | atlas gagal dimuat: lihat log "Atlas tidak ditemukan"; jalankan `python tools/build_atlas.py` lalu buka Godot sekali |
| Satu kendaraan berupa kotak vektor | nama sprite di `sprite_defs.gd` tidak ada di `atlas_spec.py` |
| Turret melayang / bergeser | atur `tpos`/`bpos` di `sprite_defs.gd` |
| Sprite buram / bergaris di tepi | sprite baru belum melewati `build_atlas.py` (jangan menambah PNG langsung ke atlas) |
| `python` tidak mengenal modul | `pip install pillow numpy soundfile soxr` |


## v14: sprite tambahan (semua dari paket FrontlineHeat_assets, daftar di `tools/atlas_spec.py`)
| Nama atlas | Sumber | Dipakai untuk |
|---|---|---|
| `veh/us_lav`, `veh/ru_btr` | LAV-25 (tan/hijau), BTR-82A | APC |
| `veh/us_m109`, `veh/ru_2s3` | M109A6 Paladin, 2S3 Akatsiya | SPG howitzer |
| `veh/us_medevac`, `veh/ru_ural` | Stryker M1133, Ural-4320 | MEDEVAC |
| `veh/us_himars`, `veh/ru_uragan` | HIMARS, 9A53 Uragan-1M | peluncur MLRS panggilan radio |
| `air/c17` | C-17 (diperkecil ke 180 px, lampu navigasi mengikuti warna tim) | bantuan terjun payung |
| `fx/canopy`, `fx/crate_med`, `fx/crate` | air_para/paradrop | kanopi penerjun, peti medis (salib hijau), peti amunisi |
| `fx/rocket` | projectile_ammo | roket MLRS |
Atlas unit kini 1024x1536 (~6 MB VRAM). Bangkai kendaraan baru disimpan 1x (bukan 2x) untuk menghemat memori.
Skala gambar semua kendaraan dikalikan `Cfg.VEH_SCALE`; tambahkan kendaraan baru dengan mengisi `SpriteDefs.VEHICLES` (skala, `tpos` turret, `bpos` laras).
