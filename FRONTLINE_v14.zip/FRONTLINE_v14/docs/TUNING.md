# Panduan tuning (semua di scripts/data/cfg.gd)

| Ingin... | Ubah |
|---|---|
| Lebih banyak/sedikit AI | `AI_COUNT` (per tim, untuk SEDIKIT/SEDANG/BANYAK/EPIK) |
| Misi lebih panjang | `TICKET_BASE`, `TICKET_PER_AI`, `LENGTH_MULT` |
| Musuh lebih akurat | `AI_BASE_SPREAD`, `AI_SPREAD_PER_PX`, `DIFF_AIM` |
| Musuh bereaksi lebih cepat | `AI_REACT_MIN/MAX`, `DIFF_REACT` |
| AI lebih gigih / lebih penakut | `AI_RETREAT_HP`, `AI_RECOVER_HP` (di Unit: peluang `stubborn` di `Game.spawn_ai`) |
| Rentetan tembakan AI | `AI_BURST_MIN/MAX`, `AI_BURST_PAUSE` |
| Regu lebih besar/rapat | `SQUAD_SIZE`, `SQUAD_SPREAD` |
| Lebih/kurang kejadian acak | `CHAOS_MULT`, `DIR_EVENT_GAP`, `DIR_AMBIENT_SHELL_GAP`, `DIR_FLYOVER_GAP`, `DIR_CALM_TIME` |
| Efek lebih ringan di HP lawas | `MAX_FX`, `FX_DIST`, `AI_FAR_THINK`, `AI_NEAR_THINK` (indeks 0/1/2 = tinggi/sedang/rendah) |
| Kendaraan | `VEH_HP`, `VEH_SPEED`, `VEH_COOLDOWN`, `VEH_RESPAWN` |
| Buka divisi lebih cepat | `CLASS_NEED` |
| **v13** AI menghindar strike lagi | `AI_DODGE_DANGER = true` (+ `DANGER_FLEE_PAD`) |
| Peluru meleset jatuh lebih dekat/jauh dari sasaran | `GROUND_OVERSHOOT`, `SHELL_DEFAULT_RANGE` |
| Seberapa mematikan peluru ledak | `DIRECT_DMG` (kena langsung), `BLAST_RADIUS`, `BLAST_DMG` (splash) per jenis peluru |
| Kendaraan lebih kuat/lemah | `VEH_HP`, `RIFLE_DMG_VEH`, `VEH_SPLASH_RESIST`, `VEH_GUN_DMG`, `GUNNER_DMG`, `VEH_CRUSH_DMG`, `VEH_CRUSH_SPEED` |
| Tank AI lebih jarang menembak | `AI_VEH_FIRE_GAP`; jarak berhenti/mundur: `STOP_DIST`, `BACK_DIST` di `ai_vehicle.gd` |
| Strike AI lebih sering/jarang | `AI_RADIO_CD`, `AI_RADIO_TEAM_GAP` (barrage radio), `DIR_AMBIENT_SHELL_GAP`, `DIR_AMBIENT_DMG` (artileri ambient) |
| Granat AI | `AI_GRENADE_CD`, `AI_GRENADE_OPEN_CHANCE` |
| Tekanan tembakan (merunduk) | `SUPPRESS_PIN`, `SUPPRESS_NEAR`, `SUPPRESS_ADD`, `SUPPRESS_DECAY` |
| Taktik regu | `AI_BOUND_PERIOD` (lompat-maju), `AI_FLANK_*` (mengitari), `AI_PAUSE_CHANCE`, `AI_PACE`, `AI_BLIND_FIRE_TIME` |
| Lamanya pertandingan | `TICKET_PER_AI`; ukur tempo dengan `tests/pace_test.gd` |

| **v14** Kendaraan lebih besar/kecil | `VEH_SCALE` (gambar), `VEH_RADIUS`/`VEH_MUZZLE` (tabrakan), `NAV_VEH_CLEAR` (jarak aman jalur AI) |
| Skill kendaraan | `VEH_SKILL_CD`, `VEH_SKILL_BOOST`, `VEH_BOOST_TIME`, `VEH_BOOST_MULT`, `VEH_SMOKE_RADIUS/TIME`, `VEH_LIMP_HP/MULT` |
| MEDEVAC | `MEDEVAC_RADIUS`, `MEDEVAC_HEAL`, `MEDEVAC_IDLE_SPEED` |
| Howitzer / peluru asap | `BLAST_RADIUS[6]`, `BLAST_DMG[6]`, `BUL_SPEED[6]`, `ARTY_DEFAULT_RANGE`, `ARTY_AIM_RANGE`, `VEH_COOLDOWN[SPG]` |
| C-17 terjun payung | `PARADROP_COUNT`, `PARADROP_CD`, `PARADROP_PLANE_SPEED`, `PARADROP_FALL`, `PARADROP_SPREAD`, `PARADROP_CRATES` |
| MLRS | `MLRS_ROCKETS`, `MLRS_CD`, `MLRS_WARMUP`, `MLRS_FIRE_GAP`, `MLRS_RADIUS`, `MLRS_ROCKET_RADIUS/DMG`, `MLRS_STANDOFF`, `AI_MLRS_CHANCE` |
| Peti suplai & kill streak | `CRATE_LIFE`, `CRATE_HEAL`, `CRATE_GRENADES`, `CRATE_BUILD_POINTS`, `SUPPLY_CD`, `STREAK_REWARD_EVERY`, `STREAK_BUILD_POINTS` |
| Frekuensi MLRS/C-17 acak (Director) | pembagian peluang di `Director._big_event` (artileri .30, jet .22, MLRS .14, bantuan .34) |

**Catatan keseimbangan v13**: peluru kini benar-benar mengenai, jadi tempo gugur naik dari ~64 ke ~107 per menit (terukur dengan
`pace_test.gd`, 8 seed x 120 dtk). `TICKET_PER_AI` dinaikkan 7 -> 11 supaya lama pertandingan tetap sekitar 7-8 menit. Ubah salah satu
dari `AI_BASE_SPREAD`/`DIRECT_DMG`/`AI_RADIO_*` lalu jalankan ulang `pace_test.gd` agar tempo tidak bergeser tanpa disadari.

Setelah mengubah angka, jalankan `godot --headless --path . --script tests/sim_test.gd -- 2 240 1`
untuk melihat dampaknya (tiket, perebutan bendera, waktu simulasi per frame).
