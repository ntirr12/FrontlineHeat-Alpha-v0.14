# Kredit & catatan lisensi aset

Kode game FRONTLINE: proyek ini.

## PENTING sebelum rilis publik / komersial
Aset gambar dan suara berasal dari **paket aset `frontline_assets`** yang menurut README-nya "berasal dari game/mod
pihak lain (musik oleh Avery Alexander, peta oleh "Snob", sprite dari para modder)" dan menyarankan
**memeriksa izin/lisensi sebelum dirilis publik**. Paket ini bergaya game Rusted Warfare dan modnya.
Proyek ini TIDAK memiliki bukti izin tersebut. Sebelum merilis di toko aplikasi:
1. Pastikan hak pakai tiap aset (hubungi pembuat / pemilik game asli, atau ganti dengan aset berlisensi jelas).
2. Mengganti aset itu mudah: lihat `docs/ASET.md` (cukup ganti PNG/WAV lalu bangun ulang atlas).

## Yang diketahui dari paket
- Musik `assets/audio/music/*.ogg`: *Action A-10* dan *Tactical Invasion* oleh **Avery Alexander**.
- Peta (tidak dipakai di proyek ini): oleh "Snob".
- Sprite sumber memuat tulisan "snob" pada tank `m1aX`; tulisan itu dihapus otomatis saat build atlas.

## Aset yang dipakai (ringkas)
Sprite: `art_src/` (sebagian kecil dari paket). Suara: lihat tabel di `tools/build_audio.py`.
Font, ikon aplikasi, dan seluruh kode berasal dari proyek FRONTLINE.
