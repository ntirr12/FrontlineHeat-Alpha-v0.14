# Arsitektur FRONTLINE

## 1. Alur satu frame
`Game._process` -> `Game.sim(dt)` (scripts/main.gd), urutannya:

1. `input.update()` - analog/tombol -> `move`, `aim`, `fire`
2. `planner.update()` - tiap 2,5 dtk bagi regu AI ke bendera
3. `_update_spawns()` - spawn AI (maks `Cfg.AI_COUNT[...]` per tim)
4. `director.update()` - kejadian acak (artileri, jet, MLRS, C-17 terjun, tarik aksi ke pemain)
5. Setiap prajurit: `infantry.tick` (timer) lalu `brain.update` (AI) atau `player_ctl.update` (pemain)
6. Kendaraan, turret, bendera/tiket, benda pendukung (granat, airstrike, drone), `air.update` (C-17, MLRS, peti)
7. `grid.rebuild` -> `combat.update_bullets` -> efek -> kamera

Tampilan terpisah dari simulasi: `view_root` (kamera) berisi `TerrainView` (statis) / `DecalView` / `BattleView`;
`CanvasLayer` berisi `Hud` dan `Menus`. Simulasi bisa jalan tanpa tampilan (dipakai tes headless).

## 2. Otak AI (scripts/ai/ai_brain.gd)
`think(u)` (berkala 0,12-0,9 dtk) memilih **state**; `_act(u, dt)` (tiap frame) menjalankannya.

| State | Arti |
|---|---|
| DODGE | **nonaktif sejak v13** (`Cfg.AI_DODGE_DANGER`): AI tidak lari dari strike. Nilai enum dipertahankan agar tes lama tidak bergeser |
| RETREAT | HP < `AI_RETREAT_HP`: mundur ke tempat berlindung / bendera sendiri sampai pulih |
| EVADE | ada kendaraan musuh dan tak punya Javelin: berlindung/menjauh, lempar granat |
| COVER | di balik tembok/gedung, mengintip bergantian; juga dipilih saat **tertekan tembakan** (suppression) |
| ENGAGE | membidik, menembak per rentetan **sambil berdiri**, bergerak di jeda rentetan; lompat-maju bergantian; satu anggota mengitari |
| HUNT | musuh hilang: cek posisi terakhir terlihat; beberapa detik pertama menembak penekan ke titik itu |
| CAPTURE / ADVANCE | di dalam lingkaran bendera / bergerak ke tujuan regu |
| BOARD / SPY | naik kendaraan / perilaku Spy |

Regu (`Squad`): pemimpin mencari jalur, anggota mengikuti dengan formasi; pemimpin menunggu anggota yang tertinggal.
Pengemudi kendaraan menjadi regu tunggal (`AiPlanner.make_solo`).

## 2b. Alur satu peluru (v13, scripts/systems/combat.gd)
1. `shoot()` membuat peluru. Bila penembak membidik sasaran (`land_dist`), umur peluru dipas supaya jatuh di sekitar sasaran
   (`Cfg.GROUND_OVERSHOOT`). AI memberi `u.aim_point` (otak AI), pemain memakai `aim_distance_for()` (musuh terdekat di garis bidik).
2. `_step_bullet()` menyapu segmen `prev -> pos`: gedung (`World.bullet_sweep`), prajurit (`_sweep_infantry`), kendaraan, turret.
   Tabrakan **paling awal** menang. Tabrakan lewat `_seg_circle` (garis vs lingkaran).
3. Kena: senapan = `Cfg.RIFLE_DMG * dmg_mult`; peluru ledak = `Cfg.DIRECT_DMG[kind]` ke sasaran + `explode()` untuk sekitarnya
   (sasaran langsung dikecualikan agar tidak dihitung dua kali). Karung pasir/dinding menghentikan peluru (`Vfx.Surf.COVER`).
4. Tidak kena: habis umur = jatuh ke tanah -> `Vfx.impact(GROUND)` (senapan) atau `explode()` (peluru ledak, damage splash).
5. Peluru yang lewat dekat AI menambah `u.suppress`; ledakan dekat juga. `suppress` tinggi = merunduk/cari cover & kurang akurat.

## 2c. Efek pertempuran (v13, scripts/systems/vfx.gd)
`Vfx` hanya menyusun efek dari `Fx` pool (jenis baru: DUST, FLAME, DEBRIS, TURRET, BODY, FLASH, EMBER). Peristiwa tertunda
(ledakan susulan, turret mendarat) memakai antrean `Vfx.Evt`. Satu-satunya efek yang memengaruhi permainan adalah ledakan
susulan kecil bangkai (`POP`). `Combat.explode()` memanggil `Vfx.blast()`; `VehicleSys.damage()` memanggil `Vfx.vehicle_destroyed()`.
Posisi semburan api tiap kendaraan = `Vfx.HATCHES`. Pool membuang efek kecil lebih dulu saat 75% penuh (`Fx.LOW_PRIORITY`).

## 2d. Bantuan udara & artileri (v14, scripts/systems/air_support.gd + render/air_view.gd)
`AirSupport` (`Game.air`) memegang tiga fitur yang dipanggil lewat radio; datanya disimpan di `Game` (`airlifts`, `chutes`, `crates`, `salvos`, `rockets`)
dengan kelas di `entities/battle_objects.gd` (`BO.Airlift/Chute/Crate/Salvo/Rocket`). `Game.sim()` memanggil `air.update(dt)` sekali per frame.
- **C-17**: `call_airlift(dz, team, by_player)` -> pesawat terbang lurus lewat titik terjun -> `_release()` melepas penerjun (`BO.Chute`) -> `_land_chute()` membuat prajurit
  AI lewat `Game.spawn_ai` dan menutup regu (`planner.close_open`). Pemanggil: pemain (`Support._use_air_support`) dan Director (`_reinforcement`).
- **MLRS**: `call_mlrs(target, team, by_player)` -> `BO.Salvo` (peluncur masuk, bersiap `MLRS_WARMUP`) -> `_launch()` membuat `BO.Rocket` (lengkung dari peluncur ke titik acak
  dalam oval) -> `_update_rockets()` meledakkan lewat `Combat.explode`. Pemanggil: pemain, AI Support (`AI_MLRS_CHANCE`), Director (`_mlrs_salvo`).
- **Peti**: `spawn_crate()` -> `_update_crates()` memberi HP/amunisi pada prajurit sekutu yang membutuhkannya.
- `AirView` (anak `view_root`, di atas `BattleView`) hanya menggambar. Urutan gambar PER TEKSTUR: 1) cakram lembut 2) atlas efek 3) atlas unit 4) garis/teks.
  `refresh()` berhenti menggambar bila semua daftar kosong.
Kendaraan v14 (skill, MEDEVAC, pincang) ada di `VehicleSys` (`vehicle_skill`, `_medevac_tick`, `drive`); peluru lengkung di `Combat._step_bullet` (cabang `BUL_ARC`).

## 3. Cara menambah sesuatu
- **Divisi baru**: tambah entri di tiap array `CLASS_*` di `cfg.gd` (+ `CLASS_ITEMS`, `LOCK_TIME`, `CLASS_DESC`), isi perilaku senjata di
  `infantry.gd`, tambahkan ke `Cfg.Cls`. Jangan lupa `IDEAL`/`FIRE_RANGE` di `ai_brain.gd`.
- **Kendaraan baru**: tambah ke enum `Cfg.Veh` (di AKHIR) dan SEMUA array `VEH_*` (panjangnya harus = `VEH_COUNT`; `tests/air_test.gd` memeriksanya), `STOP_DIST/BACK_DIST/ENGAGE_DIST`
  di `ai_vehicle.gd`, `Vfx.HATCHES`; gambar vektor di `BattleView._draw_vehicle`, tampilan sprite di `SpriteDefs.VEHICLES` (+ sprite di `tools/atlas_spec.py`, lalu `python tools/build_atlas.py`).
- **Item baru**: enum `Cfg.Item`, array `ITEM_*`, lalu case di `Support.use_item`.
- **Perilaku AI baru**: tambah nilai di `AiBrain.State`, pilih di `_choose_state`, jalankan di `_act` (satu fungsi `_act_xxx`).
- **Kejadian Director baru**: fungsi baru di `director.gd`, panggil dari `_big_event`.
- **Opsi menu baru**: tambah variabel di `prefs.gd` (+ load/save), baris di `Menus._setting_rows`, nilai di `_setting_value`, dan case di `Menus._do`.

## 3b. Lapisan aset (v12)
Gameplay **tidak tahu** ada sprite. Hanya `scripts/render/` dan `scripts/audio/` yang menyentuh aset:
`Game.sprites` (SpriteBank) disusun tiap `start_match()`, lalu `BattleView`/`TerrainView`/`DecalView` memakainya.
Setiap fungsi gambar punya dua jalur: **sprite** lalu **vektor lama** (fallback). Detail: `docs/ASET.md`.
- Efek bersprite lewat jenis `Fx.Type.EXPLOSION / MUZZLE / BLOOD`. Pemanggil `g.fx.spawn(...)` tidak berubah selain parameter jenis.
- Audio: `AudioDefs` memetakan nomor suara -> sampel; nomor tanpa sampel dibangkitkan `Synth.make(i)`.

## 4. Optimasi yang dipakai (jangan dihapus tanpa ukur)
- `TerrainView`: peta dipotong 1024px, tiap potongan digambar sekali; hanya digambar ulang saat tembok berubah.
- Pool: peluru (`Combat`), efek (`FxPool`); tidak ada alokasi saat tempur ramai.
- `SpatialGrid`: kueri musuh/peluru per sel, bukan semua prajurit.
- `World.los`: marching di grid 32px (bukan loop semua gedung).
- A*: dibagi per regu + anggaran per frame (`AiNav.budget`).
- LOD AI: prajurit jauh dari pemain berpikir lebih jarang (`Cfg.AI_FAR_THINK`) dan update tiap 2-3 frame.
- Governor kualitas (`Game._governor`): turunkan efek dulu, jumlah AI paling akhir.
- v12: sprite digabung dalam atlas (sedikit draw-call); warna tim dibake & skin dipilih sekali per pertandingan;
  `SpriteBank` menyimpan objek siap pakai (tanpa operasi teks per frame); bayangan, goyang jalan, dan api bangkai
  hanya di kualitas TINGGI/SEDANG; SFX WAV mono tanpa dekoding; musik OGG (tanpa thread sintesis).
- **v13 - aturan menggambar (hasil ukur Godot 4.7.2 GL Compatibility)**: `draw_circle`/`draw_arc` SELALU 1 draw call sendiri;
  kotak/garis/sprite bertekstur sama yang BERURUTAN digabung jadi 1 draw call; selang-seling jenis atau tekstur memutus gabungan;
  `draw_set_transform` tidak memutus gabungan. Karena itu `TerrainView.paint`, `BattleView` (prajurit, kendaraan, efek) dan `Hud`
  menggambar PER LAPIS (semua bayangan, lalu semua cakram, lalu semua badan...) dan mengganti lingkaran/cincin dengan quad
  bertekstur dari `Gfx.soft_disc/disc_hard/ring/flame/glow` (GradientTexture2D, dihitung native). Ikon tombol HUD dibake sekali
  (`IconAtlas`). **Saat menambah gambar baru: kelompokkan per jenis, jangan menyelipkan draw_circle di antara sprite.**
  Ukur dengan `tests/render_bench.gd`; mundur ke gambar vektor otomatis bila atlas/tekstur tidak ada.
- v13: `SpatialGrid.cell/query` tidak lagi membuat array kosong; `World.bullet_sweep` memakai grid 32px sebelum tes persegi gedung;
  `Combat.death_stats` (hanya saat `profile_on`) memberi rincian sumber kematian untuk menyetel keseimbangan.
