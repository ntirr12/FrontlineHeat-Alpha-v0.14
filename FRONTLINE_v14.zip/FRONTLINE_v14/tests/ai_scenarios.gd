extends SceneTree
## Skenario perilaku AI (headless). Mencetak metrik; bukan lulus/gagal ketat tapi ada ambang peringatan.
var g: Game

func step(n: int) -> void:
	for i in n:
		g.time += 1.0 / 30.0
		g.frame += 1
		g.sim(1.0 / 30.0)

func _initialize() -> void:
	g = load("res://main.tscn").instantiate()
	root.add_child(g)
	await process_frame
	g.prefs.ai_count = 2
	g.prefs.quality = 1
	g.prefs.chaos = 0
	g.start_match()
	g.pick_class(0)
	g.player.pos = Vector2(5000, 100)           # pemain menjauh dari aksi
	g.dev = true
	g.cheats["god"] = true
	seed(11)
	# ---------- 1. kekompakan regu saat maju + mobilitas kendaraan
	var coh_sum := 0.0
	var coh_n := 0
	var veh_start := {}
	for v in g.vehicles:
		veh_start[v] = v.pos
	for s in 60:
		step(30)
		for sq in g.planner.squads:
			if sq.size() >= 3 and sq.leader != null and not sq.solo:
				for m in sq.members:
					if m != sq.leader and m.state == AiBrain.State.ADVANCE and m.hp > 0.0 and m.mount == null:
						coh_sum += m.pos.distance_to(sq.leader.pos)
						coh_n += 1
	print("1. KEKOMPAKAN REGU: jarak rata2 anggota-ke-pemimpin saat ADVANCE = %.0f px (n=%d)  [ideal < 250]" % [coh_sum / maxf(1.0, coh_n), coh_n])
	var moved := 0.0
	var alive_v := 0
	for v in g.vehicles:
		if not v.dead and v.driver != null and v.driver.is_ai:
			alive_v += 1
			moved += v.pos.distance_to(veh_start[v])
	print("2. KENDARAAN: %d berawak AI, jarak dari titik awal rata2 %.0f px setelah 60 dtk" % [alive_v, moved / maxf(1.0, alive_v)])
	# ---------- 3. TIDAK menghindar dari strike (v13: AI tidak "tahu" bom akan jatuh; dulu skenario ini mengukur kabur dari zona bahaya)
	var best: Squad = null
	for sq in g.planner.squads:
		if sq.size() >= 3 and sq.team == 2 and sq.leader.mount == null and (best == null or sq.size() > best.size()):
			best = sq
	if best != null:
		var c := best.leader.pos
		var inside: Array[Unit] = []
		for m in best.members:
			if m.pos.distance_to(c) < 200.0 and m.mount == null:
				inside.append(m)
		g.alerts.clear()
		g.support.call_barrage(c, 1, false, 12, 160.0, false, Vector2.RIGHT)       # strike NYATA tim 1 di atas regu merah
		var dodged := 0
		for i in 45:
			step(1)
			for m in inside:
				if m.hp > 0.0 and m.state == AiBrain.State.DODGE:
					dodged += 1
		var staying := 0
		for m in inside:
			if m.hp <= 0.0 or m.pos.distance_to(c) < 160.0 + 60.0:
				staying += 1
		print("3. TIDAK MENGHINDAR STRIKE: state DODGE=%d (harus 0)  alert dibuat=%d (harus 0)  masih di sekitar titik serangan/gugur: %d/%d" % [dodged, g.alerts.size(), staying, inside.size()])
	# ---------- 4. mundur & pulih
	var retreat_started := 0
	var healed := 0
	var died_retreating := 0
	var died_later := 0
	var timed_out := 0
	var tracked := {}
	var starts := {}
	var hist := [0, 0, 0, 0]
	for s in 120:
		step(30)
		for u in g.units:
			if not u.is_ai or u.hp <= 0.0:
				continue
			if u.retreating and not tracked.has(u.slot_id):
				tracked[u.slot_id] = u
				starts[u.slot_id] = g.time
				retreat_started += 1
		for id in tracked.keys():
			var u: Unit = tracked[id]
			if u.hp <= 0.0:
				if u.retreating:
					died_retreating += 1
					var life: float = g.time - starts[id]
					hist[0 if life < 1.5 else (1 if life < 4.0 else (2 if life < 8.0 else 3))] += 1
				else:
					died_later += 1
				tracked.erase(id)
			elif not u.retreating:
				if u.hp >= u.max_hp * Cfg.AI_RECOVER_HP:
					healed += 1
				else:
					timed_out += 1
				tracked.erase(id)
	print("4. MUNDUR: mulai=%d  pulih=%d  selesai-belum-pulih=%d  gugur-saat-mundur=%d  (gugur-setelahnya=%d) umur-setelah-mulai-mundur <1.5s:%d 1.5-4s:%d 4-8s:%d >8s:%d" % [retreat_started, healed, timed_out, died_retreating, died_later, hist[0], hist[1], hist[2], hist[3]])
	# ---------- 5. rasio state selama 2 menit
	var cnt := {}
	var tot := 0
	for s in 60:
		step(30)
		for u in g.units:
			if u.is_ai and u.hp > 0.0 and u.mount == null:
				cnt[u.state] = cnt.get(u.state, 0) + 1
				tot += 1
	var names := ["ADVANCE", "ENGAGE", "COVER", "HUNT", "RETREAT", "CAPTURE", "DODGE", "EVADE", "BOARD", "SPY"]
	var line := ""
	for k in cnt.keys():
		line += "%s=%.0f%% " % [names[k], 100.0 * cnt[k] / tot]
	print("5. DISTRIBUSI STATE: ", line)
	quit()
