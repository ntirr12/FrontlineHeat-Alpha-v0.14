extends SceneTree
## TES SISTEM TEMPUR v13: hit registration, titik jatuh peluru, kena langsung vs splash, kendaraan, cook-off, AI tidak menghindar strike.
## Tiap tes diisolasi: peluru dijalankan manual lewat Combat.update_bullets (tanpa sim penuh) supaya hasilnya pasti.
##   godot --headless --path . --script tests/combat_test.gd
var fails := 0
var g: Game

func check(name: String, ok: bool, detail := "") -> void:
	print(("  [LULUS] " if ok else "  [GAGAL] ") + name + ("  (" + detail + ")" if detail != "" else ""))
	if not ok:
		fails += 1

func _frames(n: int) -> void:
	for i in n:
		await process_frame

## Ambil satu prajurit musuh (tim 2), kosongkan sekitarnya, buat kebal & diam di titik p.
func _dummy(p: Vector2, team := 2) -> Unit:
	for u in g.units:
		if u.team == team and u.mount == null and u.hp > 0.0:
			u.pos = p
			u.hp = 1e7
			u.max_hp = 1e7
			u.in_cover = false
			u.in_bunker = false
			return u
	return null

func _park_others(except: Array) -> void:
	for u in g.units:
		if not except.has(u):
			u.pos = Vector2(100 + randf() * 200, 100 + randf() * 200)     # jauhkan semua yang lain ke pojok peta
	for v in g.vehicles:
		if not except.has(v):
			v.pos = Vector2(200, 2800)
			v.home = v.pos
	g.grid.rebuild(g.units)

func _run_bullets(secs: float, dt := 1.0 / 30.0) -> void:
	var t := 0.0
	while t < secs:
		g.grid.rebuild(g.units)
		g.combat.update_bullets(dt)
		g.vfx.update(dt)
		g.fx.update(dt)
		t += dt

func _initialize() -> void:
	g = load("res://main.tscn").instantiate()
	root.add_child(g)
	await _frames(5)
	seed(5)
	g.prefs.ai_count = 0
	g.prefs.quality = 1
	g.prefs.chaos = 0
	g.start_match()
	g.pick_class(0)
	g.dev = true
	g.cheats["god"] = true
	await _frames(3)
	var A := Vector2(2600, 1500)

	print("== 1. Peluru TIDAK menembus sasaran (frame lambat 20 FPS, tanpa sebaran) ==")
	var tgt := _dummy(A + Vector2(300, 0))
	_park_others([tgt])
	var hp0 := tgt.hp
	var shots := 400
	for i in shots:
		g.combat.shoot(A, 0.0, 1, Cfg.Bul.RIFLE, null, false)
	_run_bullets(1.0, 1.0 / 20.0)
	var hits := int(round((hp0 - tgt.hp) / Cfg.RIFLE_DMG))
	check("semua peluru lurus mengenai sasaran 300px", hits >= int(shots * .98), "kena %d/%d" % [hits, shots])
	_run_bullets(.05, 1.0 / 20.0)
	check("tidak ada peluru tersisa melayang", g.combat.bullets.size() == 0, "sisa %d" % g.combat.bullets.size())

	print("== 2. Peluru meleset jatuh ke TANAH di sekitar sasaran ==")
	_park_others([])
	var spread_ok := true
	var maxd := 0.0
	var mind := 1e9
	for i in 300:
		var b := g.combat.shoot(A, randf_range(-.4, .4), 1, Cfg.Bul.RIFLE, null, false, 300.0)
		var reach := b.life * Cfg.BUL_SPEED[Cfg.Bul.RIFLE]
		maxd = maxf(maxd, reach)
		mind = minf(mind, reach)
	check("jarak jatuh dalam rentang sasaran %.0f..%.0f" % [300 + Cfg.GROUND_OVERSHOOT.x, 300 + Cfg.GROUND_OVERSHOOT.y],
			mind >= 300 + Cfg.GROUND_OVERSHOOT.x - 1.0 and maxd <= 300 + Cfg.GROUND_OVERSHOOT.y + 1.0, "min %.0f maks %.0f" % [mind, maxd])
	var dust0 := 0
	g.cam = A + Vector2(150, 0)
	g.fx.cam_pos = g.cam
	_run_bullets(.30)                                       # peluru mendarat di ~0,26-0,34 dtk (300px / 1100 px/dtk)
	for f in g.fx.active:
		if f.type == Fx.Type.DUST:
			dust0 += 1
	check("ada debu hantaman di tanah di sekitar titik jatuh", dust0 > 0, "debu aktif %d" % dust0)
	_run_bullets(.5)
	check("semua peluru berakhir (tidak terbang sampai ujung peta)", g.combat.bullets.size() == 0, "sisa %d" % g.combat.bullets.size())

	print("== 3. Peluru meriam meleset 45px dari sasaran: tetap kena SPLASH ==")
	var t3 := _dummy(A + Vector2(400, 45))
	_park_others([t3])
	hp0 = t3.hp
	g.combat.shoot(A, 0.0, 1, Cfg.Bul.SHELL, null, false, 400.0)
	var sb := g.combat.bullets[0]
	sb.life = 400.0 / Cfg.BUL_SPEED[Cfg.Bul.SHELL]                                # pas jatuh di depan sasaran (tanpa overshoot acak)
	_run_bullets(1.2)
	check("sasaran di dekat titik jatuh kena kerusakan ledakan", t3.hp < hp0, "kerusakan %.0f" % (hp0 - t3.hp))

	print("== 4. KENA LANGSUNG: kerusakan = DIRECT_DMG, tidak ganda dengan splash ==")
	_park_others([])
	var tank: Vehicle = null
	for v in g.vehicles:
		if v.kind == Cfg.Veh.TANK and v.team == 2:
			tank = v
	tank.pos = A + Vector2(300, 0)
	tank.dead = false
	tank.hp = tank.max_hp
	g.combat.shoot(A, 0.0, 1, Cfg.Bul.SHELL, null, false)
	_run_bullets(1.0)
	var dmg := tank.max_hp - tank.hp
	check("tank kena 1 peluru meriam = %.0f" % Cfg.DIRECT_DMG[Cfg.Bul.SHELL], absf(dmg - Cfg.DIRECT_DMG[Cfg.Bul.SHELL]) < 1.0, "kerusakan %.1f" % dmg)

	print("== 5. Buff kendaraan ==")
	check("HP tank >= 800", Cfg.VEH_HP[Cfg.Veh.TANK] >= 800.0, "%.0f" % Cfg.VEH_HP[Cfg.Veh.TANK])
	tank.hp = tank.max_hp
	g.combat.explode(tank.pos + Vector2(40, 0), 120.0, 140.0, 1, false)
	var gd := tank.max_hp - tank.hp
	check("granat ke tank diredam armor (<60% dari 140)", gd > 0.0 and gd < 140.0 * .6, "kerusakan %.1f" % gd)
	check("peluru senapan nyaris tidak melukai tank (<1 per peluru)", Cfg.RIFLE_DMG_VEH[Cfg.Veh.TANK] < 1.0)

	print("== 6. Tank hancur: semburan api, turret terlempar, ledakan susulan ==")
	g.fx.clear()
	var decals0 := g.decals.size()
	tank.hp = tank.max_hp
	g.vehicle_sys.damage(tank, 99999.0)
	var kinds := {}
	for f in g.fx.active:
		kinds[f.type] = true
	check("bola api & kilatan", kinds.has(Fx.Type.EXPLOSION) and kinds.has(Fx.Type.FLASH))
	check("semburan api (FLAME)", kinds.has(Fx.Type.FLAME))
	check("turret terlempar (TURRET)", kinds.has(Fx.Type.TURRET))
	_run_bullets(1.6)
	var still_turret := false
	for f in g.fx.active:
		if f.type == Fx.Type.TURRET:
			still_turret = true
	check("turret sudah mendarat", not still_turret)
	check("turret meninggalkan kawah/bekas", g.decals.size() > decals0)

	print("== 7. AI TIDAK menghindar dari strike ==")
	check("zona bahaya tidak dibuat (AI tidak 'tahu')", Cfg.AI_DODGE_DANGER == false)
	var u7 := _dummy(A, 2)
	_park_others([u7])
	g.alerts.clear()
	g.support.call_barrage(A, 1, false, 10, 200.0, false, Vector2.RIGHT)
	check("call_barrage tidak membuat alert", g.alerts.size() == 0, "alert %d" % g.alerts.size())
	var dodged := false
	for i in 90:
		g.sim(1.0 / 30.0)
		if u7.state == AiBrain.State.DODGE:
			dodged = true
	check("prajurit di titik jatuh tidak pernah masuk state DODGE", not dodged)

	print("== 8. Tekanan tembakan (suppression) ==")
	var u8 := _dummy(A, 2)
	u8.is_ai = true
	_park_others([u8])
	u8.suppress = 0.0
	for i in 5:
		g.combat.shoot(A + Vector2(-200, 24), 0.0, 1, Cfg.Bul.RIFLE, null, false)     # lewat 24px dari badan: nyaris kena
	_run_bullets(.6)
	check("peluru yang nyaris kena menekan AI", u8.suppress > .5, "suppress %.2f" % u8.suppress)

	print("== 9. Melindas ==")
	var u9 := _dummy(A + Vector2(5, 0), 3 - tank.team)      # korban = tim lawan tank
	u9.hp = 100.0
	u9.max_hp = 100.0
	_park_others([u9, tank])
	tank.dead = false
	tank.hp = tank.max_hp
	tank.pos = A
	tank.speed = 150.0
	var drv: Unit = null
	for u in g.units:
		if u.team == tank.team and u != g.player and u != u9:
			drv = u
	tank.driver = drv
	g.grid.rebuild(g.units)
	g.vehicle_sys._crush(tank, .3)
	check("kendaraan cepat melindas prajurit musuh (kerusakan %.0f)" % Cfg.VEH_CRUSH_DMG, u9.hp < 100.0, "hp %.0f" % u9.hp)
	tank.driver = null

	print("")
	print("HASIL: %s (%d gagal)" % ["SEMUA LULUS" if fails == 0 else "ADA YANG GAGAL", fails])
	quit(1 if fails > 0 else 0)
