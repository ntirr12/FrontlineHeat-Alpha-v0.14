extends SceneTree
## Tes fitur pemain tanpa render: tiap divisi, tiap item, kendaraan, drone, skill, analog tetap/melayang, menu.
## godot --headless --path . --script tests/player_test.gd
var g: Game
var fails := 0

func check(ok: bool, what: String) -> void:
	if ok:
		print("  ok   ", what)
	else:
		fails += 1
		print("  GAGAL ", what)

func step(n: int) -> void:
	for i in n:
		g.time += 1.0 / 30.0
		g.frame += 1
		g.sim(1.0 / 30.0)

func touch(role: int, base: Vector2, pos: Vector2, idx := 1) -> void:
	var t := TouchInput.Touch.new()
	t.role = role
	t.base = base
	t.pos = pos
	g.input.touches[idx] = t

func _initialize() -> void:
	g = load("res://main.tscn").instantiate()
	root.add_child(g)
	await process_frame
	g.dev = true
	g.cheats["god"] = true
	g.cheats["unl"] = true
	g.prefs.ai_count = 0
	g.prefs.quality = 1
	seed(7)
	g.start_match()
	print("== 1. Semua divisi: spawn, tembak, reload, item ==")
	for c in 8:
		g.pick_class(c)
		check(g.player != null and g.player.cls == c, "pick_class %s" % Cfg.CLASS_NAMES[c])
		g.player.pos = Objectives.base_pos(1) + Vector2(150, 0)
		g.prefs.fire_mode = 0
		touch(TouchInput.Role.AIM, Vector2(800, 500), Vector2(800 + 200, 500))
		var ammo0 := g.player.ammo
		var b0 := g.combat.bullets.size()
		step(12)
		check(g.input.fire, "  fire aktif saat analog bidik mentok")
		check(g.player.ammo < ammo0 or c == Cfg.Cls.JUGGERNAUT or g.player.reload_t > 0.0, "  amunisi berkurang")
		g.input.touches.clear()
		for it in Cfg.CLASS_ITEMS[c]:
			g.player_ctl.item = it
			g.player.build_points = 100.0
			g.player.radio_cd = 0.0
			g.player.c4 = 3
			g.player.grenades = [3, 3, 3, 3]
			g.player_ctl.release_throw(Vector2(.5, 0))
		step(40)
		check(g.player != null, "  item %d buah dipakai tanpa crash" % Cfg.CLASS_ITEMS[c].size())
		g.player_ctl.action(0)
		g.player_ctl.action(3)
		g.player_ctl.action(5)
		g.player_ctl.action(6)
		g.player_ctl.action(2)
		step(5)
		g.units.erase(g.player)
		g.player.hp = 0.0
		g.player = null
		g.selecting = true
	print("== 2. Kendaraan ==")
	g.pick_class(0)
	var v: Vehicle = null
	for x in g.vehicles:
		if x.team == 1 and x.kind == Cfg.Veh.TANK:
			v = x
	if v.dead:                                    # sejak v13 peluru meriam AI benar-benar mengenai: tank AI bisa sudah hancur di sini (hidup lagi setelah Cfg.VEH_RESPAWN)
		v.dead = false
		v.hp = v.max_hp
		v.pos = v.home
		v.speed = 0.0
	if v.driver != null:
		g.vehicle_sys.vacate(v.driver)
	g.player.pos = v.pos + Vector2(-30, 0)
	g.player_ctl.action(1)
	check(g.player.mount == v and v.driver == g.player, "naik tank")
	touch(TouchInput.Role.MOVE, Vector2(200, 500), Vector2(290, 500), 1)
	touch(TouchInput.Role.AIM, Vector2(800, 500), Vector2(1000, 500), 2)
	var x0 := v.pos.x
	step(60)
	check(v.pos.x > x0 + 20.0, "tank bergerak (%.0f px)" % (v.pos.x - x0))
	check(g.combat.bullets.size() > 0 or v.cooldown > 0.0, "tank menembak")
	g.input.touches.clear()
	g.player_ctl.action(1)
	check(g.player.mount == null, "turun dari tank")
	print("== 3. Drone FPV ==")
	var st: Structure = null
	for s in g.structs:
		if s.kind == Cfg.Item.DRONE_ST and s.team == 1 and (st == null or s.pos.distance_to(Objectives.base_pos(1) + Vector2(0, 190)) < st.pos.distance_to(Objectives.base_pos(1) + Vector2(0, 190))):
			st = s
	for q in g.turrets:
		if q.pos.distance_to(st.pos) < 150.0:
			q.dead = true
	g.player.pos = st.pos + Vector2(20, 0)
	st.timer = 0.0
	for x in g.vehicles:
		if x.pos.distance_to(st.pos) < 200.0:
			x.dead = true
	g.player_ctl.action(1)
	check(g.player_drone != null, "drone diluncurkan")
	touch(TouchInput.Role.AIM, Vector2(800, 500), Vector2(800, 700), 2)
	step(120)
	check(g.player_drone == null, "drone nyelonap & meledak")
	g.input.touches.clear()
	print("== 4. Analog melayang vs tetap ==")
	g.input.reset()
	g.prefs.stick_style = 0
	g.input.touch_down(5, Vector2(300, 400))
	g.input.touch_drag(5, Vector2(380, 400))
	g.input.update()
	check(g.input.move.x > .3, "MELAYANG: gerak kanan (%.2f)" % g.input.move.x)
	g.input.touch_up(5)
	g.prefs.stick_style = 1
	var mb := g.input.move_base()
	var consumed := g.input.touch_down(6, Vector2(900, 200))
	check(not consumed, "TETAP: sentuhan jauh dari analog diabaikan")
	g.input.touch_up(6)
	g.input.reset()
	g.input.touch_down(7, Vector2(mb.x + 20, mb.y))
	g.input.touch_drag(7, Vector2(mb.x + 100, mb.y))
	g.input.update()
	check(g.input.move.x > .3, "TETAP: gerak kanan dari posisi analog tetap (%.2f)" % g.input.move.x)
	g.input.touch_up(7)
	g.input.reset()
	g.prefs.fire_mode = 2
	var fp := g.input.fire_pos()
	g.input.touch_down(9, fp)
	g.input.update()
	check(g.input.fire and g.input.fire_hold_no_aim, "mode TOMBOL: tombol tembak aktif")
	g.input.touch_drag(9, fp + Vector2(60, 0))
	g.input.update()
	check(g.input.fire and g.input.aim.x > .9, "mode TOMBOL: geser = membidik sambil menembak")
	g.input.touch_up(9)
	g.input.reset()
	g.prefs.fire_mode = 1
	touch(TouchInput.Role.AIM, Vector2(800, 500), Vector2(800 + 50, 500))
	g.input.update()
	check(g.input.fire, "mode SENTUH: geser sedikit = tembak")
	g.input.reset()
	print("== 5. Menu & pengaturan ==")
	g.menus = null
	var m := Menus.new()
	m.g = g
	for id in ["c_ss", "c_fm", "t_af", "c_dz", "c_as", "c_res", "ai3", "ln2", "ch2", "df2", "bm1", "tab1"]:
		m._do(id)
	check(g.prefs.ai_count == 3 and g.prefs.match_length == 2 and g.prefs.chaos == 2, "preset misi tersimpan di Prefs")
	g.prefs.save_all()
	var p2 := Prefs.new()
	p2.load_all()
	check(p2.ai_count == 3 and p2.stick_style == g.prefs.stick_style and p2.auto_fire == g.prefs.auto_fire, "simpan/muat pengaturan baru")
	print("== 6. Selesai pertandingan ==")
	g.tickets[2] = 0
	step(2)
	check(g.mode == Game.Mode.OVER and g.win, "misi berakhir saat tiket musuh 0")
	print(("SEMUA TES LULUS" if fails == 0 else "TES GAGAL: %d" % fails))
	quit(1 if fails > 0 else 0)
