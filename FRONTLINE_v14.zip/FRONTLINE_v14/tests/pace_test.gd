extends SceneTree
## Tes TEMPO pertempuran: berapa prajurit gugur per menit (dari selisih tiket) dan berapa tembakan per kematian.
## Dipakai untuk memastikan perubahan akurasi/kerusakan tidak membuat pertandingan terlalu cepat/lambat.
## Pakai: godot --headless --path . --script tests/pace_test.gd -- [detik per seed] [jumlah seed]
func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	var total := float(args[0]) if args.size() > 0 else 150.0
	var seeds := int(args[1]) if args.size() > 1 else 3
	var g: Game = load("res://main.tscn").instantiate()
	root.add_child(g)
	await process_frame
	var sum_dpm := 0.0
	var sum_spk := 0.0
	for sd in seeds:
		seed(100 + sd)                       # seed SEBELUM start_match agar peta & jalannya pertandingan reproduksibel
		g.prefs.ai_count = 2
		g.prefs.quality = 1
		g.prefs.chaos = 1
		g.start_match()
		g.pick_class(0)
		g.player.pos = Vector2(5000, 100)
		g.dev = true
		g.profile_on = true
		g.combat.death_stats.clear()
		g.cheats["god"] = true
		var t0: int = g.tickets[1] + g.tickets[2]
		var shots := 0
		var t := 0.0
		var dt := 1.0 / 30.0
		var last_b := 0
		while t < total and g.mode != Game.Mode.OVER:
			g.time += dt
			g.frame += 1
			g.sim(dt)
			t += dt
		var lost: int = t0 - (g.tickets[1] + g.tickets[2])
		var dpm := lost / (t / 60.0)
		sum_dpm += dpm
		print("   sumber: ", g.combat.death_stats)
		print("seed %d: gugur=%d dalam %.0fs  => %.1f gugur/menit" % [sd, lost, t, dpm])
	print("RATA2 gugur/menit = %.1f" % (sum_dpm / seeds))
	quit()
