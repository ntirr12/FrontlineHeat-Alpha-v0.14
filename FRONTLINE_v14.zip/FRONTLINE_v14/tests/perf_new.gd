extends SceneTree
## Ukur biaya CPU skrip per frame: simulasi + semua skrip gambar (tanpa rasterisasi GPU).
## xvfb-run ... --script tests/perf_new.gd -- [ai_count 0..3] [kualitas 1..3]
func _initialize() -> void:
	var a := OS.get_cmdline_user_args()
	var g: Game = load("res://main.tscn").instantiate()
	root.add_child(g)
	for i in 3: await process_frame
	g.prefs.ai_count = int(a[0]) if a.size() > 0 else 1
	g.prefs.quality = int(a[1]) if a.size() > 1 else 2
	g.prefs.chaos = 1
	g.apply_settings()
	g.dev = true
	g.cheats["god"] = true
	g.start_match()
	g.pick_class(0)
	seed(5)
	for i in 800:                              # maju ~27 detik permainan tanpa render
		g.time += 1.0 / 30.0
		g.frame += 1
		g.sim(1.0 / 30.0)
	g.player.pos = g.objectives.flags[2].pos + Vector2(-150, 0)
	g.cam = g.player.pos
	for i in 20: await process_frame           # biarkan chunk peta tergambar pertama kali
	g.profile_on = true
	g.draw_us = 0
	g.prof.clear()
	var n := 60
	var t0 := Time.get_ticks_usec()
	var sim_us := 0
	for i in n:
		await process_frame
	var total := Time.get_ticks_usec() - t0
	var sim_total := 0
	for k in g.prof.keys():
		if not k.begins_with(" "):
			sim_total += g.prof[k][0]
	print("BARU AI=%d/tim kualitas=%d: simulasi=%.2f ms  gambar(skrip)=%.2f ms  per frame  (prajurit=%d, peluru=%d)" % [g.ai_cap(), g.quality_level + 1, sim_total / 1000.0 / n, g.draw_us / 1000.0 / n, g.units.size(), g.combat.bullets.size()])
	quit()
