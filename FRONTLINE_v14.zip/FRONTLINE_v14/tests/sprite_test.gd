extends SceneTree
## TES SPRITE v12: atlas termuat & sah, SEMUA nama di SpriteDefs ada di atlas (3 biome), fallback vektor aktif bila bank mati.
##   godot --headless --path . --script tests/sprite_test.gd
var fails := 0

func ok(cond: bool, msg: String) -> void:
	print(("  ok   " if cond else "  GAGAL ") + msg)
	if not cond:
		fails += 1

func _initialize() -> void:
	print("== 1. Atlas ==")
	ok(Cfg.USE_SPRITES, "Cfg.USE_SPRITES aktif")
	ok(SpriteLib.load_atlas(), "atlas termuat")
	ok(AtlasData.FILES.size() == AtlasData.UP.size(), "tiap atlas punya faktor upscale")
	var bad := 0
	for k in AtlasData.SPRITES:
		var a: Array = AtlasData.SPRITES[k]
		var tex := load(AtlasData.FILES[int(a[0])]) as Texture2D
		var tw := tex.get_width()
		var th := tex.get_height()
		if a[3] <= 0 or a[4] <= 0 or a[1] < 0 or a[2] < 0 or a[1] + a[3] > tw or a[2] + a[4] > th:
			bad += 1
			print("     di luar atlas: ", k)
	ok(bad == 0, "%d sprite semuanya berada di dalam gambar atlas" % AtlasData.SPRITES.size())
	var vram := 0.0
	for f: String in AtlasData.FILES:
		var t := load(f) as Texture2D
		vram += t.get_width() * t.get_height() * 4.0
		ok(t.get_width() <= 2048 and t.get_height() <= 2048, "%s <= 2048px (%dx%d)" % [f.get_file(), t.get_width(), t.get_height()])
	ok(vram / 1048576.0 < 12.0, "memori video atlas %.1f MB (< 12 MB)" % (vram / 1048576.0))

	print("== 2. Bank sprite di tiap biome ==")
	for biome in 3:
		var sp := SpriteBank.new()
		sp.resolve(biome)
		var tag := "biome %d (%s)" % [biome, sp.skin]
		ok(sp.ok, tag + ": bank siap")
		var miss: Array[String] = []
		for team in [1, 2]:
			for cls in SpriteDefs.CLASS_ROLE.size():
				var fr: Array = sp.inf[team][cls]
				if fr.is_empty():
					miss.append("inf t%d c%d" % [team, cls])
			for kind in SpriteDefs.VEHICLES:
				var vs := sp.veh_set(kind, team)
				var needs_turret: bool = SpriteDefs.VEHICLES[kind][team].has("turret")        # v14: MEDEVAC memang tanpa turret
				if vs == null or vs.body == null or (needs_turret and vs.turret == null):
					miss.append("veh %d t%d" % [kind, team])
				elif SpriteDefs.VEHICLES[kind][team].has("barrel") and vs.barrel == null:
					miss.append("barrel %d t%d" % [kind, team])
				elif vs.wreck == null:
					miss.append("wreck %d t%d" % [kind, team])
			for ty in SpriteDefs.TURRETS:
				if sp.tur[ty][team] == null:
					miss.append("turret %d t%d" % [ty, team])
			if sp.tower[team] == null:
				miss.append("tower t%d" % team)
		for t in [0, 1, 2]:
			if (sp.jets[t] as Array).has(null):
				miss.append("jet t%d" % t)
		for nm in ["ring", "trap", "wire", "bunker", "bunker_cover", "depot", "smoke", "smoke_b", "muzzle_r", "parachute",
				"roof_fans", "roof_grill", "roof_tech"]:
			if sp.get(nm) == null:
				miss.append(nm)
		for nm in ["expl_s", "expl_m", "fire", "muzzle_t", "trees", "rocks", "bushes", "cacti", "craters", "walls",
				"decal_craters", "blood", "corpses"]:
			if (sp.get(nm) as Array).is_empty():
				miss.append(nm)
		ok(miss.is_empty(), tag + ": semua sprite ditemukan" + ("" if miss.is_empty() else "  KURANG: " + str(miss)))
		ok(sp.skin == ("tan" if biome == 1 else "grn"), tag + ": skin sesuai biome")
		# sprite tim 1 dan tim 2 harus berbeda (warna tim dibake)
		var a1: SpriteLib.Spr = sp.inf[1][0][0]
		var a2: SpriteLib.Spr = sp.inf[2][0][0]
		ok(a1.r != a2.r, tag + ": prajurit tim 1 & 2 memakai sprite berbeda")
		if biome == 2:
			ok(sp.trees[0].r != SpriteLib.find("prop/tree1").r, tag + ": pohon salju memakai varian bersalju")

	print("== 3. Fallback ==")
	var off := SpriteBank.new()
	ok(off.veh_set(Cfg.Veh.TANK, 1) == null, "bank belum di-resolve -> veh_set null (gambar vektor dipakai)")
	var sp2 := SpriteBank.new()
	sp2.resolve(0)
	sp2.ok = false
	ok(sp2.veh_set(Cfg.Veh.TANK, 1) == null, "bank dimatikan -> veh_set null")
	ok(SpriteLib.find("tidak/ada", 1, "tan") == null, "nama tidak dikenal -> null (bukan error)")
	ok(SpriteLib.find("veh/ru_bmp3/body", 2, "tan") != null, "kendaraan satu-skin jatuh ke skin lain")
	ok(Fx.Type.PUFF == 0 and Fx.Type.RING == 1 and Fx.Type.SMOKE == 2 and Fx.Type.SPARK == 3, "nilai enum Fx lama tidak bergeser")
	print("SEMUA TES SPRITE LULUS" if fails == 0 else "ADA %d TES GAGAL" % fails)
	quit(1 if fails > 0 else 0)
