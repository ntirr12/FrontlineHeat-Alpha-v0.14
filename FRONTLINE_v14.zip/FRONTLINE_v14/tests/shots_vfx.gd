extends SceneTree
## Skenario efek: (1) tank dihancurkan -> semburan api, turret terlempar, ledakan susulan; (2) hujan peluru jatuh ke tanah;
## (3) ledakan peluru meriam. Hasil: /tmp/shots/vfx_*.png. Argumen: kualitas efek 0|1|2 (bawaan 0).
func _frames(n: int) -> void:
	for i in n:
		await process_frame

func _shot(name: String) -> void:
	root.get_texture().get_image().save_png("/tmp/shots/%s.png" % name)

func _initialize() -> void:
	var ql := int(OS.get_cmdline_user_args()[0]) if OS.get_cmdline_user_args().size() > 0 else 0
	DirAccess.make_dir_recursive_absolute("/tmp/shots")
	var g: Game = load("res://main.tscn").instantiate()
	root.add_child(g)
	await _frames(5)
	seed(31)
	g.prefs.ai_count = 0
	g.prefs.quality = 1
	g.prefs.chaos = 0
	g.dev = true
	g.cheats["god"] = true
	g.start_match()
	g.pick_class(0)
	g.zoom = 1.0
	g.quality_level = ql
	g.fx.quality = ql
	var at := Vector2(2600, 1500)
	g.player.pos = at + Vector2(-260, 120)
	g.cam = at
	var tank: Vehicle = null
	for v in g.vehicles:
		if v.kind == Cfg.Veh.TANK:
			tank = v
	tank.pos = at
	tank.heading = -0.4
	tank.aim = 0.3
	await _frames(10)
	g.vehicle_sys.damage(tank, 99999.0)               # BOOM
	for f in [2, 6, 10, 14, 20, 30, 45, 70]:
		await _frames(f - (0 if f == 2 else [2, 6, 10, 14, 20, 30, 45][[6, 10, 14, 20, 30, 45, 70].find(f)]))
		_shot("vfx_tank_%02d" % f)
	print("tank selesai. fx aktif=", g.fx.active.size(), " dead=", tank.dead)
	# (2) peluru jatuh ke tanah di sekitar sasaran 300px di depan
	var mz := at + Vector2(-300, 250)
	for i in 60:
		g.combat.shoot(mz, randf_range(-.25, .25) - .12, 1, Cfg.Bul.RIFLE, null, false, 300.0)
		await _frames(1)
	g.cam = mz + Vector2(300, 0)
	_shot("vfx_ground")
	# (3) peluru meriam jatuh di dekat sasaran
	g.combat.shoot(mz, -.05, 1, Cfg.Bul.SHELL, null, false, 400.0)
	await _frames(14)
	_shot("vfx_shell_a")
	await _frames(8)
	_shot("vfx_shell_b")
	print("ok ql=", ql, " fx=", g.fx.active.size())
	quit()
