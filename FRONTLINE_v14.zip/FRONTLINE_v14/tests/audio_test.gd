extends SceneTree
## TES AUDIO v12: semua nomor suara terisi, sampel nyata dimuat, musik OGG ter-loop, fallback sintesis aktif.
##   godot --headless --path . --script tests/audio_test.gd
var fails := 0

func ok(cond: bool, msg: String) -> void:
	print(("  ok   " if cond else "  GAGAL ") + msg)
	if not cond:
		fails += 1

func _initialize() -> void:
	var g: Game = load("res://main.tscn").instantiate()
	root.add_child(g)
	await process_frame
	var a := AudioMgr.new()
	g.add_child(a)
	a.setup(g)
	print("== 1. Bank suara ==")
	ok(a._sounds.size() == AudioDefs.COUNT, "jumlah nomor suara = %d" % AudioDefs.COUNT)
	var empty := 0
	for i in AudioDefs.COUNT:
		if (a._sounds[i] as Array).is_empty():
			empty += 1
			print("     kosong: nomor ", i)
	ok(empty == 0, "tidak ada nomor suara yang kosong")
	for i in AudioDefs.SAMPLES:
		var want: int = AudioDefs.SAMPLES[i].size()
		ok((a._sounds[i] as Array).size() == want, "nomor %d: %d varian sampel nyata" % [i, want])
		for st in a._sounds[i]:
			if not (st is AudioStreamWAV) or (st as AudioStreamWAV).data.size() < 100:
				ok(false, "nomor %d berisi aliran rusak" % i)
	ok((a._sounds[3][0] as AudioStreamWAV).mix_rate > 0, "suara UI (nomor 3) tetap sintesis")
	print("== 2. Musik ==")
	ok(a._music_streams.size() == 2, "dua lagu dimuat dari file")
	for m in a._music_streams:
		ok(m is AudioStreamOggVorbis and (m as AudioStreamOggVorbis).loop, "lagu OGG ter-loop")
	ok(a._thread == null, "tanpa thread pembangkit musik sintesis (hemat CPU saat start)")
	ok(a._music_streams[0].get_length() > 60.0, "lagu menu panjang %.0f detik" % a._music_streams[0].get_length())
	print("== 3. Pemutaran ==")
	g.prefs.sfx_vol = 1.0
	g.cam = Vector2(500, 500)
	for n in AudioDefs.COUNT:
		a.sfx_at(n, Vector2(500, 500))
		a.sfx_ui(n)
	await process_frame
	var playing := 0
	for p in a._players:
		if p.playing:
			playing += 1
	ok(playing > 0, "pemutar berbunyi (%d aktif)" % playing)
	print("== 4. Fallback: sampel hilang -> sintesis ==")
	var saved := AudioDefs.SAMPLES.duplicate(true)
	var b := AudioMgr.new()
	g.add_child(b)
	b.g = g
	# simulasi tanpa sampel: kosongkan bank lalu isi ulang lewat jalur fallback
	for i in AudioDefs.COUNT:
		b._sounds.append([])
	for i in AudioDefs.COUNT:
		if AudioDefs.FALLBACK.has(i) and not (b._sounds[AudioDefs.FALLBACK[i]] as Array).is_empty():
			b._sounds[i] = b._sounds[AudioDefs.FALLBACK[i]]
		elif i < Synth.SFX_COUNT:
			b._sounds[i] = [b._synth.make(i)]
	var syn := 0
	for i in Synth.SFX_COUNT:
		if not (b._sounds[i] as Array).is_empty():
			syn += 1
	ok(syn == Synth.SFX_COUNT, "semua %d suara lama tersedia dari sintesis" % Synth.SFX_COUNT)
	ok(not (b._sounds[15] as Array).is_empty(), "meriam tank (15) jatuh ke ledakan sintesis")
	ok(saved.size() == AudioDefs.SAMPLES.size(), "tabel sampel tidak berubah")
	print("SEMUA TES AUDIO LULUS" if fails == 0 else "ADA %d TES GAGAL" % fails)
	quit(1 if fails > 0 else 0)
