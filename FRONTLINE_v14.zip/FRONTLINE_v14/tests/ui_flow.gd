extends SceneTree
## Tes alur UI end-to-end (butuh xvfb): klik tombol menu & sentuh analog memakai event layar sentuh sungguhan.
var g: Game
var fails := 0

func check(ok: bool, what: String) -> void:
	if ok: print("  ok   ", what)
	else:
		fails += 1
		print("  GAGAL ", what)

func frames(n: int) -> void:
	for i in n: await process_frame

func touch(idx: int, p: Vector2, pressed: bool) -> void:
	var e := InputEventScreenTouch.new()
	e.index = idx
	e.position = p
	e.pressed = pressed
	Input.parse_input_event(e)

func drag(idx: int, p: Vector2) -> void:
	var e := InputEventScreenDrag.new()
	e.index = idx
	e.position = p
	Input.parse_input_event(e)

func click_id(id: String) -> bool:
	for b in g.menus._buttons:
		if b.id == id:
			var c: Vector2 = (b.r as Rect2).get_center()
			touch(9, c, true)
			await frames(2)
			touch(9, c, false)
			await frames(3)
			return true
	print("   tombol tidak ditemukan: ", id)
	return false

func _initialize() -> void:
	g = load("res://main.tscn").instantiate()
	root.add_child(g)
	await frames(20)
	print("== alur menu ==")
	check(g.mode == Game.Mode.MENU and g.screen == "main", "mulai di menu utama")
	check(await click_id("play") and g.screen == "setup", "MAIN -> persiapan misi")
	await frames(3)
	check(await click_id("ai1"), "pilih jumlah AI SEDANG")
	check(g.prefs.ai_count == 1, "  ai_count = 1")
	check(await click_id("ch0") and g.prefs.chaos == 0, "pilih kekacauan TENANG")
	check(await click_id("ai2") and g.prefs.ai_count == 2, "pilih jumlah AI BANYAK")
	check(await click_id("ch1"), "kekacauan NORMAL")
	check(await click_id("go"), "MULAI MISI")
	await frames(8)
	check(g.mode == Game.Mode.PLAY and g.selecting, "pertandingan mulai, layar pilih divisi")
	check(g.ai_alive[1] >= 0 and g.units.size() >= 20, "AI di-spawn (%d prajurit)" % g.units.size())
	await frames(3)
	check(await click_id("cl0") and g.player != null, "pilih divisi ASSAULT")
	print("== sentuhan analog ==")
	g.prefs.stick_style = 0
	g.prefs.fire_mode = 0
	var p0 := g.player.pos
	touch(1, Vector2(200, 450), true)
	await frames(2)
	drag(1, Vector2(290, 450))
	await frames(30)
	check(g.input.move.x > .5, "analog kiri (melayang) menghasilkan gerak (%.2f)" % g.input.move.x)
	check(g.player.pos.distance_to(p0) > 20.0, "pemain berjalan (%.0f px)" % g.player.pos.distance_to(p0))
	touch(1, Vector2(290, 450), false)
	await frames(2)
	touch(2, Vector2(850, 400), true)
	await frames(2)
	drag(2, Vector2(850 + 100, 400))
	await frames(10)
	check(g.input.fire and g.input.aim.x > .5, "analog kanan mentok = menembak")
	touch(2, Vector2(950, 400), false)
	await frames(2)
	print("== jeda & pengaturan ==")
	touch(3, g.input.pause_pos(), true)
	await frames(2)
	touch(3, g.input.pause_pos(), false)
	await frames(3)
	check(g.paused and g.screen == "pause", "tombol jeda membuka menu jeda")
	check(await click_id("set") and g.screen == "set", "PENGATURAN dari jeda")
	check(await click_id("tab1"), "tab KONTROL")
	check(await click_id("c_ss") and g.prefs.stick_style == 1, "gaya analog -> TETAP")
	check(await click_id("c_fm") and g.prefs.fire_mode == 1, "mode tembak -> SENTUH")
	check(await click_id("back") and g.screen == "pause", "kembali ke jeda")
	check(await click_id("resume") and not g.paused, "LANJUT")
	print("== analog TETAP lewat sentuhan nyata ==")
	var mb := g.input.move_base()
	touch(4, mb + Vector2(10, 0), true)
	await frames(2)
	drag(4, mb + Vector2(100, 0))
	await frames(5)
	check(g.input.move.x > .5, "analog TETAP merespons sentuhan di posisinya (%.2f)" % g.input.move.x)
	touch(4, mb, false)
	await frames(2)
	g.input.reset()
	print(("SEMUA TES UI LULUS" if fails == 0 else "TES UI GAGAL: %d" % fails))
	quit(1 if fails > 0 else 0)
