extends SceneTree
## Tangkapan layar di tengah pertempuran (pemain kebal, ditempatkan di bendera tengah).
func _frames(n: int) -> void:
	for i in n:
		await process_frame

func _initialize() -> void:
	DirAccess.make_dir_recursive_absolute("/tmp/shots")
	var g: Game = load("res://main.tscn").instantiate()
	root.add_child(g)
	await _frames(5)
	g.prefs.ai_count = int(OS.get_cmdline_user_args()[0]) if OS.get_cmdline_user_args().size() > 0 else 2
	g.prefs.quality = 1
	g.prefs.chaos = 2
	g.dev = true
	g.cheats["god"] = true
	g.start_match()
	g.pick_class(0)
	var mid := g.objectives.flags[2].pos
	g.player.pos = mid + Vector2(-150, 0)
	g.cam = g.player.pos
	for k in 4:
		await _frames(30 * 14)
		g.player.pos = g.objectives.flags[2].pos + Vector2(-150, 0) if k % 2 == 0 else g.objectives.flags[1].pos + Vector2(100, 60)
		await _frames(20)
		root.get_texture().get_image().save_png("/tmp/shots/b%d.png" % k)
		print("t=", int(g.time), " AI=", g.ai_alive, " bullets=", g.combat.bullets.size(), " fx=", g.fx.active.size(), " barrages=", g.barrages.size(), " jets=", g.jets.size())
	quit()
