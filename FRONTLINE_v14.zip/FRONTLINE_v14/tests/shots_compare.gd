extends SceneTree
## Tangkapan layar pembanding (terrain + prajurit + efek) di tengah pertempuran. Argumen: awalan nama file.
func _frames(n: int) -> void:
	for i in n:
		await process_frame

func _initialize() -> void:
	var tag := OS.get_cmdline_user_args()[0] if OS.get_cmdline_user_args().size() > 0 else "x"
	DirAccess.make_dir_recursive_absolute("/tmp/shots")
	var g: Game = load("res://main.tscn").instantiate()
	root.add_child(g)
	await _frames(5)
	seed(777)
	g.prefs.ai_count = 2
	g.prefs.quality = 1
	g.prefs.chaos = 2
	g.dev = true
	g.cheats["god"] = true
	g.start_match()
	g.pick_class(0)
	g.zoom = 1.0
	var mid := g.objectives.flags[2].pos
	g.player.pos = mid + Vector2(-150, 0)
	g.cam = g.player.pos
	await _frames(30 * 25)
	g.player.pos = mid + Vector2(-120, 0)
	await _frames(15)
	root.get_texture().get_image().save_png("/tmp/shots/%s_mid.png" % tag)
	g.player.pos = g.objectives.flags[1].pos + Vector2(100, 60)
	await _frames(15)
	root.get_texture().get_image().save_png("/tmp/shots/%s_base.png" % tag)
	print("ok ", tag, " AI=", g.ai_alive, " bullets=", g.combat.bullets.size(), " fx=", g.fx.active.size())
	quit()
