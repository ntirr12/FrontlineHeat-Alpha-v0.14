extends SceneTree
## BENCHMARK RENDER: jalankan pertempuran N detik (frame), ukur sisi GRAFIS.
##   xvfb-run -a -s "-screen 0 1280x720x24" godot --rendering-driver opengl3 --path . --resolution 1280x720 \
##        --script tests/render_bench.gd -- <kualitas 1|2|3> <detik> <biome 0|1|2> [jumlah AI] [air = beban udara v14]
## Metrik yang bermakna di sandbox (render software): draw-call, objek, memori tekstur, waktu CPU skrip gambar.
func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	var q := int(args[0]) if args.size() > 0 else 1
	var secs := int(args[1]) if args.size() > 1 else 25
	var biome := int(args[2]) if args.size() > 2 else 0
	var g: Game = load("res://main.tscn").instantiate()
	root.add_child(g)
	for i in 20:
		await process_frame
	seed(1234)
	g.prefs.ai_count = int(args[3]) if args.size() > 3 else 2
	g.prefs.quality = q
	g.prefs.biome = biome + 1
	g.start_match()
	await process_frame
	g.pick_class(0)
	g.profile_on = true
	g.draw_us = 0
	var frames := secs * 30
	var air_load := args.size() > 4 and args[4] == "air"            # v14: beban udara - MLRS + C-17 berulang selama benchmark
	var dc := 0.0
	var dc_max := 0
	var obj := 0.0
	var prim := 0.0
	var n := 0
	for f in frames:
		await process_frame
		if air_load and f % 150 == 70:
			var c: Vector2 = g.player.pos + Vector2(500, 0)
			g.air.call_mlrs(c, 1, false)
			g.air.call_airlift(c + Vector2(0, 150), 1, false)
			g.air.call_mlrs(c + Vector2(-300, 200), 2, false)
		if f > 60:                                     # lewati pemanasan
			var d := RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME)
			dc += d
			dc_max = maxi(dc_max, d)
			obj += RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_OBJECTS_IN_FRAME)
			prim += RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME)
			n += 1
	var tex_mb := RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TEXTURE_MEM_USED) / 1048576.0
	var vid_mb := RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_VIDEO_MEM_USED) / 1048576.0
	print("BENCH q=%d biome=%d | draw-call rata2=%.1f maks=%d | objek rata2=%.1f | primitif rata2=%.0f | draw skrip=%.2f ms/frame | mem tekstur=%.1f MB (video %.1f MB) | AI=%s" % [
		q, biome, dc / n, dc_max, obj / n, prim / n, g.draw_us / 1000.0 / frames, tex_mb, vid_mb, g.ai_alive])
	quit()
