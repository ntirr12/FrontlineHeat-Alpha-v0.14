extends SceneTree
## PEMENTASAN VISUAL SPRITE: menata semua jenis prajurit/kendaraan/bangunan/efek di satu adegan beku
## lalu memotret dari dekat. Dipakai untuk memeriksa tampilan aset secara cepat.
##   xvfb-run -a -s "-screen 0 1280x720x24" godot --rendering-driver opengl3 --path . --resolution 1280x720 \
##       --script tests/shots_sprites.gd -- <biome 0 hutan | 1 gurun | 2 salju> [kualitas] [vec]
##   "vec" = paksa gambar vektor (menguji jalur fallback)
## Hasil: /tmp/shots_sprites/b<biome>_*.png

func _shot(name: String) -> void:
	root.get_texture().get_image().save_png("/tmp/shots_sprites/%s.png" % name)


func _frames(n: int) -> void:
	for i in n:
		await process_frame


func _initialize() -> void:
	DirAccess.make_dir_recursive_absolute("/tmp/shots_sprites")
	var args := OS.get_cmdline_user_args()
	var biome := int(args[0]) if args.size() > 0 else 0
	var g: Game = load("res://main.tscn").instantiate()
	root.add_child(g)
	await _frames(20)
	g.prefs.ai_count = 0
	g.prefs.quality = int(args[1]) if args.size() > 1 else 1        # 1 tinggi, 2 sedang, 3 rendah
	g.prefs.biome = biome + 1
	var vec := args.size() > 2 and args[2] == "vec"                  # uji fallback: paksa gambar vektor lama
	SpriteLib.disabled = vec
	g.start_match()
	await _frames(4)
	g.pick_class(0)
	await _frames(10)
	var tag := "b%d%s" % [biome, "_vec" if vec else ""]

	(g.hud.get_parent() as CanvasLayer).visible = false      # sembunyikan seluruh HUD/menu agar adegan bersih
	# ---- bersihkan, lalu susun adegan di sekitar titik C (di dalam peta, dekat markas biru)
	g.paused = true
	var C: Vector2 = g.player.pos + Vector2(420, -80)
	g.units.clear()
	g.units.append(g.player)
	g.player.pos = C + Vector2(-9999, 0)         # singkirkan pemain dari adegan
	g.vehicles.clear()
	g.turrets.clear()
	g.structs.clear()

	# baris prajurit: tiap divisi, tim 1 (atas) dan tim 2 (bawah)
	for cls in 8:
		for team in [1, 2]:
			var u := Unit.create(cls, team, true, C + Vector2(cls * 56 - 200, -150 if team == 1 else -80))
			u.angle = 0.0 if team == 1 else PI
			u.shot_t = 1.5 if cls % 2 == 0 else 0.0           # selang-seling: frame menembak / diam
			u.move_anim_t = 1.0 if cls % 3 == 0 else 0.0
			g.units.append(u)
	# Spy menyamar
	var spy := Unit.create(Cfg.Cls.SPY, 1, true, C + Vector2(250, -115))
	spy.disguise_t = 99.0
	g.units.append(spy)

	# kendaraan: 5 jenis x 2 tim
	for k in 5:
		for team in [1, 2]:
			var v := Vehicle.create(k, C + Vector2(k * 130 - 260, 20 if team == 1 else 140), team, 0.0 if team == 1 else PI)
			v.weapon = k % 2
			g.vehicles.append(v)
	var wreck := Vehicle.create(Cfg.Veh.TANK, C + Vector2(400, 80), 2, 0.6)
	wreck.dead = true
	wreck.hp = 0.0
	g.vehicles.append(wreck)

	# turret & bangunan
	for ty in 2:
		for team in [1, 2]:
			g.turrets.append(Turret.create(ty, C + Vector2(-330 + ty * 70, 250 if team == 1 else 330), team, 0.0 if team == 1 else PI))
	var items := [Cfg.Item.TOWER, Cfg.Item.TRAP, Cfg.Item.WIRE, Cfg.Item.BUNKER, Cfg.Item.DRONE_ST, Cfg.Item.JAMMER]
	for i in items.size():
		g.structs.append(Structure.create(items[i], C + Vector2(-60 + i * 110, 300), 1))

	# jet & parasut
	g.support.spawn_jet(C + Vector2(-200, -330), Vector2.RIGHT, 6, 1)
	g.support.spawn_jet(C + Vector2(200, -330), Vector2.LEFT, 0, 2)
	g.fx.clear()
	g.cam = C + Vector2(40, 100)
	g.zoom = 1.05
	g.view_root.position = g.vs / 2.0 - g.cam * g.zoom
	g.view_root.scale = Vector2(g.zoom, g.zoom)
	await _frames(6)
	_shot(tag + "_1_adegan")

	# zoom ke prajurit
	g.cam = C + Vector2(0, -115)
	g.zoom = 2.1
	g.view_root.position = g.vs / 2.0 - g.cam * g.zoom
	g.view_root.scale = Vector2(g.zoom, g.zoom)
	await _frames(4)
	_shot(tag + "_2_prajurit")

	# zoom ke kendaraan
	g.cam = C + Vector2(0, 80)
	g.zoom = 1.6
	g.view_root.position = g.vs / 2.0 - g.cam * g.zoom
	g.view_root.scale = Vector2(g.zoom, g.zoom)
	await _frames(4)
	_shot(tag + "_3_kendaraan")

	# efek: ledakan, muzzle, darah, asap pada frame berbeda
	g.cam = C + Vector2(0, 380)
	g.zoom = 1.2
	g.view_root.position = g.vs / 2.0 - g.cam * g.zoom
	g.view_root.scale = Vector2(g.zoom, g.zoom)
	g.units.clear()
	g.vehicles.clear()
	g.turrets.clear()
	g.structs.clear()
	var E := C + Vector2(0, 420)
	for i in 4:
		g.fx.spawn(E + Vector2(i * 110 - 165, 0), .6, 40.0 + i * 20.0, Color(1, .55, .1), Fx.Type.EXPLOSION)
	g.fx.spawn(E + Vector2(-200, 120), .6, 80.0, Color(1, .55, .1), Fx.Type.EXPLOSION)
	g.fx.spawn(E + Vector2(-100, 120), 1.2, 60.0, Color(.3, .3, .3, .8), Fx.Type.SMOKE)
	g.fx.spawn(E + Vector2(0, 120), .25, 24.0, Color(1, .9, .5), Fx.Type.MUZZLE, Vector2.RIGHT)
	g.fx.spawn(E + Vector2(60, 120), .25, 7.0, Color(1, .9, .5), Fx.Type.MUZZLE, Vector2.UP)
	g.fx.spawn(E + Vector2(120, 120), .3, 12.0, Color(.7, .1, .1), Fx.Type.BLOOD)
	g.add_decal(E + Vector2(200, 100), 40.0, 90.0, 0, Color.BLACK)
	g.add_decal(E + Vector2(260, 110), 10.0, 90.0, 1, Cfg.TEAM_COLORS[1].darkened(.5))
	g.add_decal(E + Vector2(300, 110), 10.0, 90.0, 1, Cfg.TEAM_COLORS[2].darkened(.5))
	g.add_decal(E + Vector2(340, 110), 9.0, 90.0, 2, Color(.5, .05, .05))
	g.decals_dirty = true
	g.fx.update(.15)
	await _frames(4)
	_shot(tag + "_4_efek")
	g.fx.update(.2)
	await _frames(4)
	_shot(tag + "_5_efek_lanjut")

	# lingkungan: tembok, pohon, batu di sekitar markas
	g.paused = false
	g.player.pos = Objectives.base_pos(1) + Vector2(260, 0)
	g.cam = g.player.pos
	g.zoom = 1.0
	await _frames(12)
	g.paused = true
	g.cam = g.player.pos + Vector2(200, -100)
	g.view_root.position = g.vs / 2.0 - g.cam * g.zoom
	await _frames(4)
	_shot(tag + "_6_lingkungan")
	quit()
