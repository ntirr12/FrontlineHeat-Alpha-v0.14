#!/bin/bash
# Impor proyek & tampilkan hanya error/warning skrip. Pemakaian: bash tests/check.sh
cd "$(dirname "$0")/.."
G=${GODOT:-/home/claude/godot/Godot_v4.7.2-stable_linux.x86_64}
timeout 150 $G --headless --import --path . 2>&1 | sed 's/\x1b\[[0-9;]*m//g' | grep -iE "error|parse|warning|invalid|cannot|identifier" | head -${1:-40}
echo "--- selesai cek ---"
