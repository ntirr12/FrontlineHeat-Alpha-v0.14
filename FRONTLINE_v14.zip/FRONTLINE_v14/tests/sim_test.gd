extends SceneTree
## Tes simulasi headless: jalankan pertandingan tanpa render dan cetak metrik AI.
## Pakai: godot --headless --path . --script tests/sim_test.gd -- [ai_count 0..3] [detik] [kualitas 1..3]
func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	var g: Game = load("res://main.tscn").instantiate()
	root.add_child(g)
	await process_frame
	g.prefs.ai_count = int(args[0]) if args.size() > 0 else 2
	var total := float(args[1]) if args.size() > 1 else 300.0
	g.prefs.quality = int(args[2]) if args.size() > 2 else 1
	g.prefs.chaos = 1
	g.profile_on = true
	g.apply_settings()
	g.start_match()
	g.pick_class(0)
	seed(42)
	var dt := 1.0 / 30.0
	var t := 0.0
	var us_sum := 0
	var us_max := 0
	var all_us: Array = []
	var steps := 0
	var last_pos := {}
	var stuck := 0
	var samples := 0
	var flag_changes := 0
	var prev_owner := []
	for f in g.objectives.flags: prev_owner.append(f.owner_team)
	var next_report := 30.0
	var states := {}
	while t < total:
		g.time += dt
		g.frame += 1
		var t0 := Time.get_ticks_usec()
		g.sim(dt)
		var us := Time.get_ticks_usec() - t0
		us_sum += us
		us_max = maxi(us_max, us)
		all_us.append(us)
		steps += 1
		t += dt
		for i in g.objectives.flags.size():
			if g.objectives.flags[i].owner_team != prev_owner[i]:
				flag_changes += 1
				prev_owner[i] = g.objectives.flags[i].owner_team
		if steps % 90 == 0:
			for u in g.units:
				if u.is_ai and u.hp > 0.0 and u.mount == null:
					if last_pos.has(u.slot_id) and u.pos.distance_to(last_pos[u.slot_id]) < 20.0 and u.state != AiBrain.State.CAPTURE and u.state != AiBrain.State.COVER and u.state != AiBrain.State.RETREAT:
						stuck += 1
					last_pos[u.slot_id] = u.pos
					samples += 1
					states[u.state] = states.get(u.state, 0) + 1
		if t >= next_report:
			next_report += 30.0
			var a1 := 0
			var a2 := 0
			for u in g.units:
				if u.is_ai and u.hp > 0.0:
					if u.team == 1: a1 += 1
					else: a2 += 1
			var ow := ""
			for f in g.objectives.flags: ow += str(f.owner_team)
			print("t=%3d  AI biru=%2d merah=%2d  tiket=%d/%d  bendera=%s  kend=%d  regu=%d  peluru=%d  sim=%.2fms" % [int(t), a1, a2, g.tickets[1], g.tickets[2], ow, g.vehicles.size(), g.planner.squads.size(), g.combat.bullets.size(), us_sum / 1000.0 / steps])
		if g.mode == Game.Mode.OVER:
			print("MATCH SELESAI t=", int(t), " menang=", g.win)
			break
	var names := ["ADVANCE", "ENGAGE", "COVER", "HUNT", "RETREAT", "CAPTURE", "DODGE", "EVADE", "BOARD", "SPY"]
	var st := ""
	for k in states.keys(): st += "%s=%d " % [names[k], states[k]]
	print("RINGKAS: pergantian_bendera=", flag_changes, " macet=", stuck, "/", samples, " rata2_sim_ms=%.2f maks_ms=%.2f" % [us_sum / 1000.0 / steps, us_max / 1000.0])
	all_us.sort()
	var n := all_us.size()
	print("FRAME_US p50=%d p95=%d p99=%d p99.9=%d maks=%d  (n=%d)" % [all_us[n / 2], all_us[int(n * .95)], all_us[int(n * .99)], all_us[int(n * .999)], all_us[n - 1], n])
	print("STATE: ", st)
	for k in g.prof.keys():
		print("  PROF %-16s rata2=%.3fms maks=%.2fms" % [k, g.prof[k][0] / 1000.0 / steps, g.prof[k][1] / 1000.0])
	quit()
