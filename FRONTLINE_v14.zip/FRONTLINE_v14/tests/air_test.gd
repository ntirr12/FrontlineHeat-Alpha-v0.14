extends SceneTree
## TES FITUR v14: kendaraan baru (APC, SPG, MEDEVAC), skala kendaraan, skill kendaraan, howitzer & peluru asap,
## C-17 terjun payung, MLRS, peti suplai, item baru di daftar divisi, hadiah kill streak.
## Tiap tes memanggil sistemnya langsung lalu menjalankan sim secara manual (tidak bergantung waktu nyata).
##   godot --headless --path . --script tests/air_test.gd
var fails := 0
var g: Game


func check(name: String, ok: bool, detail := "") -> void:
	print(("  [LULUS] " if ok else "  [GAGAL] ") + name + ("  (" + detail + ")" if detail != "" else ""))
	if not ok:
		fails += 1


func _frames(n: int) -> void:
	for i in n:
		await process_frame


var park_enemies := false      # true = semua musuh AI dijauhkan tiap langkah (agar tidak membunuh penerjun/uji coba)


## Jalankan simulasi sebanyak secs detik (langkah 1/30 dtk) tanpa menunggu waktu nyata.
func _sim(secs: float) -> void:
	var t := 0.0
	while t < secs:
		g.sim(1.0 / 30.0)
		if park_enemies:
			for u in g.units:
				if u.team == 2 and u.mount == null:
					u.pos = Vector2(200, 2800)
		t += 1.0 / 30.0


## Cari titik bebas (radius r) dengan ruang lapang 320 px ke arah +x, untuk tes mengemudi yang tidak bergantung peta acak.
func _free_spot(r: float) -> Vector2:
	for y in range(300, 2700, 90):
		for x in range(1400, 3600, 90):
			var ok := true
			for d in range(-40, 330, 30):
				if g.blocked(Vector2(x + d, y), r + 6.0):
					ok = false
					break
			if ok:
				return Vector2(x, y)
	return Vector2(2000, 1500)


func _clear_zone(p: Vector2, r: float) -> void:
	for u in g.units:
		if u != g.player and u.pos.distance_to(p) < r:
			u.pos = Vector2(100, 100)
	g.grid.rebuild(g.units)


func _initialize() -> void:
	g = load("res://main.tscn").instantiate()
	root.add_child(g)
	await _frames(5)
	seed(14)
	g.prefs.ai_count = 0
	g.prefs.quality = 1
	g.prefs.chaos = 0
	g.start_match()
	g.pick_class(0)
	g.dev = true
	g.cheats["god"] = true
	await _frames(3)

	print("== 1. KENDARAAN BARU & UKURAN")
	check("enum Veh punya 8 jenis", Cfg.VEH_COUNT == 8 and Cfg.Veh.MEDEVAC == 7)
	var veh_arrays := {"VEH_NAMES": Cfg.VEH_NAMES, "VEH_COOLDOWN": Cfg.VEH_COOLDOWN, "VEH_SHOT": Cfg.VEH_SHOT, "VEH_MUZZLE": Cfg.VEH_MUZZLE,
		"VEH_RADIUS": Cfg.VEH_RADIUS, "VEH_SPEED": Cfg.VEH_SPEED, "VEH_TURN": Cfg.VEH_TURN, "VEH_HP": Cfg.VEH_HP, "VEH_ZOOM": Cfg.VEH_ZOOM,
		"VEH_SEATS": Cfg.VEH_SEATS, "VEH_GUN_DMG": Cfg.VEH_GUN_DMG, "VEH_SPLASH_RESIST": Cfg.VEH_SPLASH_RESIST, "VEH_SKILL_CD": Cfg.VEH_SKILL_CD,
		"VEH_SKILL_BOOST": Cfg.VEH_SKILL_BOOST, "RIFLE_DMG_VEH": Cfg.RIFLE_DMG_VEH}
	for arr_name in veh_arrays:
		check("array %s punya %d entri" % [arr_name, Cfg.VEH_COUNT], (veh_arrays[arr_name] as Array).size() == Cfg.VEH_COUNT)
	var bul_arrays := {"BUL_SPEED": Cfg.BUL_SPEED, "BUL_LIFE": Cfg.BUL_LIFE, "BUL_SOUND": Cfg.BUL_SOUND, "BUL_ARC": Cfg.BUL_ARC,
		"DIRECT_DMG": Cfg.DIRECT_DMG, "BLAST_RADIUS": Cfg.BLAST_RADIUS, "BLAST_DMG": Cfg.BLAST_DMG}
	for arr_name in bul_arrays:
		check("array %s punya 8 entri peluru" % arr_name, (bul_arrays[arr_name] as Array).size() == 8)
	var item_arrays := {"ITEM_NAMES": Cfg.ITEM_NAMES, "ITEM_BUILD_COST": Cfg.ITEM_BUILD_COST, "ITEM_RANGE": Cfg.ITEM_RANGE, "ITEM_RADIUS": Cfg.ITEM_RADIUS}
	for arr_name in item_arrays:
		check("array %s sesuai jumlah item (23)" % arr_name, (item_arrays[arr_name] as Array).size() == 23)
	var counts := {}
	for v in g.vehicles:
		counts[[v.team, v.kind]] = true
	var all_kinds := true
	for tm in [1, 2]:
		for k in Cfg.VEH_COUNT:
			if k != Cfg.Veh.RAILGUN and not counts.has([tm, k]):
				all_kinds = false
	check("tiap markas punya 7 kendaraan (semua jenis kecuali railgun)", all_kinds)
	var blocked_any := false
	for v in g.vehicles:
		if g.blocked(v.pos, 1.0):
			blocked_any = true
	check("tidak ada kendaraan yang spawn di dalam tembok", not blocked_any)
	check("tank jauh lebih besar dari prajurit (radius >= 40, humvee >= 30)", Cfg.VEH_RADIUS[Cfg.Veh.TANK] >= 40 and Cfg.VEH_RADIUS[Cfg.Veh.HUMVEE_MG] >= 30)
	if g.sprites.ok:                                  # sprite hanya dimuat bila ada renderer (tidak saat --headless); dicek di tests/shots_air.gd
		var ok_sprites := true
		for k in [Cfg.Veh.APC, Cfg.Veh.SPG, Cfg.Veh.MEDEVAC]:
			for tm in [1, 2]:
				if g.sprites.veh_set(k, tm) == null:
					ok_sprites = false
		check("sprite APC/SPG/MEDEVAC tersedia di kedua tim", ok_sprites)
		check("sprite C-17, kanopi, peti, roket, peluncur MLRS tersedia", g.sprites.c17.get(1) != null and g.sprites.c17.get(2) != null
			and g.sprites.canopy != null and g.sprites.crate_med != null and g.sprites.rocket != null and g.sprites.mlrs.has(1) and g.sprites.mlrs.has(2))
	else:
		print("  (sprite tidak dimuat di mode headless - dilewati)")

	print("== 2. SKILL KENDARAAN")
	var p := g.player
	var tank: Vehicle = null
	var hum: Vehicle = null
	for v in g.vehicles:
		if v.team == 1 and v.kind == Cfg.Veh.TANK:
			tank = v
		if v.team == 1 and v.kind == Cfg.Veh.HUMVEE_MG:
			hum = v
	var n_smoke := g.smokes.size()
	check("skill tank = tirai asap", g.vehicle_sys.vehicle_skill(tank) and g.smokes.size() == n_smoke + 1)
	check("skill masuk jeda", tank.skill_cd > 10.0 and not g.vehicle_sys.vehicle_skill(tank))
	check("skill humvee = boost", g.vehicle_sys.vehicle_skill(hum) and hum.boost_t > 0.0)
	hum.heading = 0.0
	hum.speed = 0.0
	hum.pos = Vector2(1000, 400)
	hum.speed = 0.0
	for i in 40:
		g.vehicle_sys.drive(hum, Vector2.RIGHT, Vector2.ZERO, 1.0 / 30.0)
	check("boost menambah kecepatan di atas batas normal", hum.speed > Cfg.VEH_SPEED[Cfg.Veh.HUMVEE_MG] * 1.15, "speed=%.0f" % hum.speed)
	var limp: Vehicle = tank
	limp.hp = limp.max_hp * .2
	limp.speed = 0.0
	limp.pos = Vector2(1500, 700)
	for i in 60:
		g.vehicle_sys.drive(limp, Vector2.RIGHT, Vector2.ZERO, 1.0 / 30.0)
	check("mesin rusak (HP<30%) membatasi kecepatan", limp.speed <= Cfg.VEH_SPEED[Cfg.Veh.TANK] * Cfg.VEH_LIMP_MULT + 1.0, "speed=%.0f" % limp.speed)
	limp.hp = limp.max_hp

	print("== 3. MEDEVAC MENYEMBUHKAN")
	var med: Vehicle = null
	for v in g.vehicles:
		if v.team == 1 and v.kind == Cfg.Veh.MEDEVAC:
			med = v
	med.pos = Vector2(2500, 1500)
	med.speed = 0.0
	var dummy_driver := g.spawn_ai(1, Vector2(2500, 1500))
	med.driver = dummy_driver
	dummy_driver.mount = med
	var patient := g.spawn_ai(1, Vector2(2560, 1500))
	patient.hp = 30.0
	patient.max_hp = 100.0
	var far := g.spawn_ai(1, Vector2(2500 + Cfg.MEDEVAC_RADIUS + 120, 1500))
	far.hp = 30.0
	far.max_hp = 100.0
	g.grid.rebuild(g.units)
	for i in 8:                                       # 8 denyut (2 detik): panggil langsung agar AI tidak sempat berjalan pergi
		g.vehicle_sys._medevac_tick(med, .26)
	check("MEDEVAC berawak menaikkan HP prajurit sekutu di jangkauan", patient.hp > 30.0 + 12.0, "hp=%.1f" % patient.hp)
	check("di luar jangkauan tidak disembuhkan", far.hp < 31.0, "hp=%.1f" % far.hp)
	var n_crates := g.crates.size()
	g.vehicle_sys.damage(med, 99999.0)
	check("MEDEVAC hancur menjatuhkan peti medis", g.crates.size() == n_crates + 1)

	print("== 4. HOWITZER (PELURU LENGKUNG) & PELURU ASAP")
	var spg: Vehicle = null
	for v in g.vehicles:
		if v.team == 1 and v.kind == Cfg.Veh.SPG:
			spg = v
	spg.pos = Vector2(2000, 1000)
	spg.heading = 0.0
	spg.aim = 0.0
	spg.dead = false
	spg.driver = g.player                             # pemain sebagai pengemudi -> bantuan jarak (aim_distance_for) aktif
	g.player.mount = spg
	var tgt := Vector2(2000 + 900, 1000)
	_clear_zone(tgt, 500.0)
	var victim := g.spawn_ai(2, tgt)
	victim.hp = 100.0
	victim.max_hp = 100.0
	g.grid.rebuild(g.units)
	var wall_before := g.world.blocked(Vector2(2450, 1000), 10.0)
	spg.cooldown = 0.0
	spg.weapon = 0
	g.vehicle_sys.drive(spg, Vector2.ZERO, Vector2.RIGHT, 1.0 / 30.0)
	check("howitzer menembak peluru lengkung", g.combat.bullets.size() > 0 and g.combat.bullets[g.combat.bullets.size() - 1].kind == Cfg.Bul.HOWITZER)
	var b: Bullet = g.combat.bullets[g.combat.bullets.size() - 1]
	check("howitzer menjangkau sasaran jauh (~800 px) di garis bidik", b.life * Cfg.BUL_SPEED[Cfg.Bul.HOWITZER] >= 780.0, "jangkauan=%.0f" % (b.life * Cfg.BUL_SPEED[Cfg.Bul.HOWITZER]))
	var t := 0.0
	while t < 4.0 and g.combat.bullets.size() > 0:
		g.grid.rebuild(g.units)
		g.combat.update_bullets(1.0 / 30.0)
		t += 1.0 / 30.0
	check("howitzer mendarat & melukai sasaran", victim.hp < 100.0 or victim.hp <= 0.0, "hp=%.1f" % victim.hp)
	var sm0 := g.smokes.size()
	spg.cooldown = 0.0
	spg.weapon = 1
	g.vehicle_sys.drive(spg, Vector2.ZERO, Vector2.RIGHT, 1.0 / 30.0)
	t = 0.0
	while t < 4.0 and g.combat.bullets.size() > 0:
		g.combat.update_bullets(1.0 / 30.0)
		t += 1.0 / 30.0
	check("peluru asap membuat tirai asap saat mendarat", g.smokes.size() > sm0)
	var apc: Vehicle = null
	for v in g.vehicles:
		if v.team == 1 and v.kind == Cfg.Veh.APC:
			apc = v
	check("APC punya 2 kursi, MEDEVAC tidak bersenjata", apc.has_free_gunner_seat() and not med.armed())
	spg.driver = null
	g.player.mount = null

	print("== 5. C-17 BANTUAN TERJUN PAYUNG")
	g.player.pos = Vector2(600, 1500)
	park_enemies = true
	var dz := Vector2(3000, 1400)
	_clear_zone(dz, 400.0)
	var squads0 := g.planner.squads.size()
	var units0 := g.units.size()
	g.air.call_airlift(dz, 1, false)
	check("C-17 muncul di luar titik terjun", g.airlifts.size() == 1 and g.airlifts[0].pos.distance_to(dz) > Cfg.PARADROP_LEAD - 50.0)
	_sim(1.0)
	var plane_moved := g.airlifts.size() == 1 and g.airlifts[0].pos.x > dz.x - Cfg.PARADROP_LEAD + 200.0
	check("C-17 bergerak ke arah titik terjun", plane_moved)
	_sim(3.2)
	check("penerjun sudah keluar & melayang", g.chutes.size() >= 1)
	var spots: Array = []                                 # titik mendarat yang direncanakan (diambil selagi masih di udara)
	for c in g.chutes:
		if not c.crate:
			spots.append(c.pos)
	var landed0 := g.air.landed
	_sim(6.5)
	check("semua penerjun mendarat jadi prajurit AI sekutu", g.air.landed - landed0 == Cfg.PARADROP_COUNT and g.chutes.is_empty(), "mendarat %d" % (g.air.landed - landed0))
	check("pesawat selesai & hilang", g.airlifts.is_empty())
	check("penerjun membentuk regu sendiri", g.planner.squads.size() > squads0)
	var landed_ok := spots.size() >= Cfg.PARADROP_COUNT - 2
	for sp in spots:
		if g.blocked(sp, 4.0) or sp.distance_to(dz) > Cfg.PARADROP_SPREAD + 5.0:
			landed_ok = false
	check("titik mendarat dekat titik terjun & tidak di dalam tembok", landed_ok, "%d titik" % spots.size())
	check("1 peti medis ikut dijatuhkan", g.crates.size() >= 1)

	park_enemies = false
	print("== 6. PETI SUPLAI")
	g.crates.clear()
	var hurt := g.spawn_ai(1, Vector2(2200, 2000))
	hurt.hp = 20.0
	hurt.max_hp = 100.0
	hurt.grenades[0] = 0
	g.air.spawn_crate(Vector2(2200, 2000), 1, 0)
	g.grid.rebuild(g.units)
	_sim(0.5)
	check("peti memulihkan HP & isi ulang granat", hurt.hp >= 80.0 and hurt.grenades[0] >= 2 and g.crates.is_empty(), "hp=%.0f gr=%d" % [hurt.hp, hurt.grenades[0]])
	var full := g.spawn_ai(1, Vector2(2400, 2000))
	full.hp = full.max_hp
	full.grenades[0] = 3
	g.air.spawn_crate(Vector2(2400, 2000), 1, 1)
	g.grid.rebuild(g.units)
	_sim(0.5)
	check("prajurit yang sudah penuh tidak menghabiskan peti", g.crates.size() == 1)
	var foe := g.spawn_ai(2, Vector2(2400, 2000))
	foe.hp = 10.0
	foe.max_hp = 100.0
	g.grid.rebuild(g.units)
	_sim(0.5)
	check("musuh tidak bisa mengambil peti tim lain", g.crates.size() == 1 and foe.hp < 30.0)
	g.crates[0].t = Cfg.CRATE_LIFE + 1.0
	_sim(0.2)
	check("peti hilang setelah umurnya habis", g.crates.is_empty())

	print("== 7. MLRS")
	var target := Vector2(3200, 1500)
	_clear_zone(target, 500.0)
	var enemy_hp: Array = []
	var enemies: Array = []
	for i in 8:
		var e := g.spawn_ai(2, target + Vector2.from_angle(i * TAU / 8.0) * 120.0)
		e.hp = 60.0
		e.max_hp = 60.0
		enemies.append(e)
	g.grid.rebuild(g.units)
	g.salvos.clear()                                     # buang salvo acak (Director/AI) agar hanya salvo uji yang diamati
	g.rockets.clear()
	g.air.call_mlrs(target, 1, false)
	var sv: BO.Salvo = g.salvos[0]
	check("peluncur muncul di belakang target (ke arah markas sendiri)", g.salvos.size() == 1 and sv.origin.x < target.x - 500.0)
	_sim(Cfg.MLRS_WARMUP - .5)
	check("belum ada roket sebelum peluncur siap", sv.fired == 0)
	_sim(1.0)
	check("roket meluncur setelah persiapan", sv.fired > 0 and g.rockets.size() > 0)
	_sim(10.0)
	var dead_or_hurt := 0
	for e in enemies:
		if e.hp < 60.0 or e.hp <= 0.0:
			dead_or_hurt += 1
	check("salvo melukai/membunuh musuh di area sasaran", dead_or_hurt >= 3, "%d/8" % dead_or_hurt)
	check("semua roket meledak dan salvo selesai", g.rockets.is_empty() and g.salvos.is_empty(), "roket=%d salvo=%d" % [g.rockets.size(), g.salvos.size()])
	var friend := g.spawn_ai(1, target)
	friend.hp = 100.0
	friend.max_hp = 100.0
	g.grid.rebuild(g.units)
	for k in 12:                                        # ledakan roket langsung di atas prajurit sendiri: harus tidak terluka (deterministik)
		g.combat.explode(friend.pos, Cfg.MLRS_ROCKET_RADIUS, Cfg.MLRS_ROCKET_DMG, 1, false)
	check("roket MLRS tidak melukai tim sendiri", friend.hp >= 100.0, "hp=%.0f" % friend.hp)

	print("== 8. ITEM RADIO BARU DI DIVISI & PEMAKAIAN PEMAIN")
	check("SUPPORT & ELITE punya MLRS, TERJUN, SUPLAI", Cfg.CLASS_ITEMS[Cfg.Cls.SUPPORT].has(Cfg.Item.MLRS) and Cfg.CLASS_ITEMS[Cfg.Cls.ELITE].has(Cfg.Item.PARADROP)
		and Cfg.CLASS_ITEMS[Cfg.Cls.SUPPORT].has(Cfg.Item.DROP_SUPPLY))
	park_enemies = false
	g.cheats["unl"] = true                              # buka kunci Elite untuk tes
	g.pick_class(Cfg.Cls.ELITE)
	await _frames(2)
	p = g.player
	p.pos = Vector2(1500, 1500)
	p.radio_cd = 0.0
	g.support.use_item(p, Cfg.Item.MLRS, Vector2(2200, 1500), Vector2.RIGHT)
	check("pemain memanggil MLRS", g.salvos.size() >= 1 and p.radio_cd > 0.0)
	var sv0 := g.salvos.size()
	g.support.use_item(p, Cfg.Item.MLRS, Vector2(2200, 1500), Vector2.RIGHT)
	check("tidak bisa memanggil lagi saat cooldown", g.salvos.size() == sv0)
	p.radio_cd = 0.0
	g.support.use_item(p, Cfg.Item.PARADROP, Vector2(2000, 1500), Vector2.RIGHT)
	check("pemain memanggil C-17", g.airlifts.size() >= 1)
	p.radio_cd = 0.0
	var cr0 := g.crates.size()
	g.support.use_item(p, Cfg.Item.DROP_SUPPLY, Vector2(1700, 1500), Vector2.RIGHT)
	_sim(3.6)
	check("DROP: SUPLAI menurunkan 2 peti", g.crates.size() >= cr0 + 2)
	g.pick_class(Cfg.Cls.ASSAULT)
	await _frames(2)
	p = g.player
	var mx := p.max_hp
	g.streak = Cfg.STREAK_REWARD_EVERY - 1
	p.radio_cd = 50.0
	var bp0 := p.build_points
	g.register_kill(victim)
	check("kill streak ke-5 mereset radio & memberi poin bangun", p.radio_cd == 0.0 and p.build_points > bp0)

	print("== 9. PEMAIN MENYETIR KENDARAAN BARU")
	for k in [Cfg.Veh.APC, Cfg.Veh.SPG, Cfg.Veh.MEDEVAC]:
		var nv: Vehicle = null
		for v in g.vehicles:
			if v.team == 1 and v.kind == k:
				nv = v
		nv.dead = false
		nv.hp = nv.max_hp
		if nv.driver != null:
			g.vehicle_sys.vacate(nv.driver)
		nv.pos = _free_spot(nv.radius())
		nv.heading = 0.0
		nv.aim = 0.0
		nv.speed = 0.0
		nv.skill_cd = 0.0
		p = g.player
		p.hp = p.max_hp
		p.pos = nv.pos + Vector2(-30, 0)
		g.player_ctl.action(1)
		check("pemain naik " + str(Cfg.VEH_NAMES[k][0]), p.mount == nv and nv.driver == p)
		var x0 := nv.pos.x
		for i in 45:
			g.vehicle_sys.drive(nv, Vector2.RIGHT * .9, Vector2.RIGHT, 1.0 / 30.0)
		g.player_ctl.action(0)                               # ganti senjata (tidak boleh crash; MEDEVAC tidak punya senjata kedua)
		for i in 10:
			g.vehicle_sys.drive(nv, Vector2.ZERO, Vector2.RIGHT, 1.0 / 30.0)
		g.player_ctl.action(6)                               # skill kendaraan
		check("kendaraan bergerak & skill dapat dipakai", nv.pos.x > x0 + 15.0 and nv.skill_cd > 0.0, "gerak=%.0f px" % (nv.pos.x - x0))
		_sim(.3)
		g.player_ctl.action(1)
		check("pemain turun dari kendaraan", p.mount == null)

	print("")
	print("HASIL: " + ("SEMUA LULUS (0 gagal)" if fails == 0 else str(fails) + " GAGAL"))
	quit(0 if fails == 0 else 1)
