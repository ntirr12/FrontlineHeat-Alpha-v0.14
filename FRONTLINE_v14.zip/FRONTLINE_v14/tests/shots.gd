extends SceneTree
## Tangkapan layar otomatis (butuh tampilan virtual: xvfb-run). Hasil di /tmp/shots/.
## xvfb-run -a -s "-screen 0 1280x720x24" godot --rendering-driver opengl3 --path . --resolution 1280x720 --script tests/shots.gd
func _shot(name: String) -> void:
	root.get_texture().get_image().save_png("/tmp/shots/%s.png" % name)

func _frames(n: int) -> void:
	for i in n:
		await process_frame

func _initialize() -> void:
	DirAccess.make_dir_recursive_absolute("/tmp/shots")
	var g: Game = load("res://main.tscn").instantiate()
	root.add_child(g)
	await _frames(30)
	_shot("01_menu")
	g.screen = "setup"
	await _frames(5)
	_shot("02_setup")
	g.screen = "set"
	g.settings_tab = 1
	await _frames(5)
	_shot("03_settings_kontrol")
	g.screen = "main"
	g.prefs.ai_count = 2
	g.prefs.quality = 1
	g.start_match()
	await _frames(5)
	_shot("04_class_select")
	g.pick_class(0)
	var args := OS.get_cmdline_user_args()
	var secs := int(args[0]) if args.size() > 0 else 25
	await _frames(secs * 30)
	_shot("05_battle")
	# kemajuan lagi, kamera dekat pusat aksi
	await _frames(30 * 20)
	_shot("06_battle_later")
	g.set_pause(true)
	await _frames(5)
	_shot("07_pause")
	g.set_pause(false)
	print("fps=", Engine.get_frames_per_second(), " AI=", g.ai_alive, " peluru=", g.combat.bullets.size())
	quit()
