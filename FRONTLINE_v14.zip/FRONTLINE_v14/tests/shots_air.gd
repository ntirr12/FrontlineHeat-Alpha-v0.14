extends SceneTree
## PEMENTASAN VISUAL v14: kendaraan (semua 8 jenis x 2 tim, di samping prajurit untuk membandingkan ukuran),
## serta C-17 + penerjun, salvo MLRS (peluncur + roket di udara), peti suplai & aura MEDEVAC.
##   xvfb-run -a -s "-screen 0 1280x720x24" godot --rendering-driver opengl3 --path . --resolution 1280x720 \
##       --script tests/shots_air.gd -- <biome 0 hutan | 1 gurun | 2 salju> [kualitas]
## Hasil: /tmp/shots_air/b<biome>_*.png

var g: Game


func _shot(name: String) -> void:
	root.get_texture().get_image().save_png("/tmp/shots_air/%s.png" % name)


func _frames(n: int) -> void:
	for i in n:
		await process_frame


## Jalankan sim sekian detik lalu biarkan 2 frame tergambar.
func _run(secs: float) -> void:
	var t := 0.0
	while t < secs:
		g.time += 1.0 / 30.0
		g.frame += 1
		g.sim(1.0 / 30.0)
		t += 1.0 / 30.0
	await _frames(2)


func _initialize() -> void:
	DirAccess.make_dir_recursive_absolute("/tmp/shots_air")
	var args := OS.get_cmdline_user_args()
	var biome := int(args[0]) if args.size() > 0 else 0
	g = load("res://main.tscn").instantiate()
	root.add_child(g)
	await _frames(20)
	g.prefs.ai_count = 0
	g.prefs.quality = int(args[1]) if args.size() > 1 else 1
	g.prefs.biome = biome + 1
	g.start_match()
	await _frames(4)
	g.pick_class(0)
	await _frames(10)
	var tag := "b%d" % biome
	(g.hud.get_parent() as CanvasLayer).visible = false
	g.cheats["god"] = true
	g.dev = true

	# ---- adegan 1: barisan kendaraan + prajurit (perbandingan ukuran)
	g.paused = true
	var C: Vector2 = g.player.pos + Vector2(520, -40)
	g.units.clear()
	g.units.append(g.player)
	g.player.pos = C + Vector2(-9999, 0)
	g.vehicles.clear()
	g.turrets.clear()
	g.structs.clear()
	for cls in 5:
		for team in [1, 2]:
			var u := Unit.create(cls, team, true, C + Vector2(cls * 70 - 280, -240 if team == 1 else -170))
			u.angle = 0.0 if team == 1 else PI
			g.units.append(u)
	var kinds := [Cfg.Veh.HUMVEE_MG, Cfg.Veh.HUMVEE_AT, Cfg.Veh.APC, Cfg.Veh.MEDEVAC, Cfg.Veh.TANK, Cfg.Veh.BRADLEY, Cfg.Veh.SPG]
	var xs := [-380.0, -240.0, -100.0, 60.0, 250.0, 430.0, 640.0]
	for i in kinds.size():
		for team in [1, 2]:
			var v := Vehicle.create(kinds[i], C + Vector2(xs[i], -20 if team == 1 else 120), team, 0.0 if team == 1 else PI)
			v.heading = -PI / 2.0 if team == 1 else PI / 2.0
			v.aim = v.heading
			g.vehicles.append(v)
	g.cam = C + Vector2(120, 0)
	g.zoom = .72
	await _frames(6)
	_shot(tag + "_1_kendaraan")

	# ---- adegan 2: kendaraan bergerak (debu roda/rantai, boost, MEDEVAC aura)
	g.vehicles.clear()
	g.units.clear()
	g.units.append(g.player)
	var med := Vehicle.create(Cfg.Veh.MEDEVAC, C + Vector2(-150, 60), 1, 0.0)
	med.driver = Unit.create(Cfg.Cls.ASSAULT, 1, true, med.pos)
	med.driver.mount = med
	g.vehicles.append(med)
	g.units.append(med.driver)
	for i in 5:
		var pt := Unit.create(i % 4, 1, true, C + Vector2(-150, 60) + Vector2.from_angle(i * 1.3) * 100.0)
		pt.hp = pt.max_hp * .4
		g.units.append(pt)
	var tk := Vehicle.create(Cfg.Veh.TANK, C + Vector2(150, 140), 1, 0.0)
	tk.driver = Unit.create(Cfg.Cls.ASSAULT, 1, true, tk.pos)
	tk.driver.mount = tk
	g.vehicles.append(tk)
	g.units.append(tk.driver)
	var hv := Vehicle.create(Cfg.Veh.HUMVEE_MG, C + Vector2(-100, -130), 1, 0.0)
	hv.driver = Unit.create(Cfg.Cls.ASSAULT, 1, true, hv.pos)
	hv.driver.mount = hv
	g.vehicles.append(hv)
	g.units.append(hv.driver)
	g.vehicle_sys.vehicle_skill(hv)
	g.cam = C
	g.zoom = .8
	g.paused = false
	for k in 40:
		g.time += 1.0 / 30.0
		g.frame += 1
		g.vehicle_sys.drive(tk, Vector2.RIGHT, Vector2.ZERO, 1.0 / 30.0)
		g.vehicle_sys.drive(hv, Vector2.RIGHT, Vector2.ZERO, 1.0 / 30.0)
		hv.skill_cd = 5.0 if hv.boost_t <= 0.0 else hv.skill_cd
		g.sim(1.0 / 30.0)
		for u in g.units:
			if u.team == 2:
				u.pos = Vector2(100, 100)
		if k % 10 == 0:
			g.vehicle_sys.vehicle_skill(hv) if hv.skill_cd <= 0.0 else null
	await _frames(2)
	_shot(tag + "_2_gerak_dan_medevac")
	g.vehicles.clear()

	# ---- adegan 3: C-17 + penerjun
	g.paused = false
	var dz: Vector2 = C
	g.cam = dz
	g.zoom = .62
	g.air.call_airlift(dz, 1, false)
	await _run(2.9)
	_shot(tag + "_3_c17")
	await _run(1.6)
	_shot(tag + "_4_terjun")
	await _run(1.4)
	_shot(tag + "_5_melayang")

	# ---- adegan 4: MLRS
	g.air.call_mlrs(dz + Vector2(100, 0), 1, false)
	await _run(2.1)
	g.cam = dz + Vector2(-300, 0)
	_shot(tag + "_6_peluncur")
	await _run(1.4)
	g.cam = dz
	_shot(tag + "_7_roket_udara")
	await _run(1.2)
	_shot(tag + "_8_hantaman")
	await _run(2.0)
	_shot(tag + "_9_hantaman_lanjut")
	quit()
